const fs = require('fs-extra');
const path = require('path');
const logger = require('../utils/logger');
const { CryndelFault, FaultCodes } = require('../utils/errors');

function secretKey() {
  try {
    const { safeStorage } = require('electron');
    if (safeStorage && safeStorage.isEncryptionAvailable && safeStorage.isEncryptionAvailable()) {
      return { kind: 'safe' };
    }
  } catch (_) { /* */ }
  return { kind: 'plain' };
}

function lockPayload(text) {
  const mode = secretKey();
  if (mode.kind === 'safe') {
    try {
      const { safeStorage } = require('electron');
      const buf = safeStorage.encryptString(text);
      return JSON.stringify({ v: 2, enc: buf.toString('base64') });
    } catch (_) { /* */ }
  }
  return text;
}

function unlockPayload(raw) {
  const s = String(raw || '').trim();
  if (!s) return s;
  try {
    const doc = JSON.parse(s);
    if (doc && doc.v === 2 && doc.enc) {
      const { safeStorage } = require('electron');
      return safeStorage.decryptString(Buffer.from(doc.enc, 'base64'));
    }
  } catch (_) { /* */ }
  return s;
}

class AtomJsonVault {
  constructor() {
    this.locks = new Map();
  }

  async withLock(file, fn) {
    let release;
    const done = new Promise((ok) => { release = ok; });
    const prev = this.locks.get(file) || Promise.resolve();
    this.locks.set(file, prev.then(() => done, () => done));
    try {
      await prev;
      return await fn();
    } finally {
      release();
    }
  }

  async read(file, fallback) {
    try {
      const exists = await fs.pathExists(file);
      if (!exists) {
        if (fallback !== undefined) {
          await this.write(file, fallback);
          return JSON.parse(JSON.stringify(fallback));
        }
        return null;
      }
      const raw = unlockPayload(await fs.readFile(file, 'utf8'));
      if (!raw.trim()) {
        return fallback !== undefined ? JSON.parse(JSON.stringify(fallback)) : null;
      }
      return JSON.parse(raw);
    } catch (err) {
      logger.error('json-db read failed', { file, message: err.message });
      if (fallback !== undefined) return JSON.parse(JSON.stringify(fallback));
      throw new CryndelFault(FaultCodes.STORAGE, `Cannot read ${file}`);
    }
  }

  async write(file, data) {
    return this.withLock(file, async () => {
      await fs.ensureDir(path.dirname(file));
      const tmp = `${file}.${process.pid}.${Date.now()}.tmp`;
      const payload = lockPayload(JSON.stringify(data, null, 2));
      await fs.writeFile(tmp, payload, 'utf8');
      await fs.move(tmp, file, { overwrite: true });
      return data;
    });
  }

  async patch(file, mutator, fallback) {
    return this.withLock(file, async () => {
      let current;
      try {
        const exists = await fs.pathExists(file);
        if (!exists) {
          current = fallback !== undefined ? JSON.parse(JSON.stringify(fallback)) : {};
        } else {
          const raw = unlockPayload(await fs.readFile(file, 'utf8'));
          current = raw.trim() ? JSON.parse(raw) : (fallback !== undefined ? JSON.parse(JSON.stringify(fallback)) : {});
        }
      } catch (_) {
        current = fallback !== undefined ? JSON.parse(JSON.stringify(fallback)) : {};
      }
      const next = await mutator(current);
      const result = next === undefined ? current : next;
      await fs.ensureDir(path.dirname(file));
      const tmp = `${file}.${process.pid}.${Date.now()}.tmp`;
      await fs.writeFile(tmp, lockPayload(JSON.stringify(result, null, 2)), 'utf8');
      await fs.move(tmp, file, { overwrite: true });
      return result;
    });
  }
}

module.exports = new AtomJsonVault();
