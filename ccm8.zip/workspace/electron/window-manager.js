const { BrowserWindow, screen } = require('electron');
const path = require('path');
const logger = require('./utils/logger');

const PRESETS = {
  compact: { width: 420, height: 747, minWidth: 320, minHeight: 520 },
  default: { width: 980, height: 720, minWidth: 420, minHeight: 520 },
  wide: { width: 1280, height: 800, minWidth: 700, minHeight: 520 }
};

class PaneSmith {
  constructor() {
    this.win = null;
    this.creating = false;
    this.aux = new Set();
  }

  create(size = {}) {
    this.creating = true;
    try {
      const area = screen && typeof screen.getPrimaryDisplay === 'function'
        ? screen.getPrimaryDisplay().workAreaSize
        : { width: 1600, height: 1000 };
      const minWidth = Math.min(320, area.width);
      const minHeight = Math.min(460, area.height);
      const width = Math.max(minWidth, Math.min(area.width, Number(size.width) || 980));
      const height = Math.max(minHeight, Math.min(area.height, Number(size.height) || 720));
      this.win = new BrowserWindow({
        width,
        height,
        minWidth: Math.max(320, Number(size.minWidth) || 420),
        minHeight: Math.max(460, Number(size.minHeight) || 520),
        center: true,
        backgroundColor: '#0b1017',
        show: false,
        autoHideMenuBar: true,
        frame: false,
        titleBarStyle: 'hidden',
        title: 'CrynChat',
        icon: path.join(__dirname, '..', 'assets', 'icon.ico'),
        webPreferences: {
          preload: path.join(__dirname, 'preload.js'),
          contextIsolation: true,
          nodeIntegration: false,
          sandbox: true,
          webviewTag: false,
          webSecurity: true,
          partition: 'persist:crynchat'
        }
      });
    } finally {
      this.creating = false;
    }
    this.win.webContents.on('did-fail-load', (_event, errorCode, errorDescription, validatedURL, isMainFrame) => {
      if (isMainFrame) {
        logger.error('renderer failed to load', {
          errorCode,
          errorDescription,
          url: validatedURL
        });
      }
    });
    this.win.webContents.on('render-process-gone', (_event, details) => {
      logger.error('renderer process exited', details);
    });
    this.win.webContents.on('console-message', (_event, level, message, line, sourceId) => {
      if (level >= 3) {
        logger.error('renderer console error', { message, line, sourceId });
      }
    });
    this.win.loadFile(path.join(__dirname, '..', 'renderer', 'index.html')).catch((err) => {
      logger.error('renderer file load failed', { message: err.message, stack: err.stack });
    });
    this.win.once('ready-to-show', () => this.win.show());

    for (const ev of ['maximize', 'unmaximize', 'minimize', 'restore', 'show', 'hide', 'enter-full-screen', 'leave-full-screen']) {
      this.win.on(ev, () => this.sendState());
    }

    this.win.on('closed', () => { this.win = null; });
    this.win.webContents.setWindowOpenHandler(({ url }) => {
      if (/^https?:\/\//i.test(url)) {
        try { require('electron').shell.openExternal(url); } catch (_) { /* */ }
      }
      return { action: 'deny' };
    });
    if (process.argv.includes('--dev')) this.win.webContents.openDevTools({ mode: 'detach' });
    return this.win;
  }

  sendState() {
    if (!this.win || this.win.isDestroyed()) return;
    try {
      this.win.webContents.send('window:state', this.state());
    } catch (_) { /* renderer gone */ }
  }

  state() {
    if (!this.win || this.win.isDestroyed()) {
      return { maximized: false, minimized: false, visible: false, fullScreen: false, bounds: null };
    }
    const b = this.win.getBounds();
    return {
      maximized: this.win.isMaximized(),
      minimized: this.win.isMinimized(),
      fullScreen: this.win.isFullScreen(),
      visible: this.win.isVisible(),
      bounds: { width: b.width, height: b.height, x: b.x, y: b.y }
    };
  }

  applyPreset(name) {
    const p = PRESETS[name] || PRESETS.default;
    return this.setSize(p.width, p.height, p);
  }

  setSize(width, height, extra = {}) {
    if (!this.win || this.win.isDestroyed()) return { ok: false };
    const area = screen.getDisplayMatching(this.win.getBounds()).workArea;
    const minWidth = Math.min(Number(extra.minWidth) || 420, area.width);
    const minHeight = Math.min(Number(extra.minHeight) || 520, area.height);
    const nextWidth = Math.round(Math.max(minWidth, Math.min(area.width, Number(width) || 980)));
    const nextHeight = Math.round(Math.max(minHeight, Math.min(area.height, Number(height) || 720)));
    if (this.win.isMaximized()) this.win.unmaximize();
    if (this.win.isFullScreen()) this.win.setFullScreen(false);
    try { this.win.setMinimumSize(minWidth, minHeight); } catch (_) { /* */ }
    this.win.setSize(nextWidth, nextHeight, true);
    this.win.center();
    this.sendState();
    return { ok: true, width: nextWidth, height: nextHeight };
  }

  setZoom(factor) {
    if (!this.win || this.win.isDestroyed()) return { ok: false, zoom: 1 };
    const f = Math.max(0.5, Math.min(2, Number(factor) || 1));
    try { this.win.webContents.setZoomFactor(f); } catch (_) { /* */ }
    try { this.win.webContents.setVisualZoomLevelLimits(1, 1); } catch (_) { /* */ }
    return { ok: true, zoom: f };
  }

  minimize() {
    if (!this.win || this.win.isDestroyed()) return null;
    this.win.minimize();
    return this.state();
  }

  toggleMaximize() {
    if (!this.win || this.win.isDestroyed()) return null;
    if (this.win.isMaximized()) this.win.unmaximize();
    else this.win.maximize();
    this.sendState();
    return this.state();
  }

  toggleFullScreen() {
    if (!this.win || this.win.isDestroyed()) return null;
    this.win.setFullScreen(!this.win.isFullScreen());
    this.sendState();
    return this.state();
  }

  close() {
    if (!this.win || this.win.isDestroyed()) return null;
    this.win.close();
    return { ok: true };
  }

  show() {
    if (!this.win || this.win.isDestroyed()) return null;
    if (this.win.isMinimized()) this.win.restore();
    if (!this.win.isVisible()) this.win.show();
    try { this.win.moveTop(); } catch (_) { /* */ }
    this.win.focus();
    this.sendState();
    return this.win;
  }
}

PaneSmith.PRESETS = PRESETS;
module.exports = PaneSmith;
