const fs = require('fs-extra');
const path = require('path');
const crypto = require('crypto');
const axios = require('axios');
const CryndelPathVault = require('../utils/paths');
const vault = require('../storage/json-db');

const API = 'https://my.cryndel.ru/acryn/index.php';
const UA = { 'User-Agent': 'CryndelLauncher/1.0.0 (contact@cryndel.ru)' };

function keyFrom(secret) {
  return crypto.createHash('sha256').update(String(secret || 'crynchat')).digest();
}

function enc(buf, secret) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', keyFrom(secret), iv);
  const out = Buffer.concat([cipher.update(buf), cipher.final()]);
  const tag = cipher.getAuthTag();
  return Buffer.concat([iv, tag, out]).toString('base64');
}

function dec(b64, secret) {
  const raw = Buffer.from(String(b64 || ''), 'base64');
  const iv = raw.subarray(0, 12);
  const tag = raw.subarray(12, 28);
  const data = raw.subarray(28);
  const decipher = crypto.createDecipheriv('aes-256-gcm', keyFrom(secret), iv);
  decipher.setAuthTag(tag);
  return Buffer.concat([decipher.update(data), decipher.final()]);
}

class CrynChat {
  dir() {
    return path.join(CryndelPathVault.userRoot(), 'crynchat');
  }

  sessionFile() {
    return path.join(this.dir(), 'session.json');
  }

  cacheFile(hash) {
    return path.join(this.layout().messengers, `${hash}.bin`);
  }

  prefsFile() {
    return path.join(this.dir(), 'prefs.json');
  }

  draftsFile() {
    return path.join(this.dir(), 'drafts.json');
  }

  mediaDir() {
    return path.join(this.dir(), 'crynchat', 'media');
  }

  stickersCacheFile() {
    return path.join(this.dir(), 'stickers.json');
  }

  accountsFile() {
    return path.join(this.dir(), 'accounts.json');
  }

  scrollFile() {
    return path.join(this.dir(), 'scroll.json');
  }

  hashesFile() {
    return path.join(this.layout().crynsys, 'Sha.json');
  }

  previewFile() {
    return path.join(this.dir(), 'previews.json');
  }

  lastThreadFile() {
    return path.join(this.dir(), 'last-thread.json');
  }

  chatsCacheFile() {
    return path.join(this.dir(), 'chats.json');
  }

  dmsCacheFile() {
    return path.join(this.dir(), 'dms.json');
  }

  mediaIndexFile() {
    return path.join(this.dir(), 'media-index.json');
  }

  usersCacheFile() {
    return path.join(this.dir(), 'users.json');
  }

  profilesCacheFile() {
    return path.join(this.dir(), 'profiles.json');
  }

  uiCacheFile() {
    return path.join(this.dir(), 'ui.json');
  }

  layout() {
    const root = this.dir();
    return {
      ls: path.join(root, 'ls'),
      usersaves: path.join(root, 'usersaves'),
      kanal: path.join(root, 'kanal'),
      profile: path.join(root, 'profile'),
      oqonek: path.join(root, 'oqonek'),
      empji: path.join(root, 'empji'),
      crynsys: path.join(root, 'crynsys'),
      bots: path.join(root, 'bots'),
      crynchat: path.join(root, 'crynchat'),
      users: path.join(root, 'users'),
      media: path.join(root, 'crynchat', 'media'),
      muzick: path.join(root, 'crynchat', 'muzick'),
      messengers: path.join(root, 'crynchat', 'messengers')
    };
  }

  async ensure() {
    const L = this.layout();
    for (const d of Object.values(L)) await fs.ensureDir(d);
    await fs.ensureDir(path.join(L.crynchat, 'data'));
    await fs.ensureDir(path.join(L.crynsys, 'pool'));
    await fs.ensureDir(path.join(this.dir(), 'threads'));
    await fs.ensureDir(this.mediaDir());
    await fs.ensureDir(path.join(this.dir(), 'avatars'));
    await fs.ensureDir(path.join(this.dir(), 'banners'));
  }

  async session() {
    await this.ensure();
    return vault.read(this.sessionFile(), {
      token: '', nick: '', email: '', verified: false, avatar: '', bio: ''
    });
  }

  async setSession(s) {
    await this.ensure();
    const prev = await this.session();
    return vault.write(this.sessionFile(), { ...prev, ...s });
  }

  unwrap(data) {
    if (!data || typeof data !== 'object') return { ok: false, code: 'E_FAIL' };
    if (data.error && typeof data.error === 'object' && data.ok === false) {
      return {
        ok: false,
        code: data.error.code || 'E_FAIL',
        error: data.error.message || data.error.code || 'E_FAIL',
        ...data
      };
    }
    if (data.ok === true && data.data && typeof data.data === 'object') {
      const out = { ok: true, ...data.data };
      if (data.data.user && typeof data.data.user === 'object') Object.assign(out, data.data.user);
      if (data.data.token) out.token = data.data.token;
      if (data.data.access_token && !out.token) out.token = data.data.access_token;
      return out;
    }
    return data;
  }

  mergeSession(data) {
    if (!data || data.ok === false) return data;
    const src = (data.user && typeof data.user === 'object') ? { ...data, ...data.user } : data;
    const patch = {};
    for (const k of ['token', 'refresh_token', 'nick', 'email', 'verified', 'avatar', 'cover', 'banner', 'bio', 'telegram', 'discord', 'youtube', 'tiktok', 'status', 'muted', 'role', 'admin', 'bubbleStyle', 'listStyle', 'nameColor', 'pirikas', 'cosmetics', 'channelId', 'rights', 'avatarHat', 'listHat', 'profileHat', 'id', 'limits', 'settings', 'tfa']) {
      if (src[k] !== undefined) patch[k] = src[k];
    }
    if (src.access_token && !patch.token) patch.token = src.access_token;
    if (data.needVerify === false) patch.verified = true;
    if (data.needVerify === true) patch.verified = false;
    if (src.verified === false) patch.verified = false;
    if (src.verified === true) patch.verified = true;
    return patch;
  }

  v1Route(action, payload) {
    const p = payload || {};
    const thread = encodeURIComponent(String(p.thread || 'global'));
    const map = {
      register: ['POST', 'auth/register'],
      login: ['POST', 'auth/login'],
      refresh: ['POST', 'auth/refresh'],
      logout: ['POST', 'auth/logout'],
      verify: ['POST', 'auth/verify'],
      resendVerify: ['POST', 'auth/resend'],
      confirmDevice: ['POST', 'auth/confirm-device'],
      setPass: ['POST', 'auth/password'],
      tfaSetup: ['POST', 'auth/tfa/setup'],
      tfaEnable: ['POST', 'auth/tfa/enable'],
      tfaDisable: ['POST', 'auth/tfa/disable'],
      sessions: ['GET', 'auth/sessions'],
      me: ['GET', 'users/me'],
      saveProfile: ['PATCH', 'users/me'],
      searchUsers: ['GET', 'users/search'],
      privacy: p.whoWrite !== undefined || p.allowFrom !== undefined || p.denyFrom !== undefined ? ['POST', 'users/me/privacy'] : ['GET', 'users/me/privacy'],
      block: ['POST', 'users/me/block'],
      user: ['GET', 'users/' + encodeURIComponent(String(p.nick || ''))],
      chats: ['GET', 'threads'],
      createGroup: ['POST', 'threads'],
      messages: ['GET', 'threads/' + thread + '/messages'],
      send: ['POST', 'threads/' + thread + '/messages'],
      typing: ['POST', 'threads/' + thread + '/typing'],
      markRead: ['POST', 'threads/' + thread + '/read'],
      pinChat: ['POST', 'threads/' + thread + '/pin'],
      archiveChat: ['POST', 'threads/' + thread + '/archive'],
      muteChat: ['POST', 'threads/' + thread + '/mute'],
      edit: ['PATCH', 'messages/' + encodeURIComponent(String(p.id || ''))],
      delete: ['POST', 'messages/' + encodeURIComponent(String(p.id || '')) + '/delete'],
      forward: ['POST', 'messages/' + encodeURIComponent(String(p.id || '')) + '/forward'],
      saveMessage: ['POST', 'messages/' + encodeURIComponent(String(p.id || '')) + '/save'],
      report: ['POST', 'messages/' + encodeURIComponent(String(p.id || '')) + '/report'],
      react: ['POST', 'messages/' + encodeURIComponent(String(p.id || '')) + '/reactions'],
      search: ['GET', 'messages/search'],
      upload: ['POST', 'media'],
      presence: ['GET', 'presence'],
      wsInfo: ['GET', 'ws'],
      dms: ['GET', 'dms'],
      dmOpen: ['POST', 'dms'],
      folders: ['GET', 'folders'],
      createFolder: ['POST', 'folders'],
      saveFolder: ['POST', 'folders/' + encodeURIComponent(String(p.id || ''))],
      adminUsers: ['GET', 'admin/users'],
      ban: ['POST', 'admin/users/' + encodeURIComponent(String(p.nick || '')) + '/ban'],
      unban: ['POST', 'admin/users/' + encodeURIComponent(String(p.nick || '')) + '/unban'],
      modMute: ['POST', 'admin/users/' + encodeURIComponent(String(p.nick || '')) + '/mute'],
      adminSettings: ['POST', 'admin/settings'],
      modlog: ['GET', 'admin/modlog'],
      adminStats: ['GET', 'admin/stats']
    };
    return map[action] || null;
  }

  async call(action, payload = {}) {
    const sess = await this.session();
    const route = this.v1Route(action, payload);
    const headers = { ...UA, 'Content-Type': 'application/json', 'X-Cryn-Client': '1' };
    if (sess.token) headers.Authorization = 'Bearer ' + sess.token;
    try {
      let res;
      if (route) {
        const [method, path] = route;
        const url = API + '?v=1&path=' + encodeURIComponent(path);
        const cfg = {
          timeout: 45000,
          headers,
          maxContentLength: 12 * 1024 * 1024,
          maxBodyLength: 12 * 1024 * 1024,
          validateStatus: () => true
        };
        if (method === 'GET') {
          res = await axios.get(url, { ...cfg, params: { ...payload, token: sess.token || '' } });
        } else {
          res = await axios({ method: method.toLowerCase(), url, data: { token: sess.token || '', ...payload }, ...cfg });
        }
      } else {
        res = await axios.post(API, { action, token: sess.token || '', ...payload }, {
          timeout: 45000,
          headers,
          maxContentLength: 12 * 1024 * 1024,
          maxBodyLength: 12 * 1024 * 1024,
          validateStatus: () => true
        });
      }
      const data = this.unwrap(res.data);
      if (data && typeof data === 'object') return data;
      return { ok: false, code: 'E_FAIL' };
    } catch (err) {
      const data = err && err.response && err.response.data;
      if (data && typeof data === 'object') return this.unwrap(data);
      return { ok: false, code: 'E_NET' };
    }
  }

  deviceId() {
    const os = require('os');
    let user = '';
    try { user = os.userInfo().username || ''; } catch (_) { user = ''; }
    return crypto.createHash('sha256').update(String(os.hostname()) + '|' + String(user)).digest('hex').slice(0, 32);
  }

  async register(nick, email, password) {
    const created = await this.createdAccounts();
    if ((created.count || 0) >= 5) {
      return { ok: false, error: 'На этом устройстве уже создано 5 аккаунтов' };
    }
    const data = await this.call('register', { nick, email, password, device: this.deviceId() });
    if (data && data.ok && data.token) {
      await this.setSession({
        token: data.token,
        refresh_token: data.refresh_token || '',
        nick: data.nick,
        email,
        verified: Boolean(data.verified),
        verifyCode: data.code || '',
        role: data.role || 'user',
        admin: Boolean(data.admin),
        limits: data.limits || null
      });
      await this.noteCreated(email);
      await this.saveAccount();
    }
    return data;
  }

  async login(email, password) {
    const data = await this.call('login', { email, password, device: this.deviceId() });
    if (data && data.ok && data.token) {
      await this.setSession({ token: data.token, refresh_token: data.refresh_token || '', ...this.mergeSession(data), email });
    }
    return data;
  }

  async logout() {
    try { await this.call('logout'); } catch (_) { /* */ }
    await this.setSession({
      token: '', refresh_token: '', nick: '', email: '', verified: false, avatar: '', bio: '', verifyCode: ''
    });
    return { ok: true };
  }

  async refresh() {
    const sess = await this.session();
    if (!sess.refresh_token) return { ok: false, code: 'E_AUTH' };
    const data = await this.call('refresh', { refresh_token: sess.refresh_token });
    if (data && data.ok && data.token) {
      await this.setSession({ token: data.token, refresh_token: data.refresh_token || sess.refresh_token, ...this.mergeSession(data) });
    }
    return data;
  }

  async me() {
    const sess = await this.session();
    if (!sess.token) return { ok: false, guest: true };
    try {
      const data = await this.call('me');
      if (data && data.ok) {
        await this.setSession(this.mergeSession(data));
        if (!data.verified && sess.verifyCode) data.code = sess.verifyCode;
        if (data.verified === false) data.needVerify = true;
      }
      return data;
    } catch (_) {
      return { ok: true, offline: true, ...sess };
    }
  }

  async verify(code) {
    const data = await this.call('verify', { code });
    if (data && data.ok) await this.setSession({ verified: true, verifyCode: '' });
    return data;
  }

  async resendVerify() {
    const data = await this.call('resendVerify');
    if (data && data.ok && data.code) await this.setSession({ verifyCode: data.code });
    return data;
  }

  hashThread(id) {
    return crypto.createHash('sha256').update(String(id || 'global')).digest('hex').slice(0, 24);
  }

  async touchThreadLru(thread) {
    await this.ensure();
    const file = path.join(this.dir(), 'thread-lru.json');
    const doc = await vault.read(file, { ids: [] });
    const id = String(thread || 'global');
    const ids = [id, ...(doc.ids || []).filter((x) => x !== id)].slice(0, 25);
    await vault.write(file, { ids, at: Date.now() });
    const keep = new Set(ids.map((t) => this.hashThread(t)));
    try {
      const dir = this.layout().messengers;
      const names = await fs.readdir(dir);
      for (const n of names) {
        const h = String(n).replace(/\.bin$/, '');
        if (!keep.has(h)) await fs.remove(path.join(dir, n)).catch(() => {});
      }
    } catch (_) { /* */ }
  }

  async cacheMessages(thread, items, { merge } = {}) {
    await this.ensure();
    const sess = await this.session();
    const hash = this.hashThread(thread);
    let next = items || [];
    if (merge) {
      const prev = await this.readCache(thread);
      const map = new Map();
      for (const it of [...prev, ...next]) {
        if (it && it.id) map.set(it.id, it);
      }
      next = [...map.values()].sort((a, b) => String(b.at || '').localeCompare(String(a.at || '')));
      if (next.length > 15000) next = next.slice(0, 15000);
    }
    const payload = JSON.stringify({ at: Date.now(), items: next });
    await fs.writeFile(this.cacheFile(hash), enc(Buffer.from(payload, 'utf8'), sess.token || 'guest'));
    this.touchThreadLru(thread).catch(() => {});
    const urls = [];
    for (const it of next.slice(0, 80)) {
      if (it && it.url) urls.push(it.url);
      if (it && it.avatar) urls.push(it.avatar);
    }
    if (urls.length) this.cacheMediaMany(urls).catch(() => {});
    return next;
  }

  async readCache(thread) {
    const sess = await this.session();
    const hash = this.hashThread(thread);
    const file = this.cacheFile(hash);
    if (!(await fs.pathExists(file))) return [];
    try {
      const json = JSON.parse(dec(await fs.readFile(file, 'utf8'), sess.token || 'guest').toString('utf8'));
      return json.items || [];
    } catch (_) {
      return [];
    }
  }

  async messages({ before, before_seq, limit, thread } = {}) {
    const th = thread || 'global';
    const cached = await this.readCache(th);
    const lim = limit || 40;
    const off = before || 0;
    const seq = before_seq || 0;
    if (!off && !seq && cached.length) {
      this.call('messages', { before: 0, before_seq: 0, limit: lim, thread: th }).then((data) => {
        if (data && data.ok) this.cacheMessages(th, data.items, { merge: true }).catch(() => {});
      }).catch(() => {});
      return { ok: true, cached: true, items: cached.slice(0, lim), done: cached.length <= lim, thread: th, total: cached.length };
    }
    try {
      const data = await this.call('messages', { before: off, before_seq: seq, limit: lim, thread: th });
      if (data && data.ok) await this.cacheMessages(th, data.items, { merge: true });
      return data;
    } catch (err) {
      return { ok: true, offline: true, items: cached.slice(off, off + lim), thread: th, done: off + lim >= cached.length };
    }
  }

  async send(text, extra = {}) {
    const data = await this.call('send', { text, ...extra });
    if (data && data.item && !data.scheduled) {
      await this.cacheMessages(extra.thread || 'global', [data.item], { merge: true });
    }
    return data;
  }

  async react(id, emoji) {
    return this.call('react', { id, emoji });
  }

  async pin(id) {
    return this.call('pin', { id });
  }

  async saveGif(url) {
    return this.call('saveGif', { url });
  }

  async delGif(url) {
    return this.call('delGif', { url });
  }

  async gifs() {
    return this.call('gifs');
  }

  async poll(question, options, extra = {}) {
    return this.call('poll', { question, options, ...extra });
  }

  async vote(id, option) {
    return this.call('vote', { id, option });
  }

  async createPack(name, kind, extra = {}) {
    return this.call('createPack', { name, kind, ...extra });
  }

  async addSticker(packId, url, name) {
    return this.call('addSticker', { packId, url, name });
  }

  async delPack(packId) {
    return this.call('delPack', { packId });
  }

  async profile() {
    const cached = await vault.read(this.profilesCacheFile(), null);
    const refresh = this.call('profile').then(async (data) => {
      if (data && data.ok) {
        await vault.write(this.profilesCacheFile(), { ...data, at: Date.now() });
        await this.setSession(this.mergeSession(data));
        const av = data.avatar || '';
        const bn = data.cover || data.banner || '';
        if (av) this.cacheMedia(av).catch(() => {});
        if (bn) this.cacheMedia(bn).catch(() => {});
      }
      return data;
    }).catch(() => null);
    if (cached && cached.nick) {
      refresh.catch(() => {});
      return { ...cached, cached: true, ok: true };
    }
    const data = await refresh;
    if (data) return data;
    return { ok: true, offline: true, ...(cached || {}) };
  }

  async saveProfile(patch) {
    const data = await this.call('saveProfile', patch || {});
    if (data && data.ok) {
      await this.setSession(this.mergeSession(data));
      await vault.write(this.profilesCacheFile(), { ...data, at: Date.now() });
      const av = data.avatar || patch.avatar || '';
      const bn = data.cover || data.banner || patch.cover || patch.banner || '';
      if (av) this.cacheMedia(av).catch(() => {});
      if (bn) this.cacheMedia(bn).catch(() => {});
    }
    return data;
  }

  async user(nick) {
    const key = String(nick || '').toLowerCase();
    const cached = await vault.read(this.usersCacheFile(), {});
    const hit = cached[key];
    const refresh = this.call('user', { nick }).then(async (data) => {
      if (data && (data.ok || data.user)) {
        const u = data.user || data;
        cached[key] = { ...u, at: Date.now() };
        await vault.write(this.usersCacheFile(), cached);
        const av = u.avatar || '';
        const bn = u.cover || u.banner || '';
        if (av) this.cacheMedia(av).catch(() => {});
        if (bn) this.cacheMedia(bn).catch(() => {});
      }
      return data;
    }).catch(() => null);
    if (hit && hit.nick) {
      refresh.catch(() => {});
      return { ok: true, cached: true, user: hit };
    }
    const data = await refresh;
    if (data) return data;
    return { ok: true, offline: true, user: hit || { nick } };
  }

  async searchUsers(q) {
    return this.call('searchUsers', { q });
  }

  async edit(id, text) {
    return this.call('edit', { id, text });
  }

  async delete(id, forAll) {
    return this.call('delete', { id, forAll: Boolean(forAll) });
  }

  async privacy(patch) {
    const p = patch || {};
    return this.call('privacy', {
      whoWrite: p.whoWrite,
      allowFrom: p.allowFrom || p.allow,
      denyFrom: p.denyFrom || p.deny
    });
  }

  async sessions() {
    return this.call('sessions');
  }

  async revokeSession(id) {
    return this.call('revokeSession', { id });
  }

  async resetPass(nick) {
    return this.call('resetPass', { nick, force: true });
  }

  async setPass(oldPass, nextPass) {
    return this.call('setPass', { old: oldPass, password: nextPass });
  }

  async emojiMap() {
    return this.call('emojiMap');
  }

  async setEmoji(code, url) {
    return this.call('setEmoji', { emoji: code, code, url });
  }

  async shareCard(url) {
    return this.call('shareCard', { url });
  }

  async forward(id, thread) {
    return this.call('forward', { id, thread: thread || 'global' });
  }

  async unread(thread) {
    return this.call('unread', { thread: thread || 'global' });
  }

  async markRead(thread) {
    return this.call('markRead', { thread: thread || 'global' });
  }

  async typing(thread) {
    return this.call('typing', { thread: thread || 'global' });
  }

  async presence(thread) {
    return this.call('presence', { thread: thread || 'global' });
  }

  async dms() {
    await this.ensure();
    const cached = await vault.read(this.dmsCacheFile(), { items: [], at: 0 });
    const refresh = this.call('dms').then(async (data) => {
      if (data && data.ok) {
        await vault.write(this.dmsCacheFile(), { items: data.items || [], at: Date.now() });
        const urls = (data.items || []).flatMap((it) => [it && it.avatar, it && it.cover, it && it.banner].filter(Boolean));
        if (urls.length) this.cacheMediaMany(urls).catch(() => {});
      }
      return data;
    }).catch(() => null);
    if (cached.items && cached.items.length) {
      refresh.catch(() => {});
      return { ok: true, cached: true, items: cached.items };
    }
    const data = await refresh;
    if (data && data.ok) return data;
    return { ok: true, offline: true, items: cached.items || [] };
  }

  async dmOpen(nick) {
    return this.call('dmOpen', { nick });
  }

  async search(q) {
    return this.call('search', { q });
  }

  async block(nick) {
    return this.call('block', { nick });
  }

  async mute(on) {
    const data = await this.call('mute', { on: Boolean(on) });
    if (data && data.ok) await this.setSession({ muted: Boolean(data.muted) });
    return data;
  }

  async report(id) {
    return this.call('report', { id });
  }

  async chats() {
    await this.ensure();
    const cached = await vault.read(this.chatsCacheFile(), { items: [], at: 0 });
    const refresh = this.call('chats').then(async (data) => {
      if (data && data.ok) {
        await vault.write(this.chatsCacheFile(), { items: data.items || [], at: Date.now() });
        const urls = (data.items || []).flatMap((it) => [it && it.avatar, it && it.banner, it && it.cover].filter(Boolean));
        if (urls.length) this.cacheMediaMany(urls).catch(() => {});
      }
      return data;
    }).catch(() => null);
    if (cached.items && cached.items.length) {
      refresh.catch(() => {});
      return { ok: true, cached: true, items: cached.items };
    }
    const data = await refresh;
    if (data && data.ok) return data;
    return { ok: true, offline: true, items: cached.items || [] };
  }

  async adminUsers(q) {
    return this.call('adminUsers', { q: q || '' });
  }

  async adminSettings(patch) {
    return this.call('adminSettings', patch || {});
  }

  async adminChat(id, patch) {
    return this.call('adminChat', { id, ...(patch || {}) });
  }

  async adminUser(nick, patch) {
    return this.call('adminUser', { nick, ...(patch || {}) });
  }

  async ban(nick, hours, reason) {
    return this.call('ban', { nick, hours: hours || 0, reason: reason || '' });
  }

  async unban(nick) {
    return this.call('unban', { nick });
  }

  async modMute(nick, minutes, reason) {
    return this.call('modMute', { nick, minutes: minutes || 30, reason: reason || '' });
  }

  async modUnmute(nick) {
    return this.call('modUnmute', { nick });
  }

  async warn(nick, reason) {
    return this.call('warn', { nick, reason: reason || '' });
  }

  async clearWarns(nick) {
    return this.call('clearWarns', { nick });
  }

  async kick(nick) {
    return this.call('kick', { nick });
  }

  async broadcast(text, thread) {
    return this.call('broadcast', { text, thread: thread || 'global' });
  }

  async purge(nick) {
    return this.call('purge', { nick });
  }

  async modlog() {
    return this.call('modlog');
  }

  async adminStats() {
    return this.call('adminStats');
  }

  async prefs() {
    await this.ensure();
    return vault.read(this.prefsFile(), {
       sound: true, preview: true, compact: false, wallpaper: '', theme: 'day',
       walls: {}, ctxCompact: true, ctxHide: ['select', 'widget', 'report'],
       accent: '#3390ec', textColor: '', bubbleIn: '', bubbleOut: '#3390ec',
       bubbleRadius: 14, bubbleTex: '', font: '', customCss: '',
       hideChats: [], showUnread: true, showMsgCount: true, avaAnim: false,
       reduceMotion: true, uiColor: '', avaRound: 50,
       animPlay: 'viewport', stickStyle: 'classic', stickPerf: true, hoverActions: true,
       shiftActions: true, customEmoji: true, oneLike: true, accFlyout: true
    });
  }

  async setPrefs(patch) {
    const cur = await this.prefs();
    return vault.write(this.prefsFile(), { ...cur, ...(patch || {}) });
  }

  async drafts() {
    await this.ensure();
    return vault.read(this.draftsFile(), {});
  }

  async setDraft(thread, text) {
    const cur = await this.drafts();
    const key = String(thread || 'global');
    if (!text) delete cur[key];
    else cur[key] = String(text).slice(0, 2000);
    return vault.write(this.draftsFile(), cur);
  }

  async upload(kind, name, b64, extra = {}) {
    const buf = Buffer.from(String(b64 || ''), 'base64');
    const sess = await this.session();
    const admin = sess.role === 'admin' || (sess.limits && sess.limits.adminUnlimited);
    const max = admin ? 12 * 1024 * 1024 : ((kind === 'audio' || kind === 'voice') ? 8 * 1024 * 1024 : 3 * 1024 * 1024);
    if (buf.length > max) return { ok: false, code: 'E_FILE_SIZE', error: 'Файл слишком большой' };
    const sha = crypto.createHash('sha256').update(buf).digest('hex');
    extra = { ...extra, hash: sha };
    await this.ensure();
    const hashes = await vault.read(this.hashesFile(), {});
    if (hashes[sha] && extra.skipCache !== true) {
      return { ok: true, url: hashes[sha], cached: true, hash: sha, kind };
    }
    try {
      const byHash = await this.call('upload', { kind, name, hash: sha, dedupe: true, ...extra });
      if (byHash && (byHash.ok || byHash.url) && byHash.url) {
        hashes[sha] = byHash.url;
        await vault.write(this.hashesFile(), hashes);
        return { ...byHash, ok: true, cached: true, hash: sha };
      }
    } catch (_) { /* fall through to full upload */ }
    const data = await this.call('upload', { kind, name, data: b64, hash: sha, ...extra });
    if (data && data.url) {
      hashes[sha] = data.url;
      await vault.write(this.hashesFile(), hashes);
    }
    if (data) data.hash = sha;
    return data;
  }

  async cacheStickers(payload) {
    await this.ensure();
    return vault.write(this.stickersCacheFile(), { at: Date.now(), ...(payload || {}) });
  }

  async readStickersCache() {
    return vault.read(this.stickersCacheFile(), { at: 0, items: [], packs: [] });
  }

  async stickers() {
    const cached = await this.readStickersCache();
    try {
      const data = await this.call('stickers');
      if (data && data.ok) await this.cacheStickers({ items: data.items, packs: cached.packs });
      return data;
    } catch (_) {
      return { ok: true, offline: true, items: cached.items || [] };
    }
  }

  async packs() {
    const cached = await this.readStickersCache();
    try {
      const data = await this.call('packs');
      if (data && data.ok) await this.cacheStickers({ items: cached.items, packs: data.items });
      return data;
    } catch (_) {
      return { ok: true, offline: true, items: cached.packs || [] };
    }
  }

  async saveSticker(url, name, packId) {
    return this.call('saveSticker', { url, name, packId });
  }

  async clearChat(thread) {
    return this.call('clearChat', { thread: thread || 'global' });
  }

  async confirmDevice(email, password, code) {
    const data = await this.call('confirmDevice', { email, password, code, device: this.deviceId() });
    if (data && data.ok && data.token) {
      await this.setSession({ token: data.token, ...this.mergeSession(data), email });
    }
    return data;
  }

  async accounts() {
    await this.ensure();
    return vault.read(this.accountsFile(), { items: [], active: '' });
  }

  async saveAccount() {
    const sess = await this.session();
    if (!sess.token) return this.accounts();
    const doc = await this.accounts();
    const item = { nick: sess.nick, email: sess.email, token: sess.token, avatar: sess.avatar || '', verified: sess.verified };
    const rest = (doc.items || []).filter((a) => a.email !== sess.email);
    rest.unshift(item);
    if (rest.length > 4) return { ok: false, error: 'Максимум 4 сохранённых аккаунта', items: rest.slice(0, 4), active: sess.email };
    return vault.write(this.accountsFile(), { items: rest.slice(0, 4), active: sess.email, created: doc.created || [] });
  }

  async switchAccount(email) {
    const doc = await this.accounts();
    const acc = (doc.items || []).find((a) => a.email === email);
    if (!acc) return { ok: false, error: 'Нет аккаунта' };
    await this.setSession({ token: acc.token, nick: acc.nick, email: acc.email, avatar: acc.avatar, verified: acc.verified });
    await vault.write(this.accountsFile(), { ...doc, active: email });
    return this.me();
  }

  async addAccount(email, password) {
    const doc = await this.accounts();
    const items = doc.items || [];
    if (items.length >= 4 && !items.some((a) => a.email === email)) {
      return { ok: false, error: 'Максимум 4 сохранённых аккаунта' };
    }
    const cur = await this.session();
    if (cur.token) await this.saveAccount();
    const data = await this.login(email, password);
    if (data && data.ok) await this.saveAccount();
    return data;
  }

  async noteCreated(email) {
    const doc = await this.accounts();
    const created = Array.isArray(doc.created) ? doc.created.slice() : [];
    const key = String(email || '').trim().toLowerCase();
    if (key && !created.includes(key)) created.push(key);
    doc.created = created;
    await vault.write(this.accountsFile(), doc);
    return { ok: true, count: created.length, created };
  }

  async createdAccounts() {
    const doc = await this.accounts();
    const created = Array.isArray(doc.created) ? doc.created : [];
    return { ok: true, count: created.length, created };
  }

  async exportData(dest) {
    const AdmZip = require('adm-zip');
    await this.ensure();
    const zip = new AdmZip();
    const root = this.dir();
    const addDir = async (dir, prefix) => {
      const names = await fs.readdir(dir);
      for (const name of names) {
        const p = path.join(dir, name);
        const st = await fs.stat(p);
        if (st.isDirectory()) await addDir(p, prefix + name + '/');
        else zip.addFile(prefix + name, await fs.readFile(p));
      }
    };
    await addDir(root, 'crynchat/');
    zip.writeZip(dest);
    return { ok: true, path: dest };
  }

  async scrollMap() {
    await this.ensure();
    return vault.read(this.scrollFile(), {});
  }

  async setScroll(thread, payload) {
    const cur = await this.scrollMap();
    cur[String(thread || 'global')] = payload || {};
    return vault.write(this.scrollFile(), cur);
  }

  async createBot(name, lang, extra = {}) {
    return this.call('createBot', { name, lang, ...extra });
  }

  async myBots() {
    return this.call('myBots');
  }

  async delBot(id) {
    return this.call('delBot', { id });
  }

  async revokeBot(id) {
    return this.call('revokeBot', { id });
  }

  mediaSrc(filePath) {
    const { pathToFileURL } = require('url');
    return pathToFileURL(filePath).href;
  }

  async cacheMedia(url) {
    if (!url) return { ok: false, src: url || '', path: '' };
    const s = String(url);
    if (s.startsWith('data:') || s.startsWith('file:') || s.startsWith('blob:')) return { ok: true, src: url, path: '', cached: true };
    await this.ensure();
    const key = crypto.createHash('sha1').update(s).digest('hex');
    const rawExt = (s.split('?')[0].split('.').pop() || 'bin').replace(/[^a-z0-9]/gi, '').slice(0, 5) || 'bin';
    const dest = path.join(this.mediaDir(), `${key}.${rawExt}`);
    const index = await vault.read(this.mediaIndexFile(), {});
    if (index[key] && index[key].src && await fs.pathExists(dest)) {
      return { ok: true, src: index[key].src, path: dest, cached: true };
    }
    if (await fs.pathExists(dest)) {
      const src = this.mediaSrc(dest);
      index[key] = { url, path: dest, src, at: Date.now() };
      await vault.write(this.mediaIndexFile(), index);
      return { ok: true, src, path: dest, cached: true };
    }
    try {
      const res = await axios.get(url, { responseType: 'arraybuffer', timeout: 25000, headers: UA, maxContentLength: 8 * 1024 * 1024 });
      await fs.writeFile(dest, Buffer.from(res.data));
      const src = this.mediaSrc(dest);
      index[key] = { url, path: dest, src, at: Date.now() };
      await vault.write(this.mediaIndexFile(), index);
      return { ok: true, src, path: dest, cached: false };
    } catch (_) {
      return { ok: false, src: url, path: '' };
    }
  }

  async cacheMediaMany(urls) {
    const list = [...new Set((urls || []).filter(Boolean))];
    const out = {};
    await Promise.all(list.slice(0, 80).map(async (u) => {
      try { out[u] = await this.cacheMedia(u); } catch (_) { out[u] = { ok: false, src: u }; }
    }));
    return { ok: true, items: out };
  }

  async mediaLookup(url) {
    if (!url) return { ok: false, src: '' };
    const s = String(url);
    if (s.startsWith('data:') || s.startsWith('file:')) return { ok: true, src: s, cached: true };
    await this.ensure();
    const key = crypto.createHash('sha1').update(s).digest('hex');
    const index = await vault.read(this.mediaIndexFile(), {});
    if (index[key] && index[key].src) return { ok: true, src: index[key].src, cached: true };
    const rawExt = (s.split('?')[0].split('.').pop() || 'bin').replace(/[^a-z0-9]/gi, '').slice(0, 5) || 'bin';
    const dest = path.join(this.mediaDir(), `${key}.${rawExt}`);
    if (await fs.pathExists(dest)) {
      const src = this.mediaSrc(dest);
      index[key] = { url, path: dest, src, at: Date.now() };
      await vault.write(this.mediaIndexFile(), index);
      return { ok: true, src, cached: true };
    }
    return { ok: false, src: url };
  }

  async readers(id, thread) {
    return this.call('readers', { id, thread: thread || 'global' });
  }

  async streakTop() {
    return this.call('streakTop');
  }

  async reviveStreak(thread) {
    return this.call('reviveStreak', { thread });
  }

  async uiBundle() {
    await this.ensure();
    return vault.read(this.uiCacheFile(), { css: '', fonts: [] });
  }

  async setUiBundle(patch) {
    const cur = await this.uiBundle();
    return vault.write(this.uiCacheFile(), { ...cur, ...(patch || {}) });
  }

  async downloadMedia(url, name) {
    const downloads = path.join(require('os').homedir(), 'Downloads', 'cryndelDW');
    await fs.ensureDir(downloads);
    const cached = await this.cacheMedia(url);
    const srcPath = cached.path;
    const base = String(name || path.basename(String(url || 'file').split('?')[0]) || 'file').replace(/[<>:"/\\|?*]/g, '_').slice(0, 80);
    const dest = path.join(downloads, base || ('file-' + Date.now()));
    if (srcPath && await fs.pathExists(srcPath)) {
      await fs.copy(srcPath, dest);
      return { ok: true, path: dest };
    }
    if (String(url).startsWith('data:')) {
      const m = String(url).match(/^data:([^;]+);base64,(.+)$/);
      if (m) {
        await fs.writeFile(dest, Buffer.from(m[2], 'base64'));
        return { ok: true, path: dest };
      }
    }
    try {
      const res = await axios.get(url, { responseType: 'arraybuffer', timeout: 30000, headers: UA, maxContentLength: 12 * 1024 * 1024 });
      await fs.writeFile(dest, Buffer.from(res.data));
      return { ok: true, path: dest };
    } catch (err) {
      return { ok: false, error: err.message || 'Не скачалось' };
    }
  }

  async setBadge(nick, badge, on) {
    return this.call('adminUser', { nick, badge, badgeOn: on !== false });
  }

  async bootstrapAdmin() {
    return { ok: false, code: 'E_ADMIN' };
  }

  async adminBot(text, extra = {}) {
    return this.call('adminBot', { text, ...extra });
  }

  async pinChat(thread) {
    return this.call('pinChat', { thread: thread || 'global' });
  }

  async archiveChat(thread) {
    return this.call('archiveChat', { thread: thread || 'global' });
  }

  async muteChat(thread, until) {
    return this.call('muteChat', { thread: thread || 'global', until: until || 0 });
  }

  async saveMessage(id) {
    const data = await this.call('saveMessage', { id });
    if (data && data.item) await this.cacheMessages('saved', [data.item], { merge: true });
    return data;
  }

  async scheduled() {
    return this.call('scheduled');
  }

  async cancelScheduled(id) {
    return this.call('cancelScheduled', { id });
  }

  async linkPreview(url) {
    await this.ensure();
    const map = await vault.read(this.previewFile(), {});
    const key = crypto.createHash('sha1').update(String(url || '')).digest('hex');
    if (map[key] && map[key].at && Date.now() - map[key].at < 86400000) return { ok: true, preview: map[key], cached: true };
    try {
      const data = await this.call('linkPreview', { url });
      if (data && data.preview) {
        map[key] = { ...data.preview, at: Date.now() };
        await vault.write(this.previewFile(), map);
      }
      return data;
    } catch (_) {
      return { ok: true, preview: map[key] || { title: String(url || '').replace(/^https?:\/\//, '').slice(0, 48), desc: '', img: '' }, offline: true };
    }
  }

  async lastThread() {
    await this.ensure();
    return vault.read(this.lastThreadFile(), { id: 'global' });
  }

  async setLastThread(id, nick) {
    await this.ensure();
    return vault.write(this.lastThreadFile(), { id: String(id || 'global'), nick: nick || '' });
  }

  async wsInfo() {
    return this.call('wsInfo');
  }

  async createKanal(handle, extra = {}) {
    return this.call('createKanal', { handle, ...extra });
  }

  async saveKanal(patch) {
    return this.call('saveKanal', patch || {});
  }

  async subKanal(id) {
    return this.call('subKanal', { id });
  }

  async kanal(id) {
    return this.call('kanal', { id });
  }

  async comment(id, text) {
    return this.call('comment', { id, text });
  }

  async comments(id) {
    return this.call('comments', { id });
  }

  async shop() {
    return this.call('shop');
  }

  async shopAdd(payload) {
    return this.call('shopAdd', payload || {});
  }

  async shopBuy(id) {
    return this.call('shopBuy', { id });
  }

  async shopWear(id, kind) {
    return this.call('shopWear', { id, kind });
  }

  async shopGive(nick, extra = {}) {
    return this.call('shopGive', { nick, ...extra });
  }

  async grantRight(nick, right) {
    return this.call('grantRight', { nick, right });
  }

  async createGroup(title, extra = {}) {
    return this.call('createGroup', { title, name: title, ...extra });
  }

  async tfaSetup() {
    return this.call('tfaSetup');
  }

  async tfaEnable(code) {
    return this.call('tfaEnable', { code });
  }

  async tfaDisable(code) {
    return this.call('tfaDisable', { code });
  }

  async folders() {
    return this.call('folders');
  }

  async createFolder(name, threads) {
    return this.call('createFolder', { name, threads: threads || [] });
  }

  async saveFolder(id, patch) {
    return this.call('saveFolder', { id, ...(patch || {}) });
  }
}

module.exports = CrynChat;
