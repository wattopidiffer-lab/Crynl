const fs = require('fs-extra');
const path = require('path');
const CryndelPathVault = require('./paths');

class VeinLogWriter {
  constructor() {
    this.ready = false;
    this.queue = [];
  }

  async ensure() {
    if (this.ready) return;
    await fs.ensureDir(CryndelPathVault.logsDir());
    this.file = path.join(CryndelPathVault.logsDir(), 'crynchat.log');
    this.ready = true;
    for (const line of this.queue) await this.append(line);
    this.queue = [];
  }

  format(level, msg, extra) {
    const stamp = new Date().toISOString();
    const tail = extra !== undefined ? ` ${JSON.stringify(extra)}` : '';
    return `[${stamp}] [${level}] ${msg}${tail}`;
  }

  async append(line) {
    try {
      await this.ensure();
      await fs.appendFile(this.file, line + '\n', 'utf8');
    } catch (_) {
      /* ignore log IO */
    }
  }

  emit(level, msg, extra) {
    const line = this.format(level, msg, extra);
    const printer = level === 'ERROR' ? console.error : console.log;
    printer(line);
    if (!this.ready) {
      this.queue.push(line);
      this.ensure().catch(() => {});
      return;
    }
    this.append(line).catch(() => {});
  }

  info(msg, extra) { this.emit('INFO', msg, extra); }
  warn(msg, extra) { this.emit('WARN', msg, extra); }
  error(msg, extra) { this.emit('ERROR', msg, extra); }
  debug(msg, extra) { this.emit('DEBUG', msg, extra); }
}

module.exports = new VeinLogWriter();
