const path = require('path');
const os = require('os');

function resolveUserRoot() {
  if (process.env.CRYNCHAT_HOME) return process.env.CRYNCHAT_HOME;
  if (process.env.CRYNDEL_HOME) return process.env.CRYNDEL_HOME;
  try {
    const { app } = require('electron');
    if (app && app.getPath) {
      return path.join(app.getPath('userData'), 'cryndel');
    }
  } catch (_) {
    /* jest / before ready */
  }
  return path.join(os.homedir(), '.crynchat');
}

const CryndelPathVault = {
  userRoot() {
    return resolveUserRoot();
  },
  dataDir() {
    return path.join(resolveUserRoot(), 'data');
  },
  logsDir() {
    return path.join(resolveUserRoot(), 'logs');
  }
};

module.exports = CryndelPathVault;
