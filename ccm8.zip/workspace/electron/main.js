const { app, BrowserWindow } = require('electron');
const path = require('path');
const fs = require('fs-extra');
const logger = require('./utils/logger');
const CryndelPathVault = require('./utils/paths');
const PaneSmith = require('./window-manager');
const bindChatIpc = require('./ipc/chat.ipc');
const bindWindowIpc = require('./ipc/window.ipc');
const CrynChat = require('./managers/chat-manager');

if (process.platform === 'win32') {
  app.commandLine.appendSwitch('--disable-gpu-sandbox');
  try { app.setAppUserModelId('ru.cryndel.chat'); } catch (_) { /* */ }
}
try { app.setName('CrynChat'); } catch (_) { /* */ }

const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
} else {
  app.on('second-instance', () => {
    const win = BrowserWindow.getAllWindows()[0];
    if (win) {
      if (win.isMinimized()) win.restore();
      win.show();
      win.focus();
    }
  });
}

class CrynChatKernel {
  constructor() {
    this.panes = new PaneSmith();
    this.hub = null;
    this.wired = false;
  }

  async boot() {
    if (this.panes.win && !this.panes.win.isDestroyed()) {
      this.panes.show();
      return;
    }
    logger.info('CrynChat startup', {
      appPath: app.getAppPath()
    });
    await fs.ensureDir(CryndelPathVault.dataDir());
    await fs.ensureDir(CryndelPathVault.logsDir());

    const chat = new CrynChat();
    this.hub = {
      window: null,
      panes: this.panes,
      chat
    };

    if (!this.wired) {
      bindChatIpc(this.hub);
      bindWindowIpc(this.hub);
      this.wired = true;
    }

    const saved = await this.loadBounds();
    this.panes.create(saved || {});
    this.hub.window = this.panes.win;
    if (saved && saved.zoom) this.panes.setZoom(saved.zoom);
    this.panes.win.on('close', () => this.saveBounds());
    logger.info('CrynChat kernel ready');
  }

  boundsFile() {
    return path.join(CryndelPathVault.dataDir(), 'window.json');
  }

  async loadBounds() {
    try {
      const doc = await fs.readJson(this.boundsFile());
      if (doc && doc.width && doc.height) return doc;
    } catch (_) { /* */ }
    return { width: 980, height: 720, minWidth: 420, minHeight: 520 };
  }

  async saveBounds() {
    try {
      const st = this.panes.state();
      const b = st && st.bounds;
      if (!b) return;
      await fs.ensureDir(path.dirname(this.boundsFile()));
      let zoom = 1;
      try { zoom = this.panes.win.webContents.getZoomFactor(); } catch (_) { /* */ }
      await fs.writeJson(this.boundsFile(), {
        width: b.width,
        height: b.height,
        minWidth: 420,
        minHeight: 520,
        zoom
      });
    } catch (_) { /* */ }
  }
}

const kernel = new CrynChatKernel();

if (gotLock) {
  app.whenReady().then(() => kernel.boot()).catch((err) => {
    logger.error('CrynChat boot failed', { message: err.message, stack: err.stack });
    app.quit();
  });

  app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') app.quit();
  });

  app.on('activate', () => {
    if (!BrowserWindow.getAllWindows().length) {
      kernel.boot().catch(() => {});
    }
  });
}
