const { ipcMain, Notification, BrowserWindow } = require('electron');

function bindChatIpc(hub) {
  ipcMain.handle('chat:me', async () => hub.chat.me());
  ipcMain.handle('chat:register', async (_e, nick, email, password) => hub.chat.register(nick, email, password));
  ipcMain.handle('chat:login', async (_e, email, password) => hub.chat.login(email, password));
  ipcMain.handle('chat:logout', async () => hub.chat.logout());
  ipcMain.handle('chat:refresh', async () => hub.chat.refresh());
  ipcMain.handle('chat:verify', async (_e, code) => hub.chat.verify(code));
  ipcMain.handle('chat:resendVerify', async () => hub.chat.resendVerify());
  ipcMain.handle('chat:messages', async (_e, opts) => hub.chat.messages(opts || {}));
  ipcMain.handle('chat:send', async (_e, text, extra) => hub.chat.send(text, extra || {}));
  ipcMain.handle('chat:react', async (_e, id, emoji) => hub.chat.react(id, emoji));
  ipcMain.handle('chat:pin', async (_e, id) => hub.chat.pin(id));
  ipcMain.handle('chat:saveGif', async (_e, url) => hub.chat.saveGif(url));
  ipcMain.handle('chat:delGif', async (_e, url) => hub.chat.delGif(url));
  ipcMain.handle('chat:gifs', async () => hub.chat.gifs());
  ipcMain.handle('chat:poll', async (_e, question, options, extra) => hub.chat.poll(question, options, extra || {}));
  ipcMain.handle('chat:vote', async (_e, id, option) => hub.chat.vote(id, option));
  ipcMain.handle('chat:stickers', async () => hub.chat.stickers());
  ipcMain.handle('chat:packs', async () => hub.chat.packs());
  ipcMain.handle('chat:createPack', async (_e, name, kind, extra) => hub.chat.createPack(name, kind, extra || {}));
  ipcMain.handle('chat:addSticker', async (_e, packId, url, name) => hub.chat.addSticker(packId, url, name));
  ipcMain.handle('chat:delPack', async (_e, packId) => hub.chat.delPack(packId));
  ipcMain.handle('chat:profile', async () => hub.chat.profile());
  ipcMain.handle('chat:saveProfile', async (_e, patch) => hub.chat.saveProfile(patch || {}));
  ipcMain.handle('chat:user', async (_e, nick) => hub.chat.user(nick));
  ipcMain.handle('chat:searchUsers', async (_e, q) => hub.chat.searchUsers(q));
  ipcMain.handle('chat:edit', async (_e, id, text) => hub.chat.edit(id, text));
  ipcMain.handle('chat:delete', async (_e, id, forAll) => hub.chat.delete(id, forAll));
  ipcMain.handle('chat:privacy', async (_e, patch) => hub.chat.privacy(patch || {}));
  ipcMain.handle('chat:sessions', async () => hub.chat.sessions());
  ipcMain.handle('chat:revokeSession', async (_e, id) => hub.chat.revokeSession(id));
  ipcMain.handle('chat:resetPass', async (_e, nick) => hub.chat.resetPass(nick));
  ipcMain.handle('chat:setPass', async (_e, oldPass, nextPass) => hub.chat.setPass(oldPass, nextPass));
  ipcMain.handle('chat:emojiMap', async () => hub.chat.emojiMap());
  ipcMain.handle('chat:setEmoji', async (_e, code, url) => hub.chat.setEmoji(code, url));
  ipcMain.handle('chat:shareCard', async (_e, url) => hub.chat.shareCard(url));
  ipcMain.handle('chat:forward', async (_e, id, thread) => hub.chat.forward(id, thread));
  ipcMain.handle('chat:unread', async (_e, thread) => hub.chat.unread(thread));
  ipcMain.handle('chat:markRead', async (_e, thread) => hub.chat.markRead(thread));
  ipcMain.handle('chat:typing', async (_e, thread) => hub.chat.typing(thread));
  ipcMain.handle('chat:presence', async (_e, thread) => hub.chat.presence(thread));
  ipcMain.handle('chat:dms', async () => hub.chat.dms());
  ipcMain.handle('chat:dmOpen', async (_e, nick) => hub.chat.dmOpen(nick));
  ipcMain.handle('chat:search', async (_e, q) => hub.chat.search(q));
  ipcMain.handle('chat:block', async (_e, nick) => hub.chat.block(nick));
  ipcMain.handle('chat:mute', async (_e, on) => hub.chat.mute(on));
  ipcMain.handle('chat:report', async (_e, id) => hub.chat.report(id));
  ipcMain.handle('chat:prefs', async () => hub.chat.prefs());
  ipcMain.handle('chat:setPrefs', async (_e, patch) => hub.chat.setPrefs(patch || {}));
  ipcMain.handle('chat:drafts', async () => hub.chat.drafts());
  ipcMain.handle('chat:setDraft', async (_e, thread, text) => hub.chat.setDraft(thread, text));
  ipcMain.handle('chat:upload', async (_e, kind, name, b64, extra) => hub.chat.upload(kind, name, b64, extra || {}));
  ipcMain.handle('chat:chats', async () => hub.chat.chats());
  ipcMain.handle('chat:adminUsers', async (_e, q) => hub.chat.adminUsers(q));
  ipcMain.handle('chat:adminSettings', async (_e, patch) => hub.chat.adminSettings(patch || {}));
  ipcMain.handle('chat:adminChat', async (_e, id, patch) => hub.chat.adminChat(id, patch || {}));
  ipcMain.handle('chat:adminUser', async (_e, nick, patch) => hub.chat.adminUser(nick, patch || {}));
  ipcMain.handle('chat:ban', async (_e, nick, hours, reason) => hub.chat.ban(nick, hours, reason));
  ipcMain.handle('chat:unban', async (_e, nick) => hub.chat.unban(nick));
  ipcMain.handle('chat:modMute', async (_e, nick, minutes, reason) => hub.chat.modMute(nick, minutes, reason));
  ipcMain.handle('chat:modUnmute', async (_e, nick) => hub.chat.modUnmute(nick));
  ipcMain.handle('chat:warn', async (_e, nick, reason) => hub.chat.warn(nick, reason));
  ipcMain.handle('chat:clearWarns', async (_e, nick) => hub.chat.clearWarns(nick));
  ipcMain.handle('chat:kick', async (_e, nick) => hub.chat.kick(nick));
  ipcMain.handle('chat:broadcast', async (_e, text, thread) => hub.chat.broadcast(text, thread));
  ipcMain.handle('chat:purge', async (_e, nick) => hub.chat.purge(nick));
  ipcMain.handle('chat:modlog', async () => hub.chat.modlog());
  ipcMain.handle('chat:adminStats', async () => hub.chat.adminStats());
  ipcMain.handle('chat:saveSticker', async (_e, url, name, packId) => hub.chat.saveSticker(url, name, packId));
  ipcMain.handle('chat:clearChat', async (_e, thread) => hub.chat.clearChat(thread));
  ipcMain.handle('chat:confirmDevice', async (_e, email, password, code) => hub.chat.confirmDevice(email, password, code));
  ipcMain.handle('chat:accounts', async () => hub.chat.accounts());
  ipcMain.handle('chat:saveAccount', async () => hub.chat.saveAccount());
  ipcMain.handle('chat:switchAccount', async (_e, email) => hub.chat.switchAccount(email));
  ipcMain.handle('chat:addAccount', async (_e, email, password) => hub.chat.addAccount(email, password));
  ipcMain.handle('chat:createdAccounts', async () => hub.chat.createdAccounts());
  ipcMain.handle('chat:exportData', async () => {
    const { dialog } = require('electron');
    const picked = await dialog.showSaveDialog(hub.window || undefined, {
      title: 'Экспорт CrynChat',
      defaultPath: 'crynchat-export.zip',
      filters: [{ name: 'ZIP', extensions: ['zip'] }]
    });
    if (picked.canceled || !picked.filePath) return { ok: false, canceled: true };
    return hub.chat.exportData(picked.filePath);
  });
  ipcMain.handle('chat:scrollMap', async () => hub.chat.scrollMap());
  ipcMain.handle('chat:setScroll', async (_e, thread, payload) => hub.chat.setScroll(thread, payload));
  ipcMain.handle('chat:createBot', async (_e, name, lang, extra) => hub.chat.createBot(name, lang, extra || {}));
  ipcMain.handle('chat:myBots', async () => hub.chat.myBots());
  ipcMain.handle('chat:delBot', async (_e, id) => hub.chat.delBot(id));
  ipcMain.handle('chat:revokeBot', async (_e, id) => hub.chat.revokeBot(id));
  ipcMain.handle('chat:cacheMedia', async (_e, url) => hub.chat.cacheMedia(url));
  ipcMain.handle('chat:pinChat', async (_e, thread) => hub.chat.pinChat(thread));
  ipcMain.handle('chat:archiveChat', async (_e, thread) => hub.chat.archiveChat(thread));
  ipcMain.handle('chat:muteChat', async (_e, thread, until) => hub.chat.muteChat(thread, until));
  ipcMain.handle('chat:saveMessage', async (_e, id) => hub.chat.saveMessage(id));
  ipcMain.handle('chat:scheduled', async () => hub.chat.scheduled());
  ipcMain.handle('chat:cancelScheduled', async (_e, id) => hub.chat.cancelScheduled(id));
  ipcMain.handle('chat:linkPreview', async (_e, url) => hub.chat.linkPreview(url));
  ipcMain.handle('chat:lastThread', async () => hub.chat.lastThread());
  ipcMain.handle('chat:setLastThread', async (_e, id, nick) => hub.chat.setLastThread(id, nick));
  ipcMain.handle('chat:popout', async () => {
    if (hub.panes && hub.panes.applyPreset) {
      hub.panes.applyPreset('compact');
      return { ok: true, standalone: true };
    }
    return { ok: false };
  });
  ipcMain.handle('chat:downloadMedia', async (_e, url, name) => hub.chat.downloadMedia(url, name));
  ipcMain.handle('chat:setBadge', async (_e, nick, badge, on) => hub.chat.setBadge(nick, badge, on));
  ipcMain.handle('chat:adminBot', async (_e, text, extra) => hub.chat.adminBot(text, extra || {}));

  ipcMain.handle('chat:readers', async (_e, id, thread) => hub.chat.readers(id, thread));
  ipcMain.handle('chat:streakTop', async () => hub.chat.streakTop());
  ipcMain.handle('chat:reviveStreak', async (_e, thread) => hub.chat.reviveStreak(thread));
  ipcMain.handle('chat:cacheMediaMany', async (_e, urls) => hub.chat.cacheMediaMany(urls || []));
  ipcMain.handle('chat:mediaLookup', async (_e, url) => hub.chat.mediaLookup(url));
  ipcMain.handle('chat:uiBundle', async () => hub.chat.uiBundle());
  ipcMain.handle('chat:setUiBundle', async (_e, patch) => hub.chat.setUiBundle(patch || {}));
  ipcMain.handle('chat:wsInfo', async () => hub.chat.wsInfo());
  ipcMain.handle('chat:createKanal', async (_e, handle, extra) => hub.chat.createKanal(handle, extra || {}));
  ipcMain.handle('chat:saveKanal', async (_e, patch) => hub.chat.saveKanal(patch || {}));
  ipcMain.handle('chat:subKanal', async (_e, id) => hub.chat.subKanal(id));
  ipcMain.handle('chat:kanal', async (_e, id) => hub.chat.kanal(id));
  ipcMain.handle('chat:comment', async (_e, id, text) => hub.chat.comment(id, text));
  ipcMain.handle('chat:comments', async (_e, id) => hub.chat.comments(id));
  ipcMain.handle('chat:shop', async () => hub.chat.shop());
  ipcMain.handle('chat:shopAdd', async (_e, payload) => hub.chat.shopAdd(payload || {}));
  ipcMain.handle('chat:shopBuy', async (_e, id) => hub.chat.shopBuy(id));
  ipcMain.handle('chat:shopWear', async (_e, id, kind) => hub.chat.shopWear(id, kind));
  ipcMain.handle('chat:shopGive', async (_e, nick, extra) => hub.chat.shopGive(nick, extra || {}));
  ipcMain.handle('chat:grantRight', async (_e, nick, right) => hub.chat.grantRight(nick, right));
  ipcMain.handle('chat:createGroup', async (_e, title, extra) => hub.chat.createGroup(title, extra || {}));
  ipcMain.handle('chat:tfaSetup', async () => hub.chat.tfaSetup());
  ipcMain.handle('chat:tfaEnable', async (_e, code) => hub.chat.tfaEnable(code));
  ipcMain.handle('chat:tfaDisable', async (_e, code) => hub.chat.tfaDisable(code));
  ipcMain.handle('chat:folders', async () => hub.chat.folders());
  ipcMain.handle('chat:createFolder', async (_e, name, threads) => hub.chat.createFolder(name, threads || []));
  ipcMain.handle('chat:saveFolder', async (_e, id, patch) => hub.chat.saveFolder(id, patch || {}));
  ipcMain.handle('chat:nativeNotify', async (e, payload) => {
    const title = String((payload && payload.title) || 'CrynChat').slice(0, 80);
    const body = String((payload && payload.body) || '').slice(0, 180);
    const silent = Boolean(payload && payload.silent);
    try {
      if (Notification.isSupported()) {
        const n = new Notification({
          title,
          body,
          silent,
          hasReply: true,
          replyPlaceholder: 'Ответить…'
        });
        n.on('click', () => {
          const win = BrowserWindow.fromWebContents(e.sender);
          if (win && !win.isDestroyed()) {
            if (win.isMinimized()) win.restore();
            win.show();
            win.focus();
          }
        });
        n.on('reply', (_ev, reply) => {
          const text = String(reply || '').trim();
          if (text) e.sender.send('chat:notify-reply', { text, title, body });
        });
        n.show();
        return { ok: true, native: true };
      }
    } catch (_) { /* */ }
    return { ok: false };
  });
}

module.exports = bindChatIpc;
