const { ipcMain } = require('electron');

function bindWindowIpc(hub) {
  function senderWin(e) {
    try {
      const wc = e && e.sender;
      if (!wc) return hub.panes && hub.panes.win;
      return typeof wc.getOwnerBrowserWindow === 'function' ? wc.getOwnerBrowserWindow() : (hub.panes && hub.panes.win);
    } catch (_) {
      return hub.panes && hub.panes.win;
    }
  }

  ipcMain.handle('window:setZoom', async (_e, factor) => {
    return hub.panes.setZoom(factor);
  });
  ipcMain.handle('window:setSize', async (_e, width, height) => {
    return hub.panes.setSize(width, height);
  });
  ipcMain.handle('window:setPreset', async (_e, name) => {
    return hub.panes.applyPreset(name);
  });
  ipcMain.handle('window:minimize', async (e) => {
    const win = senderWin(e);
    if (!win || win.isDestroyed()) return null;
    win.minimize();
    return hub.panes.state();
  });
  ipcMain.handle('window:maximize', async (e) => {
    const win = senderWin(e);
    if (!win || win.isDestroyed()) return null;
    if (win.isMaximized()) win.unmaximize();
    else win.maximize();
    return hub.panes.state();
  });
  ipcMain.handle('window:fullscreen', async (e) => {
    const win = senderWin(e);
    if (!win || win.isDestroyed()) return null;
    win.setFullScreen(!win.isFullScreen());
    return hub.panes.state();
  });
  ipcMain.handle('window:close', async (e) => {
    const win = senderWin(e);
    if (!win || win.isDestroyed()) return { ok: true };
    win.close();
    return { ok: true };
  });
  ipcMain.handle('window:show', async () => {
    hub.panes.show();
    return hub.panes.state();
  });
  ipcMain.handle('window:state', async () => hub.panes.state());
}

module.exports = bindWindowIpc;
