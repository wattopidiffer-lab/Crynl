#!/bin/sh
cd "$(dirname "$0")"
mkdir -p data/crynsys
chmod 700 data/crynsys 2>/dev/null || true
if [ ! -f data/crynsys/.wskey ]; then
  umask 077
  head -c 32 /dev/urandom | xxd -p -c 64 > data/crynsys/.wskey
  chmod 600 data/crynsys/.wskey
fi
export CRYN_WS_HOST=127.0.0.1
export CRYN_WS_PORT=18765
export CRYN_WS_PUSH="$(tr -d '\n' < data/crynsys/.wskey)"
exec node ws.js
