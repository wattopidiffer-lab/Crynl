<?php
declare(strict_types=1);

function actorOf(?array $u): array {
  if (!$u) {
    return ['uid' => '', 'role' => 'guest', 'banned' => false, 'muted' => false, 'admin' => false, 'staff' => false];
  }
  return [
    'uid' => (string)($u['id'] ?? ''),
    'role' => (string)($u['role'] ?? 'user'),
    'banned' => !empty($u['banned']) && ((int)($u['banUntil'] ?? 0) === 0 || (int)$u['banUntil'] > time()),
    'muted' => chatMuted($u),
    'admin' => isAdmin($u),
    'staff' => isStaff($u),
    'verified' => isVerified($u)
  ];
}

function threadReadonly(string $thread): bool {
  $cfg = meta();
  if (!empty($cfg['readonly'])) return true;
  $chats = $cfg['chats'] ?? [];
  $row = $chats[$thread] ?? [];
  return !empty($row['readonly']);
}

function aclCan(array $u, string $action, array $obj = []): bool {
  $actor = actorOf($u);
  if ($actor['banned'] && $action !== 'auth.logout' && $action !== 'users.me') return false;
  $thread = (string)($obj['thread'] ?? '');
  $msg = is_array($obj['msg'] ?? null) ? $obj['msg'] : null;
  $admin = $actor['admin'];

  switch ($action) {
    case 'threads.read':
      return $thread !== '' && threadOk($thread) && inThread($u, $thread);
    case 'threads.write':
      if ($admin) return $thread !== '' && threadOk($thread) && inThread($u, $thread);
      if ($actor['muted']) return false;
      if (!threadOk($thread) || !inThread($u, $thread)) return false;
      if (threadReadonly($thread)) return false;
      if (strpos($thread, 'dm:') === 0) {
        try { assertCanWriteDm($u, $thread); } catch (Throwable $e) { return false; }
      }
      if ($thread === 'channel' || $thread === 'system') return false;
      if (strpos($thread, 'kanal:') === 0) {
        $k = loadKanal(substr($thread, 6));
        return is_array($k) && (($k['owner'] ?? '') === $actor['uid']);
      }
      return true;
    case 'messages.edit_own':
    case 'messages.delete_own':
      if (!$msg) return false;
      if (!aclCan($u, 'threads.read', ['thread' => (string)($msg['thread'] ?? $thread)])) return false;
      return (string)($msg['uid'] ?? '') === $actor['uid'];
    case 'messages.moderate':
      if (!$admin && !canModMsg($u)) return false;
      if ($msg) return aclCan($u, 'threads.read', ['thread' => (string)($msg['thread'] ?? $thread)]) || $admin;
      return $thread === '' || inThread($u, $thread) || $admin;
    case 'media.get':
      if ($msg) return aclCan($u, 'threads.read', ['thread' => (string)($msg['thread'] ?? '')]);
      if ($thread !== '') return aclCan($u, 'threads.read', ['thread' => $thread]);
      return $actor['uid'] !== '' && (string)($obj['owner'] ?? '') === $actor['uid'];
    case 'admin.any':
      return $admin;
    case 'staff.any':
      return $admin || $actor['staff'];
    default:
      return false;
  }
}

function aclAssert(array $u, string $action, array $obj = []): void {
  if (!aclCan($u, $action, $obj)) fail('Нет доступа', 403);
}

function limitsFor(?array $u): array {
  $admin = $u && isAdmin($u);
  $staff = $u && isStaff($u);
  return [
    'text' => 4096,
    'caption' => 4096,
    'bio' => 360,
    'status' => 24,
    'nick' => 20,
    'mentions' => 10,
    'fileImage' => $admin ? 12000000 : 3145728,
    'fileAudio' => $admin ? 12000000 : 8388608,
    'fileAny' => $admin ? 12000000 : 3145728,
    'packMax' => $admin ? 80 : 12,
    'stickersPerPack' => 80,
    'sendPerMin' => $admin ? 0 : ($staff ? 60 : 24),
    'uploadPer5min' => $admin ? 0 : ($staff ? 40 : 12),
    'reactPerMin' => $admin ? 0 : 40,
    'readPerMin' => $admin ? 0 : 120,
    'searchPerMin' => $admin ? 0 : 30,
    'editWindowSec' => $admin ? 0 : 900,
    'adminUnlimited' => $admin
  ];
}

function rateFor(array $u, string $bucket): void {
  if (isAdmin($u)) return;
  $lim = limitsFor($u);
  $map = [
    'send' => [(int)$lim['sendPerMin'], 60],
    'up' => [(int)$lim['uploadPer5min'], 300],
    'react' => [(int)$lim['reactPerMin'], 60],
    'read' => [(int)$lim['readPerMin'], 60],
    'find' => [(int)$lim['searchPerMin'], 60],
    'edit' => [40, 60],
    'del' => [40, 60],
    'mention' => [10, 60],
    'link' => [6, 300],
    'cmt' => [30, 60],
    'kanal' => [3, 86400],
    'group' => [8, 86400],
    'invite' => [20, 3600],
    'report' => [8, 3600],
    'login' => [12, 600],
    'reg' => [5, 3600],
    'verify' => [12, 600],
    'resend' => [6, 600],
    'tfa' => [10, 600],
    'refresh' => [30, 60],
    'pass' => [8, 600]
  ];
  $pair = $map[$bucket] ?? [30, 60];
  if ($pair[0] <= 0) return;
  rate($bucket, $pair[0], $pair[1], (string)($u['id'] ?? ''));
}
