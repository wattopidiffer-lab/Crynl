<?php
declare(strict_types=1);

const VAULT_ROOT = DATA_DIR;
const VAULT_LS = DATA_DIR . '/ls';
const VAULT_SAVES = DATA_DIR . '/usersaves';
const VAULT_KANAL = DATA_DIR . '/kanal';
const VAULT_PROFILE = DATA_DIR . '/profile';
const VAULT_OQONEK = DATA_DIR . '/oqonek';
const VAULT_EMOJI = DATA_DIR . '/empji';
const VAULT_SYS = DATA_DIR . '/crynsys';
const VAULT_BOTS = DATA_DIR . '/bots';
const VAULT_CHAT = DATA_DIR . '/crynchat';
const VAULT_USERS = DATA_DIR . '/users';
const VAULT_SHA = DATA_DIR . '/crynsys/Sha';
const VAULT_USERID = DATA_DIR . '/crynsys/userid';
const VAULT_CHATID = DATA_DIR . '/crynsys/chatid';
const VAULT_BOTID = DATA_DIR . '/crynsys/botid';
const VAULT_KANALID = DATA_DIR . '/crynsys/kanalid';
const VAULT_VIDATID = DATA_DIR . '/crynsys/vidatid';
const VAULT_RIGHTSID = DATA_DIR . '/crynsys/rightsid';
const VAULT_MEDIA_POOL = DATA_DIR . '/crynsys/pool';
const VAULT_REFS = DATA_DIR . '/crynsys/refs.bin';
const VAULT_LIVE = DATA_DIR . '/crynsys/live.bin';
const VAULT_RATE = DATA_DIR . '/crynsys/rate.bin';
const VAULT_META = DATA_DIR . '/crynsys/meta.bin';
const VAULT_LOG = DATA_DIR . '/crynsys/modlog.bin';
const VAULT_KEY = DATA_DIR . '/crynsys/.key';
const VAULT_SHA1KEY = DATA_DIR . '/crynsys/.sha1';
const VAULT_SHOP = DATA_DIR . '/crynsys/shop.bin';
const VAULT_WS = DATA_DIR . '/crynsys/ws.bin';
const PUBLIC_MEDIA = 'https://my.cryndel.ru/acryn/data';

function vaultDirs(): array {
  return [
    VAULT_LS, VAULT_SAVES, VAULT_KANAL, VAULT_PROFILE, VAULT_OQONEK,
    VAULT_EMOJI, VAULT_SYS, VAULT_BOTS, VAULT_CHAT, VAULT_USERS,
    VAULT_MEDIA_POOL, VAULT_CHAT . '/media', VAULT_CHAT . '/muzick',
    VAULT_CHAT . '/messengers', VAULT_CHAT . '/data', VAULT_OQONEK
  ];
}

function vaultBoot(): void {
  foreach (vaultDirs() as $d) {
    if (!is_dir($d)) mkdir($d, 0700, true);
  }
  if (!is_file(VAULT_KEY)) {
    file_put_contents(VAULT_KEY, random_bytes(32), LOCK_EX);
    chmod(VAULT_KEY, 0600);
  }
  if (!is_file(VAULT_SHA1KEY)) {
    file_put_contents(VAULT_SHA1KEY, random_bytes(32), LOCK_EX);
    chmod(VAULT_SHA1KEY, 0600);
  }
  foreach ([VAULT_SHA, VAULT_USERID, VAULT_CHATID, VAULT_BOTID, VAULT_KANALID, VAULT_VIDATID, VAULT_RIGHTSID] as $f) {
    if (!is_file($f)) {
      file_put_contents($f, '', LOCK_EX);
      chmod($f, 0600);
    }
  }
  $gif = VAULT_OQONEK . '/oqon.gif';
  $web = VAULT_OQONEK . '/oqon.webp';
  if (!is_file($gif) && is_file(__DIR__ . '/../oqon.gif')) @copy(__DIR__ . '/../oqon.gif', $gif);
  if (!is_file($web) && is_file(__DIR__ . '/../oqon.webp')) @copy(__DIR__ . '/../oqon.webp', $web);
}

function vaultSecret(): string {
  vaultBoot();
  return (string)file_get_contents(VAULT_KEY);
}

function vaultEnc(string $plain): string {
  $iv = random_bytes(12);
  $tag = '';
  $raw = openssl_encrypt($plain, 'aes-256-gcm', vaultSecret(), OPENSSL_RAW_DATA, $iv, $tag);
  if ($raw === false) fail('storage', 500);
  return base64_encode($iv . $tag . $raw);
}

function vaultDec(string $b64): string {
  $bin = base64_decode($b64, true);
  if ($bin === false || strlen($bin) < 29) return '';
  $iv = substr($bin, 0, 12);
  $tag = substr($bin, 12, 16);
  $raw = substr($bin, 28);
  $out = openssl_decrypt($raw, 'aes-256-gcm', vaultSecret(), OPENSSL_RAW_DATA, $iv, $tag);
  return $out === false ? '' : $out;
}

function vaultRead(string $file, array $fallback): array {
  if (!is_file($file)) return $fallback;
  $raw = (string)file_get_contents($file);
  if ($raw === '') return $fallback;
  $json = vaultDec($raw);
  if ($json === '') {
    $data = json_decode($raw, true);
    return is_array($data) ? $data : $fallback;
  }
  $data = json_decode($json, true);
  return is_array($data) ? $data : $fallback;
}

function vaultWrite(string $file, array $data): void {
  $dir = dirname($file);
  if (!is_dir($dir)) mkdir($dir, 0700, true);
  $tmp = $file . '.' . getmypid() . '.' . bin2hex(random_bytes(3)) . '.tmp';
  file_put_contents($tmp, vaultEnc(json_encode($data, JSON_UNESCAPED_UNICODE)), LOCK_EX);
  rename($tmp, $file);
  chmod($file, 0600);
}

function vaultName(string $key): string {
  return substr(hash_hmac('sha256', $key, vaultSecret()), 0, 24);
}

function mskDay(?int $ts = null): string {
  $t = ($ts ?? time()) + 3 * 3600;
  return gmdate('Y-m-d', $t);
}

function dayFile(string $root, string $day): string {
  return rtrim($root, '/') . '/messengers/' . vaultName($day) . '.bin';
}

function idxSet(string $file, string $left, string $right): void {
  $map = idxMap($file);
  $map[$left] = $right;
  $map[$right] = $left;
  $lines = [];
  $seen = [];
  foreach ($map as $a => $b) {
    $k = $a . '=' . $b;
    $rk = $b . '=' . $a;
    if (isset($seen[$k]) || isset($seen[$rk])) continue;
    $seen[$k] = true;
    $lines[] = $a . '=' . $b;
  }
  file_put_contents($file, implode("\n", $lines) . (count($lines) ? "\n" : ''), LOCK_EX);
  chmod($file, 0600);
}

function idxMap(string $file): array {
  if (!is_file($file)) return [];
  $out = [];
  foreach (preg_split('/\r?\n/', (string)file_get_contents($file)) as $line) {
    $line = trim($line);
    if ($line === '' || strpos($line, '=') === false) continue;
    [$a, $b] = explode('=', $line, 2);
    $a = trim($a);
    $b = trim($b);
    if ($a === '' || $b === '') continue;
    $out[$a] = $b;
    $out[$b] = $a;
  }
  return $out;
}

function idxGet(string $file, string $key): string {
  $map = idxMap($file);
  return (string)($map[$key] ?? '');
}

function shaIndexPut(string $uid, string $nick, string $path, string $sha256, array $chats): void {
  vaultBoot();
  $rows = shaIndexAll();
  $rows[$sha256] = [
    'uid' => $uid,
    'nick' => $nick,
    'path' => $path,
    'sha256' => $sha256,
    'chats' => array_values(array_unique($chats))
  ];
  $buf = [];
  foreach ($rows as $r) {
    $buf[] = $r['uid'];
    $buf[] = $r['nick'];
    $buf[] = $r['path'];
    $buf[] = $r['sha256'];
    $buf[] = 'chats:';
    $buf[] = implode(',', $r['chats']);
    $buf[] = '';
  }
  file_put_contents(VAULT_SHA, implode("\n", $buf), LOCK_EX);
  chmod(VAULT_SHA, 0600);
}

function shaIndexAll(): array {
  if (!is_file(VAULT_SHA)) return [];
  $lines = preg_split('/\r?\n/', (string)file_get_contents(VAULT_SHA));
  $rows = [];
  $cur = [];
  $step = 0;
  foreach ($lines as $line) {
    $line = rtrim($line);
    if ($line === '') {
      if (!empty($cur['sha256'])) $rows[$cur['sha256']] = $cur;
      $cur = [];
      $step = 0;
      continue;
    }
    if ($line === 'chats:') { $step = 5; continue; }
    if ($step === 0) { $cur['uid'] = $line; $step = 1; }
    elseif ($step === 1) { $cur['nick'] = $line; $step = 2; }
    elseif ($step === 2) { $cur['path'] = $line; $step = 3; }
    elseif ($step === 3) { $cur['sha256'] = $line; $step = 4; }
    elseif ($step === 5) { $cur['chats'] = array_values(array_filter(explode(',', $line))); $step = 6; }
  }
  if (!empty($cur['sha256'])) $rows[$cur['sha256']] = $cur;
  return $rows;
}

function shaFind(string $sha256): ?array {
  $all = shaIndexAll();
  return $all[$sha256] ?? null;
}

function refsDoc(): array {
  return vaultRead(VAULT_REFS, ['files' => []]);
}

function refsSave(array $doc): void {
  vaultWrite(VAULT_REFS, $doc);
}

function mediaPoolPath(string $sha1, string $ext): string {
  $a = substr($sha1, 0, 2);
  $dir = VAULT_MEDIA_POOL . '/' . $a;
  if (!is_dir($dir)) mkdir($dir, 0700, true);
  return $dir . '/' . $sha1 . '.' . $ext;
}

function mediaPublic(string $sha1, string $ext, string $uid = ''): string {
  $sha1 = preg_replace('/[^a-f0-9]/', '', strtolower($sha1));
  $ext = preg_replace('/[^a-z0-9]/', '', strtolower($ext));
  $uid = preg_replace('/[^A-Za-z0-9:_-]/', '', $uid);
  $exp = time() + 600;
  $sig = hash_hmac('sha256', $sha1 . '|' . $ext . '|' . $exp . '|' . $uid, vaultSecret());
  $q = 'https://my.cryndel.ru/acryn/index.php?m=' . $sha1 . '&e=' . $ext . '&x=' . $exp . '&s=' . $sig;
  if ($uid !== '') $q .= '&u=' . rawurlencode($uid);
  return $q;
}

function mediaRetain(string $sha1, string $chatId): void {
  $doc = refsDoc();
  $row = $doc['files'][$sha1] ?? ['n' => 0, 'chats' => []];
  $row['n'] = (int)$row['n'] + 1;
  $row['chats'] = array_values(array_unique(array_merge($row['chats'] ?? [], [$chatId])));
  $doc['files'][$sha1] = $row;
  refsSave($doc);
}

function mediaRelease(string $sha1, string $chatId): void {
  $doc = refsDoc();
  if (empty($doc['files'][$sha1])) return;
  $row = $doc['files'][$sha1];
  $row['n'] = max(0, (int)$row['n'] - 1);
  $row['chats'] = array_values(array_filter($row['chats'] ?? [], fn($c) => $c !== $chatId));
  if ($row['n'] <= 0) {
    $path = (string)($row['path'] ?? '');
    if ($path !== '' && is_file($path)) {
      // keep file until n==0 confirmed; then unlink is allowed only if unused
      @unlink($path);
    }
    unset($doc['files'][$sha1]);
  } else {
    $doc['files'][$sha1] = $row;
  }
  refsSave($doc);
}

function storeBlob(string $bin, string $ext, string $uid, string $nick, string $chatId): array {
  $sha1 = sha1($bin);
  $sha256 = hash('sha256', $bin);
  $ext = preg_replace('/[^a-z0-9]/', '', strtolower($ext)) ?: 'bin';
  $path = mediaPoolPath($sha1, $ext);
  $hit = shaFind($sha256);
  if ($hit && is_file((string)$hit['path']) && (string)($hit['uid'] ?? '') === $uid) {
    $chats = array_values(array_unique(array_merge($hit['chats'] ?? [], [$chatId])));
    shaIndexPut($hit['uid'] ?: $uid, $hit['nick'] ?: $nick, $hit['path'], $sha256, $chats);
    mediaRetain($sha1, $chatId);
    $doc = refsDoc();
    $doc['files'][$sha1]['path'] = $hit['path'];
    $doc['files'][$sha1]['sha256'] = $sha256;
    $doc['files'][$sha1]['ext'] = $ext;
    refsSave($doc);
    return [
      'url' => mediaPublic($sha1, $ext, $uid),
      'sha1' => $sha1,
      'sha256' => $sha256,
      'path' => $hit['path'],
      'cached' => true,
      'ext' => $ext
    ];
  }
  if (!is_file($path)) file_put_contents($path, $bin, LOCK_EX);
  chmod($path, 0600);
  shaIndexPut($uid, $nick, $path, $sha256, [$chatId]);
  $doc = refsDoc();
  $doc['files'][$sha1] = [
    'n' => 0,
    'chats' => [],
    'path' => $path,
    'sha256' => $sha256,
    'ext' => $ext,
    'uid' => $uid
  ];
  refsSave($doc);
  mediaRetain($sha1, $chatId);
  return [
    'url' => mediaPublic($sha1, $ext),
    'sha1' => $sha1,
    'sha256' => $sha256,
    'path' => $path,
    'cached' => false,
    'ext' => $ext
  ];
}

function userDir(string $id): string {
  return VAULT_USERS . '/' . preg_replace('/[^A-Za-z0-9_-]/', '', $id);
}

function profileFile(string $id): string {
  return VAULT_PROFILE . '/' . preg_replace('/[^A-Za-z0-9_-]/', '', $id) . '.bin';
}

function savesDir(string $id): string {
  $d = VAULT_SAVES . '/' . preg_replace('/[^A-Za-z0-9_-]/', '', $id);
  if (!is_dir($d)) mkdir($d, 0700, true);
  if (!is_dir($d . '/stickers')) mkdir($d . '/stickers', 0700, true);
  return $d;
}

function lsDir(string $id): string {
  $d = VAULT_LS . '/' . preg_replace('/[^A-Za-z0-9_-]/', '', $id);
  foreach (['media', 'oqonek', 'messengers', 'muzick'] as $sub) {
    $p = $d . '/' . $sub;
    if (!is_dir($p)) mkdir($p, 0700, true);
  }
  return $d;
}

function kanalDir(string $id): string {
  $d = VAULT_KANAL . '/' . preg_replace('/[^A-Za-z0-9_-]/', '', $id);
  foreach (['media', 'messengers', 'muzick', 'data', 'comments'] as $sub) {
    $p = $d . '/' . $sub;
    if (!is_dir($p)) mkdir($p, 0700, true);
  }
  return $d;
}

function botDir(string $id): string {
  $d = VAULT_BOTS . '/' . preg_replace('/[^A-Za-z0-9_-]/', '', $id);
  if (!is_dir($d)) mkdir($d, 0700, true);
  return $d;
}

function oqonekFile(string $a, string $b): string {
  $ids = [$a, $b];
  sort($ids);
  return VAULT_OQONEK . '/' . vaultName($ids[0] . ':' . $ids[1]) . '.bin';
}

function dmPair(string $thread): array {
  if (!preg_match('/^dm:(u[a-f0-9]{8}):(u[a-f0-9]{8})$/', $thread, $m)) return [];
  $ids = [$m[1], $m[2]];
  sort($ids);
  return $ids;
}

function threadRoot(string $thread): string {
  if ($thread === 'global' || $thread === 'crynchat' || $thread === 'saved' || $thread === 'system' || $thread === 'channel') return VAULT_CHAT;
  if (strpos($thread, 'group:') === 0) {
    $id = preg_replace('/[^A-Za-z0-9_-]/', '', substr($thread, 6));
    $d = VAULT_CHAT . '/groups/' . $id;
    if (!is_dir($d . '/messengers')) mkdir($d . '/messengers', 0700, true);
    return $d;
  }
  if (strpos($thread, 'kanal:') === 0) {
    $id = substr($thread, 6);
    return kanalDir($id);
  }
  if (strpos($thread, 'dm:') === 0) {
    if ($thread === 'dm:createbot' || $thread === 'dm:adminbot') return VAULT_CHAT;
    $ids = dmPair($thread);
    if ($ids) {
      idxSet(VAULT_CHATID, $thread, $ids[0] . '+' . $ids[1]);
      return lsDir($ids[0]);
    }
  }
  return VAULT_CHAT;
}

function msgsOf(string $thread, string $day = ''): array {
  $root = threadRoot($thread);
  $day = $day !== '' ? $day : mskDay();
  $file = dayFile($root, $day);
  $doc = vaultRead($file, ['items' => [], 'day' => $day, 'thread' => $thread]);
  return $doc;
}

function saveMsgsOf(string $thread, string $day, array $doc): void {
  $root = threadRoot($thread);
  vaultWrite(dayFile($root, $day), $doc);
}

function scanDays(string $thread, int $limit = 14): array {
  $root = threadRoot($thread);
  $dir = $root . '/messengers';
  if (!is_dir($dir)) return [];
  $out = [];
  for ($i = 0; $i < $limit; $i++) {
    $day = mskDay(time() - $i * 86400);
    $file = dayFile($root, $day);
    if (is_file($file)) $out[] = $day;
  }
  return $out;
}

const VAULT_MSGID = DATA_DIR . '/crynsys/msgid';

function msgIndexPut(string $id, string $file): void {
  idxSet(VAULT_MSGID, $id, $file);
}

function msgIndexGet(string $id): string {
  return idxGet(VAULT_MSGID, $id);
}

function nextSeq(): int {
  $f = VAULT_SYS . '/seq';
  $n = 1;
  if (is_file($f)) $n = max(1, (int)trim((string)file_get_contents($f)) + 1);
  file_put_contents($f, (string)$n, LOCK_EX);
  chmod($f, 0600);
  return $n;
}

function pushThreadMsg(array $item): array {
  $thread = (string)($item['thread'] ?? 'global');
  $day = mskDay();
  $root = threadRoot($thread);
  $file = dayFile($root, $day);
  $doc = msgsOf($thread, $day);
  if (empty($item['seq'])) $item['seq'] = nextSeq();
  array_unshift($doc['items'], $item);
  if (count($doc['items']) > 4000) $doc['items'] = array_slice($doc['items'], 0, 4000);
  $doc['day'] = $day;
  $doc['thread'] = $thread;
  saveMsgsOf($thread, $day, $doc);
  if (!empty($item['id'])) msgIndexPut((string)$item['id'], $file);
  wsEmit('message', ['thread' => $thread, 'item' => $item]);
  return $item;
}

function findThreadMsg(string $id): ?array {
  $file = msgIndexGet($id);
  if ($file !== '' && is_file($file)) {
    $doc = vaultRead($file, ['items' => []]);
    foreach ($doc['items'] as $m) {
      if (($m['id'] ?? '') === $id) {
        $m['_file'] = $file;
        return $m;
      }
    }
  }
  foreach ([VAULT_CHAT, VAULT_LS, VAULT_KANAL] as $base) {
    $found = findMsgWalk($base, $id);
    if ($found) return $found;
  }
  return null;
}

function findMsgWalk(string $base, string $id): ?array {
  if (!is_dir($base)) return null;
  $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($base, FilesystemIterator::SKIP_DOTS));
  foreach ($it as $f) {
    if (!$f->isFile()) continue;
    if (substr($f->getFilename(), -4) !== '.bin') continue;
    if (strpos($f->getPathname(), '/messengers/') === false) continue;
    $doc = vaultRead($f->getPathname(), ['items' => []]);
    foreach ($doc['items'] as $m) {
      if (($m['id'] ?? '') === $id) {
        $m['_file'] = $f->getPathname();
        return $m;
      }
    }
  }
  return null;
}

function patchThreadMsg(string $id, callable $fn): array {
  $m = findThreadMsg($id);
  if (!$m || empty($m['_file'])) fail('Нет сообщения');
  $file = $m['_file'];
  unset($m['_file']);
  $doc = vaultRead($file, ['items' => []]);
  foreach ($doc['items'] as &$x) {
    if (($x['id'] ?? '') !== $id) continue;
    $fn($x);
    vaultWrite($file, $doc);
    return $x;
  }
  fail('Нет сообщения');
}

function loadUser(string $id): ?array {
  $f = userDir($id) . '/account.bin';
  if (!is_file($f)) return null;
  $u = vaultRead($f, []);
  return $u ? $u : null;
}

function saveUserDoc(array $u): void {
  $id = (string)($u['id'] ?? '');
  if ($id === '') return;
  $dir = userDir($id);
  if (!is_dir($dir)) mkdir($dir, 0700, true);
  vaultWrite($dir . '/account.bin', $u);
  if (!empty($u['token'])) idxSet(VAULT_SYS . '/tokenid', substr(hash('sha256', (string)$u['token']), 0, 24), $id);
  $pub = $u;
  unset($pub['hash'], $pub['token'], $pub['verifyHash'], $pub['pendingCode'], $pub['sessions'], $pub['tfaSecret']);
  vaultWrite(profileFile($id), $pub);
  idxSet(VAULT_USERID, strtolower((string)$u['nick']), $id);
}

function allUserIds(): array {
  $ids = [];
  if (!is_dir(VAULT_USERS)) return $ids;
  foreach (scandir(VAULT_USERS) as $n) {
    if ($n === '.' || $n === '..') continue;
    if (is_file(VAULT_USERS . '/' . $n . '/account.bin')) $ids[] = $n;
  }
  return $ids;
}

function allUsers(): array {
  $users = [];
  foreach (allUserIds() as $id) {
    $u = loadUser($id);
    if ($u) $users[] = $u;
  }
  return $users;
}

function migrateLegacy(): void {
  $oldUsers = DATA_DIR . '/users.bin';
  if (!is_file($oldUsers)) return;
  $flag = VAULT_SYS . '/migrated.bin';
  if (is_file($flag)) return;
  $doc = loadStore($oldUsers, ['users' => []]);
  foreach ($doc['users'] as $u) {
    if (empty($u['id'])) continue;
    $u['pirikas'] = (int)($u['pirikas'] ?? 0);
    $u['rights'] = $u['rights'] ?? [];
    $u['cosmetics'] = $u['cosmetics'] ?? ['owned' => [], 'avatarHat' => '', 'listHat' => '', 'profileHat' => ''];
    $u['channelId'] = $u['channelId'] ?? '';
    $u['tfa'] = !empty($u['tfa']);
    saveUserDoc($u);
    lsDir($u['id']);
    savesDir($u['id']);
  }
  $oldMsg = DATA_DIR . '/messages.bin';
  if (is_file($oldMsg)) {
    $md = loadStore($oldMsg, ['items' => []]);
    foreach ($md['items'] as $m) {
      if (!is_array($m)) continue;
      $thread = (string)($m['thread'] ?? 'global');
      $ts = strtotime((string)($m['at'] ?? '')) ?: time();
      $day = mskDay($ts - 3 * 3600);
      $docm = msgsOf($thread, $day);
      $docm['items'][] = $m;
      saveMsgsOf($thread, $day, $docm);
    }
  }
  vaultWrite($flag, ['at' => gmdate('c'), 'ok' => true]);
}

function wsPushSecret(): string {
  $f = DATA_DIR . '/crynsys/.wskey';
  if (!is_file($f)) {
    if (!is_dir(dirname($f))) mkdir(dirname($f), 0700, true);
    file_put_contents($f, bin2hex(random_bytes(32)), LOCK_EX);
    chmod($f, 0600);
  }
  $k = trim((string)file_get_contents($f));
  return $k !== '' ? $k : 'deny';
}

function wsEmit(string $type, array $payload): void {
  $doc = vaultRead(VAULT_WS, ['events' => []]);
  $doc['events'][] = ['t' => time(), 'type' => $type, 'data' => $payload];
  if (count($doc['events']) > 400) $doc['events'] = array_slice($doc['events'], -200);
  vaultWrite(VAULT_WS, $doc);
  $sock = @fsockopen('127.0.0.1', 18765, $e, $s, 0.15);
  if ($sock) {
    $body = json_encode(['type' => $type, 'data' => $payload], JSON_UNESCAPED_UNICODE);
    $tok = wsPushSecret();
    $req = "POST /push HTTP/1.1\r\nHost: 127.0.0.1\r\nContent-Type: application/json\r\nContent-Length: " . strlen($body) . "\r\nX-Cryn-Push: " . $tok . "\r\nConnection: close\r\n\r\n" . $body;
    fwrite($sock, $req);
    fclose($sock);
  }
}

function shopDoc(): array {
  return vaultRead(VAULT_SHOP, ['items' => [], 'next' => 1]);
}

function saveShop(array $doc): void {
  vaultWrite(VAULT_SHOP, $doc);
}

function rightName(int $n): string {
  return 'r' . max(1, min(24, $n));
}
