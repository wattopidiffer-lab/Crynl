<?php
declare(strict_types=1);

function v1Body(): array {
  $raw = file_get_contents('php://input') ?: '';
  if (strlen($raw) > MAX_BODY) fail('Слишком большой запрос', 413);
  if ($raw === '') return $_GET ?: [];
  $in = json_decode($raw, true);
  if (!is_array($in)) fail('JSON');
  return $in;
}

function v1Path(): string {
  $p = (string)($_SERVER['PATH_INFO'] ?? '');
  if ($p === '') {
    $uri = (string)($_SERVER['REQUEST_URI'] ?? '');
    if (preg_match('#/v1(?:\.php)?(/[A-Za-z0-9_./-]*)#', $uri, $m)) $p = $m[1];
  }
  $q = (string)($_GET['path'] ?? '');
  if ($p === '' && $q !== '') $p = $q;
  $p = '/' . trim($p, '/');
  if ($p === '/') $p = '';
  return $p;
}

function v1Token(array $in): string {
  $h = (string)($_SERVER['HTTP_AUTHORIZATION'] ?? '');
  if (stripos($h, 'Bearer ') === 0) return trim(substr($h, 7));
  return (string)($in['token'] ?? '');
}

function v1NeedUser(array $in): array {
  $in['token'] = v1Token($in);
  return needUser($in);
}

function v1Ok(array $data = []): void {
  echo json_encode(['ok' => true, 'data' => $data, 'error' => null], JSON_UNESCAPED_UNICODE);
  exit;
}

function v1Fail(string $code, string $message, int $http = 200): void {
  http_response_code($http === 200 ? 200 : $http);
  echo json_encode(['ok' => false, 'data' => null, 'error' => ['code' => $code, 'message' => $message]], JSON_UNESCAPED_UNICODE);
  exit;
}

function refreshTokenOf(array &$u): string {
  $rt = bin2hex(random_bytes(32));
  $u['refreshHash'] = hash('sha256', $rt);
  $u['refreshExp'] = time() + 30 * 86400;
  return $rt;
}

function tfaSecretNew(): string {
  $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
  $raw = random_bytes(20);
  $bits = '';
  foreach (str_split($raw) as $c) $bits .= str_pad(decbin(ord($c)), 8, '0', STR_PAD_LEFT);
  $out = '';
  foreach (str_split($bits, 5) as $chunk) {
    if (strlen($chunk) < 5) $chunk = str_pad($chunk, 5, '0');
    $out .= $alphabet[bindec($chunk)];
  }
  return $out;
}

function tfaDecode(string $secret): string {
  $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
  $secret = strtoupper(preg_replace('/[^A-Z2-7]/', '', $secret));
  $bits = '';
  for ($i = 0; $i < strlen($secret); $i++) {
    $n = strpos($alphabet, $secret[$i]);
    if ($n === false) continue;
    $bits .= str_pad(decbin($n), 5, '0', STR_PAD_LEFT);
  }
  $out = '';
  foreach (str_split($bits, 8) as $chunk) {
    if (strlen($chunk) < 8) continue;
    $out .= chr(bindec($chunk));
  }
  return $out;
}

function tfaCode(string $secret, int $slot = 0): string {
  $t = intdiv(time(), 30) + $slot;
  $bin = pack('N*', 0, $t);
  $key = tfaDecode($secret);
  $hash = hash_hmac('sha1', $bin, $key, true);
  $o = ord($hash[19]) & 0x0f;
  $un = unpack('N', substr($hash, $o, 4));
  $code = ($un[1] & 0x7fffffff) % 1000000;
  return str_pad((string)$code, 6, '0', STR_PAD_LEFT);
}

function tfaCheck(string $secret, string $code): bool {
  $code = preg_replace('/\D+/', '', $code);
  if (strlen($code) !== 6) return false;
  for ($i = -1; $i <= 1; $i++) {
    if (hash_equals(tfaCode($secret, $i), $code)) return true;
  }
  return false;
}

function groupFile(string $id): string {
  $id = preg_replace('/[^A-Za-z0-9_-]/', '', $id);
  $d = VAULT_CHAT . '/groups';
  if (!is_dir($d)) mkdir($d, 0700, true);
  return $d . '/' . $id . '.bin';
}

function loadGroup(string $id): ?array {
  $id = preg_replace('/^group:/', '', $id);
  $f = groupFile($id);
  if (!is_file($f)) return null;
  $g = vaultRead($f, []);
  return $g ?: null;
}

function saveGroup(array $g): void {
  $id = (string)($g['id'] ?? '');
  if ($id === '') return;
  vaultWrite(groupFile($id), $g);
}

function inviteFile(string $code): string {
  $code = preg_replace('/[^A-Za-z0-9]/', '', $code);
  $d = VAULT_SYS . '/invites';
  if (!is_dir($d)) mkdir($d, 0700, true);
  return $d . '/' . vaultName($code) . '.bin';
}

function folderDoc(array $u): array {
  return ['items' => array_values($u['folders'] ?? [])];
}
