<?php
declare(strict_types=1);

$method = strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET'));
$path = v1Path();
$in = ($method === 'GET') ? $_GET : v1Body();
$in['token'] = v1Token($in);
$parts = array_values(array_filter(explode('/', trim($path, '/'))));
$a = $parts[0] ?? '';
$b = $parts[1] ?? '';
$c = $parts[2] ?? '';
$d = $parts[3] ?? '';

header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-Cryn-Client, Authorization');
if ($method === 'OPTIONS') {
  http_response_code(204);
  exit;
}

function v1LimitsPayload(?array $u): array {
  $lim = limitsFor($u);
  return $lim + ['codes' => ['E_AUTH', 'E_FORBIDDEN', 'E_NOT_FOUND', 'E_RATE', 'E_VALIDATION']];
}

function v1AuthPack(array $u, string $access, string $refresh = ''): array {
  $out = [
    'token' => $access,
    'access_token' => $access,
    'expires_in' => TOKEN_TTL,
    'user' => publicUser($u, true),
    'limits' => v1LimitsPayload($u)
  ];
  if ($refresh !== '') $out['refresh_token'] = $refresh;
  return $out;
}

function v1Issue(array &$u): array {
  $access = issueToken($u);
  $refresh = refreshTokenOf($u);
  wsTokenPut($access, (string)$u['id'], (string)$u['nick'], (int)$u['tokenExp']);
  return [$access, $refresh];
}

if ($a === '' || ($a === 'meta' && $b === '')) {
  v1Ok([
    'name' => 'CrynChat',
    'version' => 'v1',
    'resources' => ['auth', 'users', 'threads', 'messages', 'media', 'reactions', 'presence', 'admin', 'dms', 'folders', 'invites', 'reports'],
    'limits' => v1LimitsPayload(null)
  ]);
}

if ($a === 'auth' && $b === 'register' && $method === 'POST') {
  rateFor(['id' => 'guest', 'role' => 'user'], 'reg');
  $nick = trim((string)($in['nick'] ?? ''));
  $email = strtolower(trim((string)($in['email'] ?? '')));
  $pass = (string)($in['password'] ?? '');
  if (!nickOk($nick)) v1Fail('E_VALIDATION', 'Ник: 3–20 латиница, цифры, _');
  if (!filter_var($email, FILTER_VALIDATE_EMAIL)) v1Fail('E_VALIDATION', 'Плохая почта');
  if (strlen($pass) < 8 || strlen($pass) > 72) v1Fail('E_VALIDATION', 'Пароль 8–72 символа');
  foreach (users()['users'] as $u) {
    if (strcasecmp($u['nick'], $nick) === 0 || strcasecmp($u['email'], $email) === 0) v1Fail('E_VALIDATION', 'Неверные данные');
  }
  $code = makeCode();
  $needCode = !empty(meta()['requireVerify']);
  $newUser = [
    'id' => 'u' . bin2hex(random_bytes(4)),
    'nick' => $nick,
    'email' => $email,
    'hash' => password_hash($pass, PASSWORD_DEFAULT),
    'token' => '',
    'gifs' => [],
    'created' => gmdate('c'),
    'verified' => !$needCode,
    'verifyHash' => $needCode ? password_hash($code, PASSWORD_DEFAULT) : '',
    'verifyUntil' => $needCode ? time() + 1800 : 0,
    'avatar' => '', 'bio' => '', 'telegram' => '', 'discord' => '', 'youtube' => '', 'tiktok' => '',
    'status' => '', 'muted' => false, 'blocked' => [], 'role' => 'user', 'warns' => [],
    'banned' => false, 'banUntil' => 0, 'banReason' => '', 'muteUntil' => 0, 'muteReason' => '',
    'device' => deviceId($in), 'pendingDevice' => '', 'pendingCode' => '',
    'stickersSaved' => [], 'cleared' => [], 'pinnedChats' => [], 'archived' => [], 'folders' => [],
    'saved' => [], 'pirikas' => 0, 'rights' => [],
    'cosmetics' => ['owned' => [], 'avatarHat' => '', 'listHat' => '', 'profileHat' => ''],
    'channelId' => '', 'tfa' => false, 'tfaSecret' => '', 'sessions' => []
  ];
  [$access, $refresh] = v1Issue($newUser);
  $doc = users();
  $doc['users'][] = $newUser;
  saveUsers($doc);
  lsDir($newUser['id']);
  savesDir($newUser['id']);
  if ($needCode) sendCodeMail($email, $code, 'подтверждения почты');
  v1Ok(v1AuthPack($newUser, $access, $refresh) + ['needVerify' => $needCode, 'mailed' => $needCode]);
}

if ($a === 'auth' && $b === 'login' && $method === 'POST') {
  rateFor(['id' => 'guest', 'role' => 'user'], 'login');
  $email = strtolower(trim((string)($in['email'] ?? '')));
  $pass = (string)($in['password'] ?? '');
  $otp = preg_replace('/\D+/', '', (string)($in['otp'] ?? $in['code'] ?? ''));
  $dev = deviceId($in);
  $doc = users();
  foreach ($doc['users'] as &$u) {
    if (strcasecmp((string)$u['email'], $email) !== 0) continue;
    if (!empty($u['needPassReset'])) v1Fail('E_AUTH', 'Пароль сброшен администратором. Задайте новый пароль');
    if (!password_verify($pass, (string)$u['hash'])) v1Fail('E_AUTH', 'Неверные данные');
    if (!empty($u['tfa']) && !empty($u['tfaSecret'])) {
      if ($otp === '' || !tfaCheck((string)$u['tfaSecret'], $otp)) v1Fail('E_AUTH', 'Нужен код 2FA');
    }
    $old = (string)($u['device'] ?? '');
    if ($old !== '' && $old !== $dev) {
      $code = makeCode();
      $u['pendingDevice'] = $dev;
      $u['pendingCode'] = password_hash($code, PASSWORD_DEFAULT);
      $u['pendingUntil'] = time() + 1800;
      saveUsers($doc);
      sendCodeMail($u['email'], $code, 'входа с нового устройства');
      v1Ok(['needDevice' => true, 'mailed' => true, 'email' => $u['email']]);
    }
    [$access, $refresh] = v1Issue($u);
    $u['device'] = $dev;
    saveUsers($doc);
    v1Ok(v1AuthPack($u, $access, $refresh) + ['needVerify' => !isVerified($u), 'verified' => isVerified($u)]);
  }
  v1Fail('E_AUTH', 'Неверные данные');
}

if ($a === 'auth' && $b === 'refresh' && $method === 'POST') {
  rateFor(['id' => 'guest', 'role' => 'user'], 'refresh');
  $rt = (string)($in['refresh_token'] ?? $in['refresh'] ?? '');
  if ($rt === '' || strlen($rt) < 32) v1Fail('E_AUTH', 'Нужен вход');
  $h = hash('sha256', $rt);
  foreach (allUsers() as $u) {
    if (!hash_equals((string)($u['refreshHash'] ?? ''), $h)) continue;
    if ((int)($u['refreshExp'] ?? 0) < time()) v1Fail('E_AUTH', 'Нужен вход');
    [$access, $refresh] = v1Issue($u);
    saveUserDoc($u);
    v1Ok(v1AuthPack($u, $access, $refresh));
  }
  v1Fail('E_AUTH', 'Нужен вход');
}

if ($a === 'auth' && $b === 'logout' && $method === 'POST') {
  $u = v1NeedUser($in);
  patchUser($u['id'], function (&$x) {
    $x['token'] = bin2hex(random_bytes(24));
    $x['tokenHash'] = tokenHash($x['token']);
    $x['tokenExp'] = 0;
    $x['refreshHash'] = '';
    $x['refreshExp'] = 0;
  });
  v1Ok(['logged_out' => true]);
}

if ($a === 'auth' && $b === 'verify' && $method === 'POST') {
  $u = v1NeedUser($in);
  rateFor($u, 'verify');
  $code = preg_replace('/\D+/', '', (string)($in['code'] ?? ''));
  if (strlen($code) !== 6) v1Fail('E_VALIDATION', 'Код из 6 цифр');
  if (!empty($u['verified'])) v1Ok(['verified' => true, 'user' => publicUser($u, true)]);
  if ((int)($u['verifyUntil'] ?? 0) < time()) v1Fail('E_AUTH', 'Код истёк. Запроси новый');
  if (empty($u['verifyHash']) || !password_verify($code, $u['verifyHash'])) v1Fail('E_AUTH', 'Неверный код');
  $saved = patchUser($u['id'], function (&$x) {
    $x['verified'] = true;
    $x['verifyHash'] = '';
    $x['verifyUntil'] = 0;
  });
  v1Ok(['verified' => true, 'user' => publicUser($saved, true)]);
}

if ($a === 'auth' && $b === 'resend' && $method === 'POST') {
  $u = v1NeedUser($in);
  rateFor($u, 'resend');
  if (!empty($u['verified'])) v1Ok(['verified' => true, 'mailed' => false]);
  $code = makeCode();
  patchUser($u['id'], function (&$x) use ($code) {
    $x['verifyHash'] = password_hash($code, PASSWORD_DEFAULT);
    $x['verifyUntil'] = time() + 1800;
  });
  $okMail = sendCodeMail($u['email'], $code, 'подтверждения почты');
  v1Ok(['needVerify' => true, 'mailed' => $okMail]);
}

if ($a === 'auth' && $b === 'confirm-device' && $method === 'POST') {
  rateFor(['id' => 'guest', 'role' => 'user'], 'login');
  $email = strtolower(trim((string)($in['email'] ?? '')));
  $code = preg_replace('/\D+/', '', (string)($in['code'] ?? ''));
  $pass = (string)($in['password'] ?? '');
  $dev = deviceId($in);
  $doc = users();
  foreach ($doc['users'] as &$u) {
    if (strcasecmp((string)$u['email'], $email) !== 0) continue;
    if (!password_verify($pass, (string)$u['hash'])) v1Fail('E_AUTH', 'Неверные данные');
    if (strlen($code) !== 6) v1Fail('E_VALIDATION', 'Код из 6 цифр');
    if ((int)($u['pendingUntil'] ?? 0) < time()) v1Fail('E_AUTH', 'Код истёк');
    if (empty($u['pendingCode']) || !password_verify($code, $u['pendingCode'])) v1Fail('E_AUTH', 'Неверный код');
    [$access, $refresh] = v1Issue($u);
    $u['device'] = $dev;
    $u['pendingDevice'] = '';
    $u['pendingCode'] = '';
    $u['pendingUntil'] = 0;
    saveUsers($doc);
    v1Ok(v1AuthPack($u, $access, $refresh));
  }
  v1Fail('E_AUTH', 'Неверные данные');
}

if ($a === 'auth' && $b === 'password' && $method === 'POST') {
  $u = v1NeedUser($in);
  rateFor($u, 'pass');
  $old = (string)($in['old'] ?? $in['oldPass'] ?? '');
  $pass = (string)($in['password'] ?? $in['pass'] ?? '');
  $again = (string)($in['again'] ?? $in['repeat'] ?? $pass);
  if (strlen($pass) < 8 || strlen($pass) > 72) v1Fail('E_VALIDATION', 'Пароль 8–72 символа');
  if ($pass !== $again) v1Fail('E_VALIDATION', 'Пароли не совпадают');
  if (empty($u['needPassReset'])) {
    if ($old === '' || !password_verify($old, (string)($u['hash'] ?? ''))) v1Fail('E_AUTH', 'Неверные данные');
  }
  $plain = '';
  $refresh = '';
  $saved = patchUser($u['id'], function (&$t) use ($pass, &$plain, &$refresh) {
    $t['hash'] = password_hash($pass, PASSWORD_DEFAULT);
    $t['needPassReset'] = false;
    $plain = issueToken($t);
    $refresh = refreshTokenOf($t);
  });
  wsTokenPut($plain, (string)$saved['id'], (string)$saved['nick'], (int)$saved['tokenExp']);
  v1Ok(v1AuthPack($saved, $plain, $refresh));
}

if ($a === 'auth' && $b === 'tfa' && $c === 'setup' && $method === 'POST') {
  $u = v1NeedUser($in);
  $secret = tfaSecretNew();
  patchUser($u['id'], function (&$x) use ($secret) { $x['tfaPending'] = $secret; });
  v1Ok(['secret' => $secret, 'otpauth' => 'otpauth://totp/CrynChat:' . rawurlencode((string)$u['nick']) . '?secret=' . $secret . '&issuer=CrynChat']);
}

if ($a === 'auth' && $b === 'tfa' && $c === 'enable' && $method === 'POST') {
  $u = v1NeedUser($in);
  rateFor($u, 'tfa');
  $secret = (string)($u['tfaPending'] ?? '');
  $code = (string)($in['code'] ?? $in['otp'] ?? '');
  if ($secret === '' || !tfaCheck($secret, $code)) v1Fail('E_AUTH', 'Неверный код');
  $saved = patchUser($u['id'], function (&$x) use ($secret) {
    $x['tfa'] = true;
    $x['tfaSecret'] = $secret;
    $x['tfaPending'] = '';
  });
  v1Ok(['tfa' => true, 'user' => publicUser($saved, true)]);
}

if ($a === 'auth' && $b === 'tfa' && $c === 'disable' && $method === 'POST') {
  $u = v1NeedUser($in);
  rateFor($u, 'tfa');
  $pass = (string)($in['password'] ?? '');
  $code = (string)($in['code'] ?? $in['otp'] ?? '');
  if ($pass === '' || !password_verify($pass, (string)($u['hash'] ?? ''))) v1Fail('E_AUTH', 'Неверные данные');
  if (!empty($u['tfaSecret']) && !tfaCheck((string)$u['tfaSecret'], $code)) v1Fail('E_AUTH', 'Неверный код');
  $saved = patchUser($u['id'], function (&$x) {
    $x['tfa'] = false;
    $x['tfaSecret'] = '';
  });
  v1Ok(['tfa' => false, 'user' => publicUser($saved, true)]);
}

if ($a === 'auth' && $b === 'sessions' && $c === '' && $method === 'GET') {
  $u = v1NeedUser($in);
  v1Ok(['items' => array_values($u['sessions'] ?? [])]);
}

if ($a === 'auth' && $b === 'sessions' && $c !== '' && $d === 'revoke' && $method === 'POST') {
  $u = v1NeedUser($in);
  $id = cut($c, 64);
  $plain = '';
  $saved = patchUser($u['id'], function (&$x) use ($id, &$plain) {
    $x['sessions'] = array_values(array_filter($x['sessions'] ?? [], fn($s) => ($s['id'] ?? '') !== $id));
    if (($x['device'] ?? '') === $id) {
      $x['device'] = '';
      $plain = issueToken($x);
    }
  });
  v1Ok(['items' => $saved['sessions'] ?? [], 'token' => $plain !== '' ? $plain : null]);
}

if ($a === 'auth' && $b === 'limits' && $method === 'GET') {
  $u = userByToken(v1Token($in));
  v1Ok(v1LimitsPayload($u ?: null));
}

if ($a === 'users' && $b === 'me' && ($method === 'GET' || $b === 'me' && $c === '')) {
  if ($c === '' && $method === 'GET') {
    $u = v1NeedUser($in);
    $cfg = meta();
    v1Ok(publicUser($u, true) + [
      'needVerify' => !isVerified($u),
      'unread' => unreadCount($u),
      'limits' => v1LimitsPayload($u),
      'settings' => [
        'requireVerify' => !empty($cfg['requireVerify']),
        'allowGifs' => !empty($cfg['allowGifs']),
        'allowStickers' => !empty($cfg['allowStickers']),
        'allowUploads' => !empty($cfg['allowUploads']),
        'allowPolls' => !empty($cfg['allowPolls']),
        'allowDms' => !empty($cfg['allowDms']),
        'readonly' => !empty($cfg['readonly']),
        'slowMode' => (int)($cfg['slowMode'] ?? 0)
      ],
      'ws' => ['url' => WS_PUBLIC, 'port' => WS_PORT]
    ]);
  }
}

if ($a === 'users' && $b === 'me' && ($method === 'PATCH' || $method === 'POST') && $c === '') {
  $u = v1NeedUser($in);
  rateFor($u, 'edit');
  $saved = patchUser($u['id'], function (&$x) use ($in) {
    foreach (['bio' => 360, 'telegram' => 64, 'discord' => 64, 'youtube' => 80, 'tiktok' => 64, 'status' => 24] as $k => $n) {
      if (isset($in[$k])) $x[$k] = cut((string)$in[$k], $n);
    }
    if (isset($in['listStyle'])) $x['listStyle'] = styleOk((string)$in['listStyle']);
    if (isset($in['bubbleStyle'])) $x['bubbleStyle'] = bubbleOk((string)$in['bubbleStyle']);
    if (isset($in['nameColor'])) $x['nameColor'] = colorOk((string)$in['nameColor']);
  });
  v1Ok(['user' => publicUser($saved, true)]);
}

if ($a === 'users' && $b === 'search' && $method === 'GET') {
  $u = v1NeedUser($in);
  rateFor($u, 'find');
  $q = strtolower(cut((string)($in['q'] ?? ''), 20));
  $out = [];
  foreach (users()['users'] as $x) {
    if ($x['id'] === $u['id']) continue;
    if ($q !== '' && strpos(strtolower((string)$x['nick']), $q) === false) continue;
    $out[] = publicUser($x);
    if (count($out) >= 20) break;
  }
  v1Ok(['items' => $out]);
}

if ($a === 'users' && $b === 'me' && $c === 'privacy') {
  $u = v1NeedUser($in);
  if ($method === 'PATCH' || $method === 'POST') {
    $saved = patchUser($u['id'], function (&$x) use ($in) {
      $p = $x['privacy'] ?? ['whoWrite' => 'all', 'allowFrom' => [], 'denyFrom' => []];
      if (isset($in['whoWrite']) && in_array((string)$in['whoWrite'], ['all', 'contacts', 'nobody'], true)) $p['whoWrite'] = (string)$in['whoWrite'];
      if (isset($in['allowFrom']) && is_array($in['allowFrom'])) $p['allowFrom'] = array_values(array_filter(array_map(fn($n) => cut((string)$n, 20), $in['allowFrom'])));
      if (isset($in['denyFrom']) && is_array($in['denyFrom'])) $p['denyFrom'] = array_values(array_filter(array_map(fn($n) => cut((string)$n, 20), $in['denyFrom'])));
      $x['privacy'] = $p;
    });
    $u = $saved;
  }
  v1Ok(['privacy' => $u['privacy'] ?? ['whoWrite' => 'all', 'allowFrom' => [], 'denyFrom' => []]]);
}

if ($a === 'users' && $b === 'me' && $c === 'block' && $method === 'POST') {
  $u = v1NeedUser($in);
  $nick = cut((string)($in['nick'] ?? ''), 20);
  if (!nickOk($nick)) v1Fail('E_VALIDATION', 'Ник: 3–20 латиница, цифры, _');
  $saved = patchUser($u['id'], function (&$x) use ($nick) {
    $b = $x['blocked'] ?? [];
    if (in_array($nick, $b, true)) $b = array_values(array_filter($b, fn($n) => $n !== $nick));
    else $b[] = $nick;
    $x['blocked'] = $b;
  });
  v1Ok(['blocked' => $saved['blocked'] ?? []]);
}

if ($a === 'users' && $b !== '' && $b !== 'me' && $b !== 'search' && $c === '' && $method === 'GET') {
  v1NeedUser($in);
  $x = findUserByNick($b) ?: findUserById($b);
  if (!$x) v1Fail('E_NOT_FOUND', 'Нет такого');
  v1Ok(['user' => publicUser($x)]);
}

if ($a === 'threads' && $b === '' && $method === 'GET') {
  $u = v1NeedUser($in);
  $items = array_values(meta()['chats'] ?? []);
  foreach ($items as &$citem) {
    $id = (string)($citem['id'] ?? '');
    $citem['can_read'] = aclCan($u, 'threads.read', ['thread' => $id]);
    $citem['can_write'] = aclCan($u, 'threads.write', ['thread' => $id]);
  }
  $gdir = VAULT_CHAT . '/groups';
  if (is_dir($gdir)) {
    foreach (scandir($gdir) as $fn) {
      if (substr($fn, -4) !== '.bin') continue;
      $g = vaultRead($gdir . '/' . $fn, []);
      if (!$g || empty($g['id'])) continue;
      $tid = 'group:' . $g['id'];
      if (!inThread($u, $tid)) continue;
      $items[] = [
        'id' => $tid,
        'title' => $g['title'] ?? 'Группа',
        'about' => $g['about'] ?? '',
        'kind' => 'group',
        'avatar' => $g['avatar'] ?? '',
        'members' => count($g['members'] ?? []),
        'can_read' => true,
        'can_write' => aclCan($u, 'threads.write', ['thread' => $tid])
      ];
    }
  }
  v1Ok(['items' => withLast($items, $u)]);
}

if ($a === 'threads' && $b === '' && $method === 'POST') {
  $u = v1NeedUser($in);
  needVerified($u);
  rateFor($u, 'group');
  $title = cut((string)($in['title'] ?? $in['name'] ?? ''), 40);
  if ($title === '') v1Fail('E_VALIDATION', 'Название');
  $id = 'g' . bin2hex(random_bytes(4));
  $g = [
    'id' => $id,
    'title' => $title,
    'about' => cut((string)($in['about'] ?? ''), 200),
    'owner' => $u['id'],
    'members' => [$u['id']],
    'admins' => [$u['id']],
    'created' => gmdate('c'),
    'public' => !empty($in['public']),
    'readonly' => false,
    'avatar' => ''
  ];
  saveGroup($g);
  v1Ok(['thread' => 'group:' . $id, 'group' => $g]);
}

if ($a === 'threads' && $b !== '' && $c === '' && $method === 'GET') {
  $u = v1NeedUser($in);
  $tid = rawurldecode($b);
  if (!aclCan($u, 'threads.read', ['thread' => $tid])) v1Fail('E_FORBIDDEN', 'Нет доступа');
  $info = chatInfo($tid);
  if (strpos($tid, 'group:') === 0) {
    $g = loadGroup($tid);
    if ($g) $info = $g + ['id' => $tid, 'kind' => 'group'];
  }
  $info['can_read'] = true;
  $info['can_write'] = aclCan($u, 'threads.write', ['thread' => $tid]);
  $info['can_moderate'] = aclCan($u, 'messages.moderate', ['thread' => $tid]);
  v1Ok(['thread' => $info]);
}

if ($a === 'threads' && $b !== '' && $c === 'join' && $method === 'POST') {
  $u = v1NeedUser($in);
  $tid = rawurldecode($b);
  if (strpos($tid, 'group:') !== 0) v1Fail('E_FORBIDDEN', 'Нет доступа');
  $g = loadGroup($tid);
  if (!$g) v1Fail('E_NOT_FOUND', 'Нет такого');
  if (empty($g['public']) && ($g['owner'] ?? '') !== $u['id']) v1Fail('E_FORBIDDEN', 'Нет доступа');
  $g['members'] = array_values(array_unique(array_merge($g['members'] ?? [], [$u['id']])));
  saveGroup($g);
  v1Ok(['joined' => true, 'members' => count($g['members'])]);
}

if ($a === 'threads' && $b !== '' && $c === 'leave' && $method === 'POST') {
  $u = v1NeedUser($in);
  $tid = rawurldecode($b);
  $g = loadGroup($tid);
  if (!$g) v1Fail('E_NOT_FOUND', 'Нет такого');
  $g['members'] = array_values(array_filter($g['members'] ?? [], fn($id) => $id !== $u['id']));
  saveGroup($g);
  v1Ok(['left' => true]);
}

if ($a === 'threads' && $b !== '' && $c === 'invite' && $method === 'POST') {
  $u = v1NeedUser($in);
  rateFor($u, 'invite');
  $tid = rawurldecode($b);
  if (!aclCan($u, 'threads.read', ['thread' => $tid])) v1Fail('E_FORBIDDEN', 'Нет доступа');
  $g = loadGroup($tid);
  if ($g && ($g['owner'] ?? '') !== $u['id'] && !in_array($u['id'], $g['admins'] ?? [], true) && !isAdmin($u)) {
    v1Fail('E_FORBIDDEN', 'Нет доступа');
  }
  $code = bin2hex(random_bytes(6));
  vaultWrite(inviteFile($code), ['code' => $code, 'thread' => $tid, 'by' => $u['id'], 'exp' => time() + 7 * 86400, 'uses' => 0, 'max' => max(1, (int)($in['max'] ?? 32))]);
  v1Ok(['code' => $code, 'url' => 'crynchat://join/' . $code]);
}

if ($a === 'invites' && $b !== '' && $c === 'join' && $method === 'POST') {
  $u = v1NeedUser($in);
  $code = preg_replace('/[^A-Za-z0-9]/', '', $b);
  $inv = vaultRead(inviteFile($code), []);
  if (!$inv || (int)($inv['exp'] ?? 0) < time()) v1Fail('E_NOT_FOUND', 'Нет такого');
  if ((int)($inv['uses'] ?? 0) >= (int)($inv['max'] ?? 32)) v1Fail('E_RATE', 'Слишком часто. Подожди.');
  $tid = (string)($inv['thread'] ?? '');
  $g = loadGroup($tid);
  if ($g) {
    $g['members'] = array_values(array_unique(array_merge($g['members'] ?? [], [$u['id']])));
    saveGroup($g);
  }
  $inv['uses'] = (int)($inv['uses'] ?? 0) + 1;
  vaultWrite(inviteFile($code), $inv);
  v1Ok(['thread' => $tid, 'joined' => true]);
}

if ($a === 'threads' && $b !== '' && $c === 'members' && $method === 'GET') {
  $u = v1NeedUser($in);
  $tid = rawurldecode($b);
  if (!aclCan($u, 'threads.read', ['thread' => $tid])) v1Fail('E_FORBIDDEN', 'Нет доступа');
  $g = loadGroup($tid);
  $ids = $g['members'] ?? [];
  $items = [];
  foreach ($ids as $id) {
    $x = findUserById((string)$id);
    if ($x) $items[] = publicUser($x);
  }
  v1Ok(['items' => $items]);
}

if ($a === 'threads' && $b !== '' && $c === 'kick' && $method === 'POST') {
  $u = v1NeedUser($in);
  $tid = rawurldecode($b);
  $g = loadGroup($tid);
  if (!$g) v1Fail('E_NOT_FOUND', 'Нет такого');
  if (($g['owner'] ?? '') !== $u['id'] && !isAdmin($u)) v1Fail('E_FORBIDDEN', 'Нет доступа');
  $nick = trim((string)($in['nick'] ?? $in['uid'] ?? ''));
  $x = findUserByNick($nick) ?: findUserById($nick);
  if (!$x) v1Fail('E_NOT_FOUND', 'Нет такого');
  $g['members'] = array_values(array_filter($g['members'] ?? [], fn($id) => $id !== $x['id']));
  saveGroup($g);
  v1Ok(['kicked' => $x['nick']]);
}

if ($a === 'threads' && $b !== '' && $c === 'messages' && $method === 'GET') {
  $u = v1NeedUser($in);
  $tid = rawurldecode($b);
  if (!aclCan($u, 'threads.read', ['thread' => $tid])) v1Fail('E_FORBIDDEN', 'Нет доступа');
  rateFor($u, 'read');
  $before = (int)($in['before_seq'] ?? $in['before'] ?? 0);
  $after = (int)($in['after_seq'] ?? $in['after'] ?? 0);
  $limit = min(80, max(1, (int)($in['limit'] ?? 40)));
  $block = $u['blocked'] ?? [];
  $clearedAt = (int)(($u['cleared'][$tid] ?? 0));
  $pool = [];
  foreach (scanDays($tid, 14) as $day) {
    foreach ((msgsOf($tid, $day)['items'] ?? []) as $m) $pool[] = $m;
  }
  $all = [];
  foreach ($pool as $m) {
    if (($m['thread'] ?? $tid) !== $tid) continue;
    if ($tid === 'system' && ($m['to'] ?? '') !== '' && ($m['to'] ?? '') !== $u['id']) continue;
    if ($tid === 'saved' && ($m['uid'] ?? '') !== $u['id']) continue;
    if (in_array((string)($m['nick'] ?? ''), $block, true)) continue;
    if (!empty($m['hiddenFor']) && in_array($u['id'], $m['hiddenFor'], true)) continue;
    if ($clearedAt) {
      $ts = strtotime((string)($m['at'] ?? '')) ?: 0;
      if ($ts && $ts <= $clearedAt) continue;
    }
    if (!empty($m['deleted'])) {
      $m['text'] = '';
      $m['url'] = null;
      $m['caption'] = '';
    }
    unset($m['reactors']);
    if (isset($m['poll']) && is_array($m['poll'])) unset($m['poll']['voters']);
    $seq = (int)($m['seq'] ?? 0);
    if ($before > 0 && $seq >= $before) continue;
    if ($after > 0 && $seq <= $after) continue;
    $all[] = $m;
  }
  usort($all, function ($x, $y) {
    return ((int)($y['seq'] ?? 0)) <=> ((int)($x['seq'] ?? 0));
  });
  $slice = array_slice($all, 0, $limit);
  $minSeq = 0;
  $maxSeq = 0;
  foreach ($slice as $m) {
    $s = (int)($m['seq'] ?? 0);
    if ($s && ($minSeq === 0 || $s < $minSeq)) $minSeq = $s;
    if ($s > $maxSeq) $maxSeq = $s;
  }
  v1Ok(['items' => $slice, 'done' => count($all) <= $limit, 'before_seq' => $minSeq, 'after_seq' => $maxSeq, 'thread' => $tid]);
}

if ($a === 'threads' && $b !== '' && $c === 'messages' && $method === 'POST') {
  $u = v1NeedUser($in);
  needVerified($u);
  $tid = rawurldecode($b);
  if (!aclCan($u, 'threads.write', ['thread' => $tid])) v1Fail('E_FORBIDDEN', 'Нет доступа');
  rateFor($u, 'send');
  $lim = limitsFor($u);
  $text = trim((string)($in['text'] ?? ''));
  $kind = (string)($in['kind'] ?? 'text');
  if (!in_array($kind, ['text', 'gif', 'sticker', 'image', 'audio', 'poll', 'voice'], true)) $kind = 'text';
  $len = function_exists('mb_strlen') ? mb_strlen($text) : strlen($text);
  if ($kind === 'text' && ($text === '' || $len > (int)$lim['text'])) v1Fail('E_VALIDATION', 'Текст 1–4096');
  $mentions = [];
  if (preg_match_all('/@([A-Za-z0-9_]{3,20})/', $text, $mm)) {
    $uniq = array_slice(array_unique($mm[1]), 0, (int)$lim['mentions']);
    if (count($mm[1]) > 40) v1Fail('E_RATE', 'Слишком часто. Подожди.');
    rateFor($u, 'mention');
    foreach ($uniq as $mn) {
      $ou = findUserByNick($mn);
      if ($ou && $ou['id'] !== $u['id']) {
        $mentions[] = $ou['nick'];
        notify($ou['id'], $u['nick'] . ' упомянул тебя: ' . cut($text, 120), ['from' => $u['nick'], 'srcThread' => $tid]);
      }
    }
  }
  $item = [
    'id' => id(),
    'at' => gmdate('c'),
    'nick' => $u['nick'],
    'uid' => $u['id'],
    'avatar' => $u['avatar'] ?? '',
    'kind' => $kind,
    'text' => cut($text, (int)$lim['text']),
    'url' => cut((string)($in['url'] ?? ''), 2000) ?: null,
    'name' => cut((string)($in['name'] ?? ''), 80) ?: null,
    'pinned' => false,
    'reactions' => [],
    'thread' => $tid,
    'mentions' => $mentions,
    'silent' => !empty($in['silent'])
  ];
  $replyTo = cut((string)($in['replyTo'] ?? $in['reply_to'] ?? ''), 24);
  if ($replyTo !== '') {
    $src = findMsg($replyTo);
    if ($src && canAccessMsg($u, $src)) {
      $item['reply'] = ['id' => $src['id'], 'nick' => $src['nick'] ?? '', 'text' => cut((string)($src['text'] ?? $src['kind'] ?? ''), 80), 'kind' => $src['kind'] ?? 'text'];
    }
  }
  pushMsg($item);
  v1Ok(['item' => $item]);
}

if ($a === 'threads' && $b !== '' && $c === 'typing' && $method === 'POST') {
  $u = v1NeedUser($in);
  $tid = rawurldecode($b);
  if (!aclCan($u, 'threads.read', ['thread' => $tid])) v1Fail('E_FORBIDDEN', 'Нет доступа');
  wsEmit('typing', ['thread' => $tid, 'nick' => $u['nick'], 'uid' => $u['id']]);
  v1Ok(['ok' => true]);
}

if ($a === 'threads' && $b !== '' && $c === 'read' && $method === 'POST') {
  $u = v1NeedUser($in);
  $tid = rawurldecode($b);
  if (!aclCan($u, 'threads.read', ['thread' => $tid])) v1Fail('E_FORBIDDEN', 'Нет доступа');
  $doc = live();
  $doc['read'][$u['id'] . ':' . $tid] = time();
  if (!empty($in['id'])) $doc['readMsg'][$u['id'] . ':' . $tid] = cut((string)$in['id'], 40);
  saveLive($doc);
  wsEmit('read', ['thread' => $tid, 'uid' => $u['id']]);
  v1Ok(['count' => 0]);
}

if ($a === 'threads' && $b !== '' && in_array($c, ['pin', 'archive', 'mute'], true) && $method === 'POST') {
  $u = v1NeedUser($in);
  $tid = rawurldecode($b);
  if (!aclCan($u, 'threads.read', ['thread' => $tid])) v1Fail('E_FORBIDDEN', 'Нет доступа');
  $saved = patchUser($u['id'], function (&$x) use ($c, $tid, $in) {
    if ($c === 'pin') {
      $arr = $x['pinnedChats'] ?? [];
      $x['pinnedChats'] = in_array($tid, $arr, true) ? array_values(array_filter($arr, fn($t) => $t !== $tid)) : array_values(array_merge($arr, [$tid]));
    } elseif ($c === 'archive') {
      $arr = $x['archived'] ?? [];
      $x['archived'] = in_array($tid, $arr, true) ? array_values(array_filter($arr, fn($t) => $t !== $tid)) : array_values(array_merge($arr, [$tid]));
    } else {
      $x['mutedChats'] = $x['mutedChats'] ?? [];
      $until = (int)($in['until'] ?? 0);
      if ($until > 0) $x['mutedChats'][$tid] = $until;
      else unset($x['mutedChats'][$tid]);
    }
  });
  v1Ok(['user' => publicUser($saved, true)]);
}

if ($a === 'messages' && $b !== '' && $c === '' && $method === 'PATCH') {
  $u = v1NeedUser($in);
  needVerified($u);
  rateFor($u, 'edit');
  $id = $b;
  $lim = limitsFor($u);
  $text = cut((string)($in['text'] ?? ''), (int)$lim['text']);
  if ($text === '') v1Fail('E_VALIDATION', 'Пусто');
  $item = saveMsgItem($id, function (&$m) use ($u, $text, $lim) {
    if (!aclCan($u, 'messages.edit_own', ['msg' => $m]) && !aclCan($u, 'messages.moderate', ['msg' => $m])) fail('Нет доступа', 403);
    if (($m['kind'] ?? 'text') !== 'text' && ($m['kind'] ?? '') !== 'system') fail('Нельзя править');
    $ts = strtotime((string)($m['at'] ?? '')) ?: 0;
    $win = (int)$lim['editWindowSec'];
    if ($win > 0 && $ts && time() - $ts > $win && !isAdmin($u)) fail('Поздно править');
    $m['text'] = $text;
    $m['edited'] = true;
  });
  v1Ok(['item' => $item]);
}

if ($a === 'messages' && $b !== '' && $c === 'delete' && $method === 'POST') {
  $u = v1NeedUser($in);
  needVerified($u);
  rateFor($u, 'del');
  $forAll = !empty($in['forAll']) || !empty($in['all']);
  $item = saveMsgItem($b, function (&$m) use ($u, $forAll) {
    if (!canAccessMsg($u, $m) && !canModMsg($u)) fail('Нет доступа', 403);
    $own = (($m['uid'] ?? '') === $u['id']);
    if ($forAll) {
      if (!$own && !canModMsg($u) && !isAdmin($u)) fail('Не твоё', 403);
      $m['deleted'] = true;
      $m['text'] = '';
      $m['url'] = null;
      $m['kind'] = 'text';
      return;
    }
    $hid = $m['hiddenFor'] ?? [];
    if (!in_array($u['id'], $hid, true)) $hid[] = $u['id'];
    $m['hiddenFor'] = $hid;
  });
  v1Ok(['item' => $item, 'forAll' => $forAll]);
}

if ($a === 'messages' && $b !== '' && $c === 'forward' && $method === 'POST') {
  $u = v1NeedUser($in);
  needVerified($u);
  rateFor($u, 'send');
  $src = findMsg($b);
  if (!$src || !empty($src['deleted'])) v1Fail('E_NOT_FOUND', 'Нет сообщения');
  if (!canAccessMsg($u, $src)) v1Fail('E_FORBIDDEN', 'Нет доступа');
  $tid = (string)($in['thread'] ?? 'global');
  if (!aclCan($u, 'threads.write', ['thread' => $tid])) v1Fail('E_FORBIDDEN', 'Нет доступа');
  $item = [
    'id' => id(),
    'at' => gmdate('c'),
    'nick' => $u['nick'],
    'uid' => $u['id'],
    'avatar' => $u['avatar'] ?? '',
    'kind' => $src['kind'] ?? 'text',
    'text' => $src['text'] ?? '',
    'url' => $src['url'] ?? null,
    'name' => $src['name'] ?? null,
    'pinned' => false,
    'reactions' => [],
    'thread' => $tid,
    'forwardedFrom' => $src['nick'] ?? ''
  ];
  pushMsg($item);
  v1Ok(['item' => $item]);
}

if ($a === 'messages' && $b !== '' && $c === 'save' && $method === 'POST') {
  $u = v1NeedUser($in);
  $src = findMsg($b);
  if (!$src) v1Fail('E_NOT_FOUND', 'Нет сообщения');
  if (!canAccessMsg($u, $src)) v1Fail('E_FORBIDDEN', 'Нет доступа');
  $copy = $src;
  $copy['id'] = id();
  $copy['thread'] = 'saved';
  $copy['uid'] = $u['id'];
  $copy['savedFrom'] = $src['id'] ?? '';
  $copy['at'] = gmdate('c');
  pushMsg($copy);
  v1Ok(['item' => $copy]);
}

if ($a === 'messages' && $b !== '' && $c === 'report' && $method === 'POST') {
  $u = v1NeedUser($in);
  rateFor($u, 'report');
  $src = findMsg($b);
  if (!$src) v1Fail('E_NOT_FOUND', 'Нет сообщения');
  if (!canAccessMsg($u, $src)) v1Fail('E_FORBIDDEN', 'Нет доступа');
  logMod($u, 'report', (string)($src['nick'] ?? ''), cut((string)($in['reason'] ?? ''), 200));
  v1Ok(['reported' => true]);
}

if ($a === 'messages' && $b !== '' && $c === 'reactions' && $method === 'POST') {
  $u = v1NeedUser($in);
  rateFor($u, 'react');
  $emo = cut((string)($in['emoji'] ?? $in['emo'] ?? ''), 16);
  if ($emo === '') v1Fail('E_VALIDATION', 'Этот смайл нельзя поставить');
  $item = saveMsgItem($b, function (&$m) use ($u, $emo) {
    if (!canAccessMsg($u, $m)) fail('Нет доступа', 403);
    $m['reactions'] = $m['reactions'] ?? [];
    $m['reactors'] = $m['reactors'] ?? [];
    $uid = $u['id'];
    $prev = $m['reactors'][$uid] ?? '';
    if ($prev === $emo) {
      unset($m['reactors'][$uid]);
      $m['reactions'][$emo] = max(0, (int)($m['reactions'][$emo] ?? 1) - 1);
      if ($m['reactions'][$emo] <= 0) unset($m['reactions'][$emo]);
    } else {
      if ($prev !== '') {
        $m['reactions'][$prev] = max(0, (int)($m['reactions'][$prev] ?? 1) - 1);
        if ($m['reactions'][$prev] <= 0) unset($m['reactions'][$prev]);
      }
      $m['reactors'][$uid] = $emo;
      $m['reactions'][$emo] = (int)($m['reactions'][$emo] ?? 0) + 1;
    }
  });
  v1Ok(['item' => $item]);
}

if ($a === 'messages' && $b === 'search' && $method === 'GET') {
  $u = v1NeedUser($in);
  rateFor($u, 'find');
  $q = strtolower(cut((string)($in['q'] ?? ''), 40));
  if ($q === '') v1Ok(['items' => []]);
  $out = [];
  $thread = (string)($in['thread'] ?? '');
  $targets = $thread !== '' ? [$thread] : ['global', 'saved'];
  foreach ($targets as $tid) {
    if (!aclCan($u, 'threads.read', ['thread' => $tid])) continue;
    foreach (scanDays($tid, 10) as $day) {
      foreach ((msgsOf($tid, $day)['items'] ?? []) as $m) {
        if (!empty($m['deleted'])) continue;
        if (strpos(strtolower((string)($m['text'] ?? '')), $q) === false) continue;
        if (!canAccessMsg($u, $m)) continue;
        $out[] = $m;
        if (count($out) >= 40) break 3;
      }
    }
  }
  v1Ok(['items' => $out]);
}

if ($a === 'media' && $method === 'POST' && $b === '') {
  $u = v1NeedUser($in);
  needVerified($u);
  if (empty(meta()['allowUploads']) && !isAdmin($u)) v1Fail('E_FORBIDDEN', 'Загрузки выключены');
  if (chatMuted($u) && !isAdmin($u)) v1Fail('E_FORBIDDEN', 'Ты в муте');
  rateFor($u, 'up');
  $lim = limitsFor($u);
  $kind = (string)($in['kind'] ?? 'image');
  if (!in_array($kind, ['image', 'audio', 'sticker', 'avatar', 'gif', 'voice', 'cover', 'banner', 'botava', 'file'], true)) v1Fail('E_VALIDATION', 'Тип');
  $hashIn = preg_replace('/[^a-f0-9]/', '', strtolower((string)($in['hash'] ?? '')));
  $hd = hashes();
  if ($hashIn !== '') {
    foreach ($hd['map'] as $k => $_url) {
      if (substr((string)$k, -strlen($hashIn) - 1) === ':' . $hashIn && strpos((string)$k, $u['id'] . ':') !== 0) {
        v1Fail('E_FORBIDDEN', 'Нет доступа');
      }
    }
    $ownKey = $u['id'] . ':' . $hashIn;
    if (isset($hd['map'][$ownKey])) {
      v1Ok(['url' => resignMediaUrl((string)$hd['map'][$ownKey]), 'cached' => true]);
    }
  }
  $bin = base64_decode((string)($in['data'] ?? ''), true);
  $maxFile = in_array($kind, ['audio', 'voice'], true) ? (int)$lim['fileAudio'] : (int)$lim['fileImage'];
  if ($bin === false || strlen($bin) < 16 || strlen($bin) > $maxFile) v1Fail('E_VALIDATION', 'Файл до 3 МБ');
  $name = preg_replace('/[^A-Za-z0-9._-]/', '_', (string)($in['name'] ?? 'file'));
  $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
  if (in_array($kind, ['image', 'sticker', 'avatar', 'gif', 'cover', 'banner', 'botava'], true)) {
    if (!in_array($ext, ['png', 'jpg', 'jpeg', 'webp', 'gif', 'webm', 'avif'], true)) v1Fail('E_VALIDATION', 'Формат png/jpg/webp/gif/webm/avif');
    if (!magicImageOk($bin, $ext)) v1Fail('E_VALIDATION', 'Битый файл');
  }
  $thread = (string)($in['thread'] ?? '');
  if ($kind !== 'avatar' && $kind !== 'cover' && $kind !== 'banner' && $kind !== 'sticker' && $kind !== 'botava') {
    if ($thread === '' || !aclCan($u, 'threads.write', ['thread' => $thread])) v1Fail('E_FORBIDDEN', 'Нет доступа');
  }
  $stored = storeBlob($bin, $ext, (string)$u['id'], (string)$u['nick'], $thread !== '' ? $thread : 'profile');
  $url = $stored['url'];
  $hd['map'][$u['id'] . ':' . $stored['sha256']] = $url;
  $hd['map'][$u['id'] . ':' . $stored['sha1']] = $url;
  saveHashes($hd);
  if ($kind === 'avatar') {
    $saved = patchUser($u['id'], function (&$x) use ($url) { $x['avatar'] = $url; });
    v1Ok(['url' => $url, 'user' => publicUser($saved, true)]);
  }
  if ($kind === 'cover' || $kind === 'banner') {
    $saved = patchUser($u['id'], function (&$x) use ($url) { $x['cover'] = $url; $x['banner'] = $url; });
    v1Ok(['url' => $url, 'user' => publicUser($saved, true)]);
  }
  if (!empty($in['skipMsg']) || $kind === 'sticker') v1Ok(['url' => $url]);
  $item = [
    'id' => id(),
    'at' => gmdate('c'),
    'nick' => $u['nick'],
    'uid' => $u['id'],
    'avatar' => $u['avatar'] ?? '',
    'kind' => $kind === 'voice' ? 'audio' : $kind,
    'text' => cut((string)($in['caption'] ?? $name), (int)$lim['caption']),
    'url' => $url,
    'name' => $name,
    'pinned' => false,
    'reactions' => [],
    'thread' => $thread
  ];
  if ($thread !== '') pushMsg($item);
  v1Ok(['item' => $item, 'url' => $url]);
}

if ($a === 'presence' && $method === 'GET') {
  $u = v1NeedUser($in);
  $doc = live();
  $online = [];
  $now = time();
  foreach (($doc['seen'] ?? []) as $id => $ts) {
    if ((int)$ts > $now - 90) $online[] = $id;
  }
  v1Ok(['online' => $online, 'me' => $u['id']]);
}

if ($a === 'ws' && $method === 'GET') {
  $u = v1NeedUser($in);
  v1Ok(['url' => WS_PUBLIC, 'port' => WS_PORT, 'uid' => $u['id']]);
}

if ($a === 'dms' && $method === 'GET') {
  $u = v1NeedUser($in);
  $items = [];
  $seen = [];
  foreach (scanDays('global', 1) as $_d) { /* keep warm */ }
  foreach (allUserIds() as $oid) {
    if ($oid === $u['id']) continue;
    $th = dmThread($u['id'], $oid);
    if (isset($seen[$th])) continue;
    $seen[$th] = true;
    if (!inThread($u, $th)) continue;
    $last = lastInThread($th, $u);
    if (!$last) continue;
    $peer = findUserById($oid);
    $items[] = [
      'id' => $th,
      'peer' => $peer ? publicUser($peer) : ['id' => $oid],
      'lastText' => cut((string)($last['text'] ?? ''), 80),
      'lastAt' => $last['at'] ?? ''
    ];
  }
  v1Ok(['items' => $items]);
}

if ($a === 'dms' && $method === 'POST') {
  $u = v1NeedUser($in);
  needVerified($u);
  $nick = trim((string)($in['nick'] ?? $in['uid'] ?? ''));
  $x = findUserByNick($nick) ?: findUserById($nick);
  if (!$x) v1Fail('E_NOT_FOUND', 'Нет такого');
  $th = dmThread($u['id'], $x['id']);
  try { assertCanWriteDm($u, $th); } catch (Throwable $e) { v1Fail('E_FORBIDDEN', 'Тебе нельзя писать этому пользователю'); }
  v1Ok(['thread' => $th, 'peer' => publicUser($x)]);
}

if ($a === 'folders' && $method === 'GET') {
  $u = v1NeedUser($in);
  v1Ok(folderDoc($u));
}

if ($a === 'folders' && $method === 'POST' && $b === '') {
  $u = v1NeedUser($in);
  $name = cut((string)($in['name'] ?? ''), 24);
  if ($name === '') v1Fail('E_VALIDATION', 'Название');
  $fid = 'f' . bin2hex(random_bytes(3));
  $saved = patchUser($u['id'], function (&$x) use ($fid, $name, $in) {
    $x['folders'] = $x['folders'] ?? [];
    $x['folders'][] = ['id' => $fid, 'name' => $name, 'threads' => array_values((array)($in['threads'] ?? []))];
  });
  v1Ok(['folders' => $saved['folders'] ?? [], 'id' => $fid]);
}

if ($a === 'folders' && $b !== '' && ($method === 'PATCH' || $method === 'POST')) {
  $u = v1NeedUser($in);
  $fid = cut($b, 24);
  $saved = patchUser($u['id'], function (&$x) use ($fid, $in) {
    $x['folders'] = $x['folders'] ?? [];
    if (!empty($in['delete'])) {
      $x['folders'] = array_values(array_filter($x['folders'], fn($f) => ($f['id'] ?? '') !== $fid));
      return;
    }
    foreach ($x['folders'] as &$f) {
      if (($f['id'] ?? '') !== $fid) continue;
      if (isset($in['name'])) $f['name'] = cut((string)$in['name'], 24);
      if (isset($in['threads']) && is_array($in['threads'])) $f['threads'] = array_values($in['threads']);
    }
  });
  v1Ok(['folders' => $saved['folders'] ?? []]);
}

if ($a === 'admin' && $b === 'users' && $c === '' && $method === 'GET') {
  $u = v1NeedUser($in);
  if (!aclCan($u, 'admin.any')) v1Fail('E_FORBIDDEN', 'Только админ');
  $q = strtolower(cut((string)($in['q'] ?? ''), 24));
  $out = [];
  foreach (allUsers() as $x) {
    if ($q !== '' && strpos(strtolower((string)$x['nick']), $q) === false && strpos(strtolower((string)($x['email'] ?? '')), $q) === false) continue;
    $out[] = publicUser($x, true);
    if (count($out) >= 50) break;
  }
  v1Ok(['items' => $out]);
}

if ($a === 'admin' && $b === 'users' && $c !== '' && $d === 'ban' && $method === 'POST') {
  $u = v1NeedUser($in);
  if (!canBan($u) && !isAdmin($u)) v1Fail('E_FORBIDDEN', 'Только админ');
  $x = findUserByNick($c) ?: findUserById($c);
  if (!$x) v1Fail('E_NOT_FOUND', 'Нет такого');
  $hours = max(0, (int)($in['hours'] ?? 24));
  $reason = cut((string)($in['reason'] ?? ''), 200);
  $saved = patchUser($x['id'], function (&$t) use ($hours, $reason) {
    $t['banned'] = true;
    $t['banUntil'] = $hours > 0 ? time() + $hours * 3600 : 0;
    $t['banReason'] = $reason;
    $t['tokenExp'] = 0;
  });
  logMod($u, 'ban', $saved['nick'], $reason);
  v1Ok(['user' => publicUser($saved, true)]);
}

if ($a === 'admin' && $b === 'users' && $c !== '' && $d === 'unban' && $method === 'POST') {
  $u = v1NeedUser($in);
  if (!isAdmin($u) && !canBan($u)) v1Fail('E_FORBIDDEN', 'Только админ');
  $x = findUserByNick($c) ?: findUserById($c);
  if (!$x) v1Fail('E_NOT_FOUND', 'Нет такого');
  $saved = patchUser($x['id'], function (&$t) {
    $t['banned'] = false;
    $t['banUntil'] = 0;
    $t['banReason'] = '';
  });
  logMod($u, 'unban', $saved['nick']);
  v1Ok(['user' => publicUser($saved, true)]);
}

if ($a === 'admin' && $b === 'users' && $c !== '' && $d === 'mute' && $method === 'POST') {
  $u = v1NeedUser($in);
  if (!canMute($u) && !isAdmin($u)) v1Fail('E_FORBIDDEN', 'Только модератор');
  $x = findUserByNick($c) ?: findUserById($c);
  if (!$x) v1Fail('E_NOT_FOUND', 'Нет такого');
  $mins = max(0, (int)($in['minutes'] ?? 30));
  $reason = cut((string)($in['reason'] ?? ''), 200);
  $saved = patchUser($x['id'], function (&$t) use ($mins, $reason) {
    $t['muteUntil'] = time() + $mins * 60;
    $t['muteReason'] = $reason;
  });
  logMod($u, 'mute', $saved['nick'], $reason);
  v1Ok(['user' => publicUser($saved, true)]);
}

if ($a === 'admin' && $b === 'settings' && $method === 'POST') {
  $u = v1NeedUser($in);
  if (!aclCan($u, 'admin.any')) v1Fail('E_FORBIDDEN', 'Только админ');
  $cfg = meta();
  foreach (['requireVerify', 'allowGifs', 'allowStickers', 'allowUploads', 'allowPolls', 'allowDms', 'readonly'] as $k) {
    if (array_key_exists($k, $in)) $cfg[$k] = !empty($in[$k]);
  }
  if (isset($in['slowMode'])) $cfg['slowMode'] = max(0, (int)$in['slowMode']);
  saveMeta($cfg);
  logMod($u, 'settings', '', '');
  v1Ok(['settings' => $cfg]);
}

if ($a === 'admin' && $b === 'modlog' && $method === 'GET') {
  $u = v1NeedUser($in);
  if (!aclCan($u, 'staff.any')) v1Fail('E_FORBIDDEN', 'Только модератор');
  v1Ok(['items' => array_slice(modlog()['items'] ?? [], 0, 200)]);
}

if ($a === 'admin' && $b === 'stats' && $method === 'GET') {
  $u = v1NeedUser($in);
  if (!aclCan($u, 'admin.any')) v1Fail('E_FORBIDDEN', 'Только админ');
  v1Ok(['users' => count(allUserIds()), 'online' => 0]);
}

v1Fail('E_NOT_FOUND', 'Неизвестное действие');
