<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');
header('X-Frame-Options: DENY');
$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
if ($origin === 'https://my.cryndel.ru' || $origin === 'https://cryndel.ru') {
  header('Access-Control-Allow-Origin: ' . $origin);
  header('Vary: Origin');
}
header('Access-Control-Allow-Headers: Content-Type, X-Cryn-Client');
header('Access-Control-Allow-Headers: Content-Type, X-Cryn-Client, Authorization');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
header('Cache-Control: no-store');
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') {
  http_response_code(204);
  exit;
}
const MAX_BODY = 12000000;
const MAX_FILE = 8388608;
const DATA_DIR = __DIR__ . '/data';
const KEY_FILE = DATA_DIR . '/.key';
const USERS_FILE = DATA_DIR . '/users.bin';
const MSG_FILE = DATA_DIR . '/messages.bin';
const RATE_FILE = DATA_DIR . '/rate.bin';
const PACK_FILE = DATA_DIR . '/packs.bin';
const LIVE_FILE = DATA_DIR . '/live.bin';
const META_FILE = DATA_DIR . '/meta.bin';
const LOG_FILE = DATA_DIR . '/modlog.bin';
const HASH_FILE = DATA_DIR . '/hashes.bin';
const BOTS_FILE = DATA_DIR . '/bots.bin';
const SCHED_FILE = DATA_DIR . '/sched.bin';
const PREV_FILE = DATA_DIR . '/prev.bin';
const MEDIA_DIR = DATA_DIR . '/media';
const STICK_DIR = DATA_DIR . '/stickers';
const PUBLIC_BASE = 'https://my.cryndel.ru/acryn/index.php';
const UA_OK = 'CryndelLauncher';
const WS_PORT = 18765;
const WS_PUBLIC = 'wss://my.cryndel.ru/crynws';
const TOKEN_TTL = 86400;
const MEDIA_TTL = 600;

require_once __DIR__ . '/lib/vault.php';
vaultBoot();
require_once __DIR__ . '/lib/acl.php';
require_once __DIR__ . '/lib/contract.php';

$v1Get = false;
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'GET') {
  $uri = (string)($_SERVER['REQUEST_URI'] ?? '');
  if (strpos($uri, '/v1') !== false || (string)($_GET['v'] ?? '') === '1' || (string)($_GET['path'] ?? '') !== '') {
    $v1Get = true;
  } else {
    if (isset($_GET['m'])) serveSignedMedia();
    http_response_code(200);
    echo json_encode(['ok' => false, 'code' => 'E_METHOD', 'error' => ['code' => 'E_METHOD', 'message' => 'POST only']]);
    exit;
  }
}
if (!empty($v1Get)) {
  /* v1 GET handled after helpers load */
} elseif (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
  http_response_code(200);
  echo json_encode(['ok' => false, 'code' => 'E_METHOD']);
  exit;
}

function errCode(string $msg): string {
  static $map = [
    'POST only' => 'E_METHOD',
    'storage' => 'E_STORAGE',
    'Слишком часто. Подожди.' => 'E_RATE',
    'Только модератор' => 'E_STAFF',
    'Нужен вход' => 'E_AUTH',
    'Только админ' => 'E_ADMIN',
    'Подтверди почту' => 'E_VERIFY',
    'Только в личке' => 'E_DM_ONLY',
    'Лимит возвратов на этот месяц исчерпан' => 'E_STREAK_LIMIT',
    'Нет профиля' => 'E_NO_PROFILE',
    'Только лаунчер' => 'E_LAUNCHER',
    'Слишком большой запрос' => 'E_TOO_BIG',
    'JSON' => 'E_JSON',
    'Неизвестное действие' => 'E_ACTION',
    'Ник: 3–20 латиница, цифры, _' => 'E_NICK',
    'Плохая почта' => 'E_EMAIL',
    'Пароль 8–72 символа' => 'E_PASS',
    'Ник занят' => 'E_NICK_TAKEN',
    'Почта занята' => 'E_EMAIL_TAKEN',
    'Пароль сброшен администратором. Задайте новый пароль' => 'E_PASS_RESET',
    'Неверные данные' => 'E_CREDS',
    'Код из 6 цифр' => 'E_CODE',
    'Код истёк' => 'E_CODE_EXPIRED',
    'Неверный код' => 'E_CODE_BAD',
    'Код истёк. Запроси новый' => 'E_CODE_EXPIRED',
    'Аватар только https' => 'E_URL',
    'Баннер только https' => 'E_URL',
    'Нет такого' => 'E_NOT_FOUND',
    'Нет доступа' => 'E_FORBIDDEN',
    'Чат только для чтения' => 'E_READONLY',
    'GIF выключены' => 'E_GIF_OFF',
    'Стикеры выключены' => 'E_STICK_OFF',
    'Текст 1–2000' => 'E_TEXT',
    'Текст 1–4096' => 'E_TEXT',
    'Пароли не совпадают' => 'E_VALIDATION',
    'Нужен код 2FA' => 'E_AUTH',
    'Право r1–r12' => 'E_VALIDATION',
    'Эмодзи' => 'E_EMOJI',
    'Нет предмета' => 'E_NOT_FOUND',
    'Уже куплено' => 'E_FORBIDDEN',
    'Не хватает пирикаса' => 'E_FORBIDDEN',
    'Не куплено' => 'E_FORBIDDEN',
    'Коментарии только у постов канала' => 'E_FORBIDDEN',
    'Чат' => 'E_THREAD',
    'Тебе нельзя писать этому пользователю' => 'E_DM_DENY',
    'Пользователь закрыл входящие' => 'E_DM_CLOSED',
    'Писать могут только разрешённые' => 'E_DM_CONTACTS',
    'В канале пишет только админ' => 'E_CHANNEL',
    'Нет канала' => 'E_NO_CHANNEL',
    'В канале пишет только владелец' => 'E_CHANNEL_OWNER',
    'В системный чат пишет только админ' => 'E_SYSTEM',
    'Плохая ссылка' => 'E_URL',
    'Только https GIF' => 'E_URL',
    'Только https' => 'E_URL',
    'Пусто' => 'E_EMPTY',
    'Не твоё' => 'E_NOT_YOURS',
    'Нельзя править' => 'E_NO_EDIT',
    'Поздно править' => 'E_EDIT_LATE',
    'Нет сообщения' => 'E_NO_MSG',
    'Этот смайл нельзя поставить' => 'E_EMOJI',
    'Закреплять в общем чате могут модераторы с 3 ранга' => 'E_PIN_RANK',
    'https' => 'E_URL',
    'Опросы выключены' => 'E_POLL_OFF',
    'Варианты' => 'E_POLL',
    'Опрос: вопрос и 2–6 вариантов' => 'E_POLL',
    'Нет опроса' => 'E_NO_POLL',
    'Уже голосовал' => 'E_VOTED',
    'Вариант' => 'E_POLL',
    'Название' => 'E_NAME',
    'Максимум 12 коллекций' => 'E_PACK_LIMIT',
    'Пак полный' => 'E_PACK_FULL',
    'Нет коллекции' => 'E_NO_PACK',
    'Загрузки выключены' => 'E_UPLOAD_OFF',
    'Тип' => 'E_KIND',
    'Файл до 3 МБ' => 'E_FILE_SIZE',
    'Битый файл' => 'E_FILE_BAD',
    'Формат png/jpg/webp/gif/webm/avif' => 'E_FORMAT',
    'Аудио mp3/ogg/wav' => 'E_AUDIO',
    'Лички выключены' => 'E_DM_OFF',
    'Токен бота' => 'E_BOT_TOKEN',
    'Карточка' => 'E_CARD',
    'Уже есть канал' => 'E_KANAL_EXISTS',
    'Юз канала: 3–20 латиница, цифры, _' => 'E_KANAL_HANDLE',
    'Юз канала занят' => 'E_KANAL_TAKEN',
  ];
  if (isset($map[$msg])) return $map[$msg];
  if (strpos($msg, 'муте') !== false) return 'E_MUTED';
  if (strpos($msg, 'заблокирован') !== false) return 'E_BANNED';
  if (strpos($msg, 'Медленный') !== false) return 'E_SLOW';
  if (strpos($msg, 'Файл') !== false) return 'E_FILE_SIZE';
  return 'E_FAIL';
}

function fail(string $msg, int $code = 400) {
  http_response_code(200);
  $c = errCode($msg);
  echo json_encode(['ok' => false, 'code' => $c, 'data' => null, 'error' => ['code' => $c, 'message' => $msg]], JSON_UNESCAPED_UNICODE);
  exit;
}

function ok(array $extra = []) {
  echo json_encode(['ok' => true, 'data' => $extra, 'error' => null] + $extra, JSON_UNESCAPED_UNICODE);
  exit;
}

function secret(): string {
  return vaultSecret();
}

function enc(string $plain): string {
  $iv = random_bytes(12);
  $tag = '';
  $raw = openssl_encrypt($plain, 'aes-256-gcm', secret(), OPENSSL_RAW_DATA, $iv, $tag);
  if ($raw === false) fail('storage', 500);
  return base64_encode($iv . $tag . $raw);
}

function dec(string $b64): string {
  $bin = base64_decode($b64, true);
  if ($bin === false || strlen($bin) < 29) return '';
  $iv = substr($bin, 0, 12);
  $tag = substr($bin, 12, 16);
  $raw = substr($bin, 28);
  $out = openssl_decrypt($raw, 'aes-256-gcm', secret(), OPENSSL_RAW_DATA, $iv, $tag);
  return $out === false ? '' : $out;
}

function loadStore(string $file, array $fallback): array {
  if (!is_file($file)) return $fallback;
  $json = dec((string)file_get_contents($file));
  $data = json_decode($json, true);
  return is_array($data) ? $data : $fallback;
}

function saveStore(string $file, array $data): void {
  if (!is_dir(dirname($file))) mkdir(dirname($file), 0700, true);
  $tmp = $file . '.' . getmypid() . '.tmp';
  file_put_contents($tmp, enc(json_encode($data, JSON_UNESCAPED_UNICODE)), LOCK_EX);
  rename($tmp, $file);
  chmod($file, 0600);
}

function realIp(): string {
  $remote = (string)($_SERVER['REMOTE_ADDR'] ?? '0');
  $trusted = $remote === '127.0.0.1' || $remote === '::1' || $remote === '::ffff:127.0.0.1';
  if ($trusted) {
    $xff = trim(explode(',', (string)($_SERVER['HTTP_X_FORWARDED_FOR'] ?? ''))[0]);
    if (filter_var($xff, FILTER_VALIDATE_IP)) return $xff;
  }
  return $remote;
}

function ip(): string {
  return substr(hash('sha256', realIp()), 0, 16);
}

function rate(string $bucket, int $limit, int $window, string $uid = ''): void {
  if ($limit <= 0) return;
  $now = time();
  $doc = vaultRead(VAULT_RATE, ['hits' => []]);
  $keys = [$bucket . ':ip:' . ip()];
  if ($uid !== '') $keys[] = $bucket . ':u:' . $uid;
  foreach ($keys as $key) {
    $hits = $doc['hits'][$key] ?? [];
    $hits = array_values(array_filter($hits, fn($t) => $t > $now - $window));
    if (count($hits) >= $limit) fail('Слишком часто. Подожди.', 429);
    $hits[] = $now;
    $doc['hits'][$key] = $hits;
  }
  if (count($doc['hits']) > 4000) $doc['hits'] = array_slice($doc['hits'], -2000, null, true);
  vaultWrite(VAULT_RATE, $doc);
}

function msgIdOk(string $id): bool {
  return (bool)preg_match('/^m[0-9a-f]{12}$/', $id);
}

function tokenHash(string $token): string {
  return hash('sha256', $token);
}

function issueToken(array &$u): string {
  $token = bin2hex(random_bytes(24));
  $u['token'] = $token;
  $u['tokenHash'] = tokenHash($token);
  $u['tokenAt'] = time();
  $u['tokenExp'] = time() + TOKEN_TTL;
  $dev = (string)($u['device'] ?? '');
  $sess = is_array($u['sessions'] ?? null) ? $u['sessions'] : [];
  $sess = array_values(array_filter($sess, fn($s) => ($s['id'] ?? '') !== $dev));
  array_unshift($sess, [
    'id' => $dev !== '' ? $dev : substr($token, 0, 16),
    'name' => cut((string)($_SERVER['HTTP_USER_AGENT'] ?? 'устройство'), 80),
    'at' => gmdate('c'),
    'ip' => ip(),
    'hash' => substr($u['tokenHash'], 0, 16)
  ]);
  $u['sessions'] = array_slice($sess, 0, 12);
  return $token;
}

function tokenFresh(array $u): bool {
  $exp = (int)($u['tokenExp'] ?? 0);
  if ($exp > 0 && $exp < time()) return false;
  return true;
}

function mediaSign(string $sha1, string $ext, int $ttl = MEDIA_TTL, string $uid = ''): string {
  $sha1 = preg_replace('/[^a-f0-9]/', '', strtolower($sha1));
  $ext = preg_replace('/[^a-z0-9]/', '', strtolower($ext));
  $uid = preg_replace('/[^A-Za-z0-9:_-]/', '', $uid);
  $exp = time() + max(60, $ttl);
  $sig = hash_hmac('sha256', $sha1 . '|' . $ext . '|' . $exp . '|' . $uid, vaultSecret());
  $q = PUBLIC_BASE . '?m=' . $sha1 . '&e=' . $ext . '&x=' . $exp . '&s=' . $sig;
  if ($uid !== '') $q .= '&u=' . rawurlencode($uid);
  return $q;
}

function resignMediaUrl(string $url): string {
  if ($url === '') return $url;
  if (preg_match('#(?:/pool/([a-f0-9]{2})/)?([a-f0-9]{40})\.([a-z0-9]+)#i', $url, $mm)) {
    return mediaSign(strtolower($mm[2]), strtolower($mm[3]));
  }
  return $url;
}

function serveSignedMedia(): void {
  $sha1 = preg_replace('/[^a-f0-9]/', '', strtolower((string)($_GET['m'] ?? '')));
  $ext = preg_replace('/[^a-z0-9]/', '', strtolower((string)($_GET['e'] ?? '')));
  $exp = (int)($_GET['x'] ?? 0);
  $sig = preg_replace('/[^a-f0-9]/', '', strtolower((string)($_GET['s'] ?? '')));
  $uid = preg_replace('/[^A-Za-z0-9:_-]/', '', (string)($_GET['u'] ?? ''));
  if (strlen($sha1) !== 40 || $ext === '' || $exp < time() || strlen($sig) < 32) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'code' => 'E_FORBIDDEN', 'error' => ['code' => 'E_FORBIDDEN', 'message' => 'Нет доступа']]);
    exit;
  }
  $expectUid = hash_hmac('sha256', $sha1 . '|' . $ext . '|' . $exp . '|' . $uid, vaultSecret());
  $expectOld = hash_hmac('sha256', $sha1 . '|' . $ext . '|' . $exp, vaultSecret());
  if (!hash_equals($expectUid, $sig) && !hash_equals($expectOld, $sig)) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'code' => 'E_FORBIDDEN', 'error' => ['code' => 'E_FORBIDDEN', 'message' => 'Нет доступа']]);
    exit;
  }
  $path = mediaPoolPath($sha1, $ext);
  if (!is_file($path)) {
    http_response_code(404);
    echo json_encode(['ok' => false, 'code' => 'E_NOT_FOUND']);
    exit;
  }
  $mime = [
    'png' => 'image/png', 'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg',
    'webp' => 'image/webp', 'gif' => 'image/gif', 'avif' => 'image/avif',
    'webm' => 'video/webm', 'mp3' => 'audio/mpeg', 'ogg' => 'audio/ogg',
    'wav' => 'audio/wav', 'm4a' => 'audio/mp4', 'mp4' => 'video/mp4'
  ];
  header('Content-Type: ' . ($mime[$ext] ?? 'application/octet-stream'));
  header('X-Content-Type-Options: nosniff');
  header('Content-Disposition: inline');
  header('Cache-Control: private, max-age=60');
  header('Content-Length: ' . filesize($path));
  readfile($path);
  exit;
}

function wsTokenPut(string $token, string $uid, string $nick, int $exp): void {
  $f = VAULT_SYS . '/wstokens';
  idxSet($f, tokenHash($token), $uid . '|' . preg_replace('/[^\w.-]/', '', $nick) . '|' . $exp);
}

function canAccessMsg(array $u, array $m): bool {
  $th = (string)($m['thread'] ?? 'global');
  return threadOk($th) && inThread($u, $th);
}

function peerBlocked(array $u, array $other): bool {
  if (blocked($u, (string)($other['nick'] ?? '')) || blocked($u, (string)($other['id'] ?? ''))) return true;
  if (blocked($other, (string)($u['nick'] ?? '')) || blocked($other, (string)($u['id'] ?? ''))) return true;
  return false;
}

function assertCanWriteDm(array $u, string $thread): void {
  if (strpos($thread, 'dm:') !== 0 || $thread === 'dm:createbot' || $thread === 'dm:adminbot') return;
  $peer = peerId($u, $thread);
  $other = $peer ? findUserById($peer) : null;
  if (!$other) return;
  if (peerBlocked($u, $other)) fail('Тебе нельзя писать этому пользователю', 403);
  $deny = $other['privacy']['denyFrom'] ?? [];
  $allow = $other['privacy']['allowFrom'] ?? [];
  $who = (string)($other['privacy']['whoWrite'] ?? 'all');
  if (in_array($u['nick'], $deny, true) || in_array($u['id'], $deny, true)) fail('Тебе нельзя писать этому пользователю', 403);
  if ($who === 'nobody' && !isAdmin($u)) fail('Пользователь закрыл входящие', 403);
  if ($who === 'contacts' && !in_array($u['nick'], $allow, true) && !isAdmin($u)) fail('Писать могут только разрешённые', 403);
}

function stripExif(string $bin, string &$ext): string {
  if (!function_exists('imagecreatefromstring')) return $bin;
  $im = @imagecreatefromstring($bin);
  if (!$im) return $bin;
  imagealphablending($im, true);
  imagesavealpha($im, true);
  ob_start();
  if ($ext === 'png' || $ext === 'webp' || $ext === 'gif') {
    imagepng($im, null, 6);
    $ext = 'png';
  } else {
    imagejpeg($im, null, 82);
    $ext = 'jpg';
  }
  $out = ob_get_clean();
  imagedestroy($im);
  return is_string($out) && $out !== '' ? $out : $bin;
}

function magicImageOk(string $bin, string $ext): bool {
  $magic = substr($bin, 0, 16);
  if ($ext === 'png') return strpos($magic, "\x89PNG\x0D\x0A\x1A\x0A") === 0;
  if ($ext === 'jpg' || $ext === 'jpeg') return strpos($magic, "\xFF\xD8\xFF") === 0;
  if ($ext === 'gif') return strpos($magic, 'GIF87a') === 0 || strpos($magic, 'GIF89a') === 0;
  if ($ext === 'webp') return strpos($magic, 'RIFF') === 0 && substr($bin, 8, 4) === 'WEBP';
  if ($ext === 'webm') return strpos($magic, "\x1A\x45\xDF\xA3") === 0;
  if ($ext === 'avif') return substr($magic, 4, 4) === 'ftyp' && (strpos($bin, 'avif') !== false || strpos($bin, 'avis') !== false);
  if ($ext === 'bmp') return strpos($magic, 'BM') === 0;
  return false;
}

function users(): array {
  migrateLegacy();
  return ['users' => allUsers()];
}
function saveUsers(array $doc): void {
  foreach (($doc['users'] ?? []) as $u) {
    if (is_array($u) && !empty($u['id'])) saveUserDoc($u);
  }
}
function msgs(): array {
  $items = [];
  foreach (scanDays('global', 30) as $day) {
    foreach ((msgsOf('global', $day)['items'] ?? []) as $m) $items[] = $m;
  }
  return ['items' => $items];
}
function saveMsgs(array $doc): void {
  foreach (($doc['items'] ?? []) as $m) {
    if (is_array($m)) pushThreadMsg($m);
  }
}
function packs(): array { return vaultRead(VAULT_SYS . '/packs.bin', ['packs' => []]); }
function savePacks(array $doc): void { vaultWrite(VAULT_SYS . '/packs.bin', $doc); }
function live(): array { return vaultRead(VAULT_LIVE, ['seen' => [], 'typing' => [], 'read' => []]); }
function saveLive(array $doc): void { vaultWrite(VAULT_LIVE, $doc); }
function meta(): array {
  $doc = vaultRead(VAULT_META, [
    'requireVerify' => true,
    'allowGifs' => true,
    'allowStickers' => true,
    'allowUploads' => true,
    'allowPolls' => true,
    'allowDms' => true,
    'readonly' => false,
    'slowMode' => 0,
    'defaultTheme' => 'day',
    'defaultSkin' => 'tg',
    'defaultBubble' => 'tg',
    'defaultList' => 'classic',
    'chats' => []
  ]);
  $defaults = [
    'global' => ['id' => 'global', 'title' => 'CrynChat', 'about' => 'общий чат', 'avatar' => '', 'banner' => '', 'kind' => 'group'],
    'channel' => ['id' => 'channel', 'title' => 'Канал', 'about' => 'пишет только админ', 'avatar' => '', 'banner' => '', 'kind' => 'channel'],
     'system' => ['id' => 'system', 'title' => 'Системные', 'about' => 'уведомления', 'avatar' => '', 'banner' => '', 'kind' => 'system'],
     'saved' => ['id' => 'saved', 'title' => 'Избранное', 'about' => 'сохранённые', 'avatar' => '', 'banner' => '', 'kind' => 'saved']
  ];
  $doc['chats'] = $doc['chats'] ?? [];
  foreach ($defaults as $id => $c) {
    if (empty($doc['chats'][$id])) $doc['chats'][$id] = $c;
  }
  return $doc;
}
function saveMeta(array $doc): void { vaultWrite(VAULT_META, $doc); }
function modlog(): array { return vaultRead(VAULT_LOG, ['items' => []]); }
function saveModlog(array $doc): void { vaultWrite(VAULT_LOG, $doc); }
function logMod(array $admin, string $act, string $target = '', string $note = ''): void {
  $doc = modlog();
  array_unshift($doc['items'], [
    'id' => id('l'),
    'at' => gmdate('c'),
    'admin' => $admin['nick'] ?? '',
    'act' => $act,
    'target' => $target,
    'note' => cut($note, 200)
  ]);
  if (count($doc['items']) > 2000) $doc['items'] = array_slice($doc['items'], 0, 2000);
  saveModlog($doc);
}

function botByToken(?string $token): ?array {
  if (!$token || strpos((string)$token, 'bot') !== 0) return null;
  foreach (bots()['bots'] as $b) {
    if (hash_equals((string)($b['token'] ?? ''), (string)$token)) return $b;
  }
  return null;
}

function userByToken(?string $token): ?array {
  if (!$token || !preg_match('/^[a-f0-9]{32,96}$/i', (string)$token)) return null;
  $tid = idxGet(VAULT_SYS . '/tokenid', substr(hash('sha256', $token), 0, 24));
  if ($tid !== '') {
    $u = loadUser($tid);
    if ($u && hash_equals((string)($u['token'] ?? ''), $token) && tokenFresh($u)) return $u;
  }
  foreach (allUsers() as $u) {
    if (hash_equals((string)($u['token'] ?? ''), $token) && tokenFresh($u)) {
      idxSet(VAULT_SYS . '/tokenid', substr(hash('sha256', $token), 0, 24), (string)$u['id']);
      return $u;
    }
  }
  $bot = botByToken($token);
  if (!$bot) return null;
  $owner = findUserById((string)($bot['owner'] ?? ''));
  return [
    'id' => 'bot:' . ($bot['id'] ?? 'x'),
    'nick' => (string)($bot['username'] ?? $bot['name'] ?? 'bot'),
    'avatar' => (string)($bot['avatar'] ?? ''),
    'role' => 'bot',
    'verified' => true,
    'token' => $token,
    'botId' => $bot['id'] ?? '',
    'owner' => $bot['owner'] ?? '',
    'about' => $bot['about'] ?? '',
    'email' => is_array($owner) ? ($owner['email'] ?? '') : '',
    'badges' => ['official']
  ];
}

function isAdmin(array $u): bool {
  return ($u['role'] ?? '') === 'admin';
}

function modRank(array $u): int {
  if (isAdmin($u)) return 5;
  $n = (int)($u['modRank'] ?? 0);
  if (($u['role'] ?? '') === 'mod' && $n < 1) $n = 1;
  return max(0, min(4, $n));
}

function canWarn(array $u): bool { return modRank($u) >= 1; }
function canMute(array $u): bool { return modRank($u) >= 2; }
function canModMsg(array $u): bool { return modRank($u) >= 3; }
function canBan(array $u): bool { return modRank($u) >= 4; }

function isStaff(array $u): bool {
  return modRank($u) >= 1;
}

function needStaff(array $in): array {
  $u = needUser($in);
  if (!isStaff($u)) fail('Только модератор', 403);
  return $u;
}

function botMsg(string $text, string $thread, string $nick = 'CrynBot'): array {
  return [
    'id' => id(),
    'at' => gmdate('c'),
    'nick' => $nick,
    'uid' => 'bot',
    'avatar' => '',
    'role' => 'bot',
    'kind' => 'text',
    'text' => cut($text, 2000),
    'pinned' => false,
    'reactions' => [],
    'thread' => $thread,
    'badges' => ['official']
  ];
}

function crynBot(array $u, string $text, string $thread): ?array {
  if ($text === '' || $text[0] !== '/') return null;
  $parts = preg_split('/\s+/', trim($text), 3);
  $rawCmd = strtolower(ltrim((string)($parts[0] ?? ''), '/'));
  $alias = [
    'бан' => 'ban', 'мут' => 'mute', 'муте' => 'mute', 'варн' => 'warn',
    'разбан' => 'unban', 'размут' => 'unmute', 'кик' => 'kick',
    'профиль' => 'profile', 'инфо' => 'info', 'хелп' => 'help', 'помощь' => 'help',
    'модер' => 'mod', 'ранг' => 'mod', 'снять' => 'unmod', 'огоньки' => 'streaks',
    'огонёк' => 'streaks', 'топ' => 'streaks', 'выдать' => 'grant', 'права' => 'grant'
  ];
  $cmd = $alias[$rawCmd] ?? $rawCmd;
  $nick = ltrim((string)($parts[1] ?? ''), '@');
  $rest = (string)($parts[2] ?? '');
  $help = "Admin — модерация CrynChat.\n\nРанги модера:\n1 варн\n2 мут\n3 закреп / удаление чужих\n4 бан + закреп / удаление\n\nПрава r1–r12 выдаёт админ:\n/выдать ник r3\n/grant ник r3\n\n/mod ник 1-4\n/unmod ник\n/warn ник [причина]\n/mute ник [мин] [причина]\n/unmute ник\n/ban ник [часы] [причина]\n/unban ник\n/kick ник\n/pin id\n/del id\n/streaks\n/profile [ник]\n/info\n/help";
  $who = ($thread === 'dm:adminbot') ? 'Admin' : 'CrynBot';
  if ($cmd === 'help' || $cmd === 'start') return botMsg($help, $thread, $who);
  if ($cmd === 'info') {
    $cfg = meta();
    $chat = $cfg['chats'][$thread] ?? ['title' => $thread, 'about' => ''];
    $online = 0;
    foreach ((live()['seen'] ?? []) as $t) if ((int)$t > time() - 90) $online++;
    return botMsg(($chat['title'] ?? $thread) . "\n" . ($chat['about'] ?? '') . "\nв сети: " . $online, $thread, $who);
  }
  if ($cmd === 'profile') {
    $x = $nick !== '' ? findUserByNick($nick) : $u;
    if (!$x) return botMsg('Нет такого @' . $nick, $thread, $who);
    $warns = count($x['warns'] ?? []);
    $role = $x['role'] ?? 'user';
    $rank = modRank($x);
    $st = !empty($x['banned']) ? 'бан' : (chatMuted($x) ? 'мут' : 'ок');
    $rk = $rank > 0 && $rank < 5 ? ' · мод ' . $rank : ($rank >= 5 ? ' · админ' : '');
    return botMsg('@' . $x['nick'] . ' · ' . $role . $rk . ' · ' . $st . ' · варны ' . $warns . (!empty($x['bio']) ? "\n" . $x['bio'] : ''), $thread, $who);
  }
  if ($cmd === 'streaks') {
    if (!isAdmin($u)) return botMsg('Топ огоньков только админу', $thread, $who);
    return botMsg(streakTopText(), $thread, $who);
  }
  if ($cmd === 'grant' || $cmd === 'выдать') {
    if (!isAdmin($u)) return botMsg('Выдавать права может только админ', $thread, $who);
    if ($nick === '') return botMsg('Укажи ник. /выдать ник r1-r12', $thread, $who);
    $x = findUserByNick($nick) ?: findUserById($nick);
    if (!$x) return botMsg('Нет такого @' . $nick, $thread, $who);
    $right = strtolower(trim($rest));
    if (preg_match('/r?([1-9]|1[0-2])/', $right, $rm)) $right = 'r' . $rm[1];
    else $right = 'r1';
    $saved = patchUser($x['id'], function (&$t) use ($right) {
      $t['rights'] = array_values(array_unique(array_merge($t['rights'] ?? [], [$right])));
      $n = (int)substr($right, 1);
      if ($n >= 1 && ($t['role'] ?? '') !== 'admin') {
        $t['role'] = 'mod';
        $t['modRank'] = max((int)($t['modRank'] ?? 0), min(4, $n));
      }
    });
    logMod($u, 'grant', $saved['nick'], $right);
    return botMsg('@' . $saved['nick'] . ' получил ' . $right, $thread, $who);
  }
  if ($cmd === 'mod' || $cmd === 'setmod') {
    if (!isAdmin($u)) return botMsg('Назначать модеров может только админ', $thread, $who);
    if ($nick === '') return botMsg('Укажи ник. /mod ник 1-4', $thread, $who);
    $x = findUserByNick($nick);
    if (!$x) return botMsg('Нет такого @' . $nick, $thread, $who);
    $rank = (int)preg_replace('/\D/', '', $rest);
    if ($rank < 1 || $rank > 4) $rank = 1;
    $saved = patchUser($x['id'], function (&$t) use ($rank) {
      $t['role'] = 'mod';
      $t['modRank'] = $rank;
    });
    logMod($u, 'mod', $saved['nick'], (string)$rank);
    sysMsg($saved['nick'] . ' назначен модератором ' . $rank . ' ранга', 'global');
    return botMsg('@' . $saved['nick'] . ' — модератор ' . $rank . " ранга.\n1 варн · 2 мут · 3 закреп/удаление · 4 бан", $thread, $who);
  }
  if ($cmd === 'unmod') {
    if (!isAdmin($u)) return botMsg('Снимать модеров может только админ', $thread, $who);
    if ($nick === '') return botMsg('Укажи ник. /unmod ник', $thread, $who);
    $x = findUserByNick($nick);
    if (!$x) return botMsg('Нет такого @' . $nick, $thread, $who);
    $saved = patchUser($x['id'], function (&$t) {
      $t['role'] = 'user';
      $t['modRank'] = 0;
    });
    logMod($u, 'unmod', $saved['nick']);
    sysMsg($saved['nick'] . ' больше не модератор', 'global');
    return botMsg('@' . $saved['nick'] . ' снят с модерации', $thread, $who);
  }
  if ($cmd === 'pin' || $cmd === 'del') {
    if (!canModMsg($u)) return botMsg('Нужен 3 ранг: закреп и удаление чужих', $thread, $who);
    $id = $nick;
    if ($id === '') return botMsg('Укажи id сообщения', $thread, $who);
    if ($cmd === 'pin') {
      $item = saveMsgItem($id, function (&$m) {
        $m['pinned'] = empty($m['pinned']);
      });
      return botMsg(($item['pinned'] ?? false) ? 'Закреплено' : 'Откреплено', $thread, $who);
    }
    saveMsgItem($id, function (&$m) {
      $m['deleted'] = true;
      $m['text'] = '';
      $m['url'] = null;
      $m['kind'] = 'text';
    });
    return botMsg('Сообщение удалено', $thread, $who);
  }
  if (!in_array($cmd, ['ban', 'unban', 'mute', 'unmute', 'warn', 'kick'], true)) return null;
  if ($nick === '') return botMsg('Укажи ник. /help', $thread, $who);
  $x = findUserByNick($nick);
  if (!$x) return botMsg('Нет такого @' . $nick, $thread, $who);
  if ($cmd === 'ban' || $cmd === 'unban') {
    if (!canBan($u)) return botMsg('Бан с 4 ранга', $thread, $who);
  } elseif ($cmd === 'mute' || $cmd === 'unmute') {
    if (!canMute($u)) return botMsg('Мут с 2 ранга', $thread, $who);
  } elseif ($cmd === 'warn') {
    if (!canWarn($u)) return botMsg('Варн с 1 ранга', $thread, $who);
  } elseif ($cmd === 'kick') {
    if (!canMute($u)) return botMsg('Кик с 2 ранга', $thread, $who);
  } else if (!isStaff($u)) {
    return botMsg('Нет прав', $thread, $who);
  }
  if (isAdmin($x) && $x['id'] !== $u['id'] && ($cmd === 'ban' || $cmd === 'kick' || $cmd === 'mute')) {
    return botMsg('Админа так нельзя', $thread, $who);
  }
  if ($cmd === 'ban') {
    $hours = 0;
    $reason = $rest;
    if (preg_match('/^(\d+)\s*(.*)$/', $rest, $mm)) {
      $hours = max(0, (int)$mm[1]);
      $reason = trim($mm[2]);
    }
    if ($reason === '') $reason = 'бан';
    $until = $hours > 0 ? time() + $hours * 3600 : 0;
    $saved = patchUser($x['id'], function (&$t) use ($until, $reason) {
      $t['banned'] = true;
      $t['banUntil'] = $until;
      $t['banReason'] = $reason;
      $t['token'] = bin2hex(random_bytes(24));
    });
    logMod($u, 'ban', $saved['nick'], $reason);
    sysMsg($saved['nick'] . ' забанен' . ($reason ? ': ' . $reason : ''), $thread);
    return botMsg('@' . $saved['nick'] . ' забанен' . ($hours ? ' на ' . $hours . 'ч' : ''), $thread, $who);
  }
  if ($cmd === 'unban') {
    $saved = patchUser($x['id'], function (&$t) {
      $t['banned'] = false;
      $t['banUntil'] = 0;
      $t['banReason'] = '';
    });
    logMod($u, 'unban', $saved['nick']);
    sysMsg($saved['nick'] . ' разбанен', $thread);
    return botMsg('@' . $saved['nick'] . ' разбанен', $thread, $who);
  }
  if ($cmd === 'mute') {
    $mins = 30;
    $reason = $rest;
    if (preg_match('/^(\d+)\s*(.*)$/', $rest, $mm)) {
      $mins = max(1, (int)$mm[1]);
      $reason = trim($mm[2]);
    }
    if ($reason === '') $reason = 'мут';
    $saved = patchUser($x['id'], function (&$t) use ($mins, $reason) {
      $t['muteUntil'] = time() + $mins * 60;
      $t['muteReason'] = $reason;
    });
    logMod($u, 'mute', $saved['nick'], $reason);
    sysMsg($saved['nick'] . ' в муте на ' . $mins . ' мин', $thread);
    return botMsg('@' . $saved['nick'] . ' мут ' . $mins . ' мин', $thread, $who);
  }
  if ($cmd === 'unmute') {
    $saved = patchUser($x['id'], function (&$t) {
      $t['muteUntil'] = 0;
      $t['muteReason'] = '';
    });
    logMod($u, 'unmute', $saved['nick']);
    sysMsg($saved['nick'] . ' снят с мута', $thread);
    return botMsg('@' . $saved['nick'] . ' снят с мута', $thread, $who);
  }
  if ($cmd === 'warn') {
    $note = $rest !== '' ? cut($rest, 160) : 'предупреждение';
    $saved = patchUser($x['id'], function (&$t) use ($note, $u) {
      $t['warns'] = $t['warns'] ?? [];
      $t['warns'][] = ['at' => gmdate('c'), 'by' => $u['nick'], 'note' => $note];
    });
    $n = count($saved['warns'] ?? []);
    logMod($u, 'warn', $saved['nick'], $note);
    sysMsg($saved['nick'] . ' предупреждение (' . $n . '): ' . $note, $thread);
    if ($n >= 3 && empty($saved['banned'])) {
      patchUser($x['id'], function (&$t) {
        $t['banned'] = true;
        $t['banUntil'] = time() + 24 * 3600;
        $t['banReason'] = '3 варна';
        $t['token'] = bin2hex(random_bytes(24));
      });
      return botMsg('@' . $saved['nick'] . ' 3 варна — бан на сутки', $thread, $who);
    }
    return botMsg('@' . $saved['nick'] . ' варн (' . $n . '): ' . $note, $thread, $who);
  }
  if ($cmd === 'kick') {
    if (isAdmin($x)) return botMsg('Админа кикать нельзя', $thread, $who);
    patchUser($x['id'], function (&$t) { $t['token'] = bin2hex(random_bytes(24)); });
    logMod($u, 'kick', $nick);
    sysMsg($nick . ' отключён админом', $thread);
    return botMsg('@' . $nick . ' кикнут', $thread, $who);
  }
  return null;
}

function ensureFirstAdmin(): void {
}

function needUser(array $in): array {
  $u = userByToken((string)($in['token'] ?? ''));
  if (!$u) fail('Нужен вход', 401);
  if (!empty($u['banned'])) {
    $until = (int)($u['banUntil'] ?? 0);
    if ($until === 0 || $until > time()) fail('Аккаунт заблокирован' . (!empty($u['banReason']) ? ': ' . $u['banReason'] : ''), 403);
  }
  touchSeen($u);
  return $u;
}

function needAdmin(array $in): array {
  $u = needUser($in);
  if (!isAdmin($u)) fail('Только админ', 403);
  return $u;
}

function isVerified(array $u): bool {
  if (empty(meta()['requireVerify'])) return true;
  return !array_key_exists('verified', $u) || !empty($u['verified']);
}

function needVerified(array $u): void {
  if (!isVerified($u)) fail('Подтверди почту');
}

function chatMuted(array $u): bool {
  $until = (int)($u['muteUntil'] ?? 0);
  return $until > time();
}

function sysMsg(string $text, string $thread = 'global'): array {
  return pushMsg([
    'id' => id(),
    'at' => gmdate('c'),
    'nick' => 'система',
    'uid' => 'system',
    'avatar' => '',
    'kind' => 'system',
    'text' => cut($text, 400),
    'pinned' => false,
    'reactions' => [],
    'thread' => $thread
  ]);
}

function nickOk(string $n): bool {
  return (bool)preg_match('/^[A-Za-z0-9_]{3,20}$/', $n);
}

function id(string $p = 'm'): string {
  return $p . bin2hex(random_bytes(6));
}

function cut(string $s, int $n): string {
  $s = trim($s);
  return function_exists('mb_substr') ? mb_substr($s, 0, $n) : substr($s, 0, $n);
}

function makeCode(): string {
  return str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);
}

const MAIL_TOKEN = (string)(getenv('CRYN_MAIL_TOKEN') ?: '');
const MAIL_API = 'https://ms.cryndel.ru/mail/index.php';

function sendCodeMail(string $email, string $code, string $why = 'подтверждения'): bool {
  $payload = json_encode(['token' => MAIL_TOKEN, 'email' => $email, 'code' => $code, 'why' => $why], JSON_UNESCAPED_UNICODE);
  $ctx = stream_context_create([
    'http' => [
      'method' => 'POST',
      'header' => "Content-Type: application/json\r\nX-Cryn-Mail: " . MAIL_TOKEN . "\r\n",
      'content' => $payload,
      'timeout' => 8,
      'ignore_errors' => true
    ]
  ]);
  $res = @file_get_contents(MAIL_API, false, $ctx);
  if ($res !== false) {
    $j = json_decode($res, true);
    if (is_array($j) && !empty($j['ok'])) return true;
  }
  $subj = '=?UTF-8?B?' . base64_encode('CrynChat: код ' . $why) . '?=';
  $body = "Здравствуйте!\n\nКод " . $why . ": " . $code . "\nДействует 30 минут.\n\nЕсли это были не вы — просто проигнорируйте письмо.\n\nCrynChat";
  $headers = "From: CrynChat <noreply@cryndel.ru>\r\n";
  $headers .= "MIME-Version: 1.0\r\n";
  $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
  $headers .= "Content-Transfer-Encoding: 8bit\r\n";
  return @mail($email, $subj, $body, $headers);
}

function hashes(): array { return vaultRead(VAULT_SYS . '/hashes.bin', ['map' => []]); }
function saveHashes(array $doc): void { vaultWrite(VAULT_SYS . '/hashes.bin', $doc); }
function bots(): array {
  $bots = [];
  if (is_dir(VAULT_BOTS)) {
    foreach (scandir(VAULT_BOTS) as $n) {
      if ($n === '.' || $n === '..') continue;
      $f = VAULT_BOTS . '/' . $n . '/data.bin';
      if (!is_file($f)) continue;
      $b = vaultRead($f, []);
      if ($b) $bots[] = $b;
    }
  }
  if ($bots) return ['bots' => $bots];
  return vaultRead(VAULT_SYS . '/bots.bin', ['bots' => []]);
}
function saveBots(array $doc): void {
  foreach (($doc['bots'] ?? []) as $b) {
    if (empty($b['id'])) continue;
    $d = botDir((string)$b['id']);
    vaultWrite($d . '/data.bin', $b);
    if (!empty($b['username'])) idxSet(VAULT_BOTID, strtolower((string)$b['username']), (string)$b['id']);
  }
  vaultWrite(VAULT_SYS . '/bots.bin', $doc);
}
function sched(): array { return vaultRead(VAULT_SYS . '/sched.bin', ['items' => []]); }
function saveSched(array $doc): void { vaultWrite(VAULT_SYS . '/sched.bin', $doc); }
function previews(): array { return vaultRead(VAULT_SYS . '/prev.bin', ['map' => []]); }
function savePreviews(array $doc): void { vaultWrite(VAULT_SYS . '/prev.bin', $doc); }

function launcherOk(): bool {
  $ua = (string)($_SERVER['HTTP_USER_AGENT'] ?? '');
  if (stripos($ua, UA_OK) !== false) return true;
  $origin = (string)($_SERVER['HTTP_ORIGIN'] ?? '');
  return $origin === 'https://my.cryndel.ru' || $origin === 'https://cryndel.ru';
}

function ipForbidden(string $ip): bool {
  if (!filter_var($ip, FILTER_VALIDATE_IP)) return true;
  if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) return true;
  if ($ip === '0.0.0.0' || $ip === '::' || $ip === '::1') return true;
  return false;
}

function safeUrl(string $url): bool {
  if (!preg_match('#^https://[A-Za-z0-9._~:/%-]+(?:\?[A-Za-z0-9._~:/?#\[\]@!$&\'()*+,;=%-]*)?(?:\#[A-Za-z0-9._~:/?#\[\]@!$&\'()*+,;=%-]*)?$#', $url)) return false;
  $parts = parse_url($url);
  if (!is_array($parts)) return false;
  $host = strtolower((string)($parts['host'] ?? ''));
  if ($host === '' || $host === 'localhost' || substr($host, -6) === '.local' || substr($host, -7) === '.onion') return false;
  if (preg_match('/\.nip\.io$|\.sslip\.io$|\.localtest\.me$/i', $host)) return false;
  if (filter_var($host, FILTER_VALIDATE_IP)) {
    if (ipForbidden($host)) return false;
  } else {
    $resolved = @gethostbynamel($host);
    if (!is_array($resolved) || !$resolved) return false;
    foreach ($resolved as $ip) {
      if (ipForbidden($ip)) return false;
    }
  }
  return true;
}

function flushScheduled(): void {
  $doc = sched();
  if (empty($doc['items'])) return;
  $now = time();
  $keep = [];
  $changed = false;
  foreach ($doc['items'] as $it) {
    $at = (int)($it['at'] ?? 0);
    if ($at > 0 && $at <= $now && empty($it['sent'])) {
      $msg = $it['item'] ?? null;
      if (is_array($msg)) {
        $msg['id'] = $msg['id'] ?? id();
        $msg['at'] = gmdate('c');
        $msg['scheduled'] = false;
        pushMsg($msg);
      }
      $changed = true;
      continue;
    }
    $keep[] = $it;
  }
  if ($changed) {
    $doc['items'] = $keep;
    saveSched($doc);
  }
}

function deviceId(array $in): string {
  $d = preg_replace('/[^A-Za-z0-9._-]/', '', (string)($in['device'] ?? ''));
  if ($d !== '' && strlen($d) >= 8) return substr($d, 0, 64);
  return substr(hash('sha256', ($_SERVER['HTTP_USER_AGENT'] ?? '') . '|' . ip()), 0, 24);
}

function notify(string $uid, string $text, array $extra = []): array {
  $item = [
    'id' => id(),
    'at' => gmdate('c'),
    'nick' => 'система',
    'uid' => 'system',
    'avatar' => '',
    'kind' => 'system',
    'text' => cut($text, 400),
    'pinned' => false,
    'reactions' => [],
    'thread' => 'system',
    'to' => $uid
  ] + $extra;
  return pushMsg($item);
}

function publicUser(array $u, bool $self = false): array {
  $out = [
    'id' => $u['id'],
    'nick' => $u['nick'],
    'avatar' => $u['avatar'] ?? '',
    'cover' => $u['cover'] ?? ($u['banner'] ?? ''),
    'banner' => $u['cover'] ?? ($u['banner'] ?? ''),
    'bio' => $u['bio'] ?? '',
    'telegram' => $u['telegram'] ?? '',
    'discord' => $u['discord'] ?? '',
    'youtube' => $u['youtube'] ?? '',
    'tiktok' => $u['tiktok'] ?? '',
    'status' => $u['status'] ?? '',
    'online' => isOnline($u['id']),
    'lastSeen' => lastSeen($u['id']),
    'verified' => isVerified($u),
    'role' => $u['role'] ?? 'user',
    'admin' => isAdmin($u),
    'listStyle' => styleOk((string)($u['listStyle'] ?? 'classic')),
    'bubbleStyle' => bubbleOk((string)($u['bubbleStyle'] ?? 'tg')),
    'nameColor' => colorOk((string)($u['nameColor'] ?? '')),
    'badges' => array_values($u['badges'] ?? defaultBadges($u)),
    'modRank' => modRank($u),
    'pirikas' => (int)($u['pirikas'] ?? 0),
    'rights' => userRights($u),
    'cosmetics' => cosmeticsOf($u),
    'channelId' => (string)($u['channelId'] ?? ''),
    'avatarHat' => (string)(($u['cosmetics']['avatarHat'] ?? '')),
    'listHat' => (string)(($u['cosmetics']['listHat'] ?? '')),
    'profileHat' => (string)(($u['cosmetics']['profileHat'] ?? ''))
  ];
  if ($self) {
    $out['email'] = $u['email'];
    $out['gifs'] = $u['gifs'] ?? [];
    $out['muted'] = !empty($u['muted']);
    $out['blocked'] = $u['blocked'] ?? [];
    $out['muteUntil'] = (int)($u['muteUntil'] ?? 0);
    $out['banReason'] = $u['banReason'] ?? '';
    $out['banned'] = !empty($u['banned']);
    $out['warns'] = count($u['warns'] ?? []);
    $out['pinnedChats'] = $u['pinnedChats'] ?? [];
    $out['archived'] = $u['archived'] ?? [];
    $out['folders'] = $u['folders'] ?? [];
    $out['saved'] = $u['saved'] ?? [];
    $out['privacy'] = $u['privacy'] ?? ['whoWrite' => 'all', 'allowFrom' => [], 'denyFrom' => []];
    $out['allowFrom'] = $out['privacy']['allowFrom'] ?? [];
    $out['denyFrom'] = $out['privacy']['denyFrom'] ?? [];
    $out['customEmojiOff'] = !empty($u['customEmojiOff']);
    $out['needPassReset'] = !empty($u['needPassReset']);
    $out['sessions'] = array_values($u['sessions'] ?? []);
  }
  return $out;
}

function touchSeen(array $u): void {
  $doc = live();
  $doc['seen'][$u['id']] = time();
  if (count($doc['seen']) > 4000) $doc['seen'] = array_slice($doc['seen'], -2000, null, true);
  saveLive($doc);
}

function lastSeen(string $id): int {
  return (int)(live()['seen'][$id] ?? 0);
}

function isOnline(string $id): bool {
  return lastSeen($id) > time() - 90;
}

function findUserByNick(string $nick): ?array {
  $id = idxGet(VAULT_USERID, strtolower($nick));
  if ($id !== '') {
    $u = loadUser($id);
    if ($u) return $u;
  }
  foreach (allUsers() as $u) {
    if (strcasecmp((string)$u['nick'], $nick) === 0) return $u;
  }
  return null;
}

function findUserById(string $id): ?array {
  $u = loadUser($id);
  if ($u) return $u;
  foreach (allUsers() as $x) {
    if (($x['id'] ?? '') === $id) return $x;
  }
  return null;
}

function dmThread(string $a, string $b): string {
  $ids = [$a, $b];
  sort($ids);
  return 'dm:' . $ids[0] . ':' . $ids[1];
}

function threadOk(string $t): bool {
  return $t === 'global' || $t === 'channel' || $t === 'system' || $t === 'saved'
    || $t === 'dm:createbot' || $t === 'dm:adminbot'
    || (bool)preg_match('/^dm:u[a-f0-9]{8}:u[a-f0-9]{8}$/', $t)
    || (bool)preg_match('/^kanal:[A-Za-z0-9_-]{4,40}$/', $t)
    || (bool)preg_match('/^group:[A-Za-z0-9_-]{4,40}$/', $t);
}

function inThread(array $u, string $thread): bool {
  if ($thread === 'global' || $thread === 'channel') return true;
  if ($thread === 'system') return true;
  if ($thread === 'saved') return true;
  if ($thread === 'dm:createbot' || $thread === 'dm:adminbot') return true;
  if (preg_match('/^group:([A-Za-z0-9_-]{4,40})$/', $thread, $gm)) {
    $g = function_exists('loadGroup') ? loadGroup($gm[1]) : null;
    if (!$g) return false;
    if (($g['owner'] ?? '') === ($u['id'] ?? '')) return true;
    return in_array($u['id'], $g['members'] ?? [], true);
  }
  if (preg_match('/^kanal:([A-Za-z0-9_-]{4,40})$/', $thread, $km)) {
    $k = loadKanal($km[1]);
    if (!$k) return false;
    if (($k['owner'] ?? '') === ($u['id'] ?? '')) return true;
    if (!empty($k['public'])) return true;
    $subs = $k['subs'] ?? [];
    return in_array($u['id'], $subs, true);
  }
  if (!preg_match('/^dm:(u[a-f0-9]{8}):(u[a-f0-9]{8})$/', $thread, $m)) return false;
  return $m[1] === $u['id'] || $m[2] === $u['id'];
}

function loadKanal(string $id): ?array {
  $id = preg_replace('/[^A-Za-z0-9_-]/', '', $id);
  $f = kanalDir($id) . '/data/profile.bin';
  if (!is_file($f)) return null;
  $k = vaultRead($f, []);
  return $k ?: null;
}

function saveKanal(array $k): void {
  $id = (string)($k['id'] ?? '');
  if ($id === '') return;
  $dir = kanalDir($id);
  vaultWrite($dir . '/data/profile.bin', $k);
  if (!empty($k['handle'])) idxSet(VAULT_KANALID, '&@' . strtolower((string)$k['handle']), $id);
}

function kanalHandleOk(string $h): bool {
  return (bool)preg_match('/^[A-Za-z0-9_]{3,20}$/', $h);
}

function userRights(array $u): array {
  $r = $u['rights'] ?? [];
  if (!is_array($r)) $r = [];
  if (isAdmin($u)) {
    for ($i = 1; $i <= 12; $i++) $r[] = 'r' . $i;
  }
  return array_values(array_unique($r));
}

function hasRight(array $u, string $need): bool {
  if (isAdmin($u)) return true;
  return in_array($need, userRights($u), true);
}

function cosmeticsOf(array $u): array {
  $c = $u['cosmetics'] ?? [];
  return [
    'owned' => array_values($c['owned'] ?? []),
    'avatarHat' => (string)($c['avatarHat'] ?? ''),
    'listHat' => (string)($c['listHat'] ?? ''),
    'profileHat' => (string)($c['profileHat'] ?? '')
  ];
}

function shopItemPublic(array $it): array {
  return [
    'id' => $it['id'] ?? '',
    'name' => $it['name'] ?? '',
    'kind' => $it['kind'] ?? 'avatarHat',
    'desc' => $it['desc'] ?? '',
    'price' => (int)($it['price'] ?? 0),
    'url' => $it['url'] ?? '',
    'ext' => $it['ext'] ?? '',
    'anim' => !empty($it['anim'])
  ];
}

function chatInfo(string $id): array {
  $all = meta()['chats'] ?? [];
  $c = $all[$id] ?? ['id' => $id, 'title' => $id === 'channel' ? 'Канал' : 'CrynChat', 'about' => '', 'avatar' => '', 'banner' => '', 'kind' => $id === 'channel' ? 'channel' : 'group'];
  $c['id'] = $id;
  $c['banner'] = $c['banner'] ?? ($c['cover'] ?? '');
  $c['cover'] = $c['banner'];
  return $c;
}

function themeOk(string $s): string {
  static $ok = ['night', 'day', 'accent'];
  return in_array($s, $ok, true) ? $s : 'night';
}
function styleOk(string $s): string {
  static $ok = ['classic','neon','aurora','fire','ice','gold','rainbow','spark','wave','bloom','cyber','velvet','ocean','crystal','ember','pixel','ink','midnight','sunset','mintglow','silk','flare','haze','orbit','petal','steel','glow','paper','lava','mist'];
  return in_array($s, $ok, true) ? $s : 'classic';
}
function bubbleOk(string $s): string {
  static $ok = ['tg','round','square','glass','soft','outline','neon','minimal','cloud','comic','ink','ticket','pixel','ribbon','leaf','petal','chip','fold','glow','slab','whisper','capsule','frame','spark','1','2','3','4','5','6','7','8','9','p1','p2','p3','p4','p5','p6','p7','p8','p9'];
  return in_array($s, $ok, true) ? $s : 'tg';
}
function colorOk(string $s): string {
  return preg_match('/^#[0-9A-Fa-f]{6}$/', $s) ? strtolower($s) : '';
}
function defaultBadges(array $u): array {
  if (($u['role'] ?? '') === 'admin') return ['official'];
  if (($u['role'] ?? '') === 'mod') return ['staff'];
  if (($u['role'] ?? '') === 'bot') return ['official'];
  if (!empty($u['verified'])) return ['official'];
  return [];
}
function mskNow(): int {
  return time() + 3 * 3600;
}
function dayKey(int $ts = 0): string {
  $t = $ts ?: mskNow();
  return gmdate('Y-m-d', $t);
}
function monthKey(int $ts = 0): string {
  $t = $ts ?: mskNow();
  return gmdate('Y-m', $t);
}
function peerId(array $u, string $thread): string {
  if (!preg_match('/^dm:(u[a-f0-9]{8}):(u[a-f0-9]{8})$/', $thread, $m)) return '';
  return $m[1] === $u['id'] ? $m[2] : $m[1];
}
function streakTier(int $days): string {
  if ($days >= 1000) return 'k';
  if ($days >= 500) return '500';
  if ($days >= 100) return '100';
  if ($days >= 50) return '50';
  if ($days >= 10) return '10';
  if ($days >= 3) return 'lit';
  return '';
}
function streakMilestones(): array {
  return [10, 50, 100, 500, 1000];
}
function emptyStreak(): array {
  return [
    'days' => 0, 'day' => '', 'from' => false, 'to' => false, 'born' => false,
    'gray' => false, 'dead' => false, 'best' => 0, 'revives' => 0, 'reviveMonth' => '',
    'wrote' => [], 'done' => ''
  ];
}
function streakOf(array $u, string $peer): array {
  $s = $u['streaks'][$peer] ?? [];
  $today = dayKey();
  $yest = dayKey(mskNow() - 86400);
  $days = max(0, (int)($s['days'] ?? 0));
  $prev = (string)($s['day'] ?? '');
  $gray = !empty($s['gray']);
  $dead = !empty($s['dead']);
  $from = !empty($s['from']);
  $to = !empty($s['to']);
  if ($days > 0 && $prev !== '' && $prev !== $today && $prev !== $yest) {
    $dead = true;
    $gray = false;
    $days = 0;
  } elseif ($days >= 3 && $prev === $yest && (!$from || !$to)) {
    $gray = true;
  } elseif ($prev === $today && $from && $to) {
    $gray = false;
  }
  $out = [
    'days' => $days,
    'day' => $prev,
    'from' => $from,
    'to' => $to,
    'born' => !empty($s['born']),
    'gray' => $gray,
    'dead' => $dead,
    'best' => max($days, (int)($s['best'] ?? 0)),
    'revives' => (int)($s['revives'] ?? 0),
    'reviveMonth' => (string)($s['reviveMonth'] ?? ''),
    'tier' => streakTier($days),
    'lit' => $days >= 3 && !$dead && !$gray
  ];
  return $out;
}
function streakLeft(array $s): int {
  $month = monthKey();
  $used = ((string)($s['reviveMonth'] ?? '') === $month) ? (int)($s['revives'] ?? 0) : 0;
  return max(0, 4 - $used);
}
function syncStreakPair(string $a, string $b, array $s): void {
  $copy = $s;
  patchUser($a, function (&$x) use ($b, $copy) {
    $x['streaks'] = $x['streaks'] ?? [];
    $x['streaks'][$b] = $copy;
  });
  patchUser($b, function (&$x) use ($a, $copy) {
    $x['streaks'] = $x['streaks'] ?? [];
    $x['streaks'][$a] = $copy;
  });
  vaultWrite(oqonekFile($a, $b), [
    'a' => $a,
    'b' => $b,
    'share' => 'oqonek/' . vaultName($a . ':' . $b),
    'gif' => 'oqon.gif',
    'webp' => 'oqon.webp',
    'streak' => $copy
  ]);
}
function bumpStreak(array $u, string $thread): array {
  $peer = peerId($u, $thread);
  if ($peer === '') return ['days' => 0, 'lit' => false, 'born' => false, 'gray' => false, 'dead' => false];
  $today = dayKey();
  $yest = dayKey(mskNow() - 86400);
  $me = findUserById($u['id']);
  $other = findUserById($peer);
  if (!is_array($me) || !is_array($other)) return ['days' => 0, 'lit' => false, 'born' => false];
  $s = array_merge(emptyStreak(), $me['streaks'][$peer] ?? []);
  $prev = (string)($s['day'] ?? '');
  $month = monthKey();
  if ((string)($s['reviveMonth'] ?? '') !== $month) {
    $s['revives'] = 0;
    $s['reviveMonth'] = $month;
  }
  $wrote = is_array($s['wrote'] ?? null) ? $s['wrote'] : [];
  if (!empty($s['from']) && !in_array($u['id'], $wrote, true)) $wrote[] = $u['id'];
  if (!empty($s['to']) && !in_array($peer, $wrote, true)) $wrote[] = $peer;
  $hadDays = (int)($s['days'] ?? 0);
  $out = [
    'days' => $hadDays,
    'lit' => false,
    'born' => false,
    'gray' => !empty($s['gray']),
    'dead' => false,
    'peer' => $peer,
    'milestone' => 0,
    'reviveOffer' => false,
    'revivesLeft' => streakLeft($s),
    'tier' => streakTier($hadDays)
  ];
  if ($prev !== '' && $prev !== $today && $prev !== $yest && $hadDays >= 3) {
    $left = streakLeft($s);
    $s['best'] = max((int)($s['best'] ?? 0), $hadDays);
    $s['dead'] = true;
    $s['gray'] = false;
    $s['days'] = 0;
    $s['born'] = false;
    $s['day'] = $today;
    $s['wrote'] = [$u['id']];
    $s['from'] = true;
    $s['to'] = false;
    syncStreakPair($u['id'], $peer, $s);
    $out['dead'] = true;
    $out['days'] = 0;
    $out['reviveOffer'] = $left > 0;
    $out['revivesLeft'] = $left;
    $out['lit'] = false;
    $out['tier'] = '';
    return $out;
  }
  if ($prev !== $today) {
    $s['day'] = $today;
    $wrote = [$u['id']];
    if ($prev === $yest && $hadDays >= 3) $s['gray'] = true;
  } else {
    if (!in_array($u['id'], $wrote, true)) $wrote[] = $u['id'];
  }
  $s['wrote'] = array_values(array_unique($wrote));
  $s['from'] = in_array($u['id'], $s['wrote'], true);
  $s['to'] = in_array($peer, $s['wrote'], true);
  $both = count($s['wrote']) >= 2;
  $before = $hadDays;
  $done = (string)($s['done'] ?? '');
  if ($both && $done !== $today) {
    $s['gray'] = false;
    $s['dead'] = false;
    if ($done === $yest) $s['days'] = max(1, $before) + 1;
    elseif ($before > 0 && $prev === $yest) $s['days'] = max(1, $before) + 1;
    elseif ($before > 0 && $done === '') $s['days'] = max(1, $before);
    else $s['days'] = 1;
    $s['done'] = $today;
    $s['best'] = max((int)($s['best'] ?? 0), (int)$s['days']);
    if ((int)$s['days'] >= 3 && empty($s['born'])) {
      $s['born'] = true;
      $out['born'] = true;
    }
    foreach (streakMilestones() as $ms) {
      if ($before < $ms && (int)$s['days'] >= $ms) $out['milestone'] = $ms;
    }
  }
  syncStreakPair($u['id'], $peer, $s);
  $days = (int)($s['days'] ?? 0);
  $out['days'] = $days;
  $out['gray'] = !empty($s['gray']);
  $out['lit'] = $days >= 3 && empty($s['gray']) && empty($s['dead']);
  $out['tier'] = streakTier($days);
  $out['revivesLeft'] = streakLeft($s);
  return $out;
}
function reviveStreak(array $u, string $thread): array {
  $peer = peerId($u, $thread);
  if ($peer === '') fail('Только в личке');
  $me = findUserById($u['id']);
  $s = $me['streaks'][$peer] ?? emptyStreak();
  $month = monthKey();
  if ((string)($s['reviveMonth'] ?? '') !== $month) {
    $s['revives'] = 0;
    $s['reviveMonth'] = $month;
  }
  if (streakLeft($s) <= 0) fail('Лимит возвратов на этот месяц исчерпан');
  $best = max(1, (int)($s['best'] ?? 0), (int)($s['days'] ?? 0));
  $s['revives'] = (int)($s['revives'] ?? 0) + 1;
  $s['reviveMonth'] = $month;
  $s['days'] = max(3, min($best, (int)($s['days'] ?? 0) ?: $best));
  $s['day'] = dayKey();
  $s['from'] = true;
  $s['to'] = true;
  $s['gray'] = false;
  $s['dead'] = false;
  $s['born'] = true;
  $s['best'] = max((int)($s['best'] ?? 0), (int)$s['days']);
  syncStreakPair($u['id'], $peer, $s);
  return [
    'days' => (int)$s['days'],
    'lit' => true,
    'born' => false,
    'revived' => true,
    'revivesLeft' => streakLeft($s),
    'tier' => streakTier((int)$s['days']),
    'peer' => $peer
  ];
}
function streakTopText(): string {
  $rows = [];
  foreach (users()['users'] as $u) {
    foreach (($u['streaks'] ?? []) as $peer => $s) {
      $days = (int)($s['days'] ?? 0);
      if ($days < 3) continue;
      $other = findUserById((string)$peer);
      $onick = is_array($other) ? ($other['nick'] ?? $peer) : $peer;
      $key = min((string)$u['nick'], (string)$onick) . '|' . max((string)$u['nick'], (string)$onick);
      if (!isset($rows[$key]) || $rows[$key]['days'] < $days) {
        $rows[$key] = ['a' => $u['nick'], 'b' => $onick, 'days' => $days, 'tier' => streakTier($days)];
      }
    }
  }
  usort($rows, fn($a, $b) => $b['days'] <=> $a['days']);
  $rows = array_slice(array_values($rows), 0, 20);
  if (!$rows) return 'Пока нет живых огоньков.';
  $lines = ['Топ огоньков'];
  $i = 1;
  foreach ($rows as $r) {
    $lines[] = $i . '. @' . $r['a'] . ' × @' . $r['b'] . ' — ' . $r['days'] . ' дн';
    $i++;
  }
  return implode("\n", $lines);
}
function streakTopList(): array {
  $rows = [];
  foreach (users()['users'] as $u) {
    foreach (($u['streaks'] ?? []) as $peer => $s) {
      $days = (int)($s['days'] ?? 0);
      if ($days < 3 && empty($s['best'])) continue;
      $other = findUserById((string)$peer);
      $onick = is_array($other) ? ($other['nick'] ?? $peer) : $peer;
      $key = min((string)$u['id'], (string)$peer) . '|' . max((string)$u['id'], (string)$peer);
      $show = max($days, (int)($s['best'] ?? 0));
      if (!isset($rows[$key]) || $rows[$key]['days'] < $show) {
        $rows[$key] = [
          'a' => $u['nick'],
          'b' => $onick,
          'days' => $days,
          'best' => max($days, (int)($s['best'] ?? 0)),
          'gray' => !empty($s['gray']),
          'tier' => streakTier($days)
        ];
      }
    }
  }
  $list = array_values($rows);
  usort($list, fn($a, $b) => ($b['days'] <=> $a['days']) ?: ($b['best'] <=> $a['best']));
  return array_slice($list, 0, 50);
}

function blocked(array $u, string $nick): bool {
  $list = $u['blocked'] ?? [];
  return in_array($nick, $list, true);
}

function mediaUrl(string $fname): string {
  if (preg_match('/^([a-f0-9]{40})\.([a-z0-9]+)$/i', $fname, $m)) {
    return mediaSign(strtolower($m[1]), strtolower($m[2]));
  }
  return PUBLIC_BASE . '?m=denied';
}

function patchUser(string $id, callable $fn) {
  $x = loadUser($id);
  if (!$x) fail('Нет профиля');
  $fn($x);
  saveUserDoc($x);
  return $x;
}

function findMsg(string $id): ?array {
  $m = findThreadMsg($id);
  if ($m) {
    unset($m['_file']);
    return $m;
  }
  return null;
}

function saveMsgItem(string $id, callable $fn) {
  return patchThreadMsg($id, $fn);
}

function pushMsg(array $item): array {
  return pushThreadMsg($item);
}

function unreadCount(array $u, string $thread = 'global'): int {
  $doc = live();
  $key = $u['id'] . ':' . $thread;
  $since = (int)($doc['read'][$key] ?? 0);
  $n = 0;
  foreach (msgs()['items'] as $m) {
    if (($m['thread'] ?? 'global') !== $thread) continue;
    if (($m['nick'] ?? '') === $u['nick']) continue;
    $ts = strtotime((string)($m['at'] ?? '')) ?: 0;
    if ($ts <= $since) break;
    $n++;
    if ($n > 99) break;
  }
  return $n;
}

function lastInThread(string $thread, ?array $u = null): array {
  foreach (scanDays($thread, 21) as $day) {
    $items = msgsOf($thread, $day)['items'] ?? [];
    foreach ($items as $m) {
      if (($m['thread'] ?? 'global') !== $thread) continue;
      if (!empty($m['deleted'])) continue;
      if ($thread === 'system' && $u && ($m['to'] ?? '') !== '' && ($m['to'] ?? '') !== $u['id']) continue;
      if ($thread === 'saved' && $u && ($m['uid'] ?? '') !== $u['id']) continue;
      return $m;
    }
  }
  return [];
}

function withLast(array $chats, ?array $u = null): array {
  $out = [];
  foreach ($chats as $c) {
    if (!is_array($c)) continue;
    $id = (string)($c['id'] ?? '');
    $last = $id !== '' ? lastInThread($id, $u) : [];
    if ($last) {
      $c['lastText'] = cut((string)($last['text'] ?? $last['caption'] ?? $last['kind'] ?? ''), 80);
      $c['lastNick'] = $last['nick'] ?? '';
      $c['lastAt'] = $last['at'] ?? '';
      $c['lastKind'] = $last['kind'] ?? '';
    }
    $out[] = $c;
  }
  return $out;
}

if (!launcherOk()) fail('Только лаунчер', 403);
flushScheduled();
$uri = (string)($_SERVER['REQUEST_URI'] ?? '');
if (!empty($v1Get) || strpos($uri, '/v1') !== false || (string)($_GET['v'] ?? '') === '1') {
  require __DIR__ . '/v1.php';
  exit;
}
$raw = file_get_contents('php://input') ?: '';
if (strlen($raw) > MAX_BODY) fail('Слишком большой запрос', 413);
$in = json_decode($raw, true);
if (!is_array($in)) fail('JSON');
$action = (string)($in['action'] ?? '');
if (!preg_match('/^[A-Za-z]{2,48}$/', $action)) fail('Неизвестное действие', 404);

if ($action === 'register') {
  rateFor(['id' => 'guest', 'role' => 'user'], 'reg');
  $nick = trim((string)($in['nick'] ?? ''));
  $email = strtolower(trim((string)($in['email'] ?? '')));
  $pass = (string)($in['password'] ?? '');
  if (!nickOk($nick)) fail('Ник: 3–20 латиница, цифры, _');
  if (!filter_var($email, FILTER_VALIDATE_EMAIL)) fail('Плохая почта');
  if (strlen($pass) < 8 || strlen($pass) > 72) fail('Пароль 8–72 символа');
  $doc = users();
  foreach ($doc['users'] as $u) {
    if (strcasecmp($u['nick'], $nick) === 0 || strcasecmp($u['email'], $email) === 0) fail('Неверные данные');
  }
  $code = makeCode();
  $isFirst = false;
  $needCode = !empty(meta()['requireVerify']);
  $newUser = [
    'id' => 'u' . bin2hex(random_bytes(4)),
    'nick' => $nick,
    'email' => $email,
    'hash' => password_hash($pass, PASSWORD_DEFAULT),
    'token' => '',
    'gifs' => [],
    'created' => gmdate('c'),
    'verified' => !$needCode,
    'verifyHash' => $needCode ? password_hash($code, PASSWORD_DEFAULT) : '',
    'verifyUntil' => $needCode ? time() + 1800 : 0,
    'avatar' => '',
    'bio' => '',
    'telegram' => '',
    'discord' => '',
    'youtube' => '',
    'tiktok' => '',
    'status' => '',
    'muted' => false,
    'blocked' => [],
    'role' => $isFirst ? 'admin' : 'user',
    'warns' => [],
    'banned' => false,
    'banUntil' => 0,
    'banReason' => '',
    'muteUntil' => 0,
    'muteReason' => '',
    'device' => deviceId($in),
    'pendingDevice' => '',
    'pendingCode' => '',
    'stickersSaved' => [],
    'cleared' => [],
    'pinnedChats' => [],
    'archived' => [],
    'folders' => [],
    'saved' => [],
    'pirikas' => 0,
    'rights' => [],
    'cosmetics' => ['owned' => [], 'avatarHat' => '', 'listHat' => '', 'profileHat' => ''],
    'channelId' => '',
    'tfa' => false,
    'sessions' => []
  ];
  $token = issueToken($newUser);
  $refresh = refreshTokenOf($newUser);
  $doc['users'][] = $newUser;
  saveUsers($doc);
  wsTokenPut($token, (string)$newUser['id'], $nick, (int)$newUser['tokenExp']);
  $uid = (string)$newUser['id'];
  lsDir($uid);
  savesDir($uid);
  if ($needCode) sendCodeMail($email, $code, 'подтверждения почты');
  ok(['token' => $token, 'refresh_token' => $refresh, 'nick' => $nick, 'email' => $email, 'needVerify' => $needCode, 'mailed' => $needCode, 'role' => 'user', 'admin' => false, 'verified' => !$needCode, 'limits' => limitsFor($newUser)]);
}

if ($action === 'login') {
  rateFor(['id' => 'guest', 'role' => 'user'], 'login');
  $email = strtolower(trim((string)($in['email'] ?? '')));
  $pass = (string)($in['password'] ?? '');
  $dev = deviceId($in);
  $doc = users();
  foreach ($doc['users'] as &$u) {
    if (strcasecmp($u['email'], $email) !== 0) continue;
    if (!empty($u['needPassReset'])) {
      fail('Пароль сброшен администратором. Задайте новый пароль', 401);
    }
    if (!password_verify($pass, $u['hash'])) fail('Неверные данные', 401);
    $old = (string)($u['device'] ?? '');
    if ($old !== '' && $old !== $dev) {
      $code = makeCode();
      $u['pendingDevice'] = $dev;
      $u['pendingCode'] = password_hash($code, PASSWORD_DEFAULT);
      $u['pendingUntil'] = time() + 1800;
      saveUsers($doc);
      sendCodeMail($u['email'], $code, 'входа с нового устройства');
      notify($u['id'], 'Попытка входа с другого устройства. Код отправлен на почту.');
      ok(['needDevice' => true, 'mailed' => true, 'email' => $u['email'], 'hint' => 'Подтверди вход кодом с почты']);
    }
    $plain = issueToken($u);
    $refresh = refreshTokenOf($u);
    $u['device'] = $dev;
    $u['pendingDevice'] = '';
    $u['pendingCode'] = '';
    saveUsers($doc);
    wsTokenPut($plain, (string)$u['id'], (string)$u['nick'], (int)$u['tokenExp']);
    $need = !isVerified($u);
    ok(['token' => $plain, 'refresh_token' => $refresh, 'nick' => $u['nick'], 'email' => $u['email'], 'needVerify' => $need, 'verified' => !$need, 'limits' => limitsFor($u)] + publicUser($u, true));
  }
  fail('Неверные данные', 401);
}

if ($action === 'confirmDevice') {
  rateFor(['id' => 'guest', 'role' => 'user'], 'login');
  $email = strtolower(trim((string)($in['email'] ?? '')));
  $code = preg_replace('/\D+/', '', (string)($in['code'] ?? ''));
  $pass = (string)($in['password'] ?? '');
  $dev = deviceId($in);
  $doc = users();
  foreach ($doc['users'] as &$u) {
    if (strcasecmp($u['email'], $email) !== 0) continue;
    if (!password_verify($pass, $u['hash'])) fail('Неверные данные', 401);
    if (strlen($code) !== 6) fail('Код из 6 цифр');
    if ((int)($u['pendingUntil'] ?? 0) < time()) fail('Код истёк');
    if (empty($u['pendingCode']) || !password_verify($code, $u['pendingCode'])) fail('Неверный код');
    $plain = issueToken($u);
    $refresh = refreshTokenOf($u);
    $u['device'] = $dev;
    $u['pendingDevice'] = '';
    $u['pendingCode'] = '';
    $u['pendingUntil'] = 0;
    saveUsers($doc);
    wsTokenPut($plain, (string)$u['id'], (string)$u['nick'], (int)$u['tokenExp']);
    notify($u['id'], 'Новое устройство подтверждено. Старая сессия сброшена.');
    $need = !isVerified($u);
    ok(['token' => $plain, 'refresh_token' => $refresh, 'nick' => $u['nick'], 'email' => $u['email'], 'needVerify' => $need, 'verified' => !$need, 'limits' => limitsFor($u)] + publicUser($u, true));
  }
  fail('Неверные данные', 401);
}

if ($action === 'verify') {
  $u = needUser($in);
  rate('verify', 12, 600);
  $code = preg_replace('/\D+/', '', (string)($in['code'] ?? ''));
  if (strlen($code) !== 6) fail('Код из 6 цифр');
  if (!empty($u['verified'])) ok(['nick' => $u['nick'], 'verified' => true] + publicUser($u, true));
  if ((int)($u['verifyUntil'] ?? 0) < time()) fail('Код истёк. Запроси новый');
  if (empty($u['verifyHash']) || !password_verify($code, $u['verifyHash'])) fail('Неверный код');
  $saved = patchUser($u['id'], function (&$x) {
    $x['verified'] = true;
    $x['verifyHash'] = '';
    $x['verifyUntil'] = 0;
  });
  ok(['nick' => $saved['nick'], 'verified' => true, 'email' => $saved['email']] + publicUser($saved, true));
}

if ($action === 'resendVerify') {
  $u = needUser($in);
  rate('resend', 6, 600);
  if (!empty($u['verified'])) ok(['verified' => true, 'mailed' => false]);
  $code = makeCode();
  patchUser($u['id'], function (&$x) use ($code) {
    $x['verifyHash'] = password_hash($code, PASSWORD_DEFAULT);
    $x['verifyUntil'] = time() + 1800;
  });
  $okMail = sendCodeMail($u['email'], $code, 'подтверждения почты');
  ok(['needVerify' => true, 'mailed' => $okMail, 'email' => $u['email']]);
}

if ($action === 'logout') {
  $u = needUser($in);
  patchUser($u['id'], function (&$x) {
    $x['token'] = bin2hex(random_bytes(24));
    $x['tokenHash'] = tokenHash($x['token']);
    $x['tokenExp'] = 0;
    $x['refreshHash'] = '';
    $x['refreshExp'] = 0;
  });
  ok(['logged_out' => true]);
}

if ($action === 'refresh') {
  rateFor(['id' => 'guest', 'role' => 'user'], 'refresh');
  $rt = (string)($in['refresh_token'] ?? $in['refresh'] ?? '');
  if ($rt === '' || strlen($rt) < 32) fail('Нужен вход', 401);
  $h = hash('sha256', $rt);
  foreach (allUsers() as $u) {
    if (!hash_equals((string)($u['refreshHash'] ?? ''), $h)) continue;
    if ((int)($u['refreshExp'] ?? 0) < time()) fail('Нужен вход', 401);
    $access = issueToken($u);
    $refresh = refreshTokenOf($u);
    saveUserDoc($u);
    wsTokenPut($access, (string)$u['id'], (string)$u['nick'], (int)$u['tokenExp']);
    ok(['token' => $access, 'refresh_token' => $refresh, 'user' => publicUser($u, true), 'limits' => limitsFor($u)]);
  }
  fail('Нужен вход', 401);
}

if ($action === 'limits') {
  $u = userByToken((string)($in['token'] ?? ''));
  ok(['limits' => limitsFor($u ?: null)]);
}

if ($action === 'createGroup') {
  $u = needUser($in);
  needVerified($u);
  rateFor($u, 'group');
  $title = cut((string)($in['title'] ?? $in['name'] ?? ''), 40);
  if ($title === '') fail('Название');
  $id = 'g' . bin2hex(random_bytes(4));
  $g = [
    'id' => $id,
    'title' => $title,
    'about' => cut((string)($in['about'] ?? ''), 200),
    'owner' => $u['id'],
    'members' => [$u['id']],
    'admins' => [$u['id']],
    'created' => gmdate('c'),
    'public' => !empty($in['public']),
    'readonly' => false,
    'avatar' => ''
  ];
  saveGroup($g);
  ok(['thread' => 'group:' . $id, 'group' => $g]);
}

if ($action === 'joinGroup') {
  $u = needUser($in);
  $tid = (string)($in['thread'] ?? $in['id'] ?? '');
  $g = loadGroup($tid);
  if (!$g) fail('Нет такого');
  if (empty($g['public']) && ($g['owner'] ?? '') !== $u['id'] && !isAdmin($u)) fail('Нет доступа', 403);
  $g['members'] = array_values(array_unique(array_merge($g['members'] ?? [], [$u['id']])));
  saveGroup($g);
  ok(['joined' => true, 'thread' => 'group:' . $g['id']]);
}

if ($action === 'leaveGroup') {
  $u = needUser($in);
  $g = loadGroup((string)($in['thread'] ?? $in['id'] ?? ''));
  if (!$g) fail('Нет такого');
  $g['members'] = array_values(array_filter($g['members'] ?? [], fn($id) => $id !== $u['id']));
  saveGroup($g);
  ok(['left' => true]);
}

if ($action === 'inviteGroup') {
  $u = needUser($in);
  rateFor($u, 'invite');
  $tid = (string)($in['thread'] ?? '');
  if (!aclCan($u, 'threads.read', ['thread' => $tid])) fail('Нет доступа', 403);
  $code = bin2hex(random_bytes(6));
  vaultWrite(inviteFile($code), ['code' => $code, 'thread' => $tid, 'by' => $u['id'], 'exp' => time() + 7 * 86400, 'uses' => 0, 'max' => 32]);
  ok(['code' => $code]);
}

if ($action === 'acceptInvite') {
  $u = needUser($in);
  $code = preg_replace('/[^A-Za-z0-9]/', '', (string)($in['code'] ?? ''));
  $inv = vaultRead(inviteFile($code), []);
  if (!$inv || (int)($inv['exp'] ?? 0) < time()) fail('Нет такого');
  $tid = (string)($inv['thread'] ?? '');
  $g = loadGroup($tid);
  if ($g) {
    $g['members'] = array_values(array_unique(array_merge($g['members'] ?? [], [$u['id']])));
    saveGroup($g);
  }
  $inv['uses'] = (int)($inv['uses'] ?? 0) + 1;
  vaultWrite(inviteFile($code), $inv);
  ok(['thread' => $tid]);
}

if ($action === 'setFolder') {
  $u = needUser($in);
  $name = cut((string)($in['name'] ?? ''), 24);
  if ($name === '') fail('Название');
  $fid = cut((string)($in['id'] ?? ''), 24);
  if ($fid === '') $fid = 'f' . bin2hex(random_bytes(3));
  $saved = patchUser($u['id'], function (&$x) use ($fid, $name, $in) {
    $x['folders'] = $x['folders'] ?? [];
    $found = false;
    foreach ($x['folders'] as &$f) {
      if (($f['id'] ?? '') !== $fid) continue;
      $f['name'] = $name;
      if (isset($in['threads'])) $f['threads'] = array_values((array)$in['threads']);
      $found = true;
    }
    if (!$found) $x['folders'][] = ['id' => $fid, 'name' => $name, 'threads' => array_values((array)($in['threads'] ?? []))];
  });
  ok(['folders' => $saved['folders'] ?? []]);
}

if ($action === 'tfaSetup') {
  $u = needUser($in);
  $secret = tfaSecretNew();
  patchUser($u['id'], function (&$x) use ($secret) { $x['tfaPending'] = $secret; });
  ok(['secret' => $secret, 'otpauth' => 'otpauth://totp/CrynChat:' . rawurlencode((string)$u['nick']) . '?secret=' . $secret . '&issuer=CrynChat']);
}

if ($action === 'tfaEnable') {
  $u = needUser($in);
  rateFor($u, 'tfa');
  $secret = (string)($u['tfaPending'] ?? '');
  $code = (string)($in['code'] ?? $in['otp'] ?? '');
  if ($secret === '' || !tfaCheck($secret, $code)) fail('Неверный код');
  $saved = patchUser($u['id'], function (&$x) use ($secret) {
    $x['tfa'] = true;
    $x['tfaSecret'] = $secret;
    $x['tfaPending'] = '';
  });
  ok(['tfa' => true, 'user' => publicUser($saved, true)]);
}

if ($action === 'tfaDisable') {
  $u = needUser($in);
  rateFor($u, 'tfa');
  $pass = (string)($in['password'] ?? '');
  $code = (string)($in['code'] ?? '');
  if ($pass === '' || !password_verify($pass, (string)($u['hash'] ?? ''))) fail('Неверные данные', 401);
  if (!empty($u['tfaSecret']) && !tfaCheck((string)$u['tfaSecret'], $code)) fail('Неверный код');
  $saved = patchUser($u['id'], function (&$x) {
    $x['tfa'] = false;
    $x['tfaSecret'] = '';
  });
  ok(['tfa' => false, 'user' => publicUser($saved, true)]);
}

if ($action === 'me') {
  $u = needUser($in);
  $cfg = meta();
  ok(publicUser($u, true) + [
    'gifs' => $u['gifs'] ?? [],
    'needVerify' => !isVerified($u),
    'unread' => unreadCount($u),
    'unreadChannel' => unreadCount($u, 'channel'),
    'unreadSaved' => unreadCount($u, 'saved'),
    'unreadSystem' => unreadCount($u, 'system'),
    'pinnedChats' => $u['pinnedChats'] ?? [],
    'archived' => $u['archived'] ?? [],
    'mutedChats' => $u['mutedChats'] ?? [],
    'settings' => [
      'requireVerify' => !empty($cfg['requireVerify']),
      'allowGifs' => !empty($cfg['allowGifs']),
      'allowStickers' => !empty($cfg['allowStickers']),
      'allowUploads' => !empty($cfg['allowUploads']),
      'allowPolls' => !empty($cfg['allowPolls']),
      'allowDms' => !empty($cfg['allowDms']),
      'readonly' => !empty($cfg['readonly']),
      'slowMode' => (int)($cfg['slowMode'] ?? 0),
      'defaultTheme' => themeOk((string)($cfg['defaultTheme'] ?? 'night')),
      'defaultSkin' => (string)($cfg['defaultSkin'] ?? 'tg'),
      'defaultBubble' => bubbleOk((string)($cfg['defaultBubble'] ?? 'tg')),
      'defaultList' => styleOk((string)($cfg['defaultList'] ?? 'classic'))
    ],
    'chats' => withLast(array_values($cfg['chats'] ?? []), $u),
    'ws' => ['url' => WS_PUBLIC, 'port' => WS_PORT],
    'pirikas' => (int)($u['pirikas'] ?? 0),
    'limits' => limitsFor($u)
  ]);
}

if ($action === 'chats') {
  $u = needUser($in);
  $items = array_values(meta()['chats'] ?? []);
  if (!empty($u['channelId'])) {
    $k = loadKanal((string)$u['channelId']);
    if ($k) $items[] = [
      'id' => 'kanal:' . $k['id'],
      'title' => $k['title'] ?? $k['handle'] ?? 'Канал',
      'about' => $k['about'] ?? '',
      'avatar' => $k['avatar'] ?? '',
      'banner' => $k['banner'] ?? '',
      'kind' => 'channel',
      'handle' => '&@' . ($k['handle'] ?? ''),
      'mine' => true
    ];
  }
  $saves = savesDir($u['id']);
  $subFile = $saves . '/channels.bin';
  $subs = vaultRead($subFile, ['ids' => []]);
  foreach (($subs['ids'] ?? []) as $kid) {
    if ((string)$kid === (string)($u['channelId'] ?? '')) continue;
    $k = loadKanal((string)$kid);
    if (!$k) continue;
    $items[] = [
      'id' => 'kanal:' . $k['id'],
      'title' => $k['title'] ?? $k['handle'] ?? 'Канал',
      'about' => $k['about'] ?? '',
      'avatar' => $k['avatar'] ?? '',
      'banner' => $k['banner'] ?? '',
      'kind' => 'channel',
      'handle' => '&@' . ($k['handle'] ?? '')
    ];
  }
  ok(['items' => withLast($items, $u)]);
}

if ($action === 'profile' || $action === 'saveProfile') {
  $u = needUser($in);
  if ($action === 'saveProfile') {
    rate('prof', 20, 60);
    $saved = patchUser($u['id'], function (&$x) use ($in) {
      foreach (['bio' => 360, 'telegram' => 64, 'discord' => 64, 'youtube' => 80, 'tiktok' => 64, 'status' => 24] as $k => $n) {
        if (isset($in[$k])) $x[$k] = cut((string)$in[$k], $n);
      }
      if (isset($in['privacy']) && is_array($in['privacy'])) {
        $x['privacy'] = [
          'whoWrite' => in_array((string)($in['privacy']['whoWrite'] ?? 'all'), ['all', 'contacts', 'nobody'], true) ? (string)$in['privacy']['whoWrite'] : 'all',
          'allowFrom' => array_values(array_filter(array_map(fn($n) => cut((string)$n, 20), (array)($in['privacy']['allowFrom'] ?? [])), fn($n) => nickOk($n))),
          'denyFrom' => array_values(array_filter(array_map(fn($n) => cut((string)$n, 20), (array)($in['privacy']['denyFrom'] ?? [])), fn($n) => nickOk($n)))
        ];
      }
      if (isset($in['customEmojiOff'])) $x['customEmojiOff'] = (bool)$in['customEmojiOff'];
      if (isset($in['avatar'])) {
        $av = cut((string)$in['avatar'], 2000);
        if ($av !== '' && !safeUrl($av) && !preg_match('#^https://my\.cryndel\.ru/#i', $av)) fail('Аватар только https');
        $x['avatar'] = $av;
      }
      if (isset($in['cover']) || isset($in['banner'])) {
        $cv = cut((string)($in['cover'] ?? $in['banner'] ?? ''), 2000);
        if ($cv !== '' && !safeUrl($cv) && !preg_match('#^https://my\.cryndel\.ru/#i', $cv)) fail('Баннер только https');
        $x['cover'] = $cv;
        $x['banner'] = $cv;
      }
      if (isset($in['muted'])) $x['muted'] = (bool)$in['muted'];
      if (isset($in['listStyle'])) $x['listStyle'] = styleOk((string)$in['listStyle']);
      if (isset($in['bubbleStyle'])) $x['bubbleStyle'] = bubbleOk((string)$in['bubbleStyle']);
      if (isset($in['nameColor'])) $x['nameColor'] = colorOk((string)$in['nameColor']);
    });
    $u = $saved;
  }
  ok(publicUser($u, true));
}

if ($action === 'user') {
  needUser($in);
  $nick = trim((string)($in['nick'] ?? ''));
  $x = findUserByNick($nick);
  if (!$x) fail('Нет такого');
  ok(['user' => publicUser($x)]);
}

if ($action === 'searchUsers') {
  $u = needUser($in);
  rateFor($u, 'find');
  $q = strtolower(cut((string)($in['q'] ?? ''), 20));
  $out = [];
  foreach (users()['users'] as $x) {
    if ($x['id'] === $u['id']) continue;
    if ($q !== '' && strpos(strtolower((string)$x['nick']), $q) === false) continue;
    $out[] = publicUser($x);
    if (count($out) >= 20) break;
  }
  ok(['items' => $out]);
}

if ($action === 'messages') {
  $u = needUser($in);
  rateFor($u, 'read');
  $thread = (string)($in['thread'] ?? 'global');
  if (!threadOk($thread)) $thread = 'global';
  if (!inThread($u, $thread)) fail('Нет доступа', 403);
  $before = max(0, (int)($in['before'] ?? 0));
  $beforeSeq = (int)($in['before_seq'] ?? 0);
  $afterSeq = (int)($in['after_seq'] ?? 0);
  $limit = min(80, max(1, (int)($in['limit'] ?? 40)));
  $all = [];
  $block = is_array($u) ? ($u['blocked'] ?? []) : [];
  $clearedAt = is_array($u) ? (int)(($u['cleared'][$thread] ?? 0)) : 0;
  $pool = [];
  foreach (scanDays($thread, 14) as $day) {
    foreach ((msgsOf($thread, $day)['items'] ?? []) as $m) $pool[] = $m;
  }
  foreach ($pool as $m) {
    if (($m['thread'] ?? $thread) !== $thread && ($m['thread'] ?? 'global') !== $thread) continue;
     if ($thread === 'system' && $u && ($m['to'] ?? '') !== '' && ($m['to'] ?? '') !== $u['id']) continue;
     if ($thread === 'saved' && $u && ($m['uid'] ?? '') !== $u['id']) continue;
    if ($u && in_array((string)($m['nick'] ?? ''), $block, true)) continue;
    if ($u && !empty($m['hiddenFor']) && in_array($u['id'], $m['hiddenFor'], true)) continue;
    if ($clearedAt) {
      $ts = strtotime((string)($m['at'] ?? '')) ?: 0;
      if ($ts && $ts <= $clearedAt) continue;
    }
    if (!empty($m['deleted'])) {
      $m['text'] = '';
      $m['url'] = null;
      $m['caption'] = '';
    }
    unset($m['reactors']);
    if (isset($m['poll']) && is_array($m['poll'])) unset($m['poll']['voters']);
    $seq = (int)($m['seq'] ?? 0);
    if ($beforeSeq > 0 && $seq >= $beforeSeq) continue;
    if ($afterSeq > 0 && $seq <= $afterSeq) continue;
    $all[] = $m;
  }
  $slice = $beforeSeq || $afterSeq ? array_slice($all, 0, $limit) : array_slice($all, $before, $limit);
  $minSeq = 0;
  $maxSeq = 0;
  foreach ($slice as $sm) {
    $ss = (int)($sm['seq'] ?? 0);
    if ($ss && ($minSeq === 0 || $ss < $minSeq)) $minSeq = $ss;
    if ($ss > $maxSeq) $maxSeq = $ss;
  }
  ok(['items' => $slice, 'done' => $before + $limit >= count($all), 'total' => count($all), 'thread' => $thread, 'before_seq' => $minSeq, 'after_seq' => $maxSeq, 'limits' => limitsFor($u)]);
}

if ($action === 'send') {
  $u = needUser($in);
  needVerified($u);
  if (chatMuted($u) && !isAdmin($u)) fail('Ты в муте до ' . gmdate('H:i', (int)$u['muteUntil']));
  $cfg = meta();
  if (!empty($cfg['readonly']) && !isAdmin($u)) fail('Чат только для чтения');
  rateFor($u, 'send');
  $text = trim((string)($in['text'] ?? ''));
  $kind = (string)($in['kind'] ?? 'text');
  if (!in_array($kind, ['text', 'gif', 'sticker', 'image', 'audio', 'poll', 'voice'], true)) $kind = 'text';
  if ($kind === 'gif' && empty($cfg['allowGifs']) && !isAdmin($u)) fail('GIF выключены');
  if ($kind === 'sticker' && empty($cfg['allowStickers']) && !isAdmin($u)) fail('Стикеры выключены');
  $lim = limitsFor($u);
  $len = function_exists('mb_strlen') ? mb_strlen($text) : strlen($text);
  if ($kind === 'text' && ($text === '' || $len > (int)$lim['text'])) fail('Текст 1–4096');
  if (preg_match_all('/@([A-Za-z0-9_]{3,20})/', $text, $mmx) && count($mmx[1]) > 40) fail('Слишком часто. Подожди.', 429);
  if (preg_match('/https?:\/\/\S{8,}/i', $text) && !preg_match('/cryndel\.ru|tenor\.com|giphy\.com|media\.tenor/i', $text)) {
    rate('link', 4, 300);
  }
  $thread = (string)($in['thread'] ?? 'global');
  if (!threadOk($thread) || !inThread($u, $thread)) fail('Чат');
  assertCanWriteDm($u, $thread);
  if ($thread === 'channel' && !isAdmin($u)) fail('В канале пишет только админ', 403);
  if (strpos($thread, 'kanal:') === 0) {
    $kid = substr($thread, 6);
    $k = loadKanal($kid);
    if (!$k) fail('Нет канала');
    if (($k['owner'] ?? '') !== $u['id'] && !isAdmin($u)) fail('В канале пишет только владелец', 403);
  }
  if ($thread === 'system' && !isAdmin($u)) fail('В системный чат пишет только админ', 403);
  if ($thread === 'saved' && ($kind !== 'text' && $kind !== 'gif' && $kind !== 'sticker' && $kind !== 'image')) fail('Чат');
  $slow = (int)($cfg['slowMode'] ?? 0);
  if ($slow > 0 && !isAdmin($u)) {
    $last = (int)($u['lastSend'] ?? 0);
    if ($last && time() - $last < $slow) fail('Медленный режим: подожди ' . $slow . 'с');
    patchUser($u['id'], function (&$x) { $x['lastSend'] = time(); });
  }
  $replyTo = cut((string)($in['replyTo'] ?? ''), 24);
  $reply = null;
  if ($replyTo !== '') {
    $src = findMsg($replyTo);
    if ($src) $reply = ['id' => $src['id'], 'nick' => $src['nick'] ?? '', 'text' => cut((string)($src['text'] ?? $src['kind'] ?? ''), 80), 'kind' => $src['kind'] ?? 'text'];
  }
  $mentions = [];
  if (preg_match_all('/@([A-Za-z0-9_]{3,20})/', $text, $mm)) {
    $uniq = array_slice(array_unique($mm[1]), 0, 10);
    rateFor($u, 'mention');
    foreach ($uniq as $mn) {
      $ou = findUserByNick($mn);
      if ($ou && $ou['id'] !== $u['id']) {
        $mentions[] = $ou['nick'];
        notify($ou['id'], $u['nick'] . ' упомянул тебя: ' . cut($text, 120), ['from' => $u['nick'], 'srcThread' => $thread]);
      }
    }
  }
  $url = isset($in['url']) ? cut((string)$in['url'], 500) : null;
  if ($url && !safeUrl($url) && !preg_match('#^https://my\.cryndel\.ru/#i', $url)) fail('Плохая ссылка');
  $when = (int)($in['at'] ?? 0);
  $item = [
    'id' => id(),
    'at' => gmdate('c'),
    'nick' => $u['nick'],
    'uid' => $u['id'],
    'avatar' => $u['avatar'] ?? '',
    'role' => $u['role'] ?? 'user',
    'kind' => $kind,
    'text' => cut($text, 2000),
    'url' => $url,
    'name' => isset($in['name']) ? cut((string)$in['name'], 80) : null,
    'pinned' => false,
    'reactions' => [],
    'thread' => $thread,
    'reply' => $reply,
    'edited' => false,
    'mentions' => $mentions,
    'caption' => isset($in['caption']) ? cut((string)$in['caption'], 2000) : '',
    'silent' => !empty($in['silent']),
    'bubbleStyle' => bubbleOk((string)($in['bubbleStyle'] ?? ($u['bubbleStyle'] ?? 'tg'))),
    'nameColor' => colorOk((string)($in['nameColor'] ?? ($u['nameColor'] ?? ''))),
    'listStyle' => styleOk((string)($u['listStyle'] ?? 'classic'))
  ];
  $streak = ['days' => 0, 'lit' => false, 'born' => false];
  if (strpos($thread, 'dm:') === 0 && $thread !== 'dm:createbot' && $thread !== 'dm:adminbot') {
    $streak = bumpStreak($u, $thread);
    $item['streak'] = (int)($streak['days'] ?? 0);
    $item['streakGray'] = !empty($streak['gray']);
    $item['streakTier'] = (string)($streak['tier'] ?? '');
  }
  if ($kind === 'gif' && $item['url'] && !preg_match('#^https://#i', $item['url'])) fail('Только https GIF');
  if ($kind === 'image' && $item['url'] && !preg_match('#^https://#i', $item['url'])) fail('Только https');
  if ($when > time() + 30 && $when < time() + 30 * 86400) {
    $item['scheduled'] = true;
    $item['at'] = gmdate('c', $when);
    $doc = sched();
    $doc['items'][] = ['id' => $item['id'], 'at' => $when, 'uid' => $u['id'], 'item' => $item];
    if (count($doc['items']) > 200) $doc['items'] = array_slice($doc['items'], -200);
    saveSched($doc);
    ok(['item' => $item, 'scheduled' => true]);
  }
  pushMsg($item);
  $bot = ($kind === 'text') ? crynBot($u, $text, $thread) : null;
  $extra = [];
  if (!empty($streak['dead']) || !empty($streak['born']) || !empty($streak['lit']) || !empty($streak['milestone']) || !empty($streak['gray'])) {
    $extra['streak'] = $streak;
  }
  if (!empty($streak['born'])) $extra['streakBorn'] = true;
  if (!empty($streak['dead'])) $extra['streakDead'] = true;
  if (!empty($streak['milestone'])) $extra['streakMilestone'] = (int)$streak['milestone'];
  if ($bot) {
    $bot = pushMsg($bot);
    ok(['item' => $item, 'bot' => $bot] + $extra);
  }
  ok(['item' => $item] + $extra);
}

if ($action === 'edit') {
  $u = needUser($in);
  needVerified($u);
  rateFor($u, 'edit');
  $id = (string)($in['id'] ?? '');
  $lim = limitsFor($u);
  $text = cut((string)($in['text'] ?? ''), (int)$lim['text']);
  if ($text === '') fail('Пусто');
  $item = saveMsgItem($id, function (&$m) use ($u, $text, $lim) {
    if (!canAccessMsg($u, $m) && !canModMsg($u)) fail('Нет доступа', 403);
    $own = (($m['uid'] ?? '') === $u['id']);
    if (!$own && !canModMsg($u)) fail('Не твоё', 403);
    if (($m['kind'] ?? 'text') !== 'text' && ($m['kind'] ?? '') !== 'system') fail('Нельзя править');
    $ts = strtotime((string)($m['at'] ?? '')) ?: 0;
    $win = (int)$lim['editWindowSec'];
    if ($win > 0 && $ts && time() - $ts > $win && !isAdmin($u)) fail('Поздно править');
    $m['text'] = $text;
    $m['edited'] = true;
  });
  ok(['item' => $item]);
}

if ($action === 'delete') {
  $u = needUser($in);
  needVerified($u);
  rateFor($u, 'del');
  $id = (string)($in['id'] ?? '');
  $forAll = !empty($in['forAll']) || !empty($in['all']);
  $item = saveMsgItem($id, function (&$m) use ($u, $forAll) {
    if (!canAccessMsg($u, $m) && !canModMsg($u)) fail('Нет доступа', 403);
    $own = (($m['uid'] ?? '') === $u['id']);
    if ($forAll) {
      if (!$own && !canModMsg($u) && !isAdmin($u)) fail('Не твоё', 403);
      $sha = (string)($m['sha1'] ?? '');
      if ($sha === '' && !empty($m['url']) && preg_match('/([a-f0-9]{40})/i', (string)$m['url'], $mm)) $sha = strtolower($mm[1]);
      if ($sha !== '') mediaRelease($sha, (string)($m['thread'] ?? 'global'));
      $m['deleted'] = true;
      $m['text'] = '';
      $m['url'] = null;
      $m['kind'] = 'text';
      return;
    }
    $hid = $m['hiddenFor'] ?? [];
    if (!in_array($u['id'], $hid, true)) $hid[] = $u['id'];
    $m['hiddenFor'] = $hid;
  });
  ok(['item' => $item, 'forAll' => $forAll, 'forMe' => !$forAll]);
}

if ($action === 'forward') {
  $u = needUser($in);
  needVerified($u);
  rateFor($u, 'send');
  $id = (string)($in['id'] ?? '');
  $thread = (string)($in['thread'] ?? 'global');
  if (!msgIdOk($id)) fail('Нет сообщения');
  if (!threadOk($thread) || !inThread($u, $thread)) fail('Чат');
  assertCanWriteDm($u, $thread);
  $src = findMsg($id);
  if (!$src || !empty($src['deleted'])) fail('Нет сообщения');
  if (!canAccessMsg($u, $src)) fail('Нет доступа', 403);
  $item = [
    'id' => id(),
    'at' => gmdate('c'),
    'nick' => $u['nick'],
    'uid' => $u['id'],
    'avatar' => $u['avatar'] ?? '',
    'kind' => $src['kind'] ?? 'text',
    'text' => $src['text'] ?? '',
    'url' => $src['url'] ?? null,
    'name' => $src['name'] ?? null,
    'pinned' => false,
    'reactions' => [],
    'thread' => $thread,
    'forwardedFrom' => $src['nick'] ?? '',
    'edited' => false
  ];
  if (($item['kind'] ?? '') === 'poll') {
    $item['kind'] = 'text';
    $item['text'] = 'Опрос: ' . cut((string)($src['text'] ?? ''), 200);
  }
  pushMsg($item);
  ok(['item' => $item]);
}

if ($action === 'react') {
  $u = needUser($in);
  rateFor($u, 'react');
  $emoji = trim((string)($in['emoji'] ?? ''));
  $map = meta()['emojiMap'] ?? [];
  $emoOk = $emoji !== '' && strlen($emoji) <= 24 && !preg_match('/[<>&]/', $emoji) && (
    isset($map[$emoji])
    || preg_match('/^[\x{1F000}-\x{1FAFF}\x{2600}-\x{27BF}\x{2300}-\x{23FF}\x{2B00}-\x{2BFF}\x{1F1E6}-\x{1F1FF}\x{200D}\x{FE0F}\x{20E3}#*0-9❤♥♡]+$/u', $emoji)
  );
  if (!$emoOk) fail('Этот смайл нельзя поставить');
  $id = (string)($in['id'] ?? '');
  $item = saveMsgItem($id, function (&$m) use ($emoji, $u) {
    if (!canAccessMsg($u, $m)) fail('Нет доступа', 403);
    $who = $m['reactors'][$u['id']] ?? '';
    if ($who === $emoji) {
      $m['reactions'][$emoji] = max(0, (int)($m['reactions'][$emoji] ?? 0) - 1);
      unset($m['reactors'][$u['id']]);
    } else {
      if ($who) $m['reactions'][$who] = max(0, (int)($m['reactions'][$who] ?? 0) - 1);
      $m['reactions'][$emoji] = (int)($m['reactions'][$emoji] ?? 0) + 1;
      $m['reactors'][$u['id']] = $emoji;
    }
  });
  unset($item['reactors']);
  ok(['item' => $item]);
}

if ($action === 'pin') {
  $u = needUser($in);
  rate('pin', 10, 60);
  $id = (string)($in['id'] ?? '');
  $item = saveMsgItem($id, function (&$m) use ($u) {
    if (!canAccessMsg($u, $m)) fail('Нет доступа', 403);
    $th = (string)($m['thread'] ?? 'global');
    $ownDm = strpos($th, 'dm:') === 0 && inThread($u, $th);
    if (!$ownDm && $th !== 'saved' && !canModMsg($u)) fail('Закреплять в общем чате могут модераторы с 3 ранга', 403);
    $m['pinned'] = empty($m['pinned']);
    if (!empty($m['pinned'])) $m['pinAt'] = time();
    else unset($m['pinAt']);
  });
  ok(['item' => $item]);
}

if ($action === 'saveGif') {
  $u = needUser($in);
  $url = (string)($in['url'] ?? '');
  if (!safeUrl($url)) fail('https');
  $saved = patchUser($u['id'], function (&$x) use ($url) {
    $x['gifs'] = $x['gifs'] ?? [];
    if (!in_array($url, $x['gifs'], true)) array_unshift($x['gifs'], $url);
    $x['gifs'] = array_slice($x['gifs'], 0, 40);
  });
  ok(['gifs' => $saved['gifs']]);
}

if ($action === 'delGif') {
  $u = needUser($in);
  $url = (string)($in['url'] ?? '');
  $saved = patchUser($u['id'], function (&$x) use ($url) {
    $x['gifs'] = array_values(array_filter($x['gifs'] ?? [], fn($g) => $g !== $url));
  });
  ok(['gifs' => $saved['gifs']]);
}

if ($action === 'gifs') {
  $u = needUser($in);
  ok(['items' => $u['gifs'] ?? []]);
}

if ($action === 'poll') {
  $u = needUser($in);
  needVerified($u);
  if (empty(meta()['allowPolls']) && !isAdmin($u)) fail('Опросы выключены');
  if (chatMuted($u) && !isAdmin($u)) fail('Ты в муте');
  rate('poll', 8, 300);
  $q = trim((string)($in['question'] ?? ''));
  $opts = $in['options'] ?? [];
  if (!is_array($opts)) fail('Варианты');
  $opts = array_values(array_filter(array_map(fn($s) => cut((string)$s, 80), $opts)));
  if ($q === '' || count($opts) < 2 || count($opts) > 6) fail('Опрос: вопрос и 2–6 вариантов');
  $thread = (string)($in['thread'] ?? 'global');
  if (!threadOk($thread) || !inThread($u, $thread)) fail('Чат');
  if ($thread === 'channel' && !isAdmin($u)) fail('В канале пишет только админ', 403);
  $item = [
    'id' => id(),
    'at' => gmdate('c'),
    'nick' => $u['nick'],
    'uid' => $u['id'],
    'avatar' => $u['avatar'] ?? '',
    'kind' => 'poll',
    'text' => $q,
    'pinned' => false,
    'reactions' => [],
    'thread' => $thread,
    'poll' => ['question' => $q, 'options' => $opts, 'votes' => array_fill(0, count($opts), 0), 'voters' => []]
  ];
  pushMsg($item);
  ok(['item' => $item]);
}

if ($action === 'vote') {
  $u = needUser($in);
  $id = (string)($in['id'] ?? '');
  $opt = (int)($in['option'] ?? -1);
  $item = saveMsgItem($id, function (&$m) use ($u, $opt) {
    if (($m['kind'] ?? '') !== 'poll') fail('Нет опроса');
    if (in_array($u['id'], $m['poll']['voters'] ?? [], true)) fail('Уже голосовал');
    if (!isset($m['poll']['votes'][$opt])) fail('Вариант');
    $m['poll']['votes'][$opt]++;
    $m['poll']['voters'][] = $u['id'];
  });
  if (isset($item['poll']['voters'])) unset($item['poll']['voters']);
  ok(['item' => $item]);
}

if ($action === 'stickers') {
  $items = [];
  if (is_dir(STICK_DIR)) {
    foreach (scandir(STICK_DIR) ?: [] as $n) {
      if (!preg_match('/\.(png|webp|gif)$/i', $n)) continue;
      $items[] = ['name' => $n, 'url' => PUBLIC_BASE . '/stickers/' . rawurlencode($n), 'pack' => 'official'];
    }
  }
  $u = userByToken((string)($in['token'] ?? ''));
  foreach (packs()['packs'] as $p) {
    $own = $u && ($p['owner'] ?? '') === $u['id'];
    if (!$own && empty($p['public'])) continue;
    foreach ($p['items'] ?? [] as $it) {
      $items[] = ['name' => $it['name'] ?? $p['name'], 'url' => $it['url'] ?? '', 'pack' => $p['id'], 'packName' => $p['name'] ?? ''];
    }
  }
  ok(['items' => $items]);
}

if ($action === 'packs') {
  $u = needUser($in);
  $out = [];
  foreach (packs()['packs'] as $p) {
    $own = ($p['owner'] ?? '') === $u['id'];
    if (!$own && empty($p['public'])) continue;
    $out[] = [
      'id' => $p['id'],
      'name' => $p['name'],
      'kind' => $p['kind'] ?? 'sticker',
      'owner' => $own,
      'count' => count($p['items'] ?? []),
      'items' => $p['items'] ?? []
    ];
  }
  ok(['items' => $out]);
}

if ($action === 'createPack') {
  $u = needUser($in);
  needVerified($u);
  rate('pack', 8, 3600);
  $name = cut((string)($in['name'] ?? ''), 32);
  $kind = (string)($in['kind'] ?? 'sticker');
  if ($name === '') fail('Название');
  if (!in_array($kind, ['sticker', 'gif'], true)) $kind = 'sticker';
  $doc = packs();
  $n = 0;
  foreach ($doc['packs'] as $p) if (($p['owner'] ?? '') === $u['id']) $n++;
  if ($n >= 12) fail('Максимум 12 коллекций');
  $pack = ['id' => id('p'), 'name' => $name, 'kind' => $kind, 'owner' => $u['id'], 'public' => !empty($in['public']), 'items' => []];
  $doc['packs'][] = $pack;
  savePacks($doc);
  ok(['pack' => $pack]);
}

if ($action === 'addSticker') {
  $u = needUser($in);
  needVerified($u);
  rate('stick', 20, 60);
  $packId = (string)($in['packId'] ?? '');
  $url = cut((string)($in['url'] ?? ''), 500);
  $name = cut((string)($in['name'] ?? 'sticker'), 40);
  if (!safeUrl($url)) fail('https');
  $doc = packs();
  foreach ($doc['packs'] as &$p) {
    if (($p['id'] ?? '') !== $packId) continue;
    if (($p['owner'] ?? '') !== $u['id']) fail('Не твоё', 403);
    if (count($p['items'] ?? []) >= 80) fail('Пак полный');
    $p['items'][] = ['name' => $name, 'url' => $url];
    savePacks($doc);
    ok(['pack' => $p]);
  }
  fail('Нет коллекции');
}

if ($action === 'delPack') {
  $u = needUser($in);
  $packId = (string)($in['packId'] ?? '');
  $doc = packs();
  $next = [];
  $found = false;
  foreach ($doc['packs'] as $p) {
    if (($p['id'] ?? '') === $packId) {
      if (($p['owner'] ?? '') !== $u['id']) fail('Не твоё', 403);
      $found = true;
      continue;
    }
    $next[] = $p;
  }
  if (!$found) fail('Нет коллекции');
  $doc['packs'] = $next;
  savePacks($doc);
  ok();
}

if ($action === 'upload') {
  $u = needUser($in);
  needVerified($u);
  if (empty(meta()['allowUploads']) && !isAdmin($u)) fail('Загрузки выключены');
  if (chatMuted($u) && !isAdmin($u)) fail('Ты в муте');
  rateFor($u, 'up');
  $kind = (string)($in['kind'] ?? 'image');
  if (!in_array($kind, ['image', 'audio', 'sticker', 'avatar', 'gif', 'voice', 'cover', 'banner', 'botava'], true)) fail('Тип');
  $name = preg_replace('/[^A-Za-z0-9._-]/', '_', (string)($in['name'] ?? 'file'));
  $hashIn = preg_replace('/[^a-f0-9]/', '', strtolower((string)($in['hash'] ?? '')));
  $hd = hashes();
  if ($hashIn !== '') {
    foreach ($hd['map'] as $hk => $_hu) {
      if (substr((string)$hk, -strlen($hashIn) - 1) === ':' . $hashIn && strpos((string)$hk, $u['id'] . ':') !== 0) fail('Нет доступа', 403);
    }
  }
  $ownKey = (string)$u['id'] . ':' . $hashIn;
  if ($hashIn !== '' && isset($hd['map'][$ownKey])) {
    $url = resignMediaUrl((string)$hd['map'][$ownKey]);
    if ($kind === 'avatar') {
      $saved = patchUser($u['id'], function (&$x) use ($url) { $x['avatar'] = $url; });
      ok(['url' => $url, 'cached' => true, 'user' => publicUser($saved, true)]);
    }
    if ($kind === 'cover' || $kind === 'banner') {
      $saved = patchUser($u['id'], function (&$x) use ($url) { $x['cover'] = $url; $x['banner'] = $url; });
      ok(['url' => $url, 'cached' => true, 'user' => publicUser($saved, true)]);
    }
    $thread = (string)($in['thread'] ?? 'global');
    if ($kind !== 'sticker' && $kind !== 'avatar' && threadOk($thread) && inThread($u, $thread)) {
      assertCanWriteDm($u, $thread);
      $msgKind = $kind === 'voice' ? 'audio' : $kind;
      $item = [
        'id' => id(),
        'at' => gmdate('c'),
        'nick' => $u['nick'],
        'uid' => $u['id'],
        'avatar' => $u['avatar'] ?? '',
        'kind' => $msgKind,
        'text' => cut((string)($in['caption'] ?? $name), 2000),
        'url' => $url,
        'name' => $name,
        'pinned' => false,
        'reactions' => [],
        'thread' => $thread,
        'cached' => true
      ];
      pushMsg($item);
      ok(['item' => $item, 'url' => $url, 'cached' => true]);
    }
    ok(['url' => $url, 'cached' => true]);
  }
  $bin = base64_decode((string)($in['data'] ?? ''), true);
  $limUp = limitsFor($u);
  $maxFile = in_array($kind, ['audio', 'voice'], true) ? (int)$limUp['fileAudio'] : (int)$limUp['fileImage'];
  if ($bin === false || strlen($bin) < 16 || strlen($bin) > $maxFile) fail('Файл до 3 МБ');
  if (!is_dir(MEDIA_DIR)) mkdir(MEDIA_DIR, 0700, true);
  $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
  $magicOk = false;
  if (in_array($kind, ['image', 'sticker', 'avatar', 'gif', 'cover', 'banner', 'botava'], true)) {
    $allow = ['png', 'jpg', 'jpeg', 'webp', 'gif', 'webm', 'avif'];
    if (!in_array($ext, $allow, true)) fail('Формат png/jpg/webp/gif/webm/avif');
    $magicOk = magicImageOk($bin, $ext);
    if (!$magicOk) fail('Битый файл');
    if (in_array($ext, ['jpg', 'jpeg', 'png', 'webp'], true) && $kind !== 'gif') {
      $bin = stripExif($bin, $ext);
    }
    if (function_exists('imagecreatefromstring') && $kind !== 'gif' && $ext !== 'gif' && $ext !== 'webp' && $ext !== 'webm' && $ext !== 'avif') {
      $im = @imagecreatefromstring($bin);
      if ($im) {
        $w = imagesx($im);
        $h = imagesy($im);
        $max = $kind === 'sticker' || $kind === 'avatar' ? 512 : ($kind === 'cover' || $kind === 'banner' ? 1920 : 1280);
        if ($w > $max || $h > $max) {
          $s = min($max / $w, $max / $h);
          $nw = max(1, (int)($w * $s));
          $nh = max(1, (int)($h * $s));
          $dst = imagecreatetruecolor($nw, $nh);
          imagealphablending($dst, false);
          imagesavealpha($dst, true);
          imagecopyresampled($dst, $im, 0, 0, 0, 0, $nw, $nh, $w, $h);
          ob_start();
          if ($ext === 'png' || $kind === 'sticker' || $kind === 'avatar') {
            imagepng($dst);
            $ext = 'png';
          } else {
            imagejpeg($dst, null, 78);
            $ext = 'jpg';
          }
          $bin = ob_get_clean();
          imagedestroy($dst);
        }
        imagedestroy($im);
      }
    }
  } else {
    if (!in_array($ext, ['mp3', 'ogg', 'wav', 'm4a', 'webm'], true)) fail('Аудио mp3/ogg/wav');
    $magic = substr($bin, 0, 16);
    $magicOk = strpos($magic, 'ID3') === 0
      || strpos($magic, "\xFF\xFB") === 0
      || strpos($magic, "\xFF\xF3") === 0
      || strpos($magic, "\xFF\xF2") === 0
      || strpos($magic, "\xFF\xF1") === 0
      || strpos($magic, "\xFF\xF9") === 0
      || strpos($magic, 'OggS') === 0
      || strpos($magic, 'RIFF') === 0
      || strpos($magic, 'ftyp') !== false
      || strpos($magic, "\x1A\x45\xDF\xA3") === 0
      || (ord($magic[0]) === 0xFF && (ord($magic[1]) & 0xE0) === 0xE0);
    if (!$magicOk && strlen($bin) > 64) fail('Битый файл');
  }
  $thread = (string)($in['thread'] ?? 'global');
  if ($kind !== 'avatar' && $kind !== 'cover' && $kind !== 'banner' && $kind !== 'sticker' && $kind !== 'botava') {
    if (!threadOk($thread) || !inThread($u, $thread)) fail('Чат');
    assertCanWriteDm($u, $thread);
  }
  $stored = storeBlob($bin, $ext, (string)$u['id'], (string)$u['nick'], $thread);
  $url = $stored['url'];
  $sha = $stored['sha256'];
  $hd = hashes();
  $hd['map'][(string)$u['id'] . ':' . $sha] = $url;
  $hd['map'][(string)$u['id'] . ':' . $stored['sha1']] = $url;
  if (count($hd['map']) > 8000) $hd['map'] = array_slice($hd['map'], -4000, null, true);
  saveHashes($hd);
  if ($kind === 'avatar') {
    $saved = patchUser($u['id'], function (&$x) use ($url) { $x['avatar'] = $url; });
    ok(['url' => $url, 'user' => publicUser($saved, true)]);
  }
  if ($kind === 'cover' || $kind === 'banner') {
    $saved = patchUser($u['id'], function (&$x) use ($url) { $x['cover'] = $url; $x['banner'] = $url; });
    ok(['url' => $url, 'user' => publicUser($saved, true)]);
  }
  $packId = (string)($in['packId'] ?? '');
  if ($packId !== '' && in_array($kind, ['sticker', 'gif'], true)) {
    $doc = packs();
    foreach ($doc['packs'] as &$p) {
      if (($p['id'] ?? '') !== $packId) continue;
      if (($p['owner'] ?? '') !== $u['id']) fail('Не твоё', 403);
      if (count($p['items'] ?? []) >= 80) fail('Пак полный');
      $p['items'][] = ['name' => cut($name, 40), 'url' => $url];
      savePacks($doc);
      ok(['url' => $url, 'pack' => $p]);
    }
    fail('Нет коллекции');
  }
  if ($kind === 'sticker') ok(['url' => $url]);
  $msgKind = $kind === 'voice' ? 'audio' : ($kind === 'gif' ? 'gif' : $kind);
  if ($msgKind === 'sticker') $msgKind = 'sticker';
  $thread = (string)($in['thread'] ?? 'global');
  if (!threadOk($thread) || !inThread($u, $thread)) fail('Чат');
  $item = [
    'id' => id(),
    'at' => gmdate('c'),
    'nick' => $u['nick'],
    'uid' => $u['id'],
    'avatar' => $u['avatar'] ?? '',
    'kind' => $msgKind === 'voice' ? 'audio' : $msgKind,
    'text' => cut((string)($in['caption'] ?? $name), 2000),
    'caption' => cut((string)($in['caption'] ?? ''), 2000),
    'url' => $url,
    'name' => $name,
    'pinned' => false,
    'reactions' => [],
    'thread' => $thread
  ];
  pushMsg($item);
  ok(['item' => $item, 'url' => $url]);
}

if ($action === 'unread') {
  $u = needUser($in);
  $thread = (string)($in['thread'] ?? 'global');
  ok(['count' => unreadCount($u, $thread), 'muted' => !empty($u['muted'])]);
}

if ($action === 'markRead') {
  $u = needUser($in);
  $thread = (string)($in['thread'] ?? 'global');
  if (!threadOk($thread)) $thread = 'global';
  $doc = live();
  $doc['read'][$u['id'] . ':' . $thread] = time();
  if (!empty($in['id'])) $doc['readMsg'][$u['id'] . ':' . $thread] = cut((string)$in['id'], 40);
  saveLive($doc);
  ok(['count' => 0]);
}

if ($action === 'readers') {
  $u = needUser($in);
  $id = cut((string)($in['id'] ?? ''), 40);
  $thread = (string)($in['thread'] ?? 'global');
  if (!threadOk($thread)) $thread = 'global';
  $msg = null;
  foreach (msgs()['items'] as $m) {
    if (($m['id'] ?? '') === $id) { $msg = $m; break; }
  }
  $at = $msg ? strtotime((string)($msg['at'] ?? '')) : 0;
  $doc = live();
  $items = [];
  $seen = [];
  foreach (($doc['read'] ?? []) as $k => $ts) {
    $ks = (string)$k;
    if (substr($ks, -strlen(':' . $thread)) !== ':' . $thread) continue;
    $uid = explode(':', (string)$k, 2)[0];
    if ($uid === ($u['id'] ?? '')) continue;
    if ($at && (int)$ts < $at) continue;
    $ou = findUserById($uid);
    if (!is_array($ou) || isset($seen[$uid])) continue;
    $seen[$uid] = true;
    $items[] = [
      'nick' => $ou['nick'] ?? $uid,
      'avatar' => $ou['avatar'] ?? '',
      'at' => (int)$ts
    ];
  }
  usort($items, fn($a, $b) => ($b['at'] <=> $a['at']));
  ok(['items' => array_slice($items, 0, 80), 'id' => $id]);
}

if ($action === 'typing') {
  $u = needUser($in);
  $thread = (string)($in['thread'] ?? 'global');
  if (!threadOk($thread) || !inThread($u, $thread)) fail('Чат');
  assertCanWriteDm($u, $thread);
  $doc = live();
  $doc['typing'][$thread . ':' . $u['id']] = ['nick' => $u['nick'], 'at' => time()];
  saveLive($doc);
  ok();
}

if ($action === 'presence') {
  $u = needUser($in);
  $thread = (string)($in['thread'] ?? 'global');
  $now = time();
  $typing = [];
  $online = 0;
  $doc = live();
  foreach ($doc['typing'] ?? [] as $k => $t) {
    if (($t['at'] ?? 0) < $now - 6) continue;
    if (strpos($k, $thread . ':') !== 0) continue;
    if (($t['nick'] ?? '') === $u['nick']) continue;
    $typing[] = $t['nick'];
  }
  $people = [];
  foreach ($doc['seen'] ?? [] as $id => $at) {
    if ($at <= $now - 90) continue;
    $online++;
    $ou = findUserById((string)$id);
    if (!is_array($ou)) continue;
    $people[] = [
      'nick' => $ou['nick'] ?? '',
      'avatar' => $ou['avatar'] ?? '',
      'status' => $ou['status'] ?? '',
      'role' => $ou['role'] ?? 'user',
      'online' => true
    ];
  }
  usort($people, fn($a, $b) => strcasecmp((string)$a['nick'], (string)$b['nick']));
  ok(['typing' => $typing, 'online' => $online, 'people' => array_slice($people, 0, 80), 'unread' => unreadCount($u, $thread)]);
}

if ($action === 'dms') {
  $u = needUser($in);
  $map = [];
  foreach (msgs()['items'] as $m) {
    $th = (string)($m['thread'] ?? 'global');
    if (!inThread($u, $th) || $th === 'global' || $th === 'channel' || $th === 'system' || $th === 'saved') continue;
    if ($th === 'dm:createbot' || $th === 'dm:adminbot') continue;
    if (isset($map[$th])) continue;
    $other = '';
    $avatar = '';
    $listStyle = 'classic';
    $nameColor = '';
    $badges = [];
    $streak = ['days' => 0];
    if (preg_match('/^dm:(u[a-f0-9]{8}):(u[a-f0-9]{8})$/', $th, $mm)) {
      $oid = $mm[1] === $u['id'] ? $mm[2] : $mm[1];
      $ou = findUserById($oid);
      $other = is_array($ou) ? ($ou['nick'] ?? $oid) : $oid;
      $avatar = is_array($ou) ? ($ou['avatar'] ?? '') : '';
      $listStyle = is_array($ou) ? styleOk((string)($ou['listStyle'] ?? 'classic')) : 'classic';
      $nameColor = is_array($ou) ? colorOk((string)($ou['nameColor'] ?? '')) : '';
      $badges = is_array($ou) ? array_values($ou['badges'] ?? defaultBadges($ou)) : [];
      $streak = is_array($ou) ? streakOf($u, $oid) : ['days' => 0];
    }
    $map[$th] = [
      'thread' => $th,
      'nick' => $other,
      'text' => cut((string)($m['text'] ?? $m['kind'] ?? ''), 80),
      'at' => $m['at'] ?? '',
      'unread' => unreadCount($u, $th),
      'avatar' => $avatar,
      'listStyle' => $listStyle ?? 'classic',
      'nameColor' => $nameColor ?? '',
      'badges' => $badges ?? [],
      'streak' => (int)($streak['days'] ?? 0),
      'streakGray' => !empty($streak['gray']),
      'streakTier' => (string)($streak['tier'] ?? ''),
      'streakLit' => !empty($streak['lit'])
    ];
  }
  ok(['items' => array_values($map)]);
}

if ($action === 'dmOpen') {
  $u = needUser($in);
  needVerified($u);
  if (empty(meta()['allowDms']) && !isAdmin($u)) fail('Лички выключены');
  $nick = trim((string)($in['nick'] ?? ''));
  $x = findUserByNick($nick);
  if (!$x) fail('Нет такого');
  if ($x['id'] === $u['id']) fail('Это ты');
  if (peerBlocked($u, $x)) fail('Тебе нельзя писать этому пользователю', 403);
  $th = dmThread($u['id'], $x['id']);
  assertCanWriteDm($u, $th);
  ok(['thread' => $th, 'user' => publicUser($x)]);
}

if ($action === 'search') {
  $u = needUser($in);
  rate('search', 20, 60);
  $q = strtolower(cut((string)($in['q'] ?? ''), 40));
  if ($q === '') ok(['items' => []]);
  $out = [];
  foreach (msgs()['items'] as $m) {
    $th = (string)($m['thread'] ?? 'global');
    if (!inThread($u, $th)) continue;
    $hay = strtolower((string)($m['text'] ?? '') . ' ' . ($m['nick'] ?? ''));
    if (strpos($hay, $q) === false) continue;
    $out[] = $m;
    if (count($out) >= 40) break;
  }
  ok(['items' => $out]);
}

if ($action === 'block') {
  $u = needUser($in);
  $nick = trim((string)($in['nick'] ?? ''));
  if (!nickOk($nick)) fail('Ник');
  $saved = patchUser($u['id'], function (&$x) use ($nick) {
    $list = $x['blocked'] ?? [];
    if (in_array($nick, $list, true)) $list = array_values(array_filter($list, fn($n) => $n !== $nick));
    else $list[] = $nick;
    $x['blocked'] = $list;
  });
  ok(['blocked' => $saved['blocked']]);
}

if ($action === 'mute') {
  $u = needUser($in);
  $on = !empty($in['on']);
  $saved = patchUser($u['id'], function (&$x) use ($on) { $x['muted'] = $on; });
  ok(['muted' => !empty($saved['muted'])]);
}

if ($action === 'report') {
  $u = needUser($in);
  rate('rep', 6, 3600);
  $id = cut((string)($in['id'] ?? ''), 24);
  if (!msgIdOk($id)) fail('Сообщение');
  $src = findMsg($id);
  if (!$src) fail('Нет сообщения');
  if (!canAccessMsg($u, $src)) fail('Нет доступа', 403);
  logMod($u, 'report', (string)($src['nick'] ?? ''), 'msg:' . $id);
  foreach (users()['users'] as $adm) {
    if (($adm['role'] ?? '') !== 'admin') continue;
    notify($adm['id'], $u['nick'] . ' пожаловался на ' . ($src['nick'] ?? 'сообщение'));
  }
  ok(['reported' => $id]);
}

if ($action === 'online') {
  needUser($in);
  $now = time();
  $n = 0;
  $people = [];
  foreach (live()['seen'] ?? [] as $id => $at) {
    if ((int)$at <= $now - 90) continue;
    $n++;
    $ou = findUserById((string)$id);
    if (!is_array($ou)) continue;
    $people[] = [
      'nick' => $ou['nick'] ?? '',
      'avatar' => $ou['avatar'] ?? '',
      'status' => $ou['status'] ?? '',
      'role' => $ou['role'] ?? 'user',
      'online' => true
    ];
  }
  usort($people, fn($a, $b) => strcasecmp((string)$a['nick'], (string)$b['nick']));
  ok(['count' => $n, 'people' => array_slice($people, 0, 80)]);
}

if ($action === 'adminUsers') {
  needStaff($in);
  $q = strtolower(cut((string)($in['q'] ?? ''), 20));
  $out = [];
  foreach (users()['users'] as $x) {
    if ($q !== '' && strpos(strtolower((string)$x['nick'] . ' ' . ($x['email'] ?? '')), $q) === false) continue;
    $out[] = publicUser($x, true) + [
      'created' => $x['created'] ?? '',
      'muteUntil' => (int)($x['muteUntil'] ?? 0),
      'muteReason' => $x['muteReason'] ?? '',
      'banUntil' => (int)($x['banUntil'] ?? 0),
      'banReason' => $x['banReason'] ?? '',
      'warns' => $x['warns'] ?? []
    ];
    if (count($out) >= 80) break;
  }
  ok(['items' => $out]);
}

if ($action === 'adminSettings') {
  $u = needAdmin($in);
  $cfg = meta();
  $keys = ['requireVerify', 'allowGifs', 'allowStickers', 'allowUploads', 'allowPolls', 'allowDms', 'readonly'];
  $changed = false;
  foreach ($keys as $k) {
    if (array_key_exists($k, $in)) { $cfg[$k] = (bool)$in[$k]; $changed = true; }
  }
  if (isset($in['slowMode'])) { $cfg['slowMode'] = max(0, min(300, (int)$in['slowMode'])); $changed = true; }
  if (isset($in['defaultTheme'])) {
    $cfg['defaultTheme'] = themeOk((string)$in['defaultTheme']);
    $changed = true;
  }
  if (isset($in['defaultSkin'])) {
    $s = (string)$in['defaultSkin'];
    $cfg['defaultSkin'] = ($s === 'wa') ? 'wa' : 'tg';
    $changed = true;
  }
  if (isset($in['defaultBubble'])) {
    $cfg['defaultBubble'] = bubbleOk((string)$in['defaultBubble']);
    $changed = true;
  }
  if (isset($in['defaultList'])) {
    $cfg['defaultList'] = styleOk((string)$in['defaultList']);
    $changed = true;
  }
  if ($changed) {
    saveMeta($cfg);
    logMod($u, 'settings', '', json_encode($in, JSON_UNESCAPED_UNICODE));
  }
  ok(['settings' => [
    'requireVerify' => !empty($cfg['requireVerify']),
    'allowGifs' => !empty($cfg['allowGifs']),
    'allowStickers' => !empty($cfg['allowStickers']),
    'allowUploads' => !empty($cfg['allowUploads']),
    'allowPolls' => !empty($cfg['allowPolls']),
    'allowDms' => !empty($cfg['allowDms']),
    'readonly' => !empty($cfg['readonly']),
    'slowMode' => (int)($cfg['slowMode'] ?? 0),
    'defaultTheme' => themeOk((string)($cfg['defaultTheme'] ?? 'night')),
    'defaultSkin' => (string)($cfg['defaultSkin'] ?? 'tg'),
    'defaultBubble' => bubbleOk((string)($cfg['defaultBubble'] ?? 'tg')),
    'defaultList' => styleOk((string)($cfg['defaultList'] ?? 'classic'))
  ], 'chats' => array_values($cfg['chats'] ?? [])]);
}

if ($action === 'adminChat') {
  $u = needAdmin($in);
  $id = (string)($in['id'] ?? 'global');
  if ($id !== 'global' && $id !== 'channel') fail('Чат');
  $cfg = meta();
  $chat = $cfg['chats'][$id] ?? chatInfo($id);
  if (isset($in['title'])) $chat['title'] = cut((string)$in['title'], 40);
  if (isset($in['about'])) $chat['about'] = cut((string)$in['about'], 160);
  if (isset($in['avatar'])) {
    $av = cut((string)$in['avatar'], 2000);
    if ($av !== '' && !preg_match('#^https://#i', $av) && strpos($av, 'data:image/') !== 0) fail('Аватар только https');
    $chat['avatar'] = $av;
  }
  if (isset($in['banner']) || isset($in['cover'])) {
    $bn = cut((string)($in['banner'] ?? $in['cover'] ?? ''), 2000);
    if ($bn !== '' && !preg_match('#^https://#i', $bn) && strpos($bn, 'data:image/') !== 0) fail('Баннер только https');
    $chat['banner'] = $bn;
    $chat['cover'] = $bn;
  }
  $cfg['chats'][$id] = $chat + ['id' => $id, 'kind' => $id === 'channel' ? 'channel' : 'group'];
  saveMeta($cfg);
  logMod($u, 'chat', $id, $chat['title'] ?? '');
  ok(['chat' => $cfg['chats'][$id]]);
}

if ($action === 'adminUser') {
  $u = needAdmin($in);
  $nick = trim((string)($in['nick'] ?? ''));
  $x = findUserByNick($nick);
  if (!$x) fail('Нет такого');
  if (($x['id'] ?? '') === $u['id'] && isset($in['role']) && $in['role'] !== 'admin') fail('Нельзя снять себя');
  $saved = patchUser($x['id'], function (&$t) use ($in, $x) {
    foreach (['bio' => 280, 'telegram' => 64, 'discord' => 64, 'youtube' => 80, 'tiktok' => 64, 'status' => 80, 'email' => 80] as $k => $n) {
      if (isset($in[$k])) $t[$k] = cut((string)$in[$k], $n);
    }
    if (isset($in['avatar'])) {
      $av = cut((string)$in['avatar'], 500);
      if ($av !== '' && !preg_match('#^https://#i', $av)) fail('Аватар только https');
      $t['avatar'] = $av;
    }
    if (isset($in['nickNew'])) {
      $nn = trim((string)$in['nickNew']);
      if ($nn && $nn !== $t['nick']) {
        if (!nickOk($nn)) fail('Ник: 3–20 латиница, цифры, _');
        $clash = findUserByNick($nn);
        if ($clash && ($clash['id'] ?? '') !== ($t['id'] ?? '')) fail('Ник занят');
        $t['nick'] = $nn;
      }
    }
    if (isset($in['verified'])) $t['verified'] = (bool)$in['verified'];
    if (isset($in['role'])) {
      $role = (string)$in['role'];
      $t['role'] = in_array($role, ['admin', 'mod', 'user'], true) ? $role : 'user';
      if ($t['role'] === 'user') $t['modRank'] = 0;
      if ($t['role'] === 'mod' && empty($t['modRank'])) $t['modRank'] = 1;
    }
    if (isset($in['modRank'])) {
      $rk = max(0, min(4, (int)$in['modRank']));
      $t['modRank'] = $rk;
      if ($rk >= 1 && ($t['role'] ?? '') !== 'admin') $t['role'] = 'mod';
      if ($rk < 1 && ($t['role'] ?? '') === 'mod') $t['role'] = 'user';
    }
  });
  logMod($u, 'editUser', $saved['nick']);
  ok(['user' => publicUser($saved, true)]);
}

if ($action === 'ban') {
  $u = needStaff($in);
  if (!canBan($u)) fail('Бан с 4 ранга', 403);
  $nick = trim((string)($in['nick'] ?? ''));
  $x = findUserByNick($nick);
  if (!$x) fail('Нет такого');
  if (isAdmin($x) && $x['id'] !== $u['id']) fail('Админа банить нельзя');
  $hours = max(0, (int)($in['hours'] ?? 0));
  $reason = cut((string)($in['reason'] ?? 'бан'), 160);
  $until = $hours > 0 ? time() + $hours * 3600 : 0;
  $saved = patchUser($x['id'], function (&$t) use ($until, $reason) {
    $t['banned'] = true;
    $t['banUntil'] = $until;
    $t['banReason'] = $reason;
    $t['token'] = bin2hex(random_bytes(24));
  });
  logMod($u, 'ban', $saved['nick'], $reason);
  sysMsg($saved['nick'] . ' забанен' . ($reason ? ': ' . $reason : ''));
  ok(['user' => publicUser($saved, true)]);
}

if ($action === 'unban') {
  $u = needStaff($in);
  if (!canBan($u)) fail('Разбан с 4 ранга', 403);
  $nick = trim((string)($in['nick'] ?? ''));
  $x = findUserByNick($nick);
  if (!$x) fail('Нет такого');
  $saved = patchUser($x['id'], function (&$t) {
    $t['banned'] = false;
    $t['banUntil'] = 0;
    $t['banReason'] = '';
  });
  logMod($u, 'unban', $saved['nick']);
  sysMsg($saved['nick'] . ' разбанен');
  ok(['user' => publicUser($saved, true)]);
}

if ($action === 'modMute') {
  $u = needStaff($in);
  if (!canMute($u)) fail('Мут с 2 ранга', 403);
  $nick = trim((string)($in['nick'] ?? ''));
  $x = findUserByNick($nick);
  if (!$x) fail('Нет такого');
  $mins = max(1, (int)($in['minutes'] ?? 30));
  $reason = cut((string)($in['reason'] ?? 'мут'), 160);
  $saved = patchUser($x['id'], function (&$t) use ($mins, $reason) {
    $t['muteUntil'] = time() + $mins * 60;
    $t['muteReason'] = $reason;
  });
  logMod($u, 'mute', $saved['nick'], $reason);
  sysMsg($saved['nick'] . ' в муте на ' . $mins . ' мин');
  ok(['user' => publicUser($saved, true)]);
}

if ($action === 'modUnmute') {
  $u = needStaff($in);
  if (!canMute($u)) fail('Размут с 2 ранга', 403);
  $nick = trim((string)($in['nick'] ?? ''));
  $x = findUserByNick($nick);
  if (!$x) fail('Нет такого');
  $saved = patchUser($x['id'], function (&$t) {
    $t['muteUntil'] = 0;
    $t['muteReason'] = '';
  });
  logMod($u, 'unmute', $saved['nick']);
  sysMsg($saved['nick'] . ' снят с мута');
  ok(['user' => publicUser($saved, true)]);
}

if ($action === 'warn') {
  $u = needStaff($in);
  if (!canWarn($u)) fail('Варн с 1 ранга', 403);
  $nick = trim((string)($in['nick'] ?? ''));
  $x = findUserByNick($nick);
  if (!$x) fail('Нет такого');
  $note = cut((string)($in['reason'] ?? 'предупреждение'), 160);
  $saved = patchUser($x['id'], function (&$t) use ($note, $u) {
    $t['warns'] = $t['warns'] ?? [];
    $t['warns'][] = ['at' => gmdate('c'), 'by' => $u['nick'], 'note' => $note];
  });
  $n = count($saved['warns'] ?? []);
  logMod($u, 'warn', $saved['nick'], $note);
  sysMsg($saved['nick'] . ' предупреждение (' . $n . '): ' . $note);
  if ($n >= 3 && empty($saved['banned'])) {
    patchUser($x['id'], function (&$t) {
      $t['banned'] = true;
      $t['banUntil'] = time() + 24 * 3600;
      $t['banReason'] = '3 предупреждения';
      $t['token'] = bin2hex(random_bytes(24));
    });
    sysMsg($saved['nick'] . ' забанен автоматически (3 варна)');
  }
  ok(['user' => publicUser($saved, true), 'warns' => $n]);
}

if ($action === 'clearWarns') {
  $u = needAdmin($in);
  $nick = trim((string)($in['nick'] ?? ''));
  $x = findUserByNick($nick);
  if (!$x) fail('Нет такого');
  $saved = patchUser($x['id'], function (&$t) { $t['warns'] = []; });
  logMod($u, 'clearWarns', $saved['nick']);
  ok(['user' => publicUser($saved, true)]);
}

if ($action === 'kick') {
  $u = needStaff($in);
  if (!canMute($u)) fail('Кик с 2 ранга', 403);
  $nick = trim((string)($in['nick'] ?? ''));
  $x = findUserByNick($nick);
  if (!$x) fail('Нет такого');
  if (isAdmin($x)) fail('Админа кикать нельзя');
  patchUser($x['id'], function (&$t) { $t['token'] = bin2hex(random_bytes(24)); });
  logMod($u, 'kick', $nick);
  sysMsg($nick . ' отключён админом');
  ok();
}

if ($action === 'broadcast') {
  $u = needAdmin($in);
  $text = cut((string)($in['text'] ?? ''), 400);
  if ($text === '') fail('Текст');
  $th = (string)($in['thread'] ?? 'global');
  if ($th !== 'global' && $th !== 'channel' && $th !== 'system') $th = 'global';
  $item = sysMsg($text, $th);
  logMod($u, 'broadcast', $th, $text);
  ok(['item' => $item]);
}

if ($action === 'purge') {
  $u = needAdmin($in);
  $nick = trim((string)($in['nick'] ?? ''));
  if ($nick === '') fail('Ник');
  $target = findUserByNick($nick);
  $uid = $target['id'] ?? '';
  $doc = msgs();
  $n = 0;
  foreach ($doc['items'] as &$m) {
    $sameUid = $uid !== '' && ($m['uid'] ?? '') === $uid;
    $legacy = ($m['uid'] ?? '') === '' && ($m['nick'] ?? '') === $nick;
    if (!$sameUid && !$legacy) continue;
    if (!empty($m['deleted'])) continue;
    $m['deleted'] = true;
    $m['text'] = '';
    $m['url'] = null;
    $n++;
  }
  saveMsgs($doc);
  logMod($u, 'purge', $nick, (string)$n);
  sysMsg('Сообщения ' . $nick . ' очищены (' . $n . ')');
  ok(['count' => $n]);
}

if ($action === 'modlog') {
  needAdmin($in);
  $items = modlog()['items'];
  ok(['items' => array_slice($items, 0, 80)]);
}

if ($action === 'adminStats') {
  needAdmin($in);
  $now = time();
  $online = 0;
  foreach (live()['seen'] ?? [] as $at) if ((int)$at > $now - 90) $online++;
  $bans = 0;
  $mutes = 0;
  foreach (users()['users'] as $x) {
    if (!empty($x['banned'])) $bans++;
    if ((int)($x['muteUntil'] ?? 0) > $now) $mutes++;
  }
  ok([
    'users' => count(users()['users']),
    'messages' => count(msgs()['items']),
    'online' => $online,
    'bans' => $bans,
    'mutes' => $mutes,
    'packs' => count(packs()['packs'])
  ]);
}

if ($action === 'clearChat') {
  $u = needUser($in);
  $thread = (string)($in['thread'] ?? 'global');
  if (!threadOk($thread) || !inThread($u, $thread)) fail('Чат');
  $saved = patchUser($u['id'], function (&$x) use ($thread) {
    $x['cleared'] = $x['cleared'] ?? [];
    $x['cleared'][$thread] = time();
  });
  ok(['cleared' => true, 'thread' => $thread]);
}

if ($action === 'saveSticker') {
  $u = needUser($in);
  needVerified($u);
  $url = cut((string)($in['url'] ?? ''), 500);
  $name = cut((string)($in['name'] ?? 'sticker'), 40);
  if (!safeUrl($url)) fail('https');
  $packId = (string)($in['packId'] ?? '');
  $doc = packs();
  if ($packId === '') {
    foreach ($doc['packs'] as $p) {
      if (($p['owner'] ?? '') === $u['id'] && ($p['kind'] ?? 'sticker') === 'sticker') {
        $packId = $p['id'];
        break;
      }
    }
    if ($packId === '') {
      $packId = id('p');
      $doc['packs'][] = ['id' => $packId, 'name' => 'Избранное', 'kind' => 'sticker', 'owner' => $u['id'], 'public' => false, 'items' => []];
    }
  }
  foreach ($doc['packs'] as &$p) {
    if (($p['id'] ?? '') !== $packId) continue;
    if (($p['owner'] ?? '') !== $u['id']) fail('Не твоё', 403);
    foreach ($p['items'] ?? [] as $it) {
      if (($it['url'] ?? '') === $url) ok(['pack' => $p, 'exists' => true]);
    }
    if (count($p['items'] ?? []) >= 80) fail('Пак полный');
    $p['items'][] = ['name' => $name, 'url' => $url];
    savePacks($doc);
    ok(['pack' => $p]);
  }
  fail('Нет коллекции');
}

if ($action === 'createBot') {
  $u = needUser($in);
  needVerified($u);
  rate('bot', 4, 3600);
  $name = cut((string)($in['name'] ?? ''), 24);
  if (!preg_match('/^[A-Za-z0-9_]{3,24}$/', $name)) fail('Имя бота 3–24');
  $lang = (string)($in['lang'] ?? 'js');
  if (!in_array($lang, ['js', 'php', 'python'], true)) $lang = 'js';
  $doc = bots();
  foreach ($doc['bots'] as $b) {
    if (strcasecmp((string)$b['name'], $name) === 0) fail('Имя занято');
  }
  $token = 'bot' . bin2hex(random_bytes(18));
  $username = cut((string)($in['username'] ?? $name), 32);
  $username = ltrim($username, '@');
  if ($username !== '' && !preg_match('/^[A-Za-z0-9_]{3,32}$/', $username)) fail('Юз 3–32');
  if ($username !== '' && substr($username, -4) !== '_bot') $username .= '_bot';
  foreach ($doc['bots'] as $b) {
    if ($username !== '' && strcasecmp((string)($b['username'] ?? ''), $username) === 0) fail('Юз занят');
  }
  $bot = [
    'id' => 'bot' . str_pad((string)random_int(0, 999999999999), 12, '0', STR_PAD_LEFT),
    'name' => $name,
    'username' => $username !== '' ? $username : $name,
    'owner' => $u['id'],
    'token' => $token,
    'lang' => $lang,
    'about' => cut((string)($in['about'] ?? ''), 160),
    'avatar' => cut((string)($in['avatar'] ?? ''), 400),
    'webhook' => cut((string)($in['webhook'] ?? ''), 400),
    'commands' => [],
    'created' => gmdate('c')
  ];
  $doc['bots'][] = $bot;
  saveBots($doc);
  idxSet(VAULT_BOTID, strtolower((string)$bot['username']), (string)$bot['id']);
  notify($u['id'], 'Бот @' . $name . ' создан. Токен в профиле ботов.');
  ok(['bot' => $bot]);
}

if ($action === 'myBots') {
  $u = needUser($in);
  $out = [];
  foreach (bots()['bots'] as $b) {
    if (($b['owner'] ?? '') !== $u['id']) continue;
    $out[] = $b;
  }
  ok(['items' => $out]);
}

if ($action === 'delBot') {
  $u = needUser($in);
  $id = (string)($in['id'] ?? '');
  $doc = bots();
  $next = [];
  $found = false;
  foreach ($doc['bots'] as $b) {
    if (($b['id'] ?? '') === $id) {
      if (($b['owner'] ?? '') !== $u['id']) fail('Не твоё', 403);
      $found = true;
      continue;
    }
    $next[] = $b;
  }
  if (!$found) fail('Нет бота');
  $doc['bots'] = $next;
  saveBots($doc);
  ok();
}

if ($action === 'pinChat') {
  $u = needUser($in);
  $thread = (string)($in['thread'] ?? '');
  if (!threadOk($thread) || !inThread($u, $thread)) fail('Чат');
  $saved = patchUser($u['id'], function (&$x) use ($thread) {
    $list = $x['pinnedChats'] ?? [];
    if (in_array($thread, $list, true)) $list = array_values(array_filter($list, fn($t) => $t !== $thread));
    else array_unshift($list, $thread);
    $x['pinnedChats'] = array_slice($list, 0, 12);
  });
  ok(['pinnedChats' => $saved['pinnedChats'] ?? []]);
}

if ($action === 'archiveChat') {
  $u = needUser($in);
  $thread = (string)($in['thread'] ?? '');
  if (!threadOk($thread) || !inThread($u, $thread)) fail('Чат');
  $saved = patchUser($u['id'], function (&$x) use ($thread) {
    $list = $x['archived'] ?? [];
    if (in_array($thread, $list, true)) $list = array_values(array_filter($list, fn($t) => $t !== $thread));
    else $list[] = $thread;
    $x['archived'] = $list;
  });
  ok(['archived' => $saved['archived'] ?? []]);
}

if ($action === 'muteChat') {
  $u = needUser($in);
  $thread = (string)($in['thread'] ?? '');
  if (!threadOk($thread) || !inThread($u, $thread)) fail('Чат');
  $until = max(0, (int)($in['until'] ?? 0));
  $saved = patchUser($u['id'], function (&$x) use ($thread, $until) {
    $x['mutedChats'] = $x['mutedChats'] ?? [];
    if ($until <= 0) unset($x['mutedChats'][$thread]);
    else $x['mutedChats'][$thread] = $until;
  });
  ok(['mutedChats' => $saved['mutedChats'] ?? []]);
}

if ($action === 'saveMessage') {
  $u = needUser($in);
  needVerified($u);
  $id = (string)($in['id'] ?? '');
  if (!msgIdOk($id)) fail('Нет сообщения');
  $src = findMsg($id);
  if (!$src || !empty($src['deleted'])) fail('Нет сообщения');
  $th = (string)($src['thread'] ?? 'global');
  if (!inThread($u, $th) || !canAccessMsg($u, $src)) fail('Нет доступа', 403);
  $item = [
    'id' => id(),
    'at' => gmdate('c'),
    'nick' => $u['nick'],
    'uid' => $u['id'],
    'avatar' => $u['avatar'] ?? '',
    'kind' => $src['kind'] ?? 'text',
    'text' => $src['text'] ?? '',
    'url' => $src['url'] ?? null,
    'name' => $src['name'] ?? null,
    'pinned' => false,
    'reactions' => [],
    'thread' => 'saved',
    'forwardedFrom' => $src['nick'] ?? '',
    'edited' => false
  ];
  if (($item['kind'] ?? '') === 'poll') {
    $item['kind'] = 'text';
    $item['text'] = 'Опрос: ' . cut((string)($src['text'] ?? ''), 200);
  }
  pushMsg($item);
  ok(['item' => $item]);
}

if ($action === 'scheduled') {
  $u = needUser($in);
  $out = [];
  foreach (sched()['items'] as $it) {
    if (($it['uid'] ?? '') !== $u['id']) continue;
    $out[] = $it;
  }
  ok(['items' => $out]);
}

if ($action === 'cancelScheduled') {
  $u = needUser($in);
  $id = (string)($in['id'] ?? '');
  $doc = sched();
  $next = [];
  $found = false;
  foreach ($doc['items'] as $it) {
    if (($it['id'] ?? '') === $id && ($it['uid'] ?? '') === $u['id']) {
      $found = true;
      continue;
    }
    $next[] = $it;
  }
  if (!$found) fail('Нет отложенного');
  $doc['items'] = $next;
  saveSched($doc);
  ok();
}

if ($action === 'linkPreview') {
  $u = needUser($in);
  rate('prev', 20, 60);
  $url = cut((string)($in['url'] ?? ''), 400);
  if (!safeUrl($url)) fail('https');
  $doc = previews();
  $key = hash('sha1', $url);
  if (isset($doc['map'][$key]) && (int)($doc['map'][$key]['at'] ?? 0) > time() - 86400) {
    ok(['preview' => $doc['map'][$key]]);
  }
  $ctx = stream_context_create([
    'http' => ['method' => 'GET', 'timeout' => 4, 'follow_location' => 0, 'header' => "User-Agent: CryndelLauncher/1.0\r\n"],
    'ssl' => ['verify_peer' => true, 'verify_peer_name' => true]
  ]);
  $html = @file_get_contents($url, false, $ctx, 0, 48000);
  $title = '';
  $desc = '';
  $img = '';
  if (is_string($html) && $html !== '') {
    if (preg_match('/<title[^>]*>([^<]{1,120})/i', $html, $m)) $title = html_entity_decode(trim($m[1]), ENT_QUOTES | ENT_HTML5, 'UTF-8');
    if (preg_match('/property=["\']og:description["\']\s+content=["\']([^"\']{1,200})/i', $html, $m)
      || preg_match('/name=["\']description["\']\s+content=["\']([^"\']{1,200})/i', $html, $m)) {
      $desc = html_entity_decode(trim($m[1]), ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }
    if (preg_match('/property=["\']og:image["\']\s+content=["\']([^"\']{1,400})/i', $html, $m)) {
      $img = $m[1];
      if ($img && !safeUrl($img)) $img = '';
    }
  }
  $preview = [
    'url' => $url,
    'title' => cut($title !== '' ? $title : preg_replace('#^https?://#', '', $url), 80),
    'desc' => cut($desc, 140),
    'img' => $img,
    'at' => time()
  ];
  $doc['map'][$key] = $preview;
  if (count($doc['map']) > 800) $doc['map'] = array_slice($doc['map'], -400, null, true);
  savePreviews($doc);
  ok(['preview' => $preview]);
}

if ($action === 'adminBot') {
  $u = needStaff($in);
  $text = (string)($in['text'] ?? '');
  $thread = (string)($in['thread'] ?? 'dm:adminbot');
  $bot = crynBot($u, $text, $thread);
  if (!$bot) $bot = botMsg("Неизвестная команда.\n/mod /unmod /warn /mute /ban /pin /del /streaks /help", $thread, 'Admin');
  if (!empty($bot['id'])) $bot = pushMsg($bot);
  ok(['bot' => $bot]);
}

if ($action === 'streakTop') {
  $u = needAdmin($in);
  ok(['items' => streakTopList()]);
}

if ($action === 'reviveStreak') {
  $u = needUser($in);
  $thread = (string)($in['thread'] ?? '');
  $r = reviveStreak($u, $thread);
  $item = sysMsg('Огонёк возвращён. Осталось возвратов в этом месяце: ' . (int)$r['revivesLeft'] . '. Сброс 1-го числа в 00:00 МСК.', $thread);
  ok(['streak' => $r, 'item' => $item]);
}

if ($action === 'setBot') {
  $u = needUser($in);
  $id = (string)($in['id'] ?? '');
  $doc = bots();
  foreach ($doc['bots'] as &$b) {
    if (($b['id'] ?? '') !== $id) continue;
    if (($b['owner'] ?? '') !== $u['id'] && !isAdmin($u)) fail('Не твоё', 403);
    if (isset($in['about'])) $b['about'] = cut((string)$in['about'], 160);
    if (isset($in['avatar'])) $b['avatar'] = cut((string)$in['avatar'], 400);
    if (isset($in['webhook'])) {
      $wh = cut((string)$in['webhook'], 400);
      if ($wh !== '' && !preg_match('#^https://#i', $wh)) fail('Webhook только https');
      $b['webhook'] = $wh;
    }
    if (isset($in['commands']) && is_array($in['commands'])) {
      $cmds = [];
      foreach ($in['commands'] as $c) {
        $name = ltrim(cut((string)($c['name'] ?? $c['cmd'] ?? ''), 32), '/');
        if (!preg_match('/^[a-z0-9_]{1,24}$/', $name)) continue;
        $cmds[] = ['name' => $name, 'hint' => cut((string)($c['hint'] ?? $c['desc'] ?? ''), 80)];
        if (count($cmds) >= 24) break;
      }
      $b['commands'] = $cmds;
    }
    saveBots($doc);
    ok(['bot' => $b]);
  }
  fail('Нет бота');
}

if ($action === 'revokeBot') {
  $u = needUser($in);
  $id = (string)($in['id'] ?? '');
  $doc = bots();
  foreach ($doc['bots'] as &$b) {
    if (($b['id'] ?? '') !== $id) continue;
    if (($b['owner'] ?? '') !== $u['id'] && !isAdmin($u)) fail('Не твоё', 403);
    $b['token'] = 'bot' . bin2hex(random_bytes(18));
    saveBots($doc);
    ok(['bot' => $b]);
  }
  fail('Нет бота');
}

if ($action === 'botSend') {
  $bot = botByToken((string)($in['token'] ?? ''));
  if (!$bot) fail('Токен бота', 401);
  rate('botsend', 40, 60);
  $thread = (string)($in['thread'] ?? 'global');
  if (!threadOk($thread)) fail('Чат');
  $kind = (string)($in['kind'] ?? 'text');
  if (!in_array($kind, ['text', 'image', 'gif', 'sticker'], true)) $kind = 'text';
  $botUrl = isset($in['url']) ? cut((string)$in['url'], 500) : null;
  if ($botUrl && !safeUrl($botUrl) && !preg_match('#^https://my\.cryndel\.ru/#i', $botUrl)) fail('Плохая ссылка');
  $item = [
    'id' => id(),
    'at' => gmdate('c'),
    'nick' => (string)($bot['username'] ?? $bot['name'] ?? 'bot'),
    'uid' => 'bot:' . ($bot['id'] ?? ''),
    'avatar' => (string)($bot['avatar'] ?? ''),
    'role' => 'bot',
    'kind' => $kind,
    'text' => cut((string)($in['text'] ?? ''), 2000),
    'url' => $botUrl,
    'pinned' => false,
    'reactions' => [],
    'thread' => $thread,
    'badges' => ['official'],
    'buttons' => []
  ];
  if (!empty($in['buttons']) && is_array($in['buttons'])) {
    foreach ($in['buttons'] as $btn) {
      $lab = cut((string)($btn['text'] ?? $btn['label'] ?? ''), 40);
      if ($lab === '') continue;
      $one = ['text' => $lab];
      if (!empty($btn['url']) && preg_match('#^https://#i', (string)$btn['url'])) $one['url'] = cut((string)$btn['url'], 400);
      if (!empty($btn['cmd'])) $one['cmd'] = cut((string)$btn['cmd'], 80);
      $item['buttons'][] = $one;
      if (count($item['buttons']) >= 8) break;
    }
  }
  pushMsg($item);
  ok(['item' => $item]);
}

if ($action === 'resetPass') {
  $u = needAdmin($in);
  $nick = trim((string)($in['nick'] ?? ''));
  $x = findUserByNick($nick);
  if (!$x) fail('Нет такого');
  $allow = !empty($in['allow']) || !empty(meta()['allowPassReset']);
  if (!$allow && empty($in['force'])) fail('Сброс пароля выключен');
  patchUser($x['id'], function (&$t) {
    $t['needPassReset'] = true;
    $t['hash'] = password_hash(bin2hex(random_bytes(12)), PASSWORD_DEFAULT);
    $t['token'] = bin2hex(random_bytes(24));
    $t['tokenHash'] = tokenHash($t['token']);
    $t['tokenExp'] = 0;
    $t['sessions'] = [];
  });
  notify($x['id'], 'Ваш пароль сброшен администратором. Задайте пароль в настройках или напишите /pass пароль пароль');
  logMod($u, 'resetPass', $nick, '');
  ok(['reset' => true, 'nick' => $x['nick']]);
}

if ($action === 'setPass') {
  $u = needUser($in);
  $old = (string)($in['old'] ?? $in['oldPass'] ?? '');
  $pass = (string)($in['password'] ?? $in['pass'] ?? '');
  $again = (string)($in['again'] ?? $in['repeat'] ?? $pass);
  if (strlen($pass) < 8 || strlen($pass) > 72) fail('Пароль 8–72 символа');
  if ($pass !== $again) fail('Пароли не совпадают');
  if (empty($u['needPassReset'])) {
    if ($old === '' || !password_verify($old, (string)($u['hash'] ?? ''))) fail('Неверные данные', 401);
  }
  $plain = '';
  $saved = patchUser($u['id'], function (&$t) use ($pass, &$plain) {
    $t['hash'] = password_hash($pass, PASSWORD_DEFAULT);
    $t['needPassReset'] = false;
    $plain = issueToken($t);
  });
  wsTokenPut($plain, (string)$saved['id'], (string)$saved['nick'], (int)$saved['tokenExp']);
  ok(['ok' => true, 'token' => $plain]);
}

if ($action === 'emojiMap') {
  $cfg = meta();
  $map = $cfg['emojiMap'] ?? [];
  ok(['items' => $map, 'off' => false]);
}

if ($action === 'setEmoji') {
  $u = needAdmin($in);
  $emo = cut((string)($in['emoji'] ?? $in['code'] ?? ''), 16);
  $url = cut((string)($in['url'] ?? ''), 500);
  if ($emo === '') fail('Эмодзи');
  $cfg = meta();
  $cfg['emojiMap'] = $cfg['emojiMap'] ?? [];
  if ($url === '') unset($cfg['emojiMap'][$emo]);
  else $cfg['emojiMap'][$emo] = $url;
  saveMeta($cfg);
  logMod($u, 'emoji', $emo, $url);
  ok(['items' => $cfg['emojiMap']]);
}

if ($action === 'sessions') {
  $u = needUser($in);
  ok(['items' => array_values($u['sessions'] ?? [['id' => $u['device'] ?? '', 'name' => 'это устройство', 'at' => gmdate('c')]])]);
}

if ($action === 'revokeSession') {
  $u = needUser($in);
  $id = cut((string)($in['id'] ?? ''), 64);
  $plain = '';
  $saved = patchUser($u['id'], function (&$x) use ($id, &$plain) {
    $x['sessions'] = array_values(array_filter($x['sessions'] ?? [], fn($s) => ($s['id'] ?? '') !== $id));
    if (($x['device'] ?? '') === $id) {
      $x['device'] = '';
      $plain = issueToken($x);
    }
  });
  if ($plain !== '') wsTokenPut($plain, (string)$saved['id'], (string)$saved['nick'], (int)$saved['tokenExp']);
  ok(['items' => $saved['sessions'] ?? [], 'token' => $plain !== '' ? $plain : null]);
}

if ($action === 'privacy') {
  $u = needUser($in);
  if (isset($in['whoWrite']) || isset($in['allowFrom']) || isset($in['denyFrom'])) {
    $saved = patchUser($u['id'], function (&$x) use ($in) {
      $p = $x['privacy'] ?? ['whoWrite' => 'all', 'allowFrom' => [], 'denyFrom' => []];
      if (isset($in['whoWrite']) && in_array((string)$in['whoWrite'], ['all', 'contacts', 'nobody'], true)) $p['whoWrite'] = (string)$in['whoWrite'];
      if (isset($in['allowFrom']) && is_array($in['allowFrom'])) $p['allowFrom'] = array_values(array_filter(array_map(fn($n) => cut((string)$n, 20), $in['allowFrom'])));
      if (isset($in['denyFrom']) && is_array($in['denyFrom'])) $p['denyFrom'] = array_values(array_filter(array_map(fn($n) => cut((string)$n, 20), $in['denyFrom'])));
      $x['privacy'] = $p;
    });
    $u = $saved;
  }
  ok(['privacy' => $u['privacy'] ?? ['whoWrite' => 'all', 'allowFrom' => [], 'denyFrom' => []]]);
}

if ($action === 'shareCard') {
  $u = needUser($in);
  $kind = cut((string)($in['kind'] ?? $in['t'] ?? ''), 16);
  if ($kind === 'user' || $kind === 'profile') {
    $x = findUserByNick(trim((string)($in['nick'] ?? '')));
    if (!$x) fail('Нет такого');
    ok(['kind' => 'profile', 'user' => publicUser($x)]);
  }
  if ($kind === 'msg' || $kind === 'message') {
    $mid = (string)($in['id'] ?? '');
    if (!msgIdOk($mid)) fail('Нет сообщения');
    $m = findMsg($mid);
    if (!$m) fail('Нет сообщения');
    if (!canAccessMsg($u, $m)) fail('Нет доступа', 403);
    if (!empty($m['deleted'])) ok(['kind' => 'message', 'deleted' => true, 'text' => 'удалено', 'id' => $m['id'] ?? '']);
    ok(['kind' => 'message', 'item' => $m]);
  }
  if ($kind === 'flame' || $kind === 'streak') {
    $a = findUserByNick(trim((string)($in['a'] ?? '')));
    $b = findUserByNick(trim((string)($in['b'] ?? '')));
    if (!$a || !$b) fail('Нет такого');
    $th = dmThread($a['id'], $b['id']);
    $st = streakOf($a, $b['id']);
    ok(['kind' => 'flame', 'days' => (int)($st['days'] ?? 0), 'tier' => (string)($st['tier'] ?? ''), 'a' => publicUser($a), 'b' => publicUser($b), 'thread' => $th]);
  }
  fail('Карточка');
}

if ($action === 'wsInfo') {
  $u = needUser($in);
  ok(['url' => WS_PUBLIC, 'port' => WS_PORT, 'uid' => $u['id']]);
}

if ($action === 'createKanal') {
  $u = needUser($in);
  needVerified($u);
  rateFor($u, 'kanal');
  if (!empty($u['channelId'])) fail('Уже есть канал');
  $handle = preg_replace('/^&@/', '', trim((string)($in['handle'] ?? $in['nick'] ?? $u['nick'])));
  if (!kanalHandleOk($handle)) fail('Юз канала: 3–20 латиница, цифры, _');
  if (idxGet(VAULT_KANALID, '&@' . strtolower($handle)) !== '') fail('Юз канала занят');
  $kid = 'k' . bin2hex(random_bytes(6));
  $k = [
    'id' => $kid,
    'handle' => $handle,
    'owner' => $u['id'],
    'title' => cut((string)($in['title'] ?? $handle), 40),
    'about' => cut((string)($in['about'] ?? ''), 280),
    'avatar' => '',
    'banner' => '',
    'links' => [],
    'public' => true,
    'subs' => [$u['id']],
    'created' => gmdate('c')
  ];
  if (isset($in['avatar'])) {
    $av = cut((string)$in['avatar'], 2000);
    if ($av !== '' && !preg_match('#^https://#i', $av)) fail('Аватар только https');
    $k['avatar'] = $av;
  }
  if (isset($in['banner']) || isset($in['cover'])) {
    $bn = cut((string)($in['banner'] ?? $in['cover'] ?? ''), 2000);
    if ($bn !== '' && !preg_match('#^https://#i', $bn)) fail('Баннер только https');
    $k['banner'] = $bn;
  }
  saveKanal($k);
  patchUser($u['id'], function (&$x) use ($kid) { $x['channelId'] = $kid; });
  idxSet(VAULT_KANALID, '&@' . strtolower($handle), $kid);
  ok(['kanal' => $k, 'thread' => 'kanal:' . $kid]);
}

if ($action === 'saveKanal') {
  $u = needUser($in);
  $kid = (string)($u['channelId'] ?? '');
  if (isset($in['id']) && isAdmin($u)) $kid = preg_replace('/^kanal:/', '', (string)$in['id']);
  if ($kid === '') fail('Нет канала');
  $k = loadKanal($kid);
  if (!$k) fail('Нет канала');
  if (($k['owner'] ?? '') !== $u['id'] && !isAdmin($u)) fail('Не твоё', 403);
  if (isset($in['title'])) $k['title'] = cut((string)$in['title'], 40);
  if (isset($in['about'])) $k['about'] = cut((string)$in['about'], 280);
  if (isset($in['handle'])) {
    $handle = preg_replace('/^&@/', '', trim((string)$in['handle']));
    if (!kanalHandleOk($handle)) fail('Юз канала: 3–20 латиница, цифры, _');
    $clash = idxGet(VAULT_KANALID, '&@' . strtolower($handle));
    if ($clash !== '' && $clash !== $kid) fail('Юз канала занят');
    $k['handle'] = $handle;
  }
  if (isset($in['avatar'])) {
    $av = cut((string)$in['avatar'], 2000);
    if ($av !== '' && !preg_match('#^https://#i', $av)) fail('Аватар только https');
    $k['avatar'] = $av;
  }
  if (isset($in['banner']) || isset($in['cover'])) {
    $bn = cut((string)($in['banner'] ?? $in['cover'] ?? ''), 2000);
    if ($bn !== '' && !preg_match('#^https://#i', $bn)) fail('Баннер только https');
    $k['banner'] = $bn;
  }
  if (isset($in['links']) && is_array($in['links'])) {
    $links = [];
    foreach ($in['links'] as $ln) {
      $url = cut((string)(is_array($ln) ? ($ln['url'] ?? '') : $ln), 300);
      if ($url === '' || !preg_match('#^https://#i', $url)) continue;
      $links[] = ['url' => $url, 'title' => cut((string)(is_array($ln) ? ($ln['title'] ?? '') : ''), 40)];
      if (count($links) >= 8) break;
    }
    $k['links'] = $links;
  }
  saveKanal($k);
  ok(['kanal' => $k]);
}

if ($action === 'subKanal') {
  $u = needUser($in);
  $kid = preg_replace('/^kanal:/', '', (string)($in['id'] ?? ''));
  $k = loadKanal($kid);
  if (!$k) fail('Нет канала');
  $subs = $k['subs'] ?? [];
  $on = !in_array($u['id'], $subs, true);
  if ($on) $subs[] = $u['id'];
  else $subs = array_values(array_filter($subs, fn($x) => $x !== $u['id']));
  $k['subs'] = $subs;
  saveKanal($k);
  $sf = savesDir($u['id']) . '/channels.bin';
  $sd = vaultRead($sf, ['ids' => []]);
  if ($on) $sd['ids'] = array_values(array_unique(array_merge($sd['ids'] ?? [], [$kid])));
  else $sd['ids'] = array_values(array_filter($sd['ids'] ?? [], fn($x) => $x !== $kid));
  vaultWrite($sf, $sd);
  ok(['on' => $on, 'subs' => count($subs)]);
}

if ($action === 'kanal') {
  needUser($in);
  $kid = preg_replace('/^kanal:/', '', (string)($in['id'] ?? $in['handle'] ?? ''));
  if (strpos($kid, '&@') === 0) $kid = idxGet(VAULT_KANALID, strtolower($kid));
  $k = loadKanal($kid);
  if (!$k) fail('Нет канала');
  ok(['kanal' => $k, 'thread' => 'kanal:' . $k['id'], 'subs' => count($k['subs'] ?? [])]);
}

if ($action === 'comment') {
  $u = needUser($in);
  needVerified($u);
  rateFor($u, 'cmt');
  $pid = cut((string)($in['id'] ?? $in['post'] ?? ''), 24);
  $text = cut((string)($in['text'] ?? ''), 800);
  if ($text === '') fail('Пусто');
  if (!msgIdOk($pid)) fail('Нет сообщения');
  $m = findMsg($pid);
  if (!$m) fail('Нет сообщения');
  if (!canAccessMsg($u, $m)) fail('Нет доступа', 403);
  $thread = (string)($m['thread'] ?? '');
  if (strpos($thread, 'kanal:') !== 0 && $thread !== 'channel') fail('Коментарии только у постов канала');
  $c = [
    'id' => id('c'),
    'at' => gmdate('c'),
    'uid' => $u['id'],
    'nick' => $u['nick'],
    'avatar' => $u['avatar'] ?? '',
    'text' => $text,
    'post' => $pid
  ];
  $kid = preg_replace('/^kanal:/', '', $thread);
  $file = kanalDir($kid === 'channel' ? 'channel' : $kid) . '/comments/' . $pid . '.bin';
  $doc = vaultRead($file, ['items' => []]);
  array_unshift($doc['items'], $c);
  if (count($doc['items']) > 500) $doc['items'] = array_slice($doc['items'], 0, 500);
  vaultWrite($file, $doc);
  wsEmit('comment', ['thread' => $thread, 'post' => $pid, 'item' => $c]);
  ok(['item' => $c, 'count' => count($doc['items'])]);
}

if ($action === 'comments') {
  $u = needUser($in);
  $pid = cut((string)($in['id'] ?? ''), 24);
  if (!msgIdOk($pid)) fail('Неизвестное действие', 404);
  $m = findMsg($pid);
  if (!$m) fail('Нет сообщения');
  if (!canAccessMsg($u, $m)) fail('Нет доступа', 403);
  $thread = (string)($m['thread'] ?? '');
  if (strpos($thread, 'kanal:') !== 0 && $thread !== 'channel') fail('Неизвестное действие', 404);
  $kid = preg_replace('/^kanal:/', '', $thread);
  $kid = preg_replace('/[^A-Za-z0-9_-]/', '', $kid);
  $file = kanalDir($kid === 'channel' || $kid === '' ? 'channel' : $kid) . '/comments/' . $pid . '.bin';
  $doc = vaultRead($file, ['items' => []]);
  ok(['items' => $doc['items'] ?? []]);
}

if ($action === 'shop') {
  needUser($in);
  $doc = shopDoc();
  $items = [];
  foreach (($doc['items'] ?? []) as $it) $items[] = shopItemPublic($it);
  ok(['items' => $items]);
}

if ($action === 'shopAdd') {
  $u = needAdmin($in);
  $name = cut((string)($in['name'] ?? ''), 40);
  if ($name === '') fail('Название');
  $kind = (string)($in['kind'] ?? 'avatarHat');
  if (!in_array($kind, ['avatarHat', 'listHat', 'profileHat'], true)) fail('Тип');
  $url = cut((string)($in['url'] ?? ''), 2000);
  if ($url === '' || !preg_match('#^https://#i', $url) && strpos($url, 'data:') !== 0) fail('Файл');
  $id = 'v' . bin2hex(random_bytes(4));
  $item = [
    'id' => $id,
    'name' => $name,
    'kind' => $kind,
    'desc' => cut((string)($in['desc'] ?? $in['about'] ?? ''), 200),
    'price' => max(0, (int)($in['price'] ?? 0)),
    'url' => $url,
    'ext' => cut((string)($in['ext'] ?? ''), 8),
    'anim' => !empty($in['anim']) || preg_match('/\.(gif|webp|webm|mp4)(\?|$)/i', $url)
  ];
  $doc = shopDoc();
  $doc['items'][] = $item;
  saveShop($doc);
  idxSet(VAULT_VIDATID, $id, $name);
  logMod($u, 'shopAdd', $name, $kind);
  ok(['item' => shopItemPublic($item)]);
}

if ($action === 'shopBuy') {
  $u = needUser($in);
  $id = cut((string)($in['id'] ?? ''), 24);
  $doc = shopDoc();
  $item = null;
  foreach ($doc['items'] as $it) if (($it['id'] ?? '') === $id) { $item = $it; break; }
  if (!$item) fail('Нет предмета');
  $price = (int)($item['price'] ?? 0);
  $owned = $u['cosmetics']['owned'] ?? [];
  if (in_array($id, $owned, true)) fail('Уже куплено');
  if ((int)($u['pirikas'] ?? 0) < $price) fail('Не хватает пирикаса');
  $saved = patchUser($u['id'], function (&$x) use ($id, $price, $item) {
    $x['pirikas'] = max(0, (int)($x['pirikas'] ?? 0) - $price);
    $x['cosmetics'] = $x['cosmetics'] ?? ['owned' => [], 'avatarHat' => '', 'listHat' => '', 'profileHat' => ''];
    $x['cosmetics']['owned'][] = $id;
    $kind = (string)($item['kind'] ?? 'avatarHat');
    if (in_array($kind, ['avatarHat', 'listHat', 'profileHat'], true) && empty($x['cosmetics'][$kind])) {
      $x['cosmetics'][$kind] = $id;
    }
  });
  ok(['user' => publicUser($saved, true), 'item' => shopItemPublic($item)]);
}

if ($action === 'shopWear') {
  $u = needUser($in);
  $id = cut((string)($in['id'] ?? ''), 24);
  $kind = (string)($in['kind'] ?? '');
  $owned = $u['cosmetics']['owned'] ?? [];
  if ($id !== '' && !in_array($id, $owned, true) && !isAdmin($u)) fail('Не куплено');
  $doc = shopDoc();
  if ($id !== '') {
    $found = null;
    foreach ($doc['items'] as $it) if (($it['id'] ?? '') === $id) { $found = $it; break; }
    if (!$found) fail('Нет предмета');
    if ($kind === '') $kind = (string)($found['kind'] ?? 'avatarHat');
  }
  if (!in_array($kind, ['avatarHat', 'listHat', 'profileHat'], true)) fail('Тип');
  $saved = patchUser($u['id'], function (&$x) use ($id, $kind) {
    $x['cosmetics'] = $x['cosmetics'] ?? ['owned' => [], 'avatarHat' => '', 'listHat' => '', 'profileHat' => ''];
    $x['cosmetics'][$kind] = $id;
  });
  ok(['user' => publicUser($saved, true)]);
}

if ($action === 'shopGive') {
  $u = needAdmin($in);
  $nick = trim((string)($in['nick'] ?? $in['id'] ?? ''));
  $x = findUserByNick($nick) ?: findUserById($nick);
  if (!$x) fail('Нет такого');
  $itemId = cut((string)($in['item'] ?? $in['vidat'] ?? ''), 24);
  $pir = (int)($in['pirikas'] ?? $in['coins'] ?? 0);
  $saved = patchUser($x['id'], function (&$t) use ($itemId, $pir) {
    if ($pir) $t['pirikas'] = max(0, (int)($t['pirikas'] ?? 0) + $pir);
    if ($itemId !== '') {
      $t['cosmetics'] = $t['cosmetics'] ?? ['owned' => [], 'avatarHat' => '', 'listHat' => '', 'profileHat' => ''];
      if (!in_array($itemId, $t['cosmetics']['owned'], true)) $t['cosmetics']['owned'][] = $itemId;
    }
  });
  logMod($u, 'shopGive', $saved['nick'], $itemId . ' +' . $pir);
  ok(['user' => publicUser($saved, true)]);
}

if ($action === 'grantRight') {
  $u = needAdmin($in);
  $nick = trim((string)($in['nick'] ?? $in['id'] ?? ''));
  $x = findUserByNick($nick) ?: findUserById($nick);
  if (!$x) fail('Нет такого');
  $right = strtolower(trim((string)($in['right'] ?? $in['rank'] ?? '')));
  $right = preg_replace('/^r+/', 'r', $right);
  if (!preg_match('/^r([1-9]|1[0-2])$/', $right) && is_numeric($right)) $right = 'r' . max(1, min(12, (int)$right));
  if (!preg_match('/^r([1-9]|1[0-2])$/', $right)) fail('Право r1–r12');
  $saved = patchUser($x['id'], function (&$t) use ($right) {
    $t['rights'] = array_values(array_unique(array_merge($t['rights'] ?? [], [$right])));
    $n = (int)substr($right, 1);
    if ($n >= 1 && ($t['role'] ?? '') !== 'admin') {
      $t['role'] = 'mod';
      $t['modRank'] = max((int)($t['modRank'] ?? 0), min(4, $n));
    }
  });
  idxSet(VAULT_RIGHTSID, $saved['id'] . ':' . $right, $right);
  logMod($u, 'grant', $saved['nick'], $right);
  sysMsg($saved['nick'] . ' получил ' . $right, 'global');
  ok(['user' => publicUser($saved, true), 'right' => $right]);
}

if ($action === 'revokeRight') {
  $u = needAdmin($in);
  $nick = trim((string)($in['nick'] ?? ''));
  $x = findUserByNick($nick) ?: findUserById($nick);
  if (!$x) fail('Нет такого');
  $right = strtolower(trim((string)($in['right'] ?? '')));
  $saved = patchUser($x['id'], function (&$t) use ($right) {
    $t['rights'] = array_values(array_filter($t['rights'] ?? [], fn($r) => $r !== $right));
  });
  logMod($u, 'revoke', $saved['nick'], $right);
  ok(['user' => publicUser($saved, true)]);
}

fail('Неизвестное действие', 404);
