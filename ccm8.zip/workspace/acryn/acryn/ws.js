'use strict';

const http = require('http');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const PORT = Number(process.env.CRYN_WS_PORT || 18765);
const HOST = process.env.CRYN_WS_HOST || '127.0.0.1';
const KEY_FILE = path.join(__dirname, 'data', 'crynsys', '.wskey');
const TOK_FILE = path.join(__dirname, 'data', 'crynsys', 'wstokens');
const MAX_CLIENTS = 4000;
const MAX_PER_IP = 24;
const MAX_PER_USER = 8;
const MAX_FRAME = 32768;
const ORIGINS = new Set(['https://my.cryndel.ru', 'https://cryndel.ru', 'null']);
const clients = new Map();
const byUser = new Map();
const ipHits = new Map();
const userHits = new Map();

function tokMap() {
  const out = new Map();
  try {
    const raw = fs.readFileSync(TOK_FILE, 'utf8');
    for (const line of String(raw).split(/\r?\n/)) {
      const i = line.indexOf('=');
      if (i < 1) continue;
      out.set(line.slice(0, i).trim(), line.slice(i + 1).trim());
    }
  } catch (_) { /* */ }
  return out;
}

function authToken(token) {
  if (!/^[a-f0-9]{32,96}$/i.test(token)) return null;
  const h = crypto.createHash('sha256').update(token).digest('hex');
  const map = tokMap();
  const row = map.get(h);
  if (!row) return null;
  const [uid, nick, exp] = String(row).split('|');
  if (!uid || (Number(exp) > 0 && Number(exp) < Math.floor(Date.now() / 1000))) return null;
  return { uid: String(uid).replace(/[^A-Za-z0-9:_-]/g, '').slice(0, 32), nick: String(nick || '').replace(/[^\w.-]/g, '').slice(0, 24) };
}

function threadAllowed(uid, thread) {
  const th = String(thread || '');
  if (th === 'global' || th === 'channel' || th === 'system' || th === 'saved' || th === 'presence') return true;
  if (th === 'dm:createbot' || th === 'dm:adminbot') return true;
  if (/^kanal:[A-Za-z0-9_-]{4,40}$/.test(th)) return true;
  if (/^group:[A-Za-z0-9_-]{4,40}$/.test(th)) return true;
  const m = th.match(/^dm:(u[a-f0-9]{8}):(u[a-f0-9]{8})$/);
  if (m) return m[1] === uid || m[2] === uid;
  return false;
}

function loadPushToken() {
  try {
    const raw = fs.readFileSync(KEY_FILE, 'utf8').trim();
    if (raw) return raw;
  } catch (_) { /* */ }
  const tok = crypto.randomBytes(32).toString('hex');
  try {
    fs.mkdirSync(path.dirname(KEY_FILE), { recursive: true, mode: 0o700 });
    fs.writeFileSync(KEY_FILE, tok, { mode: 0o600 });
  } catch (_) { /* */ }
  return tok;
}

let PUSH_TOKEN = loadPushToken();

function sha1(buf) {
  return crypto.createHash('sha1').update(buf).digest();
}

function send(ws, obj) {
  const meta = clients.get(ws);
  if (!ws || ws.destroyed || !meta || !meta.alive) return;
  const raw = Buffer.from(JSON.stringify(obj), 'utf8');
  if (raw.length > MAX_FRAME) return;
  frame(ws, raw, 0x1);
}

function frame(socket, payload, opcode) {
  const len = payload.length;
  let head;
  if (len < 126) {
    head = Buffer.alloc(2);
    head[0] = 0x80 | opcode;
    head[1] = len;
  } else if (len < 65536) {
    head = Buffer.alloc(4);
    head[0] = 0x80 | opcode;
    head[1] = 126;
    head.writeUInt16BE(len, 2);
  } else {
    return;
  }
  try { socket.write(Buffer.concat([head, payload])); } catch (_) { drop(socket); }
}

function unmask(buf, key) {
  const out = Buffer.alloc(buf.length);
  for (let i = 0; i < buf.length; i++) out[i] = buf[i] ^ key[i % 4];
  return out;
}

function drop(socket) {
  const meta = clients.get(socket);
  if (meta) meta.alive = false;
  if (meta && meta.uid) {
    const set = byUser.get(meta.uid);
    if (set) {
      set.delete(socket);
      if (!set.size) byUser.delete(meta.uid);
    }
  }
  clients.delete(socket);
  try { socket.destroy(); } catch (_) { /* */ }
}

function attach(socket, ip) {
  clients.set(socket, {
    uid: '', token: '', ip, authed: false, alive: true, threads: new Set(['global']),
    last: Date.now(), buf: Buffer.alloc(0), msgs: 0, nick: ''
  });
  socket.on('data', (chunk) => {
    const meta = clients.get(socket);
    if (!meta) return;
    if (meta.buf.length + chunk.length > 65536) { drop(socket); return; }
    meta.buf = Buffer.concat([meta.buf, chunk]);
    parseFrames(socket);
  });
  socket.on('error', () => drop(socket));
  socket.on('close', () => drop(socket));
  socket.setTimeout(90000, () => drop(socket));
  socket.setNoDelay(true);
}

function parseFrames(socket) {
  const meta = clients.get(socket);
  if (!meta) return;
  let buf = meta.buf;
  while (buf.length >= 2) {
    const opcode = buf[0] & 0x0f;
    const masked = (buf[1] & 0x80) !== 0;
    let len = buf[1] & 0x7f;
    let off = 2;
    if (len === 126) {
      if (buf.length < 4) break;
      len = buf.readUInt16BE(2);
      off = 4;
    } else if (len === 127) {
      drop(socket);
      return;
    }
    if (!masked) { drop(socket); return; }
    if (len > MAX_FRAME) { drop(socket); return; }
    if (buf.length < off + 4 + len) break;
    const key = buf.slice(off, off + 4);
    const payload = unmask(buf.slice(off + 4, off + 4 + len), key);
    buf = buf.slice(off + 4 + len);
    meta.buf = buf;
    if (opcode === 0x8) { drop(socket); return; }
    if (opcode === 0x9) { frame(socket, payload.slice(0, 125), 0xA); continue; }
    if (opcode === 0x1) onText(socket, payload.toString('utf8'));
  }
  meta.buf = buf;
}

function onText(socket, text) {
  if (text.length > MAX_FRAME) { drop(socket); return; }
  let msg;
  try { msg = JSON.parse(text); } catch (_) { send(socket, { ok: false, code: 'E_JSON' }); return; }
  const meta = clients.get(socket);
  if (!meta) return;
  meta.msgs += 1;
  if (meta.msgs > 80) { drop(socket); return; }
  const type = String(msg.type || msg.action || '');
  if (type === 'auth') {
    const token = String(msg.token || '').slice(0, 96);
    const row = authToken(token);
    if (!row) {
      send(socket, { ok: false, code: 'E_AUTH' });
      return;
    }
    meta.token = token;
    meta.uid = row.uid;
    meta.nick = row.nick;
    meta.authed = true;
    if (meta.uid) {
      if (!byUser.has(meta.uid)) byUser.set(meta.uid, new Set());
      const set = byUser.get(meta.uid);
      if (set.size >= 4) {
        const first = set.values().next().value;
        if (first) drop(first);
      }
      byUser.get(meta.uid).add(socket);
    }
    send(socket, { ok: true, type: 'auth', ping: 25000, uid: meta.uid });
    return;
  }
  if (!meta.authed || !meta.token) {
    send(socket, { ok: false, code: 'E_AUTH' });
    return;
  }
  if (type === 'ping') {
    meta.last = Date.now();
    send(socket, { type: 'pong', t: Date.now() });
    return;
  }
  if (type === 'sub') {
    const th = String(msg.thread || 'global').slice(0, 80);
    if (!threadAllowed(meta.uid, th)) {
      send(socket, { ok: false, code: 'E_FORBIDDEN', thread: th });
      return;
    }
    if (meta.threads.size > 40) return;
    meta.threads.add(th);
    send(socket, { ok: true, type: 'sub', thread: th });
    return;
  }
  if (type === 'unsub') {
    meta.threads.delete(String(msg.thread || ''));
    send(socket, { ok: true, type: 'unsub' });
    return;
  }
  if (type === 'typing') {
    const th = String(msg.thread || 'global').slice(0, 80);
    if (!threadAllowed(meta.uid, th) || !meta.threads.has(th)) {
      send(socket, { ok: false, code: 'E_FORBIDDEN' });
      return;
    }
    fan(th, { type: 'typing', thread: th, nick: meta.nick, uid: meta.uid }, socket);
    return;
  }
  if (type === 'read') {
    const th = String(msg.thread || 'global').slice(0, 80);
    if (!threadAllowed(meta.uid, th) || !meta.threads.has(th)) {
      send(socket, { ok: false, code: 'E_FORBIDDEN' });
      return;
    }
    fan(th, { type: 'read', thread: th, uid: meta.uid, at: Date.now() }, socket);
    return;
  }
}

function fan(thread, payload, except) {
  for (const [sock, meta] of clients) {
    if (sock === except) continue;
    if (!meta.authed || !meta.alive) continue;
    if (thread === 'presence') {
      send(sock, payload);
      continue;
    }
    if (!thread || !meta.threads.has(thread)) continue;
    send(sock, payload);
  }
}

function broadcast(payload, except) {
  for (const [sock, meta] of clients) {
    if (sock === except || !meta.authed) continue;
    send(sock, payload);
  }
}

function pushEvent(body) {
  const type = String(body.type || 'event');
  const data = body.data || body;
  const thread = String((data && data.thread) || '');
  const payload = { type, data, t: Date.now() };
  if (type === 'presence' || !thread) broadcast(payload);
  else fan(thread, payload);
}

function originOk(req) {
  const origin = String(req.headers.origin || '');
  if (!origin) return true;
  return ORIGINS.has(origin);
}

function ipOf(req) {
  return String(req.socket && req.socket.remoteAddress || '0').slice(0, 64);
}

function hitIp(ip) {
  const now = Date.now();
  const row = ipHits.get(ip) || { n: 0, t: now };
  if (now - row.t > 60000) { row.n = 0; row.t = now; }
  row.n += 1;
  ipHits.set(ip, row);
  return row.n <= MAX_PER_IP;
}

const server = http.createServer((req, res) => {
  if (req.socket.remoteAddress && !String(req.socket.remoteAddress).includes('127.0.0.1') && req.socket.remoteAddress !== '::1' && req.socket.remoteAddress !== '::ffff:127.0.0.1') {
    res.writeHead(403);
    res.end();
    return;
  }
  if (req.method === 'POST' && req.url === '/push') {
    const tok = String(req.headers['x-cryn-push'] || '');
    PUSH_TOKEN = loadPushToken();
    if (!tok || tok.length < 16 || tok !== PUSH_TOKEN) {
      res.writeHead(403);
      res.end();
      return;
    }
    const chunks = [];
    let n = 0;
    req.on('data', (c) => {
      n += c.length;
      if (n > 65536) { req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => {
      try {
        const body = JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}');
        pushEvent(body);
        res.writeHead(204);
        res.end();
      } catch (_) {
        res.writeHead(400);
        res.end();
      }
    });
    return;
  }
  if (req.url === '/health') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end('{"ok":true}');
    return;
  }
  res.writeHead(404);
  res.end();
});

server.on('upgrade', (req, socket) => {
  const ip = ipOf(req);
  if (clients.size >= MAX_CLIENTS || !hitIp(ip)) {
    socket.write('HTTP/1.1 429 Too Many Requests\r\nConnection: close\r\n\r\n');
    socket.destroy();
    return;
  }
  if (!originOk(req)) {
    socket.write('HTTP/1.1 403 Forbidden\r\nConnection: close\r\n\r\n');
    socket.destroy();
    return;
  }
  const key = req.headers['sec-websocket-key'];
  if (!key || String(req.headers.upgrade || '').toLowerCase() !== 'websocket') {
    socket.destroy();
    return;
  }
  const url = String(req.url || '/');
  if (url !== '/' && url !== '/crynws' && !url.startsWith('/crynws?')) {
    socket.write('HTTP/1.1 404 Not Found\r\nConnection: close\r\n\r\n');
    socket.destroy();
    return;
  }
  const accept = sha1(Buffer.concat([Buffer.from(String(key) + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11')])).toString('base64');
  socket.write(
    'HTTP/1.1 101 Switching Protocols\r\n' +
    'Upgrade: websocket\r\n' +
    'Connection: Upgrade\r\n' +
    'Sec-WebSocket-Accept: ' + accept + '\r\n' +
    'X-Cryn-WS: 1\r\n\r\n'
  );
  attach(socket, ip);
});

server.listen(PORT, HOST, () => {
  const stamp = path.join(__dirname, 'data', 'crynsys');
  try { fs.mkdirSync(stamp, { recursive: true, mode: 0o700 }); } catch (_) { /* */ }
  try { fs.writeFileSync(path.join(stamp, 'wsport'), String(PORT)); } catch (_) { /* */ }
  PUSH_TOKEN = loadPushToken();
});

setInterval(() => {
  const now = Date.now();
  for (const [sock, meta] of clients) {
    if (now - (meta.last || 0) > 120000) drop(sock);
    else if (meta.authed) frame(sock, Buffer.from('ping'), 0x9);
    meta.msgs = 0;
  }
  for (const [ip, row] of ipHits) {
    if (now - row.t > 120000) ipHits.delete(ip);
  }
}, 25000);

process.on('uncaughtException', () => {});
process.on('unhandledRejection', () => {});
