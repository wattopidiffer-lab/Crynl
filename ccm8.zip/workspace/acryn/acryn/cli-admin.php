<?php
declare(strict_types=1);
if (PHP_SAPI !== 'cli') {
  fwrite(STDERR, "cli only\n");
  exit(1);
}

const DATA_DIR = __DIR__ . '/data';
require_once __DIR__ . '/lib/vault.php';
vaultBoot();

function usage(): void {
  fwrite(STDERR, "php cli-admin.php create <nick> <email> <password>\nphp cli-admin.php promote <nick>\n");
  exit(1);
}

$cmd = $argv[1] ?? '';
if ($cmd === 'create') {
  $nick = $argv[2] ?? '';
  $email = strtolower($argv[3] ?? '');
  $pass = $argv[4] ?? '';
  if (!preg_match('/^[A-Za-z0-9_]{3,20}$/', $nick)) usage();
  if (!filter_var($email, FILTER_VALIDATE_EMAIL)) usage();
  if (strlen($pass) < 8 || strlen($pass) > 72) usage();
  foreach (allUsers() as $u) {
    if (strcasecmp((string)$u['nick'], $nick) === 0 || strcasecmp((string)($u['email'] ?? ''), $email) === 0) {
      fwrite(STDERR, "exists\n");
      exit(2);
    }
  }
  $u = [
    'id' => 'u' . bin2hex(random_bytes(4)),
    'nick' => $nick,
    'email' => $email,
    'hash' => password_hash($pass, PASSWORD_DEFAULT),
    'token' => bin2hex(random_bytes(24)),
    'tokenHash' => '',
    'tokenExp' => 0,
    'created' => gmdate('c'),
    'verified' => true,
    'role' => 'admin',
    'blocked' => [],
    'sessions' => [],
    'gifs' => [],
    'avatar' => '',
    'bio' => '',
    'tfa' => false
  ];
  $u['tokenHash'] = hash('sha256', $u['token']);
  saveUserDoc($u);
  echo "ok admin " . $u['nick'] . " " . $u['id'] . "\n";
  exit(0);
}
if ($cmd === 'promote') {
  $nick = $argv[2] ?? '';
  $found = null;
  foreach (allUsers() as $u) {
    if (strcasecmp((string)$u['nick'], $nick) === 0) { $found = $u; break; }
  }
  if (!$found) {
    fwrite(STDERR, "not found\n");
    exit(2);
  }
  $found['role'] = 'admin';
  saveUserDoc($found);
  echo "ok promoted " . $found['nick'] . "\n";
  exit(0);
}
usage();
