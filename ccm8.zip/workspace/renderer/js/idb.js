const DB_NAME = 'crynchat';
const DB_VER = 2;
const STORES = ['kv', 'messages', 'users', 'media', 'prefs', 'drafts', 'reacts', 'push'];

function openDb() {
  return new Promise((resolve, reject) => {
    if (!window.indexedDB) {
      reject(new Error('no-idb'));
      return;
    }
    const req = indexedDB.open(DB_NAME, DB_VER);
    req.onupgradeneeded = () => {
      const db = req.result;
      for (const name of STORES) {
        if (!db.objectStoreNames.contains(name)) {
          const st = db.createObjectStore(name, { keyPath: 'k' });
          if (name === 'messages') st.createIndex('thread', 'thread', { unique: false });
        }
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

let dbp = null;
function db() {
  if (!dbp) dbp = openDb().catch((err) => { dbp = null; throw err; });
  return dbp;
}

function tx(store, mode, fn) {
  return db().then((d) => new Promise((resolve, reject) => {
    const t = d.transaction(store, mode);
    const s = t.objectStore(store);
    const req = fn(s);
    t.oncomplete = () => resolve(req && 'result' in req ? req.result : undefined);
    t.onerror = () => reject(t.error);
    if (req && req.onsuccess && !('result' in req)) {
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    }
  }));
}

const mem = new Map();

export const idb = {
  async get(store, key) {
    const mk = store + ':' + key;
    try {
      const row = await tx(store, 'readonly', (s) => s.get(key));
      if (row && row.v !== undefined) {
        mem.set(mk, row.v);
        return row.v;
      }
    } catch (_) {
      if (mem.has(mk)) return mem.get(mk);
    }
    return undefined;
  },
  async set(store, key, value, extra) {
    const mk = store + ':' + key;
    mem.set(mk, value);
    const row = { k: key, v: value, at: Date.now(), ...(extra || {}) };
    try {
      await tx(store, 'readwrite', (s) => s.put(row));
    } catch (_) { /* */ }
    return value;
  },
  async del(store, key) {
    mem.delete(store + ':' + key);
    try { await tx(store, 'readwrite', (s) => s.delete(key)); } catch (_) { /* */ }
  },
  async kvGet(key) { return this.get('kv', key); },
  async kvSet(key, value) { return this.set('kv', key, value); },
  async msgsGet(thread) {
    const v = await this.get('messages', String(thread || 'global'));
    return Array.isArray(v) ? v : [];
  },
  async msgsSet(thread, items) {
    const list = Array.isArray(items) ? items.slice(0, 4000) : [];
    return this.set('messages', String(thread || 'global'), list, { thread: String(thread || 'global') });
  },
  async prefsGet() { return (await this.get('prefs', 'ui')) || {}; },
  async prefsSet(p) { return this.set('prefs', 'ui', p || {}); },
  async draftsGet() { return (await this.get('drafts', 'all')) || {}; },
  async draftsSet(m) { return this.set('drafts', 'all', m || {}); },
  async reactsGet() { return (await this.get('reacts', 'mine')) || {}; },
  async reactsSet(m) { return this.set('reacts', 'mine', m || {}); },
  async pushGet() { return (await this.get('push', 'state')) || {}; },
  async pushSet(m) { return this.set('push', 'state', m || {}); },
  async mediaPut(url, blob) {
    if (!url || !blob) return;
    return this.set('media', url, { blob, type: blob.type || '', size: blob.size || 0 });
  },
  async mediaGet(url) {
    const v = await this.get('media', url);
    return v && v.blob ? v : null;
  },
  async stats() {
    const out = { stores: {}, bytes: 0 };
    try {
      const d = await db();
      for (const name of STORES) {
        if (!d.objectStoreNames.contains(name)) continue;
        const n = await new Promise((resolve) => {
          const t = d.transaction(name, 'readonly');
          const r = t.objectStore(name).count();
          r.onsuccess = () => resolve(r.result || 0);
          r.onerror = () => resolve(0);
        });
        out.stores[name] = n;
      }
    } catch (_) { /* */ }
    if (navigator.storage && navigator.storage.estimate) {
      try {
        const e = await navigator.storage.estimate();
        out.bytes = e.usage || 0;
        out.quota = e.quota || 0;
      } catch (_) { /* */ }
    }
    return out;
  },
  async clearStore(name) {
    try {
      await tx(name, 'readwrite', (s) => s.clear());
    } catch (_) { /* */ }
    for (const k of [...mem.keys()]) {
      if (k.startsWith(name + ':')) mem.delete(k);
    }
  },
  async clearAll() {
    for (const n of STORES) await this.clearStore(n);
    mem.clear();
  }
};

export async function migrateLocalStorage() {
  const keys = [
    ['cryndel.chatPrefs', async (raw) => { try { await idb.prefsSet(JSON.parse(raw)); } catch (_) {} }],
    ['cryndel.emojiMap', async (raw) => { try { await idb.kvSet('emojiMap', JSON.parse(raw)); } catch (_) {} }],
    ['cryndel.myReacts', async (raw) => { try { await idb.reactsSet(JSON.parse(raw)); } catch (_) {} }],
    ['cryn-push', async (raw) => { try { await idb.pushSet(JSON.parse(raw)); } catch (_) {} }],
    ['cryn:recentStick', async (raw) => { try { await idb.kvSet('recentStick', JSON.parse(raw)); } catch (_) {} }],
    ['cryndel.onboard', async (raw) => { if (raw === '1') await idb.kvSet('onboard', '1'); }]
  ];
  for (const [k, fn] of keys) {
    try {
      const raw = localStorage.getItem(k);
      if (raw) await fn(raw);
    } catch (_) { /* */ }
  }
}
