import { el } from './utils.js';
import { svg } from './icons.js';

export function iconBtn(name, title, onclick, extraClass = '') {
  const b = el('button', { class: 'icon-btn ' + extraClass, type: 'button', onclick });
  b.innerHTML = svg(name);
  b.setAttribute('aria-label', title);
  tip(b, title);
  return b;
}

export function closeBtn(onclick) {
  return iconBtn('x', 'Закрыть', onclick, 'icon-close');
}

export function tip(node, text) {
  node.addEventListener('mouseenter', () => showTip(node, text));
  node.addEventListener('mouseleave', hideTip);
  node.addEventListener('blur', hideTip);
}

let tipEl = null;
let tipTimer = 0;
function showTip(node, text) {
  hideTip();
  tipTimer = setTimeout(() => {
    if (!tipEl) {
      tipEl = el('div', { class: 'ui-tip', id: 'uiTip' });
      document.body.appendChild(tipEl);
    }
    tipEl.textContent = text;
    tipEl.classList.add('on');
    const r = node.getBoundingClientRect();
    const tw = tipEl.offsetWidth;
    let left = r.left + r.width / 2 - tw / 2;
    left = Math.max(8, Math.min(left, window.innerWidth - tw - 8));
    let top = r.bottom + 8;
    if (top + 36 > window.innerHeight) top = r.top - 36;
    tipEl.style.left = left + 'px';
    tipEl.style.top = top + 'px';
  }, 80);
}
function hideTip() {
  clearTimeout(tipTimer);
  if (tipEl) tipEl.classList.remove('on');
}

export function chk(label, checked, onChange, hint) {
  const box = el('label', { class: 'chk' + (checked ? ' on' : '') });
  const mark = el('i');
  mark.innerHTML = svg('check');
  const lab = el('span', { text: label });
  box.appendChild(mark);
  box.appendChild(lab);
  if (hint) {
    const h = el('em', { class: 'chk-hint', text: hint });
    box.appendChild(h);
  }
  let on = Boolean(checked);
  box.addEventListener('click', (e) => {
    e.preventDefault();
    on = !on;
    box.classList.toggle('on', on);
    if (onChange) onChange(on);
  });
  box.isOn = () => on;
  box.setOn = (v) => { on = Boolean(v); box.classList.toggle('on', on); };
  return box;
}

export function menu(anchor, items, opts = {}) {
  closeMenus();
  const pop = el('div', { class: 'ui-menu ' + (opts.class || '') });
  for (const it of items) {
    if (it === 'sep') {
      pop.appendChild(el('div', { class: 'ui-menu-sep' }));
      continue;
    }
    if (it && it.head) {
      pop.appendChild(el('div', { class: 'ui-menu-head', text: it.head }));
      continue;
    }
    const b = el('button', {
      class: 'ui-menu-item' + (it.active ? ' on' : '') + (it.danger ? ' danger' : ''),
      type: 'button',
      onclick: () => {
        closeMenus();
        if (it.onclick) it.onclick();
      }
    });
    if (it.icon) b.innerHTML = svg(it.icon) + '<span>' + escapeHtml(it.label) + '</span>';
    else b.textContent = it.label;
    pop.appendChild(b);
  }
  document.body.appendChild(pop);
  place(pop, anchor, opts.place || 'up');
  const off = (e) => {
    if (!pop.contains(e.target) && e.target !== anchor) {
      closeMenus();
      document.removeEventListener('mousedown', off);
    }
  };
  setTimeout(() => document.addEventListener('mousedown', off), 0);
  return pop;
}

export function closeMenus() {
  document.querySelectorAll('.ui-menu').forEach((n) => n.remove());
}

function place(pop, anchor, where) {
  const r = anchor.getBoundingClientRect();
  const w = pop.offsetWidth;
  const h = pop.offsetHeight;
  let left = r.left;
  let top = where === 'down' ? r.bottom + 6 : r.top - h - 6;
  if (top < 8) top = r.bottom + 6;
  if (top + h > window.innerHeight - 8) top = Math.max(8, window.innerHeight - h - 8);
  if (left + w > window.innerWidth - 8) left = window.innerWidth - w - 8;
  pop.style.left = left + 'px';
  pop.style.top = top + 'px';
}

export function modal(opts = {}) {
  const veil = el('div', { class: 'modal-veil' + (opts.full ? ' full' : '') });
  const box = el('div', { class: 'modal ' + (opts.class || '') });
  const head = el('div', { class: 'modal-head' });
  if (opts.kicker) head.appendChild(el('p', { class: 'kicker', text: opts.kicker }));
  const grow = el('div', { class: 'grow' });
  head.appendChild(grow);
  if (opts.extraHead) head.appendChild(opts.extraHead);
  head.appendChild(closeBtn(() => { if (opts.onClose) opts.onClose(); veil.remove(); }));
  if (opts.title) box.appendChild(el('h2', { class: 'h2', text: opts.title }));
  box.insertBefore(head, box.firstChild);
  const body = el('div', { class: 'modal-body' });
  box.appendChild(body);
  veil.appendChild(box);
  veil.addEventListener('click', (e) => {
    if (e.target === veil) {
      if (opts.onClose) opts.onClose();
      veil.remove();
    }
  });
  document.body.appendChild(veil);
  return { veil, box, body, close: () => veil.remove() };
}

export function field(label, input, format) {
  const w = el('label', { class: 'field-wrap' });
  w.appendChild(el('span', { class: 'field-lab', text: label }));
  if (input && input.type === 'range') {
    const fmt = typeof format === 'function' ? format : (v) => String(v);
    const row = el('div', { class: 'range-field' });
    const val = el('span', { class: 'range-val', text: fmt(input.value) });
    const paint = () => { val.textContent = fmt(input.value); };
    input.addEventListener('input', paint);
    input._paintRange = paint;
    row.appendChild(input);
    row.appendChild(val);
    w.appendChild(row);
  } else {
    w.appendChild(input);
  }
  return w;
}

export function customSelect(options, value, onChange) {
  const wrap = el('div', { class: 'cselect' });
  const btn = el('button', { class: 'cselect-btn', type: 'button' });
  const lab = el('span');
  btn.appendChild(lab);
  const ch = el('i');
  ch.innerHTML = svg('chev');
  btn.appendChild(ch);
  wrap.appendChild(btn);
  function current() {
    return options.find((o) => o.value === wrap.value) || options[0] || { label: '', value: '' };
  }
  wrap.value = value;
  lab.textContent = current().label;
  btn.addEventListener('click', () => {
    menu(btn, options.map((o) => ({
      label: o.label,
      active: o.value === wrap.value,
      onclick: () => {
        wrap.value = o.value;
        lab.textContent = o.label;
        if (onChange) onChange(o.value);
      }
    })), { place: 'down', class: 'cselect-menu' });
  });
  wrap.setValue = (v) => {
    wrap.value = v;
    lab.textContent = current().label;
  };
  return wrap;
}

export function escapeHtml(s) {
  return String(s || '').replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
}

export function truncate(s, n = 28) {
  const t = String(s || '');
  return t.length > n ? t.slice(0, n - 1) + '…' : t;
}

export function paintSkinFace(img, dataUrl) {
  if (!dataUrl) return;
  const src = new Image();
  src.onload = () => {
    const c = document.createElement('canvas');
    c.width = 64;
    c.height = 64;
    const g = c.getContext('2d');
    g.imageSmoothingEnabled = false;
    const sw = src.width;
    const unit = sw / 8;
    g.drawImage(src, unit, unit, unit, unit, 0, 0, 64, 64);
    g.drawImage(src, unit * 5, unit, unit, unit, 0, 0, 64, 64);
    img.src = c.toDataURL();
  };
  src.src = dataUrl;
}

export function drawSkinFront(canvas, dataUrl) {
  if (!dataUrl || !canvas) return;
  const src = new Image();
  src.onload = () => {
    const w = canvas.width;
    const h = canvas.height;
    const g = canvas.getContext('2d');
    g.imageSmoothingEnabled = false;
    g.clearRect(0, 0, w, h);
    const u = src.width / 8;
    const scale = Math.floor(Math.min(w / 16, h / 32));
    const ox = Math.floor((w - 16 * scale) / 2);
    const oy = Math.floor((h - 32 * scale) / 2);
    function blit(sx, sy, sw, sh, dx, dy, dw, dh) {
      g.drawImage(src, sx * u, sy * u, sw * u, sh * u, ox + dx * scale, oy + dy * scale, (dw || sw) * scale, (dh || sh) * scale);
    }
    blit(1, 1, 2, 2, 4, 0);
    blit(5, 1, 2, 2, 4, 0);
    blit(2.5, 2.5, 2, 3, 4, 8);
    blit(5.5, 2.5, 2, 3, 4, 8);
    blit(5.5, 2.5, 1, 3, 2, 8);
    blit(6.5, 2.5, 1, 3, 12, 8);
    blit(0.25, 2.5, 1, 3, 6, 20);
    blit(0.25, 2.5, 1, 3, 9, 20);
  };
  src.src = dataUrl;
}

// ---------------------------------------------------------------------------
// 3D skin preview.
//
// A tiny software renderer: the six body boxes of a Minecraft skin are built in
// model space, rotated around the vertical axis (plus a small camera pitch),
// projected orthographically and painted back-to-front. Each visible face is
// texture-mapped with an affine transform, which is exact for a quad under an
// orthographic projection. No WebGL, so it also works in the preview harness.
// ---------------------------------------------------------------------------

// Standard 1.8 skin layout: [u, v, w, h] for each face of each box.
const SKIN_FACES = {
  head: {
    front: [8, 8, 8, 8], back: [24, 8, 8, 8], right: [0, 8, 8, 8],
    left: [16, 8, 8, 8], top: [8, 0, 8, 8], bottom: [16, 0, 8, 8]
  },
  body: {
    front: [20, 20, 8, 12], back: [32, 20, 8, 12], right: [16, 20, 4, 12],
    left: [28, 20, 4, 12], top: [20, 16, 8, 4], bottom: [28, 16, 8, 4]
  },
  rightArm: {
    front: [44, 20, 4, 12], back: [52, 20, 4, 12], right: [40, 20, 4, 12],
    left: [48, 20, 4, 12], top: [44, 16, 4, 4], bottom: [48, 16, 4, 4]
  },
  leftArm: {
    front: [36, 52, 4, 12], back: [44, 52, 4, 12], right: [32, 52, 4, 12],
    left: [40, 52, 4, 12], top: [36, 48, 4, 4], bottom: [40, 48, 4, 4]
  },
  rightLeg: {
    front: [4, 20, 4, 12], back: [12, 20, 4, 12], right: [0, 20, 4, 12],
    left: [8, 20, 4, 12], top: [4, 16, 4, 4], bottom: [8, 16, 4, 4]
  },
  leftLeg: {
    front: [20, 52, 4, 12], back: [28, 52, 4, 12], right: [16, 52, 4, 12],
    left: [24, 52, 4, 12], top: [20, 48, 4, 4], bottom: [24, 48, 4, 4]
  }
};

// Legacy 64x32 skins only ship the right arm/leg; the left pair mirrors it.
const LEGACY_MIRROR = { leftArm: 'rightArm', leftLeg: 'rightLeg' };

function skinBoxes() {
  // Model space is in skin pixels (16 px = 1 block), origin at the feet centre.
  return [
    { key: 'head', size: [8, 8, 8], at: [0, 28, 0] },
    { key: 'body', size: [8, 12, 4], at: [0, 16, 0] },
    { key: 'rightArm', size: [4, 12, 4], at: [6, 16, 0] },
    { key: 'leftArm', size: [4, 12, 4], at: [-6, 16, 0] },
    { key: 'rightLeg', size: [4, 12, 4], at: [2, 0, 0] },
    { key: 'leftLeg', size: [4, 12, 4], at: [-2, 0, 0] }
  ];
}

function faceQuads(box) {
  const [sx, sy, sz] = box.size;
  const [cx, cy, cz] = box.at;
  const hx = sx / 2; const hz = sz / 2;
  const x0 = cx - hx; const x1 = cx + hx;
  const y0 = cy; const y1 = cy + sy;
  const z0 = cz - hz; const z1 = cz + hz;
  const q = (a, b, c, d, n) => ({ pts: [a, b, c, d], normal: n });
  return {
    front: q([x0, y0, z1], [x1, y0, z1], [x1, y1, z1], [x0, y1, z1], [0, 0, 1]),
    back: q([x1, y0, z0], [x0, y0, z0], [x0, y1, z0], [x1, y1, z0], [0, 0, -1]),
    right: q([x1, y0, z1], [x1, y0, z0], [x1, y1, z0], [x1, y1, z1], [1, 0, 0]),
    left: q([x0, y0, z0], [x0, y0, z1], [x0, y1, z1], [x0, y1, z0], [-1, 0, 0]),
    top: q([x0, y1, z1], [x1, y1, z1], [x1, y1, z0], [x0, y1, z0], [0, 1, 0]),
    bottom: q([x0, y0, z0], [x1, y0, z0], [x1, y0, z1], [x0, y0, z1], [0, -1, 0])
  };
}

function affineTri(ctx, img, s, uv) {
  const [sx0, sy0, sx1, sy1, sx2, sy2] = s;
  const [u0, v0, u1, v1, u2, v2] = uv;
  const denom = (u1 - u0) * (v2 - v0) - (u2 - u0) * (v1 - v0);
  if (Math.abs(denom) < 1e-9) return;
  const a = ((sx1 - sx0) * (v2 - v0) - (sx2 - sx0) * (v1 - v0)) / denom;
  const b = ((sy1 - sy0) * (v2 - v0) - (sy2 - sy0) * (v1 - v0)) / denom;
  const c = ((sx2 - sx0) * (u1 - u0) - (sx1 - sx0) * (u2 - u0)) / denom;
  const d = ((sy2 - sy0) * (u1 - u0) - (sy1 - sy0) * (u2 - u0)) / denom;
  const e = sx0 - a * u0 - c * v0;
  const f = sy0 - b * u0 - d * v0;
  ctx.save();
  ctx.beginPath();
  ctx.moveTo(sx0, sy0);
  ctx.lineTo(sx1, sy1);
  ctx.lineTo(sx2, sy2);
  ctx.closePath();
  ctx.clip();
  ctx.transform(a, b, c, d, e, f);
  ctx.drawImage(img, 0, 0);
  ctx.restore();
}

// Draws one texture-mapped quad as two triangles.
function affineQuad(ctx, img, s, uv) {
  affineTri(ctx, img, [s[0], s[1], s[2], s[3], s[4], s[5]],
    [uv[0], uv[1], uv[2], uv[3], uv[4], uv[5]]);
  affineTri(ctx, img, [s[0], s[1], s[4], s[5], s[6], s[7]],
    [uv[0], uv[1], uv[4], uv[5], uv[6], uv[7]]);
}

export function drawSkin3d(canvas, dataUrl, opts = {}) {
  if (!dataUrl || !canvas) return;
  const src = new Image();
  src.onload = () => {
    const ctx = canvas.getContext('2d');
    const W = canvas.width;
    const H = canvas.height;
    const unit = src.width / 64;            // texture pixels per skin pixel
    const legacy = src.height < 64;
    const boxes = skinBoxes();
    const faces = boxes.map((b) => ({ key: b.key, quads: faceQuads(b) }));
    let raf = 0;
    let yaw = -0.35;
    let disposed = false;

    function paint() {
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.clearRect(0, 0, W, H);
      ctx.imageSmoothingEnabled = false;
      const pitch = -0.16;
      const cosY = Math.cos(yaw); const sinY = Math.sin(yaw);
      const cosP = Math.cos(pitch); const sinP = Math.sin(pitch);
      const scale = Math.min(W / 26, H / 40);
      const ox = W / 2;
      const oy = H / 2 + scale * 4;
      const project = (p) => {
        // yaw around Y, then pitch around X, then orthographic projection.
        const x = p[0] * cosY + p[2] * sinY;
        const z = -p[0] * sinY + p[2] * cosY;
        const y = p[1] * cosP - z * sinP;
        const zz = p[1] * sinP + z * cosP;
        return { x: ox + x * scale, y: oy - y * scale, z: zz };
      };
      const items = [];
      for (const part of faces) {
        let faceSet = SKIN_FACES[part.key];
        if (legacy && LEGACY_MIRROR[part.key]) faceSet = SKIN_FACES[LEGACY_MIRROR[part.key]];
        for (const name of Object.keys(part.quads)) {
          const quad = part.quads[name];
          const rect = faceSet[name];
          if (!rect) continue;
          const proj = quad.pts.map(project);
          const depth = proj.reduce((acc, p) => acc + p.z, 0) / 4;
          const n = quad.normal;
          // z of the rotated normal: the face is visible only when it points at
          // the camera. Keeps hidden faces from bleeding through.
          const viewZ = n[1] * sinP + (-n[0] * sinY + n[2] * cosY) * cosP;
          if (viewZ <= 0.02) continue;
          items.push({ proj, depth, rect });
        }
      }
      items.sort((a, b) => a.depth - b.depth);
      for (const it of items) {
        const [u, v, w, h] = it.rect;
        const u0 = u * unit; const v0 = v * unit;
        const u1 = (u + w) * unit; const v1 = (v + h) * unit;
        const s = [
          it.proj[0].x, it.proj[0].y, it.proj[1].x, it.proj[1].y,
          it.proj[2].x, it.proj[2].y, it.proj[3].x, it.proj[3].y
        ];
        const uv = [u0, v0, u1, v0, u1, v1, u0, v1];
        affineQuad(ctx, src, s, uv);
      }
      if (opts.spin && !disposed) {
        yaw += 0.006;
        raf = requestAnimationFrame(paint);
      }
    }
    paint();
    canvas._stopSkin = () => { disposed = true; if (raf) cancelAnimationFrame(raf); };
  };
  src.src = dataUrl;
}
