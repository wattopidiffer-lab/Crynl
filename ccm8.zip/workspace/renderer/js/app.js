import { store, bus } from './state.js';
import { el } from './utils.js';
import { tip } from './ui.js';
import { svg } from './icons.js';
import { mountChat } from './chat.js';
import { api } from './api.js';

function paintToasts() {
  const host = document.getElementById('toasts');
  if (!host) return;
  host.replaceChildren();
  for (const titem of store.toasts) {
    const node = el('div', { class: 'toast ' + titem.kind });
    node.appendChild(el('span', { class: 'toast-text', text: titem.text }));
    if (titem.action && titem.action.label) {
      node.appendChild(el('button', {
        class: 'toast-action',
        type: 'button',
        text: titem.action.label,
        onclick: () => {
          store.toasts = store.toasts.filter((t) => t.id !== titem.id);
          bus.emit('toast');
          titem.action.onClick();
        }
      }));
    }
    host.appendChild(node);
  }
}

function paintWinMax(st) {
  const winMax = document.getElementById('winMax');
  if (!winMax || !st) return;
  const maximized = Boolean(st.maximized || st.fullScreen);
  winMax.innerHTML = maximized
    ? '<svg viewBox="0 0 12 12"><path d="M3 5h4v4H3zM5 3h4v4" fill="none" stroke="currentColor" stroke-width="1.4"/></svg>'
    : '<svg viewBox="0 0 12 12"><rect x="2.5" y="2.5" width="7" height="7" fill="none" stroke="currentColor" stroke-width="1.4"/></svg>';
  winMax.setAttribute('aria-label', maximized ? 'Восстановить' : 'Развернуть');
}

function bindWindowChrome() {
  const W = api && api.window;
  const winMin = document.getElementById('winMin');
  const winMax = document.getElementById('winMax');
  const winFull = document.getElementById('winFull');
  const winClose = document.getElementById('winClose');
  if (winMin) {
    winMin.innerHTML = '<svg viewBox="0 0 12 12"><path d="M2 6h8" fill="none" stroke="currentColor" stroke-width="1.4"/></svg>';
    tip(winMin, 'Свернуть');
    winMin.addEventListener('click', async () => {
      if (W && W.minimize) paintWinMax(await W.minimize());
    });
  }
  if (winFull) {
    winFull.innerHTML = '<svg viewBox="0 0 12 12"><path d="M4 2H2v2M8 2h2v2M2 8v2h2M10 8v2H8" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/></svg>';
    tip(winFull, 'Во весь экран (F11)');
    winFull.addEventListener('click', async () => {
      if (W && W.fullscreen) paintWinMax(await W.fullscreen());
    });
  }
  if (winMax) {
    winMax.innerHTML = '<svg viewBox="0 0 12 12"><rect x="2.5" y="2.5" width="7" height="7" fill="none" stroke="currentColor" stroke-width="1.4"/></svg>';
    tip(winMax, 'Развернуть');
    winMax.addEventListener('click', async () => {
      if (W && W.maximize) paintWinMax(await W.maximize());
    });
  }
  if (winClose) {
    winClose.innerHTML = '<svg viewBox="0 0 12 12"><path d="M3 3l6 6M9 3L3 9" fill="none" stroke="currentColor" stroke-width="1.4"/></svg>';
    tip(winClose, 'Закрыть');
    winClose.addEventListener('click', async () => {
      if (W && W.close) await W.close();
    });
  }
  // Quick access: global search and settings, opened by other modules via events.
  const tbSearch = document.getElementById('tbSearch');
  if (tbSearch) {
    tbSearch.innerHTML = svg('search', 'titlebar-tool');
    tip(tbSearch, 'Глобальный поиск');
    tbSearch.addEventListener('click', () => {
      document.dispatchEvent(new CustomEvent('cryn:global-search'));
    });
  }
  const tbSettings = document.getElementById('tbSettings');
  if (tbSettings) {
    tbSettings.innerHTML = svg('gear', 'titlebar-tool');
    tip(tbSettings, 'Настройки');
    tbSettings.addEventListener('click', () => {
      document.dispatchEvent(new CustomEvent('cryn:open-settings'));
    });
  }
  // Double-click an empty area of the title bar maximizes / restores.
  const titlebar = document.getElementById('titlebar');
  if (titlebar) {
    titlebar.addEventListener('dblclick', (e) => {
      if (e.target.closest('button')) return;
      if (W && W.maximize) W.maximize().then(paintWinMax).catch(() => {});
    });
  }
  if (W && W.onState) W.onState((st) => paintWinMax(st));
  if (W && W.state) W.state().then(paintWinMax).catch(() => {});
  window.addEventListener('keydown', (e) => {
    if (e.code === 'F11') {
      e.preventDefault();
      if (W && W.fullscreen) W.fullscreen().then(paintWinMax).catch(() => {});
    }
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
      e.preventDefault();
      document.dispatchEvent(new CustomEvent('cryn:global-search'));
    }
    if ((e.ctrlKey || e.metaKey) && e.key === ',') {
      e.preventDefault();
      document.dispatchEvent(new CustomEvent('cryn:open-settings'));
    }
  });
}

bus.on('toast', paintToasts);

async function boot() {
  bindWindowChrome();
  const root = document.getElementById('stage');
  if (!root) return;
  await mountChat(root, {});
}

boot().catch((err) => {
  const root = document.getElementById('stage');
  if (root) root.textContent = String((err && err.message) || err || 'Ошибка');
});
