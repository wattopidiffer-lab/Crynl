const pushSeen = new Map();
export const pushCounts = new Map();
function loadReactMine() {
  const m = new Map();
  return m;
}
const reactMine = loadReactMine();
let reactSave = null;
export function hydrateReacts(raw) {
  reactMine.clear();
  const o = raw || {};
  for (const [id, emo] of Object.entries(o)) {
    if (id && emo) reactMine.set(String(id), String(emo));
  }
}
export function setReactSaver(fn) { reactSave = fn; }
function saveReactMine() {
  const o = {};
  reactMine.forEach((emo, id) => { o[id] = emo; });
  if (typeof reactSave === 'function') reactSave(o);
}
const previewCache = new Map();
const nodePool = [];
let batchBuf = [];
let batchTimer = 0;
let mediaObs = null;
let vidObs = null;

export const LIMITS = {
  status: 24,
  bio: 360,
  text: 4096,
  caption: 4096,
  mentions: 10,
  oneReact: true,
  maxFile: 3 * 1024 * 1024,
  fileAudio: 8 * 1024 * 1024,
  adminUnlimited: false
};

export function applyServerLimits(src) {
  const lim = (src && src.limits) || src || {};
  if (!lim || typeof lim !== 'object') return LIMITS;
  if (lim.text) LIMITS.text = Number(lim.text) || LIMITS.text;
  if (lim.caption) LIMITS.caption = Number(lim.caption) || LIMITS.caption;
  if (lim.bio) LIMITS.bio = Number(lim.bio) || LIMITS.bio;
  if (lim.status) LIMITS.status = Number(lim.status) || LIMITS.status;
  if (lim.mentions) LIMITS.mentions = Number(lim.mentions) || LIMITS.mentions;
  if (lim.fileImage) LIMITS.maxFile = Number(lim.fileImage) || LIMITS.maxFile;
  if (lim.fileAudio) LIMITS.fileAudio = Number(lim.fileAudio) || LIMITS.fileAudio;
  LIMITS.adminUnlimited = Boolean(lim.adminUnlimited);
  return LIMITS;
}

export function clientBlock(me, thread, kind, text, extra) {
  extra = extra || {};
  const admin = me && (me.role === 'admin' || (me.limits && me.limits.adminUnlimited));
  if (!me || !me.ok) return { code: 'E_AUTH', message: 'Войдите' };
  if (me.needVerify || me.verified === false) return { code: 'E_VERIFY', message: 'Подтверди почту' };
  if (me.banned) return { code: 'E_FORBIDDEN', message: 'Ты в бане' };
  const until = Number(me.muteUntil || 0);
  if (until && until * 1000 > Date.now() && !admin) return { code: 'E_FORBIDDEN', message: 'Ты в муте' };
  const cfg = me.settings || {};
  if (cfg.readonly && !admin) return { code: 'E_FORBIDDEN', message: 'Чат только для чтения' };
  if (kind === 'gif' && cfg.allowGifs === false && !admin) return { code: 'E_FORBIDDEN', message: 'GIF выключены' };
  if (kind === 'sticker' && cfg.allowStickers === false && !admin) return { code: 'E_FORBIDDEN', message: 'Стикеры выключены' };
  if ((kind === 'image' || kind === 'audio' || kind === 'voice') && cfg.allowUploads === false && !admin) {
    return { code: 'E_FORBIDDEN', message: 'Загрузки выключены' };
  }
  if (kind === 'poll' && cfg.allowPolls === false && !admin) return { code: 'E_FORBIDDEN', message: 'Опросы выключены' };
  if (String(thread).startsWith('dm:') && cfg.allowDms === false && !admin) return { code: 'E_FORBIDDEN', message: 'Лички выключены' };
  if (thread === 'channel' && !admin) return { code: 'E_FORBIDDEN', message: 'В канале пишет только админ' };
  if (thread === 'system' && !admin) return { code: 'E_FORBIDDEN', message: 'В системный пишет только админ' };
  if (kind === 'text') {
    const t = String(text || '').trim();
    if (!t) return { code: 'E_VALIDATION', message: 'Пусто' };
    if (t.length > LIMITS.text) return { code: 'E_VALIDATION', message: 'Сообщение слишком длинное. Максимум ' + LIMITS.text + ' символов.' };
    const mentions = t.match(/@([A-Za-z0-9_]{3,20})/g) || [];
    if (mentions.length > LIMITS.mentions) return { code: 'E_RATE', message: 'Слишком много упоминаний. Максимум ' + LIMITS.mentions + '.' };
  }
  const size = Number(extra.size || 0);
  if (size > 0 && !admin) {
    const cap = (kind === 'audio' || kind === 'voice') ? LIMITS.fileAudio : LIMITS.maxFile;
    if (size > cap) return { code: 'E_VALIDATION', message: 'Файл слишком большой' };
  }
  return null;
}

export function cut(s, n) {
  return String(s || '').slice(0, n);
}

export function canSend(me, thread, kind, text) {
  const block = clientBlock(me, thread, kind, text);
  if (block) return block.message;
  const cfg = (me && me.settings) || {};
  const slow = Number(cfg.slowMode || 0);
  const admin = me && me.role === 'admin';
  if (slow && me._lastSend && Date.now() - me._lastSend < slow * 1000 && !admin) {
    return 'Медленный режим: подожди ' + slow + 'с';
  }
  return '';
}

export function canReact(id, emo) {
  const prev = reactMine.get(id);
  if (prev && prev !== emo) return { ok: true, replace: prev };
  if (prev === emo) return { ok: true, toggle: true };
  return { ok: true };
}

export function markReact(id, emo, on) {
  if (!on) reactMine.delete(id);
  else reactMine.set(id, emo);
  saveReactMine();
}

export function shouldNotify(item, me, prefs, archived) {
  if (!item || !item.id) return false;
  if (me && item.nick === me.nick) return false;
  if (me && me.muted) return false;
  if (item.silent) return false;
  if (archived && archived.includes(item.thread)) return false;
  if (pushSeen.get(item.thread) === item.id) return false;
  const mutedChats = (me && me.mutedChats) || {};
  const until = mutedChats[item.thread];
  if (until && until * 1000 > Date.now()) return false;
  return true;
}

export function notePush(item, unread) {
  pushSeen.set(item.thread || 'global', item.id);
  const n = Math.max(1, Number(unread) || 1);
  pushCounts.set(item.thread || 'global', n);
  return n;
}

export function pushBody(item, unread) {
  const n = Math.max(1, Number(unread) || 1);
  const text = String(item.text || item.caption || item.kind || '').replace(/\s+/g, ' ').slice(0, 90);
  if (n > 1) return n + ' непрочитанных · ' + text;
  return text;
}

let pushSave = null;
export function setPushSaver(fn) { pushSave = fn; }
export function loadPushState(doc) {
  const src = doc || {};
  for (const [k, v] of Object.entries(src.seen || {})) pushSeen.set(k, v);
  for (const [k, v] of Object.entries(src.counts || {})) pushCounts.set(k, v);
}

export function savePushState() {
  const seen = {};
  const counts = {};
  pushSeen.forEach((v, k) => { seen[k] = v; });
  pushCounts.forEach((v, k) => { counts[k] = v; });
  const doc = { seen, counts, at: Date.now() };
  if (typeof pushSave === 'function') pushSave(doc);
}

export function batchIncoming(item, flush, ms) {
  batchBuf.push(item);
  if (batchTimer) return;
  const wait = Math.max(80, Math.min(180, Number(ms) || 120));
  batchTimer = setTimeout(() => {
    const pack = batchBuf.splice(0, batchBuf.length);
    batchTimer = 0;
    flush(pack);
  }, wait);
}

export function takeBatch() {
  const pack = batchBuf.splice(0, batchBuf.length);
  if (batchTimer) { clearTimeout(batchTimer); batchTimer = 0; }
  return pack;
}

export function poolGet() {
  return nodePool.pop() || null;
}

export function poolPut(node) {
  if (!node || nodePool.length > 80) return;
  node.replaceChildren();
  node.className = 'chat-msg';
  node.removeAttribute('data-mid');
  nodePool.push(node);
}

export function releaseMedia(root) {
  if (!root) return;
  root.querySelectorAll('video, audio').forEach((n) => {
    try { n.pause(); } catch (_) { /* */ }
    n.removeAttribute('src');
    n.querySelectorAll('source').forEach((s) => s.remove());
    try { n.load(); } catch (_) { /* */ }
  });
}

export function ensureMediaObserver(playMode) {
  if (mediaObs) mediaObs.disconnect();
  mediaObs = new IntersectionObserver((entries) => {
    for (const e of entries) {
      const n = e.target;
      const anim = n.getAttribute('data-anim') || '';
      const still = n.getAttribute('data-still') || '';
      if (n.tagName === 'VIDEO') {
        if (e.isIntersecting && playMode !== 'never') {
          if (anim && n.src !== anim) n.src = anim;
          n.play().catch(() => {});
          if (playMode === 'once') {
            n.onended = () => { n.pause(); };
          }
        } else {
          n.pause();
        }
        continue;
      }
      if (e.isIntersecting && playMode !== 'never') {
        if (anim && n.src !== anim) n.src = anim;
      } else if (still) {
        n.src = still;
      }
    }
  }, { rootMargin: '80px', threshold: 0.01 });
  return mediaObs;
}

export function watchMedia(el) {
  if (mediaObs && el) mediaObs.observe(el);
}

export function firstFrame(url) {
  if (!url) return '';
  if (previewCache.has(url)) return previewCache.get(url);
  return url;
}

export function setPreview(url, still) {
  if (url && still) previewCache.set(url, still);
}

export function isAnimUrl(u) {
  return /\.(gif|webp|webm|avif)(\?|$)/i.test(String(u || ''));
}

export function isVideoUrl(u) {
  return /\.(webm|mp4|mov)(\?|$)/i.test(String(u || ''));
}

export function shareUrl(kind, payload) {
  const base = 'https://my.cryndel.ru/acryn/';
  const q = new URLSearchParams();
  q.set('t', kind);
  for (const [k, v] of Object.entries(payload || {})) {
    if (v != null && v !== '') q.set(k, String(v));
  }
  const https = base + '?' + q.toString();
  return { https, cryn: 'Cryn://' + https };
}

export function parseShare(href) {
  const s = String(href || '');
  const raw = s.replace(/^Cryn:\/\//i, '');
  try {
    const u = new URL(raw);
    if (!/cryndel\.ru$/i.test(u.hostname) && u.hostname !== 'my.cryndel.ru') return null;
    const t = u.searchParams.get('t') || '';
    if (!t) return null;
    const out = { kind: t };
    u.searchParams.forEach((v, k) => { if (k !== 't') out[k] = v; });
    return out;
  } catch (_) {
    return null;
  }
}

export function streakColor(days) {
  const n = Number(days) || 0;
  if (n >= 1000) return '#6ee7ff';
  if (n >= 500) return '#60a5fa';
  if (n >= 250) return '#3b82f6';
  if (n >= 100) return '#7c3aed';
  if (n >= 50) return '#a78bfa';
  if (n >= 3) return 'linear-gradient(135deg,#ffb020,#ff6a00)';
  return '#ff8a2a';
}

export function makeStill(file) {
  return new Promise((resolve) => {
    if (!file) { resolve(''); return; }
    if (String(file.type || '').startsWith('video/')) {
      const v = document.createElement('video');
      v.muted = true;
      v.preload = 'metadata';
      const url = URL.createObjectURL(file);
      v.onloadeddata = () => {
        v.currentTime = 0;
      };
      v.onseeked = () => {
        const c = document.createElement('canvas');
        c.width = v.videoWidth || 128;
        c.height = v.videoHeight || 128;
        c.getContext('2d').drawImage(v, 0, 0, c.width, c.height);
        URL.revokeObjectURL(url);
        resolve(c.toDataURL('image/webp', 0.82));
      };
      v.onerror = () => { URL.revokeObjectURL(url); resolve(''); };
      v.src = url;
      return;
    }
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      const c = document.createElement('canvas');
      c.width = img.naturalWidth || 128;
      c.height = img.naturalHeight || 128;
      const ctx = c.getContext('2d');
      ctx.drawImage(img, 0, 0);
      URL.revokeObjectURL(url);
      try { resolve(c.toDataURL('image/webp', 0.86)); }
      catch (_) { resolve(c.toDataURL('image/png')); }
    };
    img.onerror = () => { URL.revokeObjectURL(url); resolve(''); };
    img.src = url;
  });
}

export function toStickerBlob(file) {
  return new Promise((resolve) => {
    const type = String(file.type || '');
    if (type === 'image/webp' || type === 'video/webm' || type === 'image/avif') {
      resolve(file);
      return;
    }
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      const side = 512;
      let w = img.width;
      let h = img.height;
      const s = Math.min(side / w, side / h, 1);
      w = Math.max(1, Math.round(w * s));
      h = Math.max(1, Math.round(h * s));
      const c = document.createElement('canvas');
      c.width = w;
      c.height = h;
      const ctx = c.getContext('2d');
      ctx.clearRect(0, 0, w, h);
      ctx.drawImage(img, 0, 0, w, h);
      URL.revokeObjectURL(url);
      const dump = (mime, q) => new Promise((res) => c.toBlob((b) => res(b), mime, q));
      dump('image/webp', 0.92).then((blob) => {
        if (blob) resolve(new File([blob], (file.name || 'sticker').replace(/\.\w+$/, '.webp'), { type: 'image/webp' }));
        else dump('image/png').then((b2) => resolve(b2 ? new File([b2], 'sticker.png', { type: 'image/png' }) : file));
      });
    };
    img.onerror = () => { URL.revokeObjectURL(url); resolve(file); };
    img.src = url;
  });
}

export function applyCustomEmoji(text, map, on) {
  if (!on || !map) return String(text || '');
  let s = String(text || '');
  for (const [k, url] of Object.entries(map)) {
    if (!k || !url) continue;
    const re = new RegExp(k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g');
    s = s.replace(re, '<img class="chat-cemoji" data-emo="' + k + '" src="' + url + '" alt="' + k + '">');
  }
  return s;
}

export function prefetchUrls(urls, cacheFn, n) {
  const list = [...new Set((urls || []).filter(Boolean))].slice(0, n || 28);
  if (!list.length || !cacheFn) return;
  cacheFn(list).catch(() => {});
}

loadPushState();
