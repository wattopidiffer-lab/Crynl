const WS_FALLBACK = 'wss://my.cryndel.ru/crynws';

export function openLive({ token, uid, nick, url, onEvent, onStatus }) {
  let ws = null;
  let closed = false;
  let tries = 0;
  let pingTimer = 0;
  let reconnectTimer = 0;
  const threads = new Set(['global']);

  function status(state) {
    if (typeof onStatus === 'function') {
      try { onStatus(state); } catch (_) { /* */ }
    }
  }

  function connect() {
    if (closed) return;
    if (navigator.onLine === false) {
      status('offline');
      schedule(); // подождём возврата интернета
      return;
    }
    const href = url || WS_FALLBACK;
    try { ws = new WebSocket(href); } catch (_) { schedule(); return; }
    ws.addEventListener('open', () => {
      tries = 0;
      status('connected');
      safeSend({ type: 'auth', token, uid, nick });
      for (const th of threads) safeSend({ type: 'sub', thread: th });
      pingTimer = window.setInterval(() => safeSend({ type: 'ping' }), 25000);
    });
    ws.addEventListener('message', (ev) => {
      let msg;
      try { msg = JSON.parse(String(ev.data || '')); } catch (_) { return; }
      if (onEvent) onEvent(msg);
    });
    ws.addEventListener('close', () => { cleanupSocket(); status('reconnecting'); schedule(); });
    ws.addEventListener('error', () => { try { ws.close(); } catch (_) { /* */ } });
  }

  // Вернулся интернет — пробуем подключиться сразу, не ждём таймер.
  window.addEventListener('online', () => {
    if (closed || !ws) {
      if (reconnectTimer) { clearTimeout(reconnectTimer); reconnectTimer = 0; }
      tries = 0;
      connect();
    }
  });

  function cleanupSocket() {
    if (pingTimer) { clearInterval(pingTimer); pingTimer = 0; }
    ws = null;
  }

  function schedule() {
    if (closed) return;
    tries += 1;
    const wait = Math.min(15000, 600 * tries * tries);
    reconnectTimer = window.setTimeout(connect, wait);
  }

  function safeSend(obj) {
    if (!ws || ws.readyState !== 1) return;
    try { ws.send(JSON.stringify(obj)); } catch (_) { /* */ }
  }

  connect();

  return {
    sub(thread) {
      threads.add(String(thread || 'global'));
      safeSend({ type: 'sub', thread });
    },
    unsub(thread) {
      threads.delete(String(thread || ''));
      safeSend({ type: 'unsub', thread });
    },
    typing(thread) { safeSend({ type: 'typing', thread }); },
    read(thread) { safeSend({ type: 'read', thread }); },
    ping() { safeSend({ type: 'ping' }); },
    reconnectNow() {
      if (closed) return;
      if (reconnectTimer) { clearTimeout(reconnectTimer); reconnectTimer = 0; }
      tries = 0;
      cleanupSocket();
      connect();
    },
    close() {
      closed = true;
      if (reconnectTimer) clearTimeout(reconnectTimer);
      cleanupSocket();
      try { if (ws) ws.close(); } catch (_) { /* */ }
    }
  };
}
