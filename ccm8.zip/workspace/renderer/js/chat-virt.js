const heightMap = new Map();
const keyOf = (it, i) => (it && it.id) || ('i' + i);

export function estimatedSize(item, compact) {
  if (!item) return compact ? 44 : 64;
  const k = item.id;
  if (k && heightMap.has(k)) return heightMap.get(k);
  if (item.kind === 'sticker') return 168;
  if (item.kind === 'image' || item.kind === 'gif') return 280;
  if (item.kind === 'audio' || item.kind === 'voice') return 96;
  if (item.kind === 'poll') return 168;
  if (item.kind === 'system') return 44;
  const n = String(item.text || item.caption || '').length;
  const media = item.url && (item.kind === 'image' || item.kind === 'gif') ? 180 : 0;
  return Math.min(640, (compact ? 40 : 58) + Math.ceil(n / 36) * 20 + media);
}

export function rememberHeight(id, h) {
  if (!id || !h || h < 8) return;
  heightMap.set(id, Math.round(h));
}

export function heightOf(id, fallback) {
  return heightMap.get(id) || fallback || 52;
}

export function createVirtualizer(opts) {
  const state = {
    scroll: 0,
    view: opts.viewport || 640,
    overscan: opts.overscan == null ? 14 : opts.overscan,
    compact: Boolean(opts.compact)
  };

  function sizes(items) {
    const out = [];
    let acc = 0;
    for (let i = 0; i < items.length; i++) {
      const it = items[i];
      const size = estimatedSize(it, state.compact);
      out.push({ index: i, key: keyOf(it, i), start: acc, size, item: it, end: acc + size });
      acc += size;
    }
    return { rows: out, total: acc };
  }

  function measureElement(el, id) {
    if (!el) return;
    const h = el.getBoundingClientRect().height;
    rememberHeight(id || el.getAttribute('data-mid'), h);
    return h;
  }

  function getVirtualItems(items, scrollTop, viewport) {
    state.scroll = scrollTop || 0;
    state.view = viewport || state.view;
    const { rows, total } = sizes(items);
    if (!rows.length) return { items: [], total, start: 0, end: 0, padTop: 0, padBot: 0 };
    const top = state.scroll;
    const bot = top + state.view;
    let start = 0;
    let end = rows.length;
    for (let i = 0; i < rows.length; i++) {
      if (rows[i].end >= top) { start = i; break; }
    }
    for (let i = start; i < rows.length; i++) {
      if (rows[i].start > bot) { end = i; break; }
    }
    start = Math.max(0, start - state.overscan);
    end = Math.min(rows.length, end + state.overscan);
    const vis = rows.slice(start, end);
    const padTop = vis.length ? vis[0].start : 0;
    const last = vis.length ? vis[vis.length - 1].end : 0;
    return { items: vis, total, start, end, padTop, padBot: Math.max(0, total - last) };
  }

  return { getVirtualItems, measureElement, rememberHeight, heightMap, sizes };
}

export function idle(fn) {
  if (typeof requestIdleCallback === 'function') {
    return requestIdleCallback(fn, { timeout: 180 });
  }
  return setTimeout(fn, 32);
}

export function cancelIdle(id) {
  if (typeof cancelIdleCallback === 'function') cancelIdleCallback(id);
  else clearTimeout(id);
}
