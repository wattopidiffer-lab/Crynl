import { api } from './api.js';
import { openLive } from './live.js';
import { toast } from './state.js';
import { el } from './utils.js';
import { iconBtn, menu } from './ui.js';
import { svg } from './icons.js';
import { createVirtualizer, idle, rememberHeight } from './chat-virt.js';
import {
  LIMITS, applyServerLimits, clientBlock, canSend, canReact, markReact, shouldNotify, notePush, pushBody, savePushState, loadPushState, pushCounts,
  batchIncoming, takeBatch, releaseMedia, ensureMediaObserver, watchMedia, isAnimUrl, isVideoUrl,
  shareUrl, parseShare, streakColor, toStickerBlob, makeStill, applyCustomEmoji, prefetchUrls,
  hydrateReacts, setReactSaver, setPushSaver
} from './chat-engine.js';
import { idb, migrateLocalStorage } from './idb.js';

const EMOJI = ['👍', '❤', '😂', '🥰', '😮', '😢', '👏', '🔥'];
const EMOJI_ALL = [
  ...EMOJI, '😁', '🤔', '🎉', '💯', '🙏', '👌', '👀', '⚡', '😭', '🤝', '😎', '🤩', '😅', '😡',
  '😀', '😃', '😄', '😆', '😉', '😊', '😋', '😍', '😘', '😜', '🤗', '🙄', '😴', '😷', '🤒',
  '😇', '😈', '👻', '💩', '🤖', '👾', '🎃', '😺', '💪', '✌️', '🤞', '👊', '🖐️', '👋', '🫶',
  '❤️', '🧡', '💛', '💚', '💙', '💜', '🖤', '🤍', '💔', '💖', '💕', '💞', '⭐', '🌟', '✨',
  '⚡', '💥', '💫', '🔥', '🌈', '☀️', '🌙', '🌸', '🍀', '🎮', '🎯', '🏆', '🥇', '🎵', '💎',
  '✅', '❌', '⚠️', '❓', '💤', '📌', '📎', '📝', '🧠', '👑', '💀', '🗿', '🚀', '🎁', '🎂'
];
const ERR_CODE = {
  E_AUTH: 'Войдите в аккаунт, чтобы продолжить.',
  E_CREDS: 'Неверная почта или пароль. Проверьте данные и попробуйте снова.',
  E_VERIFY: 'Сначала подтвердите почту. Код уже должен быть у вас в письме.',
  E_RATE: 'Слишком много попыток. Подождите немного и попробуйте снова.',
  E_NET: 'Нет связи с сервером. Проверьте интернет и попробуйте снова.',
  E_LAUNCHER: 'Откройте чат из приложения CrynChat.',
  E_METHOD: 'Сервер принимает только запросы из приложения.',
  E_JSON: 'Сервер не понял запрос. Попробуйте ещё раз.',
  E_STORAGE: 'Сервер не смог сохранить данные. Попробуйте позже.',
  E_TOO_BIG: 'Слишком большой запрос. Уменьшите файл или текст.',
  E_ACTION: 'Сервер не знает эту команду.',
  E_NICK: 'Ник: от 3 до 20 символов, латиница, цифры и подчёркивание.',
  E_EMAIL: 'Проверьте адрес электронной почты.',
  E_PASS: 'Пароль должен быть от 8 до 72 символов.',
  E_NICK_TAKEN: 'Этот ник уже занят. Выберите другой.',
  E_EMAIL_TAKEN: 'Эта почта уже занята. Войдите или укажите другую.',
  E_PASS_RESET: 'Пароль сброшен администратором. Задайте новый пароль.',
  E_CODE: 'Введите код из шести цифр, который пришёл на почту.',
  E_CODE_EXPIRED: 'Код истёк. Запросите новый код.',
  E_CODE_BAD: 'Неверный код. Проверьте цифры и попробуйте снова.',
  E_STAFF: 'Это действие доступно только модераторам.',
  E_ADMIN: 'Это действие доступно только администраторам.',
  E_FORBIDDEN: 'У вас нет доступа к этому действию.',
  E_BANNED: 'Аккаунт заблокирован.',
  E_MUTED: 'Вы в муте и пока не можете писать.',
  E_READONLY: 'Чат сейчас только для чтения.',
  E_THREAD: 'Нет доступа к этому чату.',
  E_TEXT: 'Сообщение слишком длинное. Максимум 4096 символов.',
  E_VALIDATION: 'Проверьте данные и попробуйте снова.',
  E_EMPTY: 'Напишите текст сообщения.',
  E_NOT_YOURS: 'Это чужое сообщение — так нельзя.',
  E_NO_EDIT: 'Это сообщение нельзя изменить.',
  E_EDIT_LATE: 'Редактировать можно только первые 15 минут.',
  E_NO_MSG: 'Сообщение уже удалено или его нет.',
  E_EMOJI: 'Этот смайл нельзя поставить.',
  E_PIN_RANK: 'Закреплять в общем чате могут модераторы с 3 ранга.',
  E_URL: 'Нужна обычная безопасная https-ссылка.',
  E_GIF_OFF: 'GIF в этом чате выключены.',
  E_STICK_OFF: 'Стикеры в этом чате выключены.',
  E_UPLOAD_OFF: 'Загрузка файлов сейчас выключена.',
  E_POLL_OFF: 'Опросы выключены.',
  E_DM_OFF: 'Личные сообщения выключены.',
  E_DM_ONLY: 'Это можно только в личных сообщениях.',
  E_DM_DENY: 'Этому пользователю писать нельзя.',
  E_DM_CLOSED: 'Пользователь закрыл входящие сообщения.',
  E_DM_CONTACTS: 'Писать могут только разрешённые контакты.',
  E_CHANNEL: 'В канале пишет только администратор.',
  E_CHANNEL_OWNER: 'В канале пишет только владелец.',
  E_SYSTEM: 'В системный чат пишет только администратор.',
  E_NO_CHANNEL: 'Канал не найден.',
  E_FILE_SIZE: 'Файл слишком большой. Для фото — до 3 МБ, для музыки — до 8 МБ.',
  E_FILE_BAD: 'Файл повреждён или в неподходящем формате.',
  E_FORMAT: 'Подходят png, jpg, webp, gif, webm или avif.',
  E_AUDIO: 'Подходят аудио mp3, ogg, wav, m4a или webm.',
  E_KIND: 'Этот тип файла не подходит.',
  E_NAME: 'Укажите название.',
  E_PACK_LIMIT: 'Можно создать не больше 12 коллекций.',
  E_PACK_FULL: 'В коллекции уже максимум стикеров.',
  E_NO_PACK: 'Коллекция не найдена.',
  E_POLL: 'Нужен вопрос и от 2 до 6 вариантов ответа.',
  E_NO_POLL: 'Это не опрос.',
  E_VOTED: 'Вы уже голосовали в этом опросе.',
  E_NOT_FOUND: 'Пользователь не найден.',
  E_NO_PROFILE: 'Профиль не найден.',
  E_SLOW: 'Слишком быстро. Подождите немного.',
  E_STREAK_LIMIT: 'Лимит возвратов огонька на этот месяц исчерпан.',
  E_BOT_TOKEN: 'Неверный токен бота.',
  E_CARD: 'Карточка не найдена.',
  E_KANAL_EXISTS: 'У вас уже есть канал.',
  E_KANAL_HANDLE: 'Юз канала: 3–20 символов, латиница, цифры и _.',
  E_KANAL_TAKEN: 'Этот юз канала уже занят.',
  E_FAIL: 'Не получилось. Попробуйте ещё раз.'
};
const ERR_MAP = {
  'Нет API': 'Чат не подключён. Попробуйте позже.',
  'Смайл': ERR_CODE.E_EMOJI,
  'Закреп с 3 ранга': ERR_CODE.E_PIN_RANK,
  'Не твоё': ERR_CODE.E_NOT_YOURS,
  'Поздно править': ERR_CODE.E_EDIT_LATE,
  'Пусто': ERR_CODE.E_EMPTY,
  'Текст 1–2000': ERR_CODE.E_TEXT,
  'Текст 1–4096': ERR_CODE.E_TEXT,
  'Чат': ERR_CODE.E_THREAD,
  'Нет сообщения': ERR_CODE.E_NO_MSG,
  'https': ERR_CODE.E_URL,
  'Только https': ERR_CODE.E_URL,
  'Файл до 3 МБ': ERR_CODE.E_FILE_SIZE,
  'Битый файл': ERR_CODE.E_FILE_BAD,
  'Формат png/jpg/webp/gif/webm/avif': ERR_CODE.E_FORMAT,
  'GIF выключены': ERR_CODE.E_GIF_OFF,
  'Стикеры выключены': ERR_CODE.E_STICK_OFF,
  'Загрузки выключены': ERR_CODE.E_UPLOAD_OFF,
  'Опросы выключены': ERR_CODE.E_POLL_OFF,
  'Лички выключены': ERR_CODE.E_DM_OFF,
  'Чат только для чтения': ERR_CODE.E_READONLY,
  'Нужен вход': ERR_CODE.E_AUTH,
  'Подтверди почту': ERR_CODE.E_VERIFY,
  'Только модератор': ERR_CODE.E_STAFF,
  'Только админ': ERR_CODE.E_ADMIN,
  'Нет доступа': ERR_CODE.E_FORBIDDEN,
  'Уже голосовал': ERR_CODE.E_VOTED,
  'Вариант': ERR_CODE.E_POLL,
  'Нет опроса': ERR_CODE.E_NO_POLL,
  'Ник занят': ERR_CODE.E_NICK_TAKEN,
  'Почта занята': ERR_CODE.E_EMAIL_TAKEN,
  'Неверные данные': ERR_CODE.E_CREDS,
  'Код из 6 цифр': ERR_CODE.E_CODE,
  'Код истёк': ERR_CODE.E_CODE_EXPIRED,
  'Неверный код': ERR_CODE.E_CODE_BAD,
  'JSON': ERR_CODE.E_JSON,
  'storage': ERR_CODE.E_STORAGE,
  'Слишком часто. Подожди.': ERR_CODE.E_RATE,
  'Слишком большой запрос': ERR_CODE.E_TOO_BIG,
  'Неизвестное действие': ERR_CODE.E_ACTION,
  'Только лаунчер': ERR_CODE.E_LAUNCHER,
  'Это ты': 'Нельзя написать самому себе.',
  'Нет такого': ERR_CODE.E_NOT_FOUND,
  'Пак полный': ERR_CODE.E_PACK_FULL,
  'Максимум 12 коллекций': ERR_CODE.E_PACK_LIMIT,
  'Название': ERR_CODE.E_NAME,
  'Нет коллекции': ERR_CODE.E_NO_PACK,
  'Нельзя править': ERR_CODE.E_NO_EDIT,
  'Нельзя писать': ERR_CODE.E_DM_DENY,
  'Войдите': ERR_CODE.E_AUTH,
  'Ты в бане': ERR_CODE.E_BANNED,
  'Ты в муте': ERR_CODE.E_MUTED,
  'Этот смайл нельзя поставить': ERR_CODE.E_EMOJI,
  'Закреплять в общем чате могут модераторы с 3 ранга': ERR_CODE.E_PIN_RANK,
  'Только в личке': ERR_CODE.E_DM_ONLY,
  'Лимит возвратов на этот месяц исчерпан': ERR_CODE.E_STREAK_LIMIT,
  'Нет профиля': ERR_CODE.E_NO_PROFILE,
  'Ник: 3–20 латиница, цифры, _': ERR_CODE.E_NICK,
  'Плохая почта': ERR_CODE.E_EMAIL,
  'Пароль 8–72 символа': ERR_CODE.E_PASS,
  'Пароль сброшен администратором. Задайте новый пароль': ERR_CODE.E_PASS_RESET,
  'Код истёк. Запроси новый': ERR_CODE.E_CODE_EXPIRED,
  'Аватар только https': ERR_CODE.E_URL,
  'Баннер только https': ERR_CODE.E_URL,
  'Тебе нельзя писать этому пользователю': ERR_CODE.E_DM_DENY,
  'Пользователь закрыл входящие': ERR_CODE.E_DM_CLOSED,
  'Писать могут только разрешённые': ERR_CODE.E_DM_CONTACTS,
  'В канале пишет только админ': ERR_CODE.E_CHANNEL,
  'В системный чат пишет только админ': ERR_CODE.E_SYSTEM,
  'Плохая ссылка': ERR_CODE.E_URL,
  'Только https GIF': ERR_CODE.E_URL,
  'Варианты': ERR_CODE.E_POLL,
  'Опрос: вопрос и 2–6 вариантов': ERR_CODE.E_POLL,
  'Тип': ERR_CODE.E_KIND,
  'Аудио mp3/ogg/wav': ERR_CODE.E_AUDIO,
  'Ник': ERR_CODE.E_NICK,
  'Сообщение': ERR_CODE.E_NO_MSG,
  'POST only': ERR_CODE.E_METHOD,
  'Файл больше 3 МБ': ERR_CODE.E_FILE_SIZE,
  'Не загрузилось': 'Не удалось загрузить файл. Проверьте формат и размер, затем попробуйте снова.',
  'Не играет': 'Не удалось воспроизвести аудио. Файл недоступен или повреждён.',
  'Не создалось': 'Не удалось создать аккаунт. Проверьте данные и попробуйте снова.',
  'Не вошло': 'Не удалось войти. Проверьте почту и пароль.',
  'Не получилось': 'Не получилось. Попробуйте ещё раз.'
};
const USER_JPG = ['assets/user.jpg', 'ssert/user.jpg', 'assets/user.png', '../assets/user.jpg', './assets/user.jpg'];
const BADGE_LABEL = { official: 'Официальный', staff: 'Сотрудник', support: 'За поддержку', creator: 'Creator' };
const mediaMem = new Map();
const avaSeen = new Set();
const userCache = new Map();
let chatsMem = { items: [], at: 0 };
let dmsMem = { items: [], at: 0 };
const PUZIR = ['tg','round','square','glass','soft','outline','neon','minimal','cloud','comic','ink','ticket','pixel','ribbon','leaf','petal','chip','fold','glow','slab','whisper','capsule','frame','spark'];
const CTX_KEYS = [
  ['reply', 'Ответить'],
  ['select', 'Выбрать'],
  ['copy', 'Копировать'],
  ['pin', 'Закрепить'],
  ['dl', 'Скачать'],
  ['widget', 'Виджет'],
  ['sticker', 'В коллекцию'],
  ['gif', 'В GIF'],
  ['edit', 'Изменить'],
  ['trash', 'Удалить'],
  ['send', 'Переслать'],
  ['star', 'В избранное'],
  ['nick', 'Профиль'],
  ['readers', 'Кто прочитал'],
  ['report', 'Жалоба']
];

function fmtTime(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '';
  return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
}

function fmtDay(iso) {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '';
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const that = new Date(d.getFullYear(), d.getMonth(), d.getDate());
  const diff = (today - that) / 86400000;
  if (diff === 0) return 'Сегодня';
  if (diff === 1) return 'Вчера';
  return d.toLocaleDateString('ru-RU', { day: 'numeric', month: 'long' });
}

function fmtLastSeen(ts) {
  const n = Number(ts) || 0;
  if (!n) return 'был недавно';
  const sec = Math.max(0, Math.floor(Date.now() / 1000 - n));
  if (sec < 90) return 'в сети';
  if (sec < 3600) return 'был ' + Math.floor(sec / 60) + ' мин назад';
  if (sec < 86400) return 'был ' + Math.floor(sec / 3600) + ' ч назад';
  return 'был ' + new Date(n * 1000).toLocaleDateString('ru-RU');
}

function initials(nick) {
  const s = String(nick || '?').replace(/^[^A-Za-zА-Яа-яЁё0-9]+/, '');
  const parts = s.split(/[\s._-]+/).filter(Boolean);
  if (parts.length >= 2) return (parts[0][0] + parts[1][0]).toUpperCase();
  return s.slice(0, 2).toUpperCase() || '?';
}

function hueFor(nick) {
  let h = 216;
  const s = String(nick || '');
  for (let i = 0; i < s.length; i++) h = (h * 33 + s.charCodeAt(i)) >>> 0;
  return h % 360;
}

function friendlyErr(e, fallback) {
  const code = String((e && (e.code || (e.data && e.data.code))) || '').trim();
  if (code && ERR_CODE[code]) return ERR_CODE[code];
  const raw = String((e && e.message) || e || '').trim();
  if (!raw) return fallback || 'Что-то пошло не так. Попробуйте ещё раз.';
  if (ERR_CODE[raw]) return ERR_CODE[raw];
  if (ERR_MAP[raw]) return ERR_MAP[raw];
  const mute = raw.match(/муте до (.+)/);
  if (mute) return 'Вы в муте до ' + mute[1] + '. Пока писать нельзя.';
  const slow = raw.match(/Медленный режим: подожди (.+)/);
  if (slow) return 'Слишком быстро. Подождите ' + slow[1] + '.';
  const ban = raw.match(/Аккаунт заблокирован(.*)/);
  if (ban) return 'Аккаунт заблокирован.';
  if (/network|fetch|Failed to fetch|ERR_INTERNET|offline|ECONN|ENOTFOUND/i.test(raw)) return ERR_CODE.E_NET;
  if (/timeout|аут/i.test(raw)) return 'Сервер не ответил вовремя. Попробуйте ещё раз.';
  if (/^E_[A-Z0-9_]+$/.test(raw)) return ERR_CODE[raw] || fallback || ERR_CODE.E_FAIL;
  if (/^\d{3}$/.test(raw) || /status code/i.test(raw)) return fallback || ERR_CODE.E_FAIL;
  return fallback || ERR_CODE.E_FAIL;
}

function failToast(e, fallback) {
  toast(friendlyErr(e, fallback), 'bad');
}

function pinPreview(p) {
  const kind = p && p.kind;
  const raw = String(p && (p.text || p.caption) || '').replace(/\s+/g, ' ').trim();
  if (raw) return raw;
  if (kind === 'image') return 'Фото';
  if (kind === 'gif') return 'GIF';
  if (kind === 'sticker') return 'Стикер';
  if (kind === 'audio' || kind === 'voice') return 'Аудио';
  if (kind === 'poll') return 'Опрос';
  if (kind === 'video') return 'Видео';
  return kind || 'Сообщение';
}

function htmlToMd(root) {
  function walk(n) {
    if (!n) return '';
    if (n.nodeType === 3) return String(n.nodeValue || '').replace(/\u00a0/g, ' ');
    if (n.nodeType !== 1) return '';
    const tag = n.tagName.toLowerCase();
    if (tag === 'img') return n.getAttribute('data-emo') || n.getAttribute('alt') || '';
    let inner = [...n.childNodes].map(walk).join('');
    const st = (n.getAttribute && n.getAttribute('style')) || '';
    const fw = (n.style && n.style.fontWeight) || '';
    const fs = (n.style && n.style.fontStyle) || '';
    const td = (n.style && n.style.textDecoration) || '';
    if (tag === 'b' || tag === 'strong' || /bold|[6-9]00/i.test(fw) || /font-weight:\s*(bold|[6-9]00)/i.test(st)) inner = '**' + inner + '**';
    else if (tag === 'i' || tag === 'em' || fs === 'italic' || /font-style:\s*italic/i.test(st)) inner = '*' + inner + '*';
    if (tag === 'u' || /underline/i.test(td) || /text-decoration:[^;]*underline/i.test(st)) inner = '__' + inner + '__';
    if (tag === 's' || tag === 'strike' || tag === 'del' || /line-through/i.test(td) || /text-decoration:[^;]*line-through/i.test(st)) inner = '~~' + inner + '~~';
    if (tag === 'code' || (n.classList && n.classList.contains('chat-code'))) inner = '`' + inner + '`';
    if (n.classList && n.classList.contains('spoiler')) inner = '||' + inner + '||';
    if (tag === 'a') {
      const href = n.getAttribute('href') || '';
      return href ? '[' + inner + '](' + href + ')' : inner;
    }
    if (tag === 'br') return '\n';
    if (tag === 'div' || tag === 'p' || tag === 'li') return inner + '\n';
    return inner;
  }
  return walk(root).replace(/\n+$/g, '').trim();
}

function mdToHtml(raw) {
  let s = String(raw || '');
  s = s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  s = s.replace(/\|\|(.+?)\|\|/g, '<span class="spoiler">$1</span>');
  s = s.replace(/\*\*(.+?)\*\*/g, '<b>$1</b>');
  s = s.replace(/__(.+?)__/g, '<u>$1</u>');
  s = s.replace(/(^|[^\w*])\*(?!\s)([^*]+?)\*(?!\*)/g, '$1<i>$2</i>');
  s = s.replace(/~~(.+?)~~/g, '<s>$1</s>');
  s = s.replace(/`([^`]+)`/g, '<code>$1</code>');
  s = s.replace(/@([A-Za-z0-9_]{3,20})/g, '<span class="mention" data-nick="$1">@$1</span>');
  s = s.replace(/#([A-Za-z0-9_]{2,24})/g, '<span class="chat-tag" data-tag="$1">#$1</span>');
  s = s.replace(/\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)/g, (_m, lab, href) => {
    const safe = String(href).replace(/"/g, '%22').replace(/'/g, '%27');
    if (!/^https:\/\//i.test(safe)) return lab;
    return '<a href="' + safe + '" rel="noreferrer noopener" target="_blank">' + lab + '</a>';
  });
  s = s.replace(/https?:\/\/[^\s<]+/g, (m, offset, full) => {
    const src = typeof full === 'string' ? full : '';
    const off = typeof offset === 'number' ? offset : 0;
    if (src.slice(Math.max(0, off - 2), off).includes('](')) return m;
    return '<a href="' + m + '" rel="noreferrer">' + m + '</a>';
  });
  return s;
}

function renderText(raw, map) {
  const node = el('div', { class: 'chat-text' });
  let html = mdToHtml(raw);
  if (map) html = applyCustomEmoji(html, map, true);
  node.innerHTML = html;
  node.querySelectorAll('.spoiler').forEach((n) => n.addEventListener('click', (e) => {
    e.stopPropagation();
    n.classList.toggle('on');
  }));
  node.querySelectorAll('.chat-cemoji').forEach((img) => {
    const src = img.getAttribute('src') || '';
    if (!/\.(webp|webm|gif)(\?|$)/i.test(src)) return;
    img.classList.add('anim');
  });
  return node;
}

function ytId(url) {
  const m = String(url || '').match(/(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|embed\/|shorts\/))([A-Za-z0-9_-]{6,})/);
  return m ? m[1] : '';
}

function firstUrl(text) {
  const m = String(text || '').match(/https?:\/\/[^\s<]+/i);
  return m ? m[0] : '';
}

function isGifUrl(u) {
  return /\.gif(\?|$)/i.test(String(u || '')) || /image\/gif/i.test(String(u || ''));
}

function badgeMark(kind) {
  if (!kind) return null;
  const n = el('span', { class: 'chat-verify-mark ' + kind, title: BADGE_LABEL[kind] || kind });
  n.innerHTML = svg('badge');
  n.appendChild(el('span', { class: 'chat-verify-tip', text: BADGE_LABEL[kind] || kind }));
  return n;
}

function nickRow(nick, badges, extraClass) {
  const row = el('div', { class: 'chat-nick-row' + (extraClass ? ' ' + extraClass : '') });
  row.appendChild(el('b', { class: 'chat-nick', text: nick || 'гость' }));
  const list = Array.isArray(badges) ? badges : (badges ? [badges] : []);
  for (const b of list) {
    const m = badgeMark(b);
    if (m) row.appendChild(m);
  }
  return row;
}

function paintFallbackAva(n, nick) {
  n.replaceChildren();
  n.classList.add('chat-ava-fallback');
  const h = hueFor(nick);
  n.style.background = 'linear-gradient(145deg, hsl(' + h + ' 58% 54%), hsl(' + ((h + 42) % 360) + ' 64% 36%))';
  n.appendChild(el('span', { class: 'chat-ava-letter', text: initials(nick) }));
}

function hatUrl(user, kind, shopMap) {
  if (!user) return '';
  const id = user[kind] || (user.cosmetics && user.cosmetics[kind]) || '';
  if (!id) return '';
  if (String(id).startsWith('http') || String(id).startsWith('data:')) return id;
  const it = shopMap && shopMap.get && shopMap.get(id);
  return (it && it.url) || '';
}

function wrapHat(node, url, extra) {
  if (!url) return node;
  const box = el('div', { class: 'chat-hat-wrap' + (extra ? ' ' + extra : '') });
  box.appendChild(node);
  const hat = el('img', { class: 'chat-hat', alt: '' });
  hat.src = url;
  if (/\.(gif|webp|webm|mp4)(\?|$)/i.test(url)) hat.classList.add('anim');
  box.appendChild(hat);
  return box;
}

function ava(src, nick, online, hats) {
  const n = el('div', { class: 'chat-ava' + (online ? ' online' : '') });
  const putImg = (url) => {
    const img = el('img', { alt: nick || '' });
    img.decoding = 'async';
    img.referrerPolicy = 'no-referrer';
    img.src = url;
    if (isGifUrl(url)) img.setAttribute('data-gif', '1');
    img.addEventListener('load', () => {
      n.classList.remove('chat-ava-load');
      avaSeen.add(src || url);
      mediaMem.set(src || url, url);
    }, { once: true });
    n.replaceChildren(img);
    return img;
  };
  const fallback = () => {
    if (n._triedJpg) { paintFallbackAva(n, nick); return; }
    n._triedJpg = true;
    let i = 0;
    const img = putImg(USER_JPG[0]);
    img.addEventListener('error', function next() {
      i += 1;
      if (i >= USER_JPG.length) { paintFallbackAva(n, nick); return; }
      img.src = USER_JPG[i];
    });
  };
  if (src) {
    const cached = mediaMem.get(src);
    const known = avaSeen.has(src) || Boolean(cached);
    if (!known) n.classList.add('chat-ava-load');
    const img = putImg(cached || src);
    img.addEventListener('error', fallback, { once: true });
    if (!cached && api.chat && api.chat.cacheMedia && !String(src).startsWith('data:')) {
      api.chat.cacheMedia(src).then((r) => {
        const s = r && (r.src || r);
        if (typeof s === 'string' && s && img.isConnected) {
          mediaMem.set(src, s);
          avaSeen.add(src);
          if (img.src !== s) img.src = s;
        }
      }).catch(() => {});
    }
  } else fallback();
  const hat = hats && (hats.avatarHat || hats.url);
  if (hat) return wrapHat(n, hat, hats.cls || '');
  return n;
}

function iconAva(name, extra) {
  const n = el('div', { class: 'chat-ava chat-ava-icon' + (extra ? ' ' + extra : '') });
  n.innerHTML = svg(name);
  return n;
}

function icon(name, title, onclick, extra) {
  const b = el('button', { class: 'chat-icon' + (extra ? ' ' + extra : ''), type: 'button', onclick });
  b.innerHTML = svg(name);
  if (title) b.setAttribute('aria-label', title);
  return b;
}

function readFile(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const s = String(reader.result || '');
      const i = s.indexOf(',');
      resolve(i >= 0 ? s.slice(i + 1) : s);
    };
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}

function pick(accept) {
  return new Promise((resolve) => {
    const inp = el('input', { type: 'file', accept: accept || '*/*' });
    inp.addEventListener('change', () => resolve(inp.files && inp.files[0] ? inp.files[0] : null));
    inp.click();
  });
}

function closeSheets(root) {
  root.querySelectorAll('.chat-sheet, .chat-ctx, .chat-lightbox, .chat-modal').forEach((n) => n.remove());
}

export async function mountChat(root, opts = {}) {
  const overlay = Boolean(opts.overlay);
  const wrap = el('div', { class: overlay ? 'crynchat crynchat-overlay has-sidebar sidebar-collapsed' : 'crynchat has-sidebar' });
  if (!overlay) {
    document.body.classList.add('chat-page');
    root.classList.add('padless');
  }
  function isNarrow() {
    return overlay || wrap.clientWidth < 860 || window.innerWidth < 860;
  }
  function syncChrome() {
    const narrow = isNarrow();
    if (listBtn) listBtn.classList.toggle('need', narrow && !wrap.classList.contains('chats-open'));
    if (!narrow) wrap.classList.remove('sidebar-collapsed');
  }
  function collapseList() {
    wrap.classList.remove('chats-open');
    if (isNarrow()) wrap.classList.add('sidebar-collapsed');
    else wrap.classList.remove('sidebar-collapsed');
    syncChrome();
  }
  function openList() {
    wrap.classList.add('chats-open');
    wrap.classList.remove('sidebar-collapsed');
    paintSidebar();
    syncChrome();
  }

  const sidebar = el('div', { class: 'chat-sidebar' });
  const sideHead = el('div', { class: 'chat-sidebar-head' });
  const meAvaBtn = el('button', { class: 'chat-icon chat-sidebar-me', type: 'button' });
  meAvaBtn.setAttribute('aria-label', 'Мой профиль');
  meAvaBtn.appendChild(ava('', 'CrynChat', false));
  meAvaBtn.addEventListener('click', (e) => { e.stopPropagation(); openProfile(me && me.nick, true); });
  meAvaBtn.addEventListener('mouseenter', () => scheduleAccFlyout());
  meAvaBtn.addEventListener('mouseleave', (e) => {
    const fly = wrap.querySelector('.chat-acc-flyout');
    if (fly && e.relatedTarget && (fly.contains(e.relatedTarget) || fly === e.relatedTarget)) return;
    cancelAccFlyout(180);
  });
  sideHead.appendChild(meAvaBtn);
  sideHead.appendChild(el('strong', { text: 'CrynChat' }));
  sideHead.appendChild(icon('block', 'Заблокированные', () => toggleListMode('blocked')));
  sideHead.appendChild(icon('archive', 'Архив', () => toggleListMode('archive')));
  sidebar.appendChild(sideHead);
  const sideSearchWrap = el('div', { class: 'chat-side-search-wrap' });
  const sideSearchIco = el('span', { class: 'chat-side-search-ico' });
  sideSearchIco.innerHTML = svg('search');
  const sideSearch = el('input', { class: 'chat-sidebar-search field', placeholder: 'Поиск чатов' });
  sideSearchWrap.appendChild(sideSearchIco);
  sideSearchWrap.appendChild(sideSearch);
  sidebar.appendChild(sideSearchWrap);
  const sideList = el('div', { class: 'chat-sidebar-list' });
  sidebar.appendChild(sideList);
  wrap.appendChild(sidebar);

  const col = el('div', { class: 'chat-col' });
  const head = el('div', { class: 'chat-head' });
  const listBtn = icon('menu', 'Чаты', () => openList());
  listBtn.classList.add('chat-list-btn');
  head.appendChild(listBtn);
  const mark = el('div', { class: 'chat-mark' });
  mark.textContent = 'C';
  head.appendChild(mark);
  const titles = el('div', { class: 'chat-titles' });
  const title = el('strong', { text: 'CrynChat' });
  const sub = el('span', { class: 'hint', text: 'общий чат' });
  titles.appendChild(title);
  titles.appendChild(sub);
  head.appendChild(titles);
  const tools = el('div', { class: 'chat-tools' });
  head.appendChild(tools);
  const headSearch = el('div', { class: 'chat-head-search hidden' });
  const headSearchIn = el('input', { class: 'chat-head-search-in', placeholder: 'Поиск по чату…' });
  headSearch.appendChild(headSearchIn);
  const headSearchX = icon('x', 'Выйти из поиска', exitHeadSearch);
  headSearchX.classList.add('chat-head-search-x');
  headSearch.appendChild(headSearchX);
  head.appendChild(headSearch);
  col.appendChild(head);

  const pins = el('div', { class: 'chat-pins hidden' });
  col.appendChild(pins);

  const list = el('div', { class: 'chat-list' });
  col.appendChild(list);

  const searchBox = el('div', { class: 'chat-search-box hidden' });
  col.appendChild(searchBox);

  const typingEl = el('div', { class: 'chat-typing' });
  col.appendChild(typingEl);

  const offlineEl = el('button', { class: 'chat-offline hidden', type: 'button' });
  offlineEl.innerHTML = svg('off') + '<span>Нет интернета — ждём соединения…</span><i>Нажмите, чтобы переподключиться</i>';
  offlineEl.addEventListener('click', () => {
    if (liveSock && liveSock.reconnectNow) liveSock.reconnectNow();
    if (typeof navigator !== 'undefined' && navigator.onLine === false) { toast('Интернет всё ещё недоступен'); return; }
    bootLive();
  });
  col.appendChild(offlineEl);

  const authBox = el('div', { class: 'chat-auth' });
  col.appendChild(authBox);

  const composer = el('div', { class: 'chat-composer hidden' });
  col.appendChild(composer);

  const jumpBtn = el('button', { class: 'chat-jump hidden', type: 'button' });
  jumpBtn.innerHTML = svg('down');
  const jumpBadge = el('span', { class: 'chat-badge hidden', text: '0' });
  jumpBtn.appendChild(jumpBadge);
  col.appendChild(jumpBtn);

  wrap.appendChild(col);
  root.appendChild(wrap);

  let me = null;
  let offset = 0;
  let loading = false;
  let done = false;
  let stickers = [];
  let packs = [];
  let gifs = [];
  let thread = 'global';
  let replyTo = null;
  let itemsCache = [];
  let lastId = '';
  let pollTimer = 0;
  let typingTimer = 0;
  let typingShowTimer = 0;
  let prefs = {
    sound: true, preview: true, compact: false, wallpaper: '', theme: 'night',
    walls: {}, ctxCompact: true, ctxHide: ['select', 'widget', 'report'],
    accent: '', textColor: '', bubbleIn: '', bubbleOut: '',
    bubbleRadius: 14, bubbleTex: '', font: '', customCss: '',
    hideChats: [], showUnread: true, showMsgCount: true, avaAnim: false,
    reduceMotion: false, uiColor: '', avaRound: 50, bubbleStyle: 'tg',
    animPlay: 'viewport', stickStyle: 'classic', stickPerf: true, hoverActions: true,
    shiftActions: true, customEmoji: true, oneLike: true, fancyAnim: false,
    accFlyout: true,
    cacheMedia: true, cacheMsgs: true, cacheUsers: true, maxCacheMb: 256
  };
  let listMode = 'chats';
  let createdCount = 0;
  const virt = createVirtualizer({ viewport: 640, overscan: 16, compact: false });
  let emojiMap = {};
  let archiveOpen = false;
  let accFlyTimer = 0;
  let accFlyHide = 0;
  let virtRange = { start: -1, end: -1 };
  let liveBuf = [];
  let uiCssEl = null;
  let streakMem = { days: 0, lit: false, gray: false, dead: false, born: false, tier: '' };
  let pendingFile = null;
  let unreadMiss = 0;
  let stickCache = { items: [], at: 0 };
  let atBottom = true;
  let editTarget = null;
  let devicePending = null;
  let selectMode = false;
  let selectedIds = new Set();
  let musicWidget = null;
  let sidebarPaintGen = 0;
  let pinCycle = 0;
  const lastMsgMap = {};
  const greetedBots = new Set();
  const shopMap = new Map();
  let liveSock = null;
  let shopItems = [];
  const linkCache = new Map();
  function maxFileOf(kind) {
    const admin = me && (me.role === 'admin' || (me.limits && me.limits.adminUnlimited));
    if (admin) return 12 * 1024 * 1024;
    if (kind === 'audio' || kind === 'voice') return LIMITS.fileAudio || 8 * 1024 * 1024;
    return LIMITS.maxFile || 3 * 1024 * 1024;
  }
  let audioCtx = null;
  function pingSound() {
    try {
      if (!audioCtx) audioCtx = new AudioContext();
      const o = audioCtx.createOscillator();
      const g = audioCtx.createGain();
      o.connect(g);
      g.connect(audioCtx.destination);
      o.frequency.value = 880;
      g.gain.value = 0.03;
      o.start();
      o.stop(audioCtx.currentTime + 0.08);
    } catch (_) { /* */ }
  }

  const C = api.chat || {};

  function unwrapApi(r) {
    if (!r || typeof r !== 'object') return r;
    if (r.ok === true && r.data && typeof r.data === 'object' && r.error === null) {
      r = { ok: true, ...r.data };
    }
    if (r.limits) applyServerLimits(r);
    return r;
  }
  function call(name, ...args) {
    if (!C[name]) return Promise.reject(Object.assign(new Error('Нет API'), { code: 'E_FAIL' }));
    return Promise.resolve(C[name](...args)).then((r) => {
      r = unwrapApi(r);
      if (r && r.ok === false) {
        const msg = (r.error && r.error.message) || r.error || r.code || 'E_FAIL';
        const err = new Error(typeof msg === 'string' ? msg : 'E_FAIL');
        err.code = (r.error && r.error.code) || r.code || 'E_FAIL';
        err.data = r;
        throw err;
      }
      return r;
    });
  }

  function setSub(text, on) {
    sub.textContent = text;
    sub.classList.toggle('on', Boolean(on));
  }

  function isAdmin() {
    return Boolean(me && (me.admin || me.role === 'admin'));
  }
  function isStaff() {
    return isAdmin() || Boolean(me && me.role === 'mod');
  }

  function hideAccFlyout() {
    clearTimeout(accFlyTimer);
    clearTimeout(accFlyHide);
    accFlyTimer = 0;
    accFlyHide = 0;
    wrap.querySelectorAll('.chat-acc-flyout').forEach((n) => n.remove());
  }

  function cancelAccFlyout(delay) {
    clearTimeout(accFlyTimer);
    accFlyTimer = 0;
    clearTimeout(accFlyHide);
    accFlyHide = setTimeout(() => {
      const n = wrap.querySelector('.chat-acc-flyout');
      if (n && n.matches(':hover')) return;
      if (meAvaBtn.matches(':hover')) return;
      hideAccFlyout();
    }, delay == null ? 180 : delay);
  }

  function scheduleAccFlyout() {
    if (prefs.accFlyout === false) return;
    clearTimeout(accFlyHide);
    accFlyHide = 0;
    if (wrap.querySelector('.chat-acc-flyout')) return;
    clearTimeout(accFlyTimer);
    accFlyTimer = setTimeout(() => showAccFlyout(), 2000);
  }

  function showAccFlyout() {
    if (prefs.accFlyout === false) return;
    wrap.querySelectorAll('.chat-acc-flyout').forEach((n) => n.remove());
    const fly = el('div', { class: 'chat-acc-flyout' });
    const fill = async () => {
      let items = [];
      try {
        const doc = C.accounts ? await C.accounts() : { items: [] };
        items = (doc && doc.items) || [];
      } catch (_) { /* */ }
      if (!fly.isConnected) return;
      fly.replaceChildren();
      fly.appendChild(el('p', { class: 'kicker', text: 'АККАУНТЫ' }));
      if (!items.length) fly.appendChild(el('p', { class: 'hint', text: 'Нет сохранённых' }));
      const seen = new Set();
      for (const a of items.slice(0, 4)) {
        const key = String(a.email || a.nick || '');
        if (key && seen.has(key)) continue;
        if (key) seen.add(key);
        const row = el('button', { class: 'chat-acc-row', type: 'button', onclick: async () => {
          hideAccFlyout();
          try {
            const r = await C.switchAccount(a.email);
            me = r;
            paintAuth();
            paintHead();
            loadFresh();
            toast('Переключено на ' + (a.nick || a.email));
          } catch (e) { failToast(e, 'Не переключилось'); }
        } });
        row.appendChild(ava(a.avatar, a.nick, a.email === (me && me.email)));
        const t = el('span', { class: 'chat-acc-meta' });
        t.appendChild(el('b', { text: a.nick || a.email || 'аккаунт' }));
        t.appendChild(el('span', { class: 'hint', text: a.email || '' }));
        row.appendChild(t);
        fly.appendChild(row);
      }
      if (items.length < 4) {
        fly.appendChild(el('button', { class: 'btn', type: 'button', text: 'Добавить аккаунт', onclick: () => { hideAccFlyout(); openAccounts(); } }));
      } else {
        fly.appendChild(el('p', { class: 'hint', text: 'Максимум 4 сохранённых' }));
      }
      fly.appendChild(el('button', { class: 'btn', type: 'button', text: 'Все аккаунты', onclick: () => { hideAccFlyout(); openAccounts(); } }));
    };
    fill();
    fly.addEventListener('mouseenter', () => { clearTimeout(accFlyHide); accFlyHide = 0; });
    fly.addEventListener('mouseleave', () => cancelAccFlyout(160));
    sideHead.appendChild(fly);
  }

  function toggleListMode(mode) {
    listMode = listMode === mode ? 'chats' : mode;
    archiveOpen = listMode === 'archive';
    sideHead.querySelectorAll('.chat-icon').forEach((n) => n.classList.remove('on'));
    const btn = sideHead.querySelector('[aria-label="' + (listMode === 'blocked' ? 'Заблокированные' : (listMode === 'archive' ? 'Архив' : '')) + '"]');
    if (btn && listMode !== 'chats') btn.classList.add('on');
    sideSearch.placeholder = listMode === 'blocked' ? 'Поиск заблокированных' : (listMode === 'archive' ? 'Поиск в архиве' : 'Поиск чатов');
    paintSidebar();
    openList();
  }

  function chatTargets() {
    const out = [];
    const seen = new Set();
    const add = (id, name, avatar) => {
      if (!id || seen.has(id)) return;
      seen.add(id);
      out.push({ id, name: name || id, avatar: avatar || '' });
    };
    add('global', 'CrynChat', '');
    add('saved', 'Избранное', '');
    add('channel', ((chatMeta('channel') || {}).title) || 'Канал', (chatMeta('channel') || {}).avatar);
    for (const c of (me && me.chats) || []) add(c.id, c.title || c.nick, c.avatar);
    for (const d of dmsMem.items || []) add(d.thread, d.nick, d.avatar);
    return out;
  }

  function openShareModal(share) {
    const kind = (share && share.kind) || 'user';
    const sh = modal(kind === 'flame' ? 'Поделиться огоньком' : 'Поделиться профилем');
    const payload = kind === 'flame'
      ? { kind: 'flame', nick: share.nick || (me && me.nick) || '', days: share.days || 0, dead: share.dead ? '1' : '' }
      : { kind: 'user', nick: share.nick || (me && me.nick) || '', avatar: share.avatar || (me && me.avatar) || '' };
    const urls = shareUrl(payload.kind, payload);
    sh.body.appendChild(shareCard(payload, urls.https));
    const https = el('input', { class: 'field', readonly: 'readonly' });
    https.value = urls.https;
    const cryn = el('input', { class: 'field', readonly: 'readonly' });
    cryn.value = urls.cryn;
    sh.body.appendChild(el('p', { class: 'kicker', text: 'ССЫЛКИ' }));
    sh.body.appendChild(https);
    sh.body.appendChild(cryn);
    const copy = async (v) => {
      try { await navigator.clipboard.writeText(v); toast('Скопировано'); }
      catch (_) { toast('Не скопировалось', 'bad'); }
    };
    const row = el('div', { class: 'row' });
    row.appendChild(el('button', { class: 'btn', text: 'Копировать https', onclick: () => copy(urls.https) }));
    row.appendChild(el('button', { class: 'btn', text: 'Копировать Cryn://', onclick: () => copy(urls.cryn) }));
    sh.body.appendChild(row);
    sh.body.appendChild(el('p', { class: 'kicker', text: 'ОТПРАВИТЬ В ЧАТ' }));
    const box = el('div', { class: 'chat-fwd-list' });
    for (const t of chatTargets()) {
      const r = el('button', { class: 'chat-acc-row', type: 'button', onclick: async () => {
        try {
          const text = urls.cryn + '\n' + urls.https;
          const res = await call('send', text, { thread: t.id, share: payload });
          if (res && res.item && t.id === thread) appendLive(res.item);
          toast('Отправлено в ' + t.name);
          sh.sh.remove();
        } catch (e) { failToast(e, 'Не получилось'); }
      } });
      r.appendChild(ava(t.avatar, t.name, false));
      r.appendChild(el('b', { text: t.name }));
      box.appendChild(r);
    }
    sh.body.appendChild(box);
  }

  function openFwdModal(item) {
    const sh = modal('Переслать');
    const q = el('input', { class: 'field', placeholder: 'Поиск чата' });
    sh.body.appendChild(q);
    const box = el('div', { class: 'chat-fwd-list' });
    sh.body.appendChild(box);
    const paint = () => {
      const s = String(q.value || '').toLowerCase();
      box.replaceChildren();
      const list = chatTargets().filter((t) => !s || t.name.toLowerCase().includes(s) || t.id.toLowerCase().includes(s));
      if (!list.length) box.appendChild(el('p', { class: 'hint', text: 'Нет чатов' }));
      for (const t of list) {
        const r = el('button', { class: 'chat-acc-row', type: 'button', onclick: async () => {
          try {
            const res = await call('forward', item.id, t.id);
            if (res && res.item && t.id === thread) appendLive(res.item);
            toast('Переслано в ' + t.name);
            sh.sh.remove();
            if (t.id !== thread) loadFresh();
          } catch (e) { failToast(e, 'Не получилось'); }
        } });
        r.appendChild(ava(t.avatar, t.name, false));
        r.appendChild(el('b', { text: t.name }));
        box.appendChild(r);
      }
    };
    q.addEventListener('input', paint);
    paint();
  }

  function chatMeta(id) {
    const a = (me && me.chats) || [];
    const b = chatsMem.items || [];
    return a.find((c) => c.id === id) || b.find((c) => c.id === id) || null;
  }

  function paintHead() {
    tools.replaceChildren();
    tools.appendChild(iconBtn('search', 'Поиск', () => enterHeadSearch()));
    if (isStaff()) tools.appendChild(iconBtn('shield', 'Админка', () => openAdmin()));
    tools.appendChild(iconBtn('more', 'Ещё', (e) => openHeadMenu(e.currentTarget)));
    syncChrome();
  }

  // Поиск прямо в шапке: прячем аватар/название, показываем поле + крестик.
  function enterHeadSearch() {
    if (!headSearch.classList.contains('hidden')) { headSearchIn.focus(); return; }
    mark.classList.add('hidden');
    titles.classList.add('hidden');
    tools.classList.add('hidden');
    headSearch.classList.remove('hidden');
    headSearchIn.focus();
  }
  function exitHeadSearch() {
    headSearch.classList.add('hidden');
    mark.classList.remove('hidden');
    titles.classList.remove('hidden');
    tools.classList.remove('hidden');
    headSearchIn.value = '';
    searchBox.classList.add('hidden');
    searchBox.replaceChildren();
  }

  let searchTimerQ = 0;
  headSearchIn.addEventListener('input', () => {
    if (searchTimerQ) { clearTimeout(searchTimerQ); searchTimerQ = 0; }
    searchTimerQ = setTimeout(() => runHeadSearch(headSearchIn.value), 260);
  });
  headSearchIn.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') runHeadSearch(headSearchIn.value);
    if (e.key === 'Escape') exitHeadSearch();
  });
  async function runHeadSearch(query) {
    query = String(query || '').trim();
    if (!query) { searchBox.classList.add('hidden'); searchBox.replaceChildren(); return; }
    searchBox.classList.remove('hidden');
    if (!searchBox.dataset.first) {
      const hint = el('p', { class: 'hint', text: 'Ищу…' });
      searchBox.replaceChildren(hint);
    }
    delete searchBox.dataset.first;
    try {
      const r = await call('search', query);
      const items = (r && r.items) || [];
      searchBox.replaceChildren();
      if (!items.length) searchBox.appendChild(el('p', { class: 'hint', text: 'Ничего не нашлось по запросу.' }));
      for (const it of items) {
        const node = bubble(it);
        if (node) searchBox.appendChild(node);
      }
      searchBox.classList.add('has-results');
    } catch (err) {
      searchBox.replaceChildren(el('p', { class: 'hint', text: friendlyErr(err, 'Не получилось найти') }));
    }
  }

  function openHeadMenu(anchor) {
    const items = [
      { head: 'АККАУНТ' },
      { icon: 'menu', label: 'Все чаты', onclick: () => openList() },
      { icon: 'nick', label: 'Мой профиль', onclick: () => openProfile(me && me.nick, true) },
      { icon: 'users', label: 'Люди', onclick: () => openPeople() },
      { icon: 'sticker', label: 'Стикеры и GIF', onclick: () => openPacks() },
      { icon: 'gear', label: 'Настройки', onclick: () => openUiSettings() },
      { icon: 'nick', label: 'Аккаунты', onclick: () => openAccounts() },
      { icon: 'bot', label: 'CrynBot', onclick: () => openThread('dm:createbot', 'CrynBot') },
      { icon: 'bell', label: (me && me.muted) ? 'Включить звук' : 'Без звука', onclick: async () => {
        try {
          const r = await call('mute', !(me && me.muted));
          if (me) me.muted = Boolean(r && r.muted);
          toast(me && me.muted ? 'Уведомления выключены' : 'Уведомления включены');
        } catch (err) { failToast(err, 'Не получилось сменить звук'); }
      } },
      { head: 'ЧАТЫ' },
      { icon: 'home', label: 'Общий чат', onclick: () => openThread('global') },
      { icon: 'bell', label: 'Уведомления', onclick: () => openThread('system', 'Уведомления') },
      { icon: 'pin', label: 'Канал', onclick: () => openThread('channel', (chatMeta('channel') || {}).title || 'Канал') },
      { icon: 'star', label: 'Избранное', onclick: () => openThread('saved', 'Избранное') },
      { icon: 'pin', label: (me && (me.pinnedChats || []).includes(thread)) ? 'Открепить чат' : 'Закрепить чат', onclick: async () => {
        try {
          const r = await call('pinChat', thread);
          if (me) me.pinnedChats = (r && r.pinnedChats) || [];
          paintSidebar();
          toast((me && (me.pinnedChats || []).includes(thread)) ? 'Чат закреплён сверху списка' : 'Чат откреплён');
        } catch (err) { failToast(err, 'Не получилось закрепить чат'); }
      } },
      { icon: 'folder', label: (me && (me.archived || []).includes(thread)) ? 'Разархивировать' : 'В архив', onclick: async () => {
        try {
          const r = await call('archiveChat', thread);
          if (me) me.archived = (r && r.archived) || [];
          paintSidebar();
          toast((me && (me.archived || []).includes(thread)) ? 'Чат в архиве' : 'Чат из архива');
        } catch (err) { failToast(err, 'Не получилось изменить архив'); }
      } },
      { icon: 'mute', label: 'Без звука 8 ч', onclick: async () => {
        try {
          await call('muteChat', thread, Math.floor(Date.now() / 1000) + 8 * 3600);
          toast('Чат без звука 8 часов');
        } catch (err) { failToast(err, 'Не получилось'); }
      } }
    ];
    if (thread && String(thread).startsWith('dm:')) {
      items.push({ icon: 'trash', label: 'Очистить чат у себя', onclick: () => clearLocalChat() });
    }
    if (isStaff() || isAdmin()) items.push({ head: 'АДМИН' });
    if (isStaff()) items.push({ icon: 'shield', label: 'Админ-панель', onclick: () => openAdmin() });
    if (isAdmin()) items.push({ icon: 'bot', label: 'Admin', onclick: () => openThread('dm:adminbot', 'Admin') });
    items.push(
      { head: 'ЕЩЁ' },
      { icon: 'open', label: 'Отдельное окно', onclick: () => C.popout && C.popout().catch(() => {}) },
      { icon: 'page', label: 'О CrynChat', onclick: () => openAbout() },
      { icon: 'sliders', label: 'Горячие клавиши', onclick: () => openShortcuts() }
    );
    if (me && me.ok) items.push('sep', { icon: 'x', label: 'Выйти', danger: true, onclick: doLogout });
    menu(anchor, items, { place: 'down', class: 'chat-head-menu' });
  }

  async function doLogout() {
    await call('logout');
    me = { ok: false, guest: true };
    paintAuth();
    toast('Вышел');
  }

  async function loadMe() {
    try { me = await call('me'); } catch (_) { me = { ok: false, guest: true }; }
    if (me && me.limits) applyServerLimits(me);
    else if (me && me.data && me.data.limits) applyServerLimits(me.data);
    if (me && Array.isArray(me.chats) && me.chats.length) {
      chatsMem = { items: me.chats, at: Date.now() };
      for (const c of me.chats) {
        if (!c || !c.id || lastMsgMap[c.id]) continue;
        if (c.lastText || c.lastKind) {
          lastMsgMap[c.id] = { text: c.lastText || '', nick: c.lastNick || '', at: c.lastAt || '', kind: c.lastKind || '', thread: c.id };
        }
      }
    }
    if (C.prefs) {
      try {
        const p = await C.prefs();
        if (p && Object.keys(p).length) {
          prefs = { ...prefs, ...p };
          idb.prefsSet(prefs).catch(() => {});
        } else {
          try {
            const back = await idb.prefsGet();
            if (back && Object.keys(back).length) prefs = { ...prefs, ...back };
          } catch (_) { /* */ }
        }
      } catch (_) { /* */ }
    }
    try {
      const pushDoc = await idb.pushGet();
      loadPushState(pushDoc);
    } catch (_) { loadPushState({}); }
    try {
      const reacts = await idb.reactsGet();
      hydrateReacts(reacts);
    } catch (_) { /* */ }
    setReactSaver((o) => { idb.reactsSet(o).catch(() => {}); });
    setPushSaver((o) => { idb.pushSet(o).catch(() => {}); });
    ensureMediaObserver(prefs.animPlay || 'viewport');
    if (me && me.needPassReset) {
      toast('Пароль сброшен. Задайте новый', 'bad');
      openSetPass();
    }
    // Эмодзи качаем один раз и держим в IndexedDB — при перезапуске сразу из кэша.
    try {
      const savedEmoji = await idb.kvGet('emojiMap');
      if (savedEmoji && typeof savedEmoji === 'object') emojiMap = savedEmoji;
    } catch (_) { /* */ }
    function applyEmojiMap(map) {
      if (map && typeof map === 'object') {
        emojiMap = map;
        idb.kvSet('emojiMap', map).catch(() => {});
      }
    }
    if (C.emojiMap) {
      C.emojiMap().then((r) => {
        const map = (r && (r.map || r.items)) || null;
        if (map) applyEmojiMap(map);
      }).catch(() => { /* интернета нет — работаем с кэшем */ });
    }
    if (C.createdAccounts) {
      C.createdAccounts().then((r) => { createdCount = Number(r && r.count) || 0; }).catch(() => {});
    }
    if (C.saveAccount) C.saveAccount().catch(() => {});
    bootLive();
    loadShop();
    paintAuth();
    paintHead();
    applyWallpaper();
    paintSidebar();
    maybeOnboard();
    if (C.cacheMediaMany) {
      const urls = [];
      if (me && me.avatar) urls.push(me.avatar);
      if (me && (me.cover || me.banner)) urls.push(me.cover || me.banner);
      for (const c of (me && me.chats) || []) {
        if (c.avatar) urls.push(c.avatar);
        if (c.banner || c.cover) urls.push(c.banner || c.cover);
      }
      C.cacheMediaMany(urls).then((r) => {
        const items = (r && r.items) || {};
        for (const [u, v] of Object.entries(items)) {
          if (v && v.src) { mediaMem.set(u, v.src); avaSeen.add(u); }
        }
      }).catch(() => {});
    }
  }

  function authField(lab, attrs) {
    const wrapF = el('label', { class: 'chat-auth-field' });
    wrapF.appendChild(el('span', { text: lab }));
    const inp = el('input', { class: 'field', ...attrs });
    wrapF.appendChild(inp);
    return { wrap: wrapF, inp };
  }

  function paintAuth() {
    authBox.replaceChildren();
    const inOk = Boolean(me && me.ok);
    const need = inOk && (me.needVerify || me.verified === false);
    composer.classList.toggle('hidden', !inOk || need);
    authBox.classList.toggle('hidden', inOk && !need);
    if (!inOk) {
      setSub('войдите, чтобы писать');
      title.textContent = 'CrynChat';
      wrap.classList.add('auth-full');
      const card = el('div', { class: 'chat-auth-card chat-auth-anim' });
      const hero = el('div', { class: 'chat-auth-hero' });
      hero.appendChild(iconAva('tg', 'brand'));
      hero.appendChild(el('h3', { text: 'CrynChat' }));
      hero.appendChild(el('p', { class: 'hint', text: 'Мессенджер Cryndel. Сессия сохранится на этом устройстве. Войдите или создайте аккаунт, чтобы продолжить.' }));
      card.appendChild(hero);
      const tabs = el('div', { class: 'chat-auth-tabs' });
      const tabIn = el('button', { class: 'on', type: 'button', text: 'Войти' });
      const tabUp = el('button', { type: 'button', text: 'Регистрация' });
      tabs.appendChild(tabIn);
      tabs.appendChild(tabUp);
      card.appendChild(tabs);
      const form = el('div', { class: 'chat-auth-form' });
      const nickF = authField('Ник', { placeholder: '3–20 символов', maxlength: '20' });
      const emailF = authField('Почта', { placeholder: 'you@mail.ru', type: 'email' });
      const passF = authField('Пароль', { placeholder: 'не меньше 8 символов, буквы и цифры', type: 'password' });
      const passRow = el('div', { class: 'chat-auth-pass' });
      passRow.appendChild(passF.wrap);
      const strength = el('div', { class: 'chat-pass-meter hidden' });
      const strBar = el('i');
      const strLab = el('span', { class: 'hint', text: '' });
      strength.appendChild(strBar);
      strength.appendChild(strLab);
      function scorePass(s) {
        const v = String(s || '');
        let n = 0;
        if (v.length >= 8) n += 1;
        if (v.length >= 12) n += 1;
        if (/[A-ZА-Я]/.test(v) && /[a-zа-я]/.test(v)) n += 1;
        if (/\d/.test(v)) n += 1;
        if (/[^A-Za-zА-Яа-я0-9]/.test(v)) n += 1;
        return n;
      }
      passF.inp.addEventListener('input', () => {
        if (mode !== 'up') { strength.classList.add('hidden'); return; }
        const n = scorePass(passF.inp.value);
        strength.classList.remove('hidden');
        strength.setAttribute('data-n', String(n));
        strBar.style.width = (n * 20) + '%';
        strLab.textContent = n < 2 ? 'Слабый пароль — добавьте цифры и длину' : (n < 4 ? 'Средний пароль — можно усилить' : 'Надёжный пароль');
      });
      const eye = el('button', { class: 'chat-icon chat-auth-eye', type: 'button', title: 'Показать пароль' });
      eye.innerHTML = svg('eye') || svg('show') || '';
      if (!eye.innerHTML) eye.textContent = '•';
      eye.addEventListener('click', () => {
        const p = passF.inp;
        p.type = p.type === 'password' ? 'text' : 'password';
      });
      passRow.appendChild(eye);
      form.appendChild(nickF.wrap);
      form.appendChild(emailF.wrap);
      form.appendChild(passRow);
      form.appendChild(strength);
      nickF.wrap.classList.add('hidden');
      let mode = 'in';
      function setMode(next) {
        mode = next;
        tabIn.classList.toggle('on', next === 'in');
        tabUp.classList.toggle('on', next === 'up');
        nickF.wrap.classList.toggle('hidden', next !== 'up');
      }
      tabIn.addEventListener('click', () => setMode('in'));
      tabUp.addEventListener('click', () => setMode('up'));
      const errEl = el('p', { class: 'chat-auth-err hidden' });
      form.appendChild(errEl);
      const goBtn = el('button', { class: 'btn btn-sky chat-auth-go', type: 'button', text: 'Войти' });
      function syncGo() { goBtn.textContent = mode === 'up' ? 'Создать аккаунт' : 'Войти'; }
      tabIn.addEventListener('click', syncGo);
      tabUp.addEventListener('click', syncGo);
      goBtn.addEventListener('click', async () => {
        errEl.classList.add('hidden');
        try {
          if (mode === 'in') {
            const r = await call('login', emailF.inp.value, passF.inp.value);
            if (r && r.needDevice) {
              devicePending = { email: emailF.inp.value, password: passF.inp.value };
              paintDevice(authBox, emailF.inp.value);
              toast('Код входа ушёл на почту');
              return;
            }
            if (!r || !r.ok) throw new Error((r && r.error) || 'Не вошло');
            me = r;
            if (C.saveAccount) C.saveAccount().catch(() => {});
            createdCount = Math.max(createdCount, 0);
            paintAuth();
            paintHead();
            if (me.needPassReset) { toast('Пароль сброшен. Задайте новый', 'bad'); openSetPass(); }
            else toast('В чате');
            loadFresh();
          } else {
            if (createdCount >= 5) { toast('На этом устройстве уже создано 5 аккаунтов', 'bad'); return; }
            const n = scorePass(passF.inp.value);
            if (passF.inp.value.length < 8 || n < 2) {
              errEl.textContent = 'Пароль слишком простой. Используйте не меньше 8 символов, буквы и цифры.';
              errEl.classList.remove('hidden');
              return;
            }
            const r = await call('register', nickF.inp.value, emailF.inp.value, passF.inp.value);
            if (!r || !r.ok) throw new Error((r && r.error) || 'Не создалось');
            me = { ...r, needVerify: true, verified: false };
            createdCount += 1;
            if (C.saveAccount) C.saveAccount().catch(() => {});
            paintAuth();
            toast(r.mailed ? 'Код ушёл на почту' : 'Регистрация прошла, проверьте почту');
          }
        } catch (e) {
          errEl.textContent = friendlyErr(e, mode === 'up' ? 'Не создалось' : 'Не вошло');
          errEl.classList.remove('hidden');
          failToast(e, mode === 'up' ? 'Не создалось' : 'Не вошло');
        }
      });
      form.appendChild(goBtn);
      [nickF.inp, emailF.inp, passF.inp].forEach((n) => n.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') { e.preventDefault(); goBtn.click(); }
      }));
      const more = el('div', { class: 'chat-auth-more' });
      more.appendChild(el('button', { class: 'btn btn-ghost', type: 'button', text: 'О CrynChat', onclick: () => openAbout() }));
      more.appendChild(el('button', { class: 'btn btn-ghost', type: 'button', text: 'Горячие клавиши', onclick: () => openShortcuts() }));
      card.appendChild(form);
      card.appendChild(more);
      authBox.appendChild(card);
      return;
    }
    wrap.classList.toggle('auth-full', Boolean(need));
    if (need) {
      setSub('подтвердите почту');
      wrap.classList.add('auth-full');
      const card = el('div', { class: 'chat-auth-card chat-auth-anim' });
      const heroV = el('div', { class: 'chat-auth-hero' });
      heroV.appendChild(iconAva('tg', 'brand'));
      heroV.appendChild(el('h3', { text: 'Подтверждение почты' }));
      heroV.appendChild(el('p', { class: 'hint', text: 'Мы отправили письмо с кодом на вашу почту. Введите 6 цифр, чтобы открыть чат. Если письма нет — проверьте спам или запросите новый код.' }));
      card.appendChild(heroV);
      const box = el('div', { class: 'chat-verify' });
      const code = el('input', { class: 'field chat-code', placeholder: '000000', maxlength: '6', inputmode: 'numeric' });
      box.appendChild(code);
      const row = el('div', { class: 'row chat-auth-row' });
      row.appendChild(el('button', { class: 'btn btn-sky', text: 'Подтвердить', onclick: async () => {
        try {
          const r = await call('verify', code.value);
          if (!r || !r.ok) throw new Error((r && r.error) || 'Не то');
          me = { ...me, ...r, verified: true, needVerify: false };
          paintAuth();
          paintHead();
          toast('Почта подтверждена');
          loadFresh();
        } catch (e) { failToast(e, 'Неверный код'); }
      } }));
      row.appendChild(el('button', { class: 'btn', text: 'Новый код', onclick: async () => {
        try {
          const r = await call('resendVerify');
          if (r && r.code) me.code = r.code;
          if (r && r.verified) {
            me = { ...me, ...r, verified: true, needVerify: false };
            paintAuth();
            paintHead();
            loadFresh();
            toast('Почта уже подтверждена');
            return;
          }
          paintAuth();
          toast(r && r.mailed === false ? 'Не удалось отправить. Попробуйте ещё раз' : 'Новый код ушёл на почту');
        } catch (e) { failToast(e, 'Не получилось'); }
      } }));
      box.appendChild(row);
      box.appendChild(el('button', { class: 'btn btn-ghost chat-auth-cancel', type: 'button', text: 'Отменить вход', onclick: async () => {
        try { await doLogout(); } catch (_) { me = { ok: false, guest: true }; paintAuth(); }
      } }));
      card.appendChild(box);
      authBox.appendChild(card);
      code.focus();
      return;
    }
    paintThreadHead();
    applyWallpaper();
    if (meAvaBtn) {
      meAvaBtn.replaceChildren(ava(me.avatar, me.nick, true));
    }
  }

  function paintDevice(box, mail) {
    box.replaceChildren();
    const card = el('div', { class: 'chat-auth-card' });
    const hero = el('div', { class: 'chat-auth-hero' });
    hero.appendChild(iconAva('shield', 'brand'));
    hero.appendChild(el('h3', { text: 'Новое устройство' }));
    hero.appendChild(el('p', { class: 'hint', text: 'Код отправлен на ' + (mail || 'почту') + '. Подтверди вход.' }));
    card.appendChild(hero);
    const code = el('input', { class: 'field chat-code', placeholder: '000000', maxlength: '6', inputmode: 'numeric' });
    card.appendChild(code);
    card.appendChild(el('button', { class: 'btn btn-sky chat-auth-go', text: 'Подтвердить', onclick: async () => {
      if (!devicePending || !C.confirmDevice) return;
      try {
        const r = await C.confirmDevice(devicePending.email, devicePending.password, code.value);
        if (!r || !r.ok) throw new Error((r && r.error) || 'Не то');
        me = r;
        devicePending = null;
        paintAuth();
        paintHead();
        toast('Устройство подтверждено');
        loadFresh();
      } catch (e) { failToast(e, 'Неверный код'); }
    } }));
    box.appendChild(card);
    code.focus();
  }

  function openAbout() {
    const sh = modal('О CrynChat', { sub: 'мессенджер Cryndel' });
    const hero = el('div', { class: 'chat-about-hero' });
    hero.appendChild(iconAva('tg', 'brand'));
    hero.appendChild(el('h3', { text: 'CrynChat' }));
    hero.appendChild(el('p', { class: 'hint', text: 'Чаты, стикеры, лички и канал — здесь и отдельным окном. Сессия живёт на этом устройстве.' }));
    sh.body.appendChild(hero);
    sh.body.classList.add('chat-form-gap');
    for (const [k, v] of [
      ['Сессия', 'Сохраняется, входить каждый раз не нужно'],
      ['Почта', 'Код подтверждения уходит письмом'],
      ['Медиа', 'До 3 МБ: png, jpg, webp, gif, webm'],
      ['Аккаунты', 'До пяти на одно устройство']
    ]) {
      const row = el('div', { class: 'chat-about-row' });
      row.appendChild(el('b', { text: k }));
      row.appendChild(el('span', { class: 'hint', text: v }));
      sh.body.appendChild(row);
    }
    const legal = el('div', { class: 'row chat-form-gap' });
    const pol = el('button', { class: 'btn chat-compact-btn', type: 'button' });
    pol.innerHTML = svg('legal') + '<span>Политика конфиденциальности</span>';
    pol.addEventListener('click', () => openLegal('privacy'));
    const terms = el('button', { class: 'btn chat-compact-btn', type: 'button' });
    terms.innerHTML = svg('page') + '<span>Условия</span>';
    terms.addEventListener('click', () => openLegal('terms'));
    legal.appendChild(pol);
    legal.appendChild(terms);
    sh.body.appendChild(legal);
  }

  function openLegal(kind) {
    const title = kind === 'terms' ? 'Условия использования' : 'Политика конфиденциальности';
    const sh = modal(title);
    sh.sh.classList.add('chat-modal-compact');
    const body = el('div', { class: 'chat-legal-body' });
    const privacy = 'Политика конфиденциальности CrynChat описывает, какие данные мы обрабатываем, зачем это нужно и какие у вас есть права. Мы собираем только сведения, без которых сервис не может работать: ник, адрес электронной почты, пароль в защищённом виде, аватар, баннер, статус, биографию и ссылки, которые вы сами указываете в профиле. Сообщения, вложения, реакции, опросы и черновики хранятся, чтобы вы могли пользоваться чатами с любого своего устройства. Технические данные (идентификатор сессии, тип устройства, время входа) нужны, чтобы показывать список сессий и давать возможность выйти с чужого устройства. Мы не продаём персональные данные и не передаём их рекламным сетям. Доступ к переписке имеют только участники соответствующего чата, а модераторы — только в объёме, необходимом для рассмотрения жалоб. Вы можете изменить или удалить профиль, отозвать сессии, ограничить, кто пишет вам и кто видит статус «в сети». Медиафайлы загружаются по вашей инициативе; ссылки на сторонние сервисы (Telegram, Discord, YouTube, TikTok) открываются вне приложения. Мы применяем шифрование канала связи, ограничиваем размер файлов и храним журналы безопасности ограниченное время. Если вы считаете, что ваши данные обработаны неверно, напишите в поддержку через жалобу на сообщение или через раздел «О приложении». Продолжая пользоваться CrynChat, вы подтверждаете, что ознакомились с этой политикой.';
    const terms = 'Условия использования CrynChat определяют правила работы с мессенджером. Регистрируясь, вы подтверждаете, что вам есть 16 лет (или вы действуете с согласия законного представителя) и несёте ответственность за свой аккаунт. Запрещено распространять вредоносный код, спам, мошенничество, материалы, нарушающие закон, а также пытаться обойти блокировки, взламывать чужие аккаунты или нагружать инфраструктуру. Администрация вправе ограничить доступ, удалить контент или сессию при нарушении правил, а также по обоснованной жалобе. Сообщения в общих чатах и каналах могут модерироваться. Личные переписки предназначены для участников диалога; пересылка чужого контента без согласия автора не приветствуется. Стикеры, GIF, опросы и вложения отправляются от вашего имени. Магазин косметики (шапки аватара) работает на внутренней валюте «пирикас» и не является азартной услугой. CrynChat предоставляется «как есть»: мы стремимся к стабильности, но не гарантируем бесперебойность. Вы можете удалить аккаунт, покинуть канал, заблокировать пользователя и экспортировать данные, если такая функция доступна. Споры решаются в соответствии с применимым правом места оказания услуги. Обновления условий публикуются в приложении; существенные изменения мы стараемся донести заранее. Нажимая «Понятно», вы принимаете эти условия и обязуетесь ими руководствоваться при использовании CrynChat.';
    body.appendChild(el('p', { text: kind === 'terms' ? terms : privacy }));
    sh.body.appendChild(body);
    const ok = el('button', { class: 'btn btn-sky chat-compact-btn', text: 'Понятно', onclick: () => sh.sh.remove() });
    sh.body.appendChild(ok);
  }

  function openShortcuts() {
    const sh = modal('Горячие клавиши', { sub: 'в поле сообщения' });
    for (const [k, v] of [
      ['Enter', 'Отправить'],
      ['Shift+Enter', 'Новая строка'],
      ['Ctrl+Enter', 'Отправить'],
      ['Ctrl+B', 'Жирный'],
      ['Ctrl+I', 'Курсив'],
      ['Ctrl+U', 'Подчёркнутый'],
      ['Esc', 'Закрыть меню и панели']
    ]) {
      const row = el('div', { class: 'chat-about-row' });
      row.appendChild(el('kbd', { class: 'chat-kbd', text: k }));
      row.appendChild(el('span', { text: v }));
      sh.body.appendChild(row);
    }
  }

  function applyWallpaper() {
    const walls = (prefs && prefs.walls) || {};
    const w = walls[thread] || '';
    if (w) {
      const s = String(w);
      if (/^(data:|https?:|blob:|file:|\/)/i.test(s)) wrap.style.setProperty('--chat-wall', 'url("' + s.replace(/["')]/g, '') + '")');
      else wrap.style.setProperty('--chat-wall', s);
    } else wrap.style.removeProperty('--chat-wall');
    wrap.classList.toggle('compact', Boolean(prefs && prefs.compact));
    wrap.classList.toggle('reduce-motion', Boolean(prefs.reduceMotion) && !prefs.fancyAnim);
    wrap.classList.toggle('fancy-anim', Boolean(prefs.fancyAnim));
    const theme = ['night', 'day', 'accent'].includes(prefs && prefs.theme) ? prefs.theme : 'night';
    wrap.setAttribute('data-theme', theme);
    wrap.setAttribute('data-skin', 'classic');
    document.documentElement.setAttribute('data-theme', theme);
    document.documentElement.setAttribute('data-skin', 'classic');
    if (prefs.accent) wrap.style.setProperty('--accent', prefs.accent);
    else wrap.style.removeProperty('--accent');
    if (prefs.textColor) wrap.style.setProperty('--text', prefs.textColor);
    else wrap.style.removeProperty('--text');
    if (prefs.uiColor) wrap.style.setProperty('--bg-2', prefs.uiColor);
    else wrap.style.removeProperty('--bg-2');
    if (prefs.bubbleIn) wrap.style.setProperty('--bubble-in', prefs.bubbleIn);
    else wrap.style.removeProperty('--bubble-in');
    if (prefs.bubbleOut) wrap.style.setProperty('--bubble-out', prefs.bubbleOut);
    else wrap.style.removeProperty('--bubble-out');
    wrap.style.setProperty('--bubble-r', (Number(prefs.bubbleRadius) || 14) + 'px');
    if (prefs.bubbleTex) wrap.style.setProperty('--bubble-tex', 'url("' + String(prefs.bubbleTex).replace(/["')]/g, '') + '")');
    else wrap.style.removeProperty('--bubble-tex');
    wrap.style.setProperty('--ava-r', (Number(prefs.avaRound) || 50) + '%');
    if (prefs.font) wrap.style.fontFamily = prefs.font;
    else wrap.style.fontFamily = '';
    applyCustomCss();
  }

  function applyCustomCss() {
    if (!uiCssEl) {
      uiCssEl = document.createElement('style');
      uiCssEl.setAttribute('data-chat-ui', '1');
      document.head.appendChild(uiCssEl);
    }
    uiCssEl.textContent = String((prefs && prefs.customCss) || '');
  }

  function openThemes() {
    openUiSettings();
  }

  function savePrefs(patch) {
    prefs = { ...prefs, ...patch };
    idb.prefsSet(prefs).catch(() => {});
    if (C.setPrefs) C.setPrefs(patch).catch(() => {});
    applyWallpaper();
  }

  function colorField(label, key, fallback) {
    const row = el('div', { class: 'chat-set-row' });
    row.appendChild(el('label', { text: label }));
    const inp = el('input', { type: 'color' });
    const cur = prefs[key] || fallback || '#3390ec';
    try { inp.value = cur; } catch (_) { inp.value = fallback || '#3390ec'; }
    inp.addEventListener('input', () => savePrefs({ [key]: inp.value }));
    row.appendChild(inp);
    return row;
  }

  function toggleRow(label, key) {
    const row = el('div', { class: 'chat-set-row' });
    row.appendChild(el('label', { text: label }));
    const b = el('button', {
      class: 'switch' + (prefs[key] ? ' on' : ''),
      type: 'button',
      'aria-pressed': prefs[key] ? 'true' : 'false',
      onclick: () => {
        savePrefs({ [key]: !prefs[key] });
        b.classList.toggle('on', Boolean(prefs[key]));
        b.setAttribute('aria-pressed', prefs[key] ? 'true' : 'false');
        if (key === 'accFlyout' && !prefs.accFlyout) hideAccFlyout();
      }
    });
    b.appendChild(el('i'));
    row.appendChild(b);
    return row;
  }

  function openUiSettings() {
    const sh = modal('Настройки', { sub: 'Внешний вид и поведение' });
    const body = sh.body;
    body.classList.add('chat-settings-body');
    body.appendChild(el('p', { class: 'kicker chat-set-sec', text: 'ТЕМА' }));
    const themes = [
      ['night', 'Тёмная'],
      ['day', 'Светлая'],
      ['accent', 'Акцент']
    ];
    const themeRow = el('div', { class: 'chat-theme-row' });
    for (const [id, lab] of themes) {
      const on = (prefs.theme || 'night') === id;
      themeRow.appendChild(el('button', {
        class: 'chat-theme-swatch ' + id + (on ? ' on' : ''),
        type: 'button',
        text: lab,
        onclick: () => { savePrefs({ theme: id, skin: 'classic' }); sh.sh.remove(); openUiSettings(); }
      }));
    }
    body.appendChild(themeRow);
    body.appendChild(toggleRow('Компактные сообщения', 'compact'));
    body.appendChild(toggleRow('Уменьшить анимации', 'reduceMotion'));
    body.appendChild(toggleRow('Красивые анимации', 'fancyAnim'));
    body.appendChild(toggleRow('Действия при наведении (1с)', 'hoverActions'));
    body.appendChild(toggleRow('Меню аккаунтов по аватарке (2 сек)', 'accFlyout'));
    body.appendChild(toggleRow('Правый Shift — быстрые действия', 'shiftActions'));
    body.appendChild(toggleRow('Один лайк на сообщение', 'oneLike'));
    body.appendChild(toggleRow('Кастомные эмодзи', 'customEmoji'));
    body.appendChild(el('p', { class: 'kicker chat-set-sec', text: 'СТИКЕРЫ И АНИМАЦИИ' }));
    const playRow = el('div', { class: 'chat-theme-row' });
    for (const [id, lab] of [['viewport', 'В кадре'], ['always', 'Всегда'], ['once', 'Один раз'], ['never', 'Никогда']]) {
      playRow.appendChild(el('button', {
        class: 'chat-theme-swatch' + ((prefs.animPlay || 'viewport') === id ? ' on' : ''),
        type: 'button', text: lab,
        onclick: () => { savePrefs({ animPlay: id }); sh.sh.remove(); openUiSettings(); }
      }));
    }
    body.appendChild(playRow);
    const stRow = el('div', { class: 'chat-theme-row' });
    for (const [id, lab] of [['classic', 'Классика'], ['hover', 'При наведении'], ['mini', 'Мини']]) {
      stRow.appendChild(el('button', {
        class: 'chat-theme-swatch' + ((prefs.stickStyle || 'classic') === id ? ' on' : ''),
        type: 'button', text: lab,
        onclick: () => { savePrefs({ stickStyle: id }); sh.sh.remove(); openUiSettings(); }
      }));
    }
    body.appendChild(stRow);
    body.appendChild(toggleRow('Экономия стикеров', 'stickPerf'));
    body.appendChild(colorField('Цвет интерфейса', 'accent', '#3390ec'));
    body.appendChild(colorField('Цвет текста', 'textColor', '#222222'));
    body.appendChild(colorField('Цвет пузыря входящих', 'bubbleIn', '#ffffff'));
    body.appendChild(colorField('Цвет моих пузырей', 'bubbleOut', '#3390ec'));
    const rad = el('div', { class: 'chat-set-row' });
    rad.appendChild(el('label', { text: 'Скругление пузырей' }));
    const range = el('input', { type: 'range', min: '0', max: '28', step: '1' });
    range.value = String(prefs.bubbleRadius || 14);
    range.addEventListener('input', () => savePrefs({ bubbleRadius: Number(range.value) }));
    rad.appendChild(range);
    body.appendChild(rad);
    const avr = el('div', { class: 'chat-set-row' });
    avr.appendChild(el('label', { text: 'Скругление аватарок' }));
    const avRange = el('input', { type: 'range', min: '0', max: '50', step: '1' });
    avRange.value = String(prefs.avaRound == null ? 50 : prefs.avaRound);
    avRange.addEventListener('input', () => savePrefs({ avaRound: Number(avRange.value) }));
    avr.appendChild(avRange);
    body.appendChild(avr);

    body.appendChild(el('p', { class: 'kicker chat-set-sec', text: 'ПУЗЫРИ / КАРТОЧКИ' }));
    body.appendChild(el('p', { class: 'hint', text: 'Стиль уходит на сервер. Другие увидят твою карточку.' }));
    const puz = el('div', { class: 'chat-puzir-grid' });
    const curStyle = (me && me.bubbleStyle) || prefs.bubbleStyle || 'tg';
    for (let i = 0; i < PUZIR.length; i++) {
      const id = PUZIR[i];
      const b = el('button', { class: 'chat-puzir chat-bubble-style-' + id + (curStyle === id ? ' on' : ''), type: 'button', text: String(i + 1) });
      const tex = 'assets/puziri/' + (i + 1) + '.png';
      b.style.backgroundImage = 'url("' + tex + '")';
      b.onclick = async () => {
        savePrefs({ bubbleStyle: id, bubbleTex: tex });
        try {
          const r = await call('saveProfile', { bubbleStyle: id });
          if (r && r.ok) me = { ...me, ...r, bubbleStyle: id };
        } catch (_) { /* local ok */ }
        toast('Пузырь: ' + id);
        sh.sh.remove();
        openUiSettings();
      };
      puz.appendChild(b);
    }
    body.appendChild(puz);
    body.appendChild(el('button', { class: 'btn', type: 'button', text: 'PNG текстура пузыря', onclick: async () => {
      const file = await pick('image/png,image/webp,image/*');
      if (!file) return;
      const b64 = await readFile(file);
      const url = 'data:' + (file.type || 'image/png') + ';base64,' + b64;
      savePrefs({ bubbleTex: url });
      toast('Текстура пузыря');
    } }));

    body.appendChild(el('p', { class: 'kicker chat-set-sec', text: 'ПКМ ПО СООБЩЕНИЮ' }));
    body.appendChild(toggleRow('Компактное меню', 'ctxCompact'));
    const hide = new Set(prefs.ctxHide || []);
    const hideBox = el('div', { class: 'chat-hide-list' });
    for (const [id, lab] of CTX_KEYS) {
      const labEl = el('label');
      const cb = el('input', { type: 'checkbox' });
      cb.checked = !hide.has(id);
      cb.addEventListener('change', () => {
        const next = new Set(prefs.ctxHide || []);
        if (cb.checked) next.delete(id);
        else next.add(id);
        savePrefs({ ctxHide: [...next] });
      });
      labEl.appendChild(cb);
      labEl.appendChild(document.createTextNode(' ' + lab));
      hideBox.appendChild(labEl);
    }
    body.appendChild(hideBox);

    body.appendChild(el('p', { class: 'kicker chat-set-sec', text: 'СПИСОК ЧАТОВ' }));
    body.appendChild(toggleRow('Счётчик непрочитанных', 'showUnread'));
    body.appendChild(toggleRow('Сколько сообщений отправлено', 'showMsgCount'));
    const hideChats = new Set(prefs.hideChats || []);
    const sysBox = el('div', { class: 'chat-hide-list' });
    for (const [id, lab] of [['saved', 'Избранное'], ['system', 'Уведомления'], ['channel', 'Канал'], ['dm:createbot', 'CrynBot'], ['dm:adminbot', 'Admin']]) {
      const labEl = el('label');
      const cb = el('input', { type: 'checkbox' });
      cb.checked = !hideChats.has(id);
      cb.addEventListener('change', () => {
        const next = new Set(prefs.hideChats || []);
        if (cb.checked) next.delete(id);
        else next.add(id);
        savePrefs({ hideChats: [...next] });
        paintSidebar();
      });
      labEl.appendChild(cb);
      labEl.appendChild(document.createTextNode(' ' + lab));
      sysBox.appendChild(labEl);
    }
    body.appendChild(sysBox);

    body.appendChild(el('p', { class: 'kicker chat-set-sec', text: 'ОБОИ ЭТОГО ЧАТА' }));
    body.appendChild(el('p', { class: 'hint', text: 'Локально, отдельно на каждый чат. Баннер профиля — на сервер.' }));
    const walls = el('div', { class: 'chat-wall-grid' });
    const curWall = (prefs.walls && prefs.walls[thread]) || '';
    const presets = [
      ['', 'Без обоев'],
      ['linear-gradient(180deg,#1b2836 0%,#0e1621 100%)', 'Ночь'],
      ['linear-gradient(180deg,#dce8f4 0%,#b7c9dc 100%)', 'День'],
      ['linear-gradient(160deg,#1a2a24 0%,#0e1a16 100%)', 'Лес'],
      ['linear-gradient(160deg,#2a1824 0%,#140c12 100%)', 'Роза'],
      ['linear-gradient(160deg,#1c1730 0%,#0e0c18 100%)', 'Фиолет'],
      ['linear-gradient(160deg,#3a2410 0%,#1a1208 100%)', 'Какао'],
      ['linear-gradient(160deg,#102030 0%,#081018 100%)', 'Океан']
    ];
    for (const [val, lab] of presets) {
      const b = el('button', { class: 'chat-wall-swatch' + (curWall === val ? ' on' : ''), type: 'button', text: lab });
      if (val) b.style.background = val;
      b.onclick = () => {
        const next = { ...(prefs.walls || {}), [thread]: val };
        savePrefs({ walls: next });
        toast(val ? 'Обои этого чата' : 'Обои сняты');
      };
      walls.appendChild(b);
    }
    body.appendChild(walls);
    body.appendChild(el('button', { class: 'btn btn-sky', type: 'button', text: 'Своё фото на этот чат', onclick: () => { sh.sh.remove(); pickWallpaper(); } }));

    body.appendChild(el('p', { class: 'kicker chat-set-sec', text: 'ШРИФТ И CSS' }));
    const fontIn = el('input', { class: 'field', placeholder: 'Шрифт: Inter, Georgia…' });
    fontIn.value = prefs.font || '';
    fontIn.addEventListener('change', () => savePrefs({ font: fontIn.value }));
    body.appendChild(fontIn);
    body.appendChild(el('button', { class: 'btn', type: 'button', text: 'Загрузить свой шрифт (.ttf/.otf/.woff)', onclick: async () => {
      const file = await pick('.ttf,.otf,.woff,.woff2,font/ttf,font/otf,font/woff');
      if (!file) return;
      const b64 = await readFile(file);
      const mime = file.type || 'font/ttf';
      const name = 'CrynFont' + Date.now().toString(36);
      const css = '@font-face{font-family:"' + name + '";src:url(data:' + mime + ';base64,' + b64 + ');}';
      savePrefs({ font: '"' + name + '", sans-serif', customCss: ((prefs.customCss || '') + '\n' + css).trim() });
      toast('Шрифт установлен');
    } }));
    const cssBox = el('textarea', { class: 'field chat-css-box', placeholder: 'Свой CSS темы…', rows: '6' });
    cssBox.value = prefs.customCss || '';
    body.appendChild(cssBox);
    body.appendChild(el('button', { class: 'btn btn-sky', type: 'button', text: 'Применить CSS', onclick: () => {
      savePrefs({ customCss: cssBox.value });
      toast('CSS применён');
    } }));
    body.appendChild(el('button', { class: 'btn', type: 'button', text: 'Загрузить CSS файл', onclick: async () => {
      const file = await pick('.css,text/css');
      if (!file) return;
      const raw = await new Promise((res, rej) => {
        const r = new FileReader();
        r.onload = () => res(String(r.result || ''));
        r.onerror = () => rej(r.error);
        r.readAsText(file);
      });
      cssBox.value = raw;
      savePrefs({ customCss: raw });
      toast('Тема CSS загружена');
    } }));

    body.appendChild(el('p', { class: 'kicker chat-set-sec', text: 'ОГОНЁК — ТЕСТ' }));
    body.appendChild(el('button', { class: 'btn btn-sky', type: 'button', text: 'Посмотреть анимации огонька', onclick: () => { sh.sh.remove(); openFlameDemo(); } }));

    body.appendChild(el('p', { class: 'kicker chat-set-sec', text: 'ОКНО' }));
    body.appendChild(el('button', { class: 'btn', type: 'button', text: 'Размер и масштаб окна', onclick: () => { sh.sh.remove(); openWinSettings(); } }));

    body.appendChild(el('p', { class: 'kicker chat-set-sec', text: 'ДАННЫЕ И КЭШ' }));
    body.appendChild(toggleRow('Кэшировать медиа', 'cacheMedia'));
    body.appendChild(toggleRow('Кэшировать сообщения', 'cacheMsgs'));
    body.appendChild(toggleRow('Кэшировать пользователей', 'cacheUsers'));
    const cacheRow = el('div', { class: 'chat-set-row' });
    cacheRow.appendChild(el('label', { text: 'Лимит кэша, МБ' }));
    const cacheIn = el('input', { class: 'field', type: 'number', min: '16', max: '2048', step: '16' });
    cacheIn.value = String(prefs.maxCacheMb || 256);
    cacheIn.addEventListener('change', () => {
      const n = Math.max(16, Math.min(2048, Number(cacheIn.value) || 256));
      cacheIn.value = String(n);
      savePrefs({ maxCacheMb: n });
    });
    cacheRow.appendChild(cacheIn);
    body.appendChild(cacheRow);
    const cacheHint = el('p', { class: 'hint', text: 'Считаю размер…' });
    body.appendChild(cacheHint);
    idb.stats().then((s) => {
      const mb = ((s.bytes || 0) / 1024 / 1024).toFixed(1);
      cacheHint.textContent = 'Занято ' + mb + ' МБ · сообщений: ' + ((s.stores && s.stores.messages) || 0);
    }).catch(() => { cacheHint.textContent = 'Кэш IndexedDB'; });
    body.appendChild(el('button', { class: 'btn', type: 'button', text: 'Очистить кэш медиа', onclick: async () => {
      await idb.clearStore('media');
      toast('Медиа-кэш очищен');
    } }));
    body.appendChild(el('button', { class: 'btn', type: 'button', text: 'Очистить кэш сообщений', onclick: async () => {
      await idb.clearStore('messages');
      toast('Кэш сообщений очищен');
    } }));
    body.appendChild(el('button', { class: 'btn', type: 'button', text: 'Очистить весь локальный кэш', onclick: async () => {
      await idb.clearAll();
      toast('Кэш очищен');
    } }));

    body.appendChild(el('p', { class: 'kicker chat-set-sec', text: 'УВЕДОМЛЕНИЯ' }));
    body.appendChild(el('button', {
      class: 'btn btn-sky',
      type: 'button',
      text: 'Разрешить push-уведомления',
      onclick: async () => {
        try {
          if (typeof Notification !== 'undefined') {
            const p = await Notification.requestPermission();
            toast(p === 'granted' ? 'Уведомления Windows включены' : 'Разрешение не выдано');
          }
          if (C.nativeNotify) await C.nativeNotify({ title: 'CrynChat', body: 'Уведомления работают' });
        } catch (e) { failToast(e, 'Не получилось'); }
      }
    }));
    body.appendChild(el('button', {
      class: 'btn',
      type: 'button',
      text: (me && me.muted) ? 'Включить звук сообщений' : 'Выключить звук сообщений',
      onclick: async () => {
        try {
          const r = await call('mute', !(me && me.muted));
          if (me) me.muted = Boolean(r && r.muted);
          toast(me && me.muted ? 'Звук выключен' : 'Звук включён');
        } catch (err) { failToast(err, 'Не получилось'); }
      }
    }));
  }

  function flameSrc(st) {
    return (st && st.dead) ? 'oqonek/oqon.webp' : 'oqonek/opon.gif';
  }

  function flameNode(st, extraClass) {
    st = st || {};
    const n = el('span', { class: 'chat-flame' + (st.lit ? ' lit' : '') + (st.gray ? ' gray' : '') + (st.dead ? ' dead' : '') + (st.born ? ' born' : '') + (extraClass ? ' ' + extraClass : '') });
    const img = el('img', { class: 'chat-flame-img', alt: 'огонёк' });
    img.src = flameSrc(st);
    img.decoding = 'async';
    n.appendChild(img);
    const days = Number(st.days) || 0;
    n.appendChild(el('b', { text: days ? String(days) : '0' }));
    if (st.tier) n.setAttribute('data-tier', st.tier);
    n.title = (st.dead ? 'Погас' : (st.gray ? 'Ждёт ответа' : 'Горит')) + ' · ' + days + ' дн.';
    n.addEventListener('click', (e) => { e.stopPropagation(); openFlameSheet(st); });
    return n;
  }

  function applyStreak(st) {
    if (!st || typeof st !== 'object') return;
    streakMem = { ...streakMem, ...st };
    paintThreadHead();
    if (st.born) toast('Огонёк зажёгся');
    if (st.dead) toast('Огонёк погас');
    if (st.milestone) toast('Огонёк ' + st.milestone + ' дней');
    if (st.reviveOffer) {
      const sh = modal('Вернуть огонёк?');
      sh.body.appendChild(el('p', { class: 'hint', text: 'Осталось возвратов в этом месяце: ' + (st.revivesLeft || 0) }));
      sh.body.appendChild(el('button', { class: 'btn btn-sky', text: 'Вернуть', onclick: async () => {
        try {
          const r = C.reviveStreak ? await C.reviveStreak(thread) : await call('reviveStreak', thread);
          if (r && r.streak) applyStreak(r.streak);
          if (r && r.item) appendLive(r.item);
          sh.sh.remove();
        } catch (e) { failToast(e, 'Не получилось'); }
      } }));
    }
  }

  function openFlameSheet(cur) {
    const st = cur || streakMem || {};
    const sh = modal('Огонёк');
    const box = el('div', { class: 'chat-flame-modal' });
    const hero = el('div', { class: 'chat-flame-hero' });
    const big = el('img', { class: 'chat-flame-big', alt: 'огонёк' });
    big.src = flameSrc(st);
    hero.appendChild(big);
    hero.appendChild(el('b', { class: 'n', text: String(st.days || 0) }));
    const status = st.dead ? 'Погас — напишите, чтобы зажечь снова' : (st.gray ? 'Ждёт вашего ответа' : 'Горит каждый день');
    hero.appendChild(el('p', { class: 'hint', text: status }));
    if (st.tier) hero.appendChild(el('span', { class: 'chat-chip', text: 'Уровень ' + st.tier }));
    box.appendChild(hero);
    const acts = el('div', { class: 'chat-profile-acts' });
    acts.appendChild(el('button', { class: 'chat-profile-cta', text: 'Поделиться огоньком', onclick: () => {
      sh.sh.remove();
      openShareModal({ kind: 'flame', nick: (me && me.nick) || '', days: st.days || 0, dead: Boolean(st.dead) });
    } }));
    if (st.dead && st.revivesLeft) {
      acts.appendChild(el('button', { class: 'btn', text: 'Вернуть огонёк', onclick: async () => {
        try {
          const r = C.reviveStreak ? await C.reviveStreak(thread) : await call('reviveStreak', thread);
          if (r && r.streak) applyStreak(r.streak);
          sh.sh.remove();
        } catch (e) { failToast(e, 'Не получилось'); }
      } }));
    }
    acts.appendChild(el('button', { class: 'btn', text: 'Как это работает', onclick: () => openFlameDemo(st) }));
    box.appendChild(acts);
    sh.body.appendChild(box);
  }

  function openFlameDemo(cur) {
    const sh = modal('Огонёк');
    const box = el('div', { class: 'chat-flame-demo' });
    const hero = el('div', { class: 'chat-flame-hero' });
    const big = el('img', { class: 'chat-flame-big', alt: 'огонёк' });
    big.src = flameSrc(cur);
    hero.appendChild(big);
    hero.appendChild(el('b', { class: 'n', text: String((cur && cur.days) || streakMem.days || 0) }));
    hero.appendChild(el('p', { class: 'hint', text: (cur && cur.dead) ? 'Погас' : ((cur && cur.gray) ? 'Ждёт ответа' : 'Горит') }));
    box.appendChild(hero);
    const mk = (lab, st, cls) => {
      const row = el('div', { class: 'chat-flame-card' });
      row.appendChild(flameNode(st, cls));
      const t = el('div');
      t.appendChild(el('b', { text: lab }));
      t.appendChild(el('p', { class: 'hint', text: (st.days || 0) + ' дней · ' + (st.dead ? 'погас' : (st.gray ? 'ждёт' : 'горит')) }));
      row.appendChild(t);
      box.appendChild(row);
    };
    mk('Только зажёгся', { days: 3, lit: true, born: true, tier: 'lit' }, 'born');
    mk('Горит', { days: 12, lit: true, tier: '10' }, '');
    mk('Серый — ждут ответа', { days: 12, gray: true, tier: '10' }, '');
    mk('Погас', { days: 0, dead: true }, '');
    mk('100 дней', { days: 100, lit: true, tier: '100' }, 'ms');
    mk('500 дней', { days: 500, lit: true, tier: '500' }, 'ms');
    mk('1000 дней', { days: 1000, lit: true, tier: 'k' }, 'ms');
    sh.body.appendChild(box);
  }

  function lightbox(url, kind) {
    const veil = el('div', { class: 'chat-lightbox' });
    if (kind === 'audio') {
      const a = document.createElement('audio');
      a.controls = true;
      a.autoplay = true;
      a.src = url;
      veil.appendChild(a);
    } else {
      const img = el('img', { alt: 'preview' });
      img.src = url;
      veil.appendChild(img);
    }
    veil.addEventListener('click', () => veil.remove());
    document.body.appendChild(veil);
  }

  function ctxMenu(x, y, item) {
    closeSheets(wrap);
    const pop = el('div', { class: 'chat-ctx' + (prefs.ctxCompact !== false ? ' compact' : '') });
    const hide = new Set(prefs.ctxHide || []);
    const emos = el('div', { class: 'chat-ctx-emos' });
    EMOJI.forEach((emo) => {
      const b = el('button', { type: 'button', onclick: () => { pop.remove(); react(item, emo); } });
      b.appendChild(emoNode(emo));
      emos.appendChild(b);
    });
    emos.appendChild(el('button', { type: 'button', class: 'chat-ctx-emo-more', text: '+', title: 'Ещё реакции', onclick: (ev) => {
      ev.stopPropagation();
      openReactPicker(item, pop);
    } }));
    pop.appendChild(emos);
    const makeBtn = (ico, label, fn, cls) => {
      const b = el('button', { type: 'button', class: cls || '', onclick: () => { pop.remove(); fn(); } });
      b.innerHTML = svg(ico) + '<span>' + label + '</span>';
      return b;
    };

    // Часто используемые — всегда наверху.
    const primary = el('div', { class: 'chat-ctx-primary' });
    primary.appendChild(makeBtn('reply', 'Ответить', () => setReply(item)));
    if (!hide.has('copy')) primary.appendChild(makeBtn('copy', 'Копировать', () => {
      const t = item.text || item.url || '';
      if (navigator.clipboard) navigator.clipboard.writeText(t).catch(() => {});
      toast('Скопировано');
    }));
    if (!hide.has('send')) primary.appendChild(makeBtn('send', 'Переслать', () => fwdMsg(item)));
    pop.appendChild(primary);

    // «Ещё» разворачивает остальные пункты прямо в меню (аккордеон).
    const moreBox = el('div', { class: 'chat-ctx-more' });
    moreBox.appendChild(makeBtn('pin', item.pinned ? 'Открепить' : 'Закрепить', () => pin(item)));
    if (!hide.has('star')) moreBox.appendChild(makeBtn('star', 'В избранное', () => saveFav(item)));
    if (!hide.has('nick')) moreBox.appendChild(makeBtn('nick', 'Профиль', () => openProfile(item.nick)));
    if (!hide.has('select')) moreBox.appendChild(makeBtn('select', 'Выбрать', () => enterSelect(item)));
    if ((item.kind === 'image' || item.kind === 'gif' || item.kind === 'video' || item.kind === 'audio') && item.url) moreBox.appendChild(makeBtn('dl', 'Скачать', () => downloadItem(item)));
    if (item.kind === 'audio' || item.kind === 'voice') moreBox.appendChild(makeBtn('widget', 'Виджет', () => pinMusicWidget(item)));
    if ((item.kind === 'gif' || item.kind === 'image') && item.url) moreBox.appendChild(makeBtn('sticker', 'В коллекцию', () => saveToPack(item)));
    if (item.kind === 'gif' && item.url) moreBox.appendChild(makeBtn('gif', 'В GIF', () => saveGif(item.url)));
    if (me && me.ok && (item.nick === me.nick || isAdmin()) && ['text', 'system', 'image', 'gif', 'poll'].includes(item.kind)) moreBox.appendChild(makeBtn('edit', 'Изменить', () => editMsg(item)));
    if (me && me.ok && (item.nick === me.nick || isAdmin())) moreBox.appendChild(makeBtn('trash', 'Удалить у себя', () => delMsg(item, false), 'bad'));
    if (isAdmin()) moreBox.appendChild(makeBtn('trash', 'Удалить для всех', () => delMsg(item, true), 'bad'));
    if (!hide.has('readers')) moreBox.appendChild(makeBtn('users', 'Кто прочитал', () => openReaders(item)));
    if (item.failed && me && item.nick === me.nick) moreBox.appendChild(makeBtn('send', 'Повторить', () => retryItem(item)));
    moreBox.appendChild(makeBtn('bell', 'Жалоба', () => reportMsg(item), 'bad'));
    if (isAdmin()) {
      if (item.id) moreBox.appendChild(makeBtn('copy', 'Копировать ID', () => {
        if (navigator.clipboard) navigator.clipboard.writeText(String(item.id)).catch(() => {});
        toast(String(item.id));
      }));
      if (item.url && (item.kind === 'image' || item.kind === 'gif' || item.kind === 'sticker' || item.kind === 'video' || item.kind === 'audio')) {
        moreBox.appendChild(makeBtn('open', 'Ссылка на файл', () => {
          if (navigator.clipboard) navigator.clipboard.writeText(String(item.url)).catch(() => {});
          toast('Ссылка скопирована');
        }));
      }
    }
    const moreBtn = el('button', { type: 'button', class: 'chat-ctx-more-btn', onclick: (ev) => {
      ev.stopPropagation();
      moreBtn.style.display = 'none';
      moreBox.classList.add('open');
    } });
    moreBtn.innerHTML = svg('chev') + '<span>Ещё</span>';
    pop.appendChild(moreBtn);
    pop.appendChild(moreBox);

    wrap.appendChild(pop);
    const box = wrap.getBoundingClientRect();
    const w = pop.offsetWidth;
    const h = pop.offsetHeight;
    const left = Math.max(8, Math.min(x - box.left, box.width - w - 8));
    const top = Math.max(8, Math.min(y - box.top, box.height - h - 8));
    pop.style.position = 'absolute';
    pop.style.left = left + 'px';
    pop.style.top = top + 'px';
    const off = (e) => {
      if (!pop.contains(e.target)) { pop.remove(); document.removeEventListener('mousedown', off); }
    };
    setTimeout(() => document.addEventListener('mousedown', off), 0);
  }

  async function saveToPack(item) {
    try {
      if (C.saveSticker) await C.saveSticker(item.url, item.name || 'sticker');
      else await call('addSticker', (packs[0] && packs[0].id) || '', item.url, item.name || 'sticker');
      toast('В коллекцию');
    } catch (e) { failToast(e, 'Не добавилось в коллекцию'); }
  }

  async function blockUser(nick) {
    try { await call('block', nick); toast('Заблокирован'); loadFresh(); } catch (e) { failToast(e, 'Не получилось заблокировать'); }
  }

  async function clearLocalChat() {
    try {
      if (C.clearChat) await C.clearChat(thread);
      itemsCache = [];
      list.replaceChildren(el('p', { class: 'chat-empty', text: 'Чат очищен у тебя' }));
      toast('Очищено только у тебя');
    } catch (e) { failToast(e, 'Не получилось очистить чат'); }
  }

  function enterSelect(item) {
    selectMode = true;
    selectedIds = new Set();
    if (item && item.id) selectedIds.add(item.id);
    paintSelectBar();
    paintList(itemsCache, true);
  }

  function paintSelectBar() {
    let bar = col.querySelector('.chat-select-bar');
    if (!selectMode) { if (bar) bar.remove(); return; }
    if (!bar) {
      bar = el('div', { class: 'chat-select-bar' });
      composer.before(bar);
    }
    bar.replaceChildren();
    bar.appendChild(el('strong', { text: selectedIds.size + ' выбрано' }));
    bar.appendChild(icon('send', 'Переслать', async () => {
      for (const id of selectedIds) {
        const it = itemsCache.find((x) => x.id === id);
        if (it) await fwdMsg(it);
      }
      selectMode = false; selectedIds.clear(); paintSelectBar(); paintList(itemsCache, true);
    }));
    bar.appendChild(icon('trash', 'Удалить', async () => {
      for (const id of selectedIds) {
        const it = itemsCache.find((x) => x.id === id);
        if (it) await delMsg(it);
      }
      selectMode = false; selectedIds.clear(); paintSelectBar();
    }, 'bad'));
    bar.appendChild(icon('x', 'Отмена', () => {
      selectMode = false; selectedIds.clear(); paintSelectBar(); paintList(itemsCache, true);
    }));
  }

  async function downloadItem(item) {
    try {
      if (C.downloadMedia) {
        const r = await C.downloadMedia(item.url, item.name || item.kind || 'file');
        toast(r && r.ok ? 'Сохранено в Downloads/cryndelDW' : ((r && r.error) || 'Не скачалось'));
      } else {
        const a = el('a', { href: item.url, download: item.name || 'file' });
        a.click();
      }
    } catch (e) { failToast(e, 'Не скачалось'); }
  }

  function pinMusicWidget(item) {
    if (musicWidget) {
      const old = musicWidget.querySelector('audio');
      if (old) try { old.pause(); } catch (_) { /* */ }
      musicWidget.remove();
    }
    musicWidget = el('div', { class: 'chat-music-widget' });
    const audio = document.createElement('audio');
    audio.src = mediaMem.get(item.url) || item.url;
    audio.preload = 'auto';
    audio.playsInline = true;
    const art = el('div', { class: 'chat-music-art' });
    art.innerHTML = svg('music');
    musicWidget.appendChild(art);
    const btn = icon('play', 'Играть', () => {
      if (audio.paused) {
        stopOtherAudio(audio);
        audio.play().then(() => { btn.innerHTML = svg('pause'); }).catch((e) => failToast(e, 'Не играет'));
      } else {
        audio.pause();
        btn.innerHTML = svg('play');
      }
    });
    btn.classList.add('chat-music-play');
    audio.addEventListener('play', () => { btn.innerHTML = svg('pause'); musicWidget.classList.add('playing'); });
    audio.addEventListener('pause', () => { btn.innerHTML = svg('play'); musicWidget.classList.remove('playing'); });
    audio.addEventListener('ended', () => { btn.innerHTML = svg('play'); musicWidget.classList.remove('playing'); });
    musicWidget.appendChild(btn);
    const meta = el('div', { class: 'chat-music-meta' });
    meta.appendChild(el('b', { text: item.name || item.nick || 'Аудио' }));
    const bar = el('div', { class: 'chat-audio-bar' });
    const fill = el('i');
    bar.appendChild(fill);
    bar.addEventListener('click', (e) => {
      if (!audio.duration) return;
      const r = bar.getBoundingClientRect();
      audio.currentTime = ((e.clientX - r.left) / r.width) * audio.duration;
    });
    const time = el('span', { class: 'chat-music-time', text: '0:00' });
    audio.addEventListener('timeupdate', () => {
      fill.style.width = audio.duration ? Math.round((audio.currentTime / audio.duration) * 100) + '%' : '0%';
      time.textContent = fmtDur(audio.currentTime) + (audio.duration ? ' / ' + fmtDur(audio.duration) : '');
    });
    audio.addEventListener('loadedmetadata', () => { time.textContent = '0:00 / ' + fmtDur(audio.duration); });
    meta.appendChild(bar);
    meta.appendChild(time);
    musicWidget.appendChild(meta);
    const mute = icon('volume', 'Звук', () => {
      audio.muted = !audio.muted;
      mute.innerHTML = svg(audio.muted ? 'mute' : 'volume');
    });
    mute.classList.add('chat-music-mute');
    musicWidget.appendChild(mute);
    const closeW = icon('x', 'Закрыть', () => {
      try { audio.pause(); } catch (_) { /* */ }
      musicWidget.remove();
      musicWidget = null;
    });
    closeW.classList.add('chat-music-x');
    musicWidget.appendChild(closeW);
    audio.style.display = 'none';
    musicWidget.appendChild(audio);
    pins.after(musicWidget);
    stopOtherAudio(audio);
    audio.play().then(() => { btn.innerHTML = svg('pause'); }).catch(() => {});
  }

  async function openReaders(item) {
    const sh = modal('Кто прочитал');
    sh.body.appendChild(el('p', { class: 'hint', text: 'Загружаю…' }));
    try {
      const r = C.readers ? await C.readers(item.id, thread) : await call('readers', item.id, thread);
      const items = (r && r.items) || [];
      sh.body.replaceChildren();
      const box = el('div', { class: 'chat-readers' });
      if (!items.length) box.appendChild(el('p', { class: 'hint', text: 'Пока никто' }));
      for (const u of items) {
        const row = el('div', { class: 'chat-user-row' });
        row.appendChild(ava(u.avatar, u.nick, false));
        const t = el('p');
        t.appendChild(el('b', { text: u.nick || '' }));
        t.appendChild(el('span', { class: 'hint', text: u.at ? fmtTime(new Date(u.at * 1000).toISOString()) : '' }));
        row.appendChild(t);
        box.appendChild(row);
      }
      sh.body.appendChild(box);
    } catch (e) {
      sh.body.replaceChildren(el('p', { class: 'hint', text: friendlyErr(e, 'Нет данных') }));
    }
  }

  async function react(item, emo) {
    if (prefs.oneLike !== false) {
      const r = canReact(item.id, emo);
      if (r.toggle) {
        const counts = item.reactions || (item.reactions = {});
        counts[emo] = Math.max(0, (counts[emo] || 1) - 1);
        markReact(item.id, emo, false);
      } else {
        const counts = item.reactions || (item.reactions = {});
        if (r.replace && counts[r.replace]) counts[r.replace] = Math.max(0, counts[r.replace] - 1);
        counts[emo] = (counts[emo] || 0) + 1;
        markReact(item.id, emo, true);
      }
    } else {
      const counts = item.reactions || (item.reactions = {});
      counts[emo] = (counts[emo] || 0) + 1;
    }
    const card = list.querySelector('[data-mid="' + item.id + '"]');
    if (card) {
      let reacts = card.querySelector('.chat-reacts');
      if (!reacts) {
        reacts = el('div', { class: 'chat-reacts' });
        const bub = card.querySelector('.chat-bubble');
        if (bub) bub.insertBefore(reacts, bub.querySelector('.chat-meta'));
      }
      if (reacts) paintReacts(item, reacts);
      const st = card.querySelector('.chat-sticker-card');
      if (st && (st.querySelector('.chat-st-like') || st.querySelector('.chat-st-count'))) {
        const hasLike = Number((item.reactions || {})['❤'] || 0) > 0;
        const old = st.querySelector('.chat-st-like') || st.querySelector('.chat-st-count');
        if (old) old.remove();
        if (hasLike) {
          const lc = el('span', { class: 'chat-st-count' });
          lc.appendChild(emoNode('❤'));
          lc.appendChild(el('span', { text: String((item.reactions || {})['❤']) }));
          lc.addEventListener('click', (ev) => { ev.stopPropagation(); react(item, '❤'); });
          st.appendChild(lc);
        } else {
          const like = el('button', { type: 'button', class: 'chat-st-like' });
          like.appendChild(emoNode('❤'));
          like.addEventListener('click', (ev) => { ev.stopPropagation(); react(item, '❤'); });
          st.appendChild(like);
        }
      }
    }
    try { await call('react', item.id, emo); } catch (e) { failToast(e, 'Не получилось поставить реакцию'); }
  }

  function emoNode(emo, extraClass) {
    const wrapN = el('span', { class: 'chat-emo-face' + (extraClass ? ' ' + extraClass : '') });
    const custom = prefs.customEmoji !== false && emojiMap && emojiMap[emo];
    if (custom) {
      const img = el('img', { class: 'chat-cemoji', src: emojiMap[emo], alt: emo, 'data-emo': emo });
      wrapN.appendChild(img);
    } else wrapN.appendChild(document.createTextNode(emo));
    return wrapN;
  }

  function paintReacts(item, host) {
    if (!host) return;
    host.replaceChildren();
    const people = item.reactors || item.reactionUsers || {};
    for (const [e2, n] of Object.entries(item.reactions || {})) {
      if (!n) continue;
      const b = el('button', { class: 'chat-emo', type: 'button', 'data-act': 'react', 'data-emo': e2 });
      b.appendChild(emoNode(e2));
      const users = Array.isArray(people[e2]) ? people[e2] : [];
      if (users.length) {
        const stack = el('span', { class: 'chat-emo-stack' });
        users.slice(0, 3).forEach((u) => {
          const src = typeof u === 'string' ? '' : (u.avatar || '');
          const nick = typeof u === 'string' ? u : (u.nick || '');
          const a = ava(src, nick, false);
          a.classList.add('chat-emo-ava');
          stack.appendChild(a);
        });
        b.appendChild(stack);
        if (n > 3) b.appendChild(el('span', { class: 'chat-emo-n', text: '+' + String(n - Math.min(3, users.length)) }));
        else if (n > users.length) b.appendChild(el('span', { class: 'chat-emo-n', text: String(n) }));
      } else {
        b.appendChild(el('span', { class: 'chat-emo-n', text: String(n) }));
      }
      b.addEventListener('click', (ev) => { ev.stopPropagation(); react(item, e2); });
      host.appendChild(b);
    }
  }

  function openReactPicker(item, near) {
    wrap.querySelectorAll('.chat-react-pick').forEach((n) => n.remove());
    const box = el('div', { class: 'chat-react-pick' });
    const grid = el('div', { class: 'chat-react-grid' });
    const listE = [...new Set([...EMOJI, ...EMOJI_ALL, ...Object.keys(emojiMap || {})])];
    listE.forEach((emo) => {
      const b = el('button', { type: 'button', class: 'chat-react-cell', onclick: () => {
        box.remove();
        if (near && near.remove) near.remove();
        react(item, emo);
      } });
      b.appendChild(emoNode(emo));
      grid.appendChild(b);
    });
    box.appendChild(grid);
    wrap.appendChild(box);
    const boxR = wrap.getBoundingClientRect();
    const src = (near && near.getBoundingClientRect) ? near.getBoundingClientRect() : boxR;
    const w = box.offsetWidth || 280;
    const h = box.offsetHeight || 220;
    box.style.left = Math.max(8, Math.min(src.left - boxR.left, boxR.width - w - 8)) + 'px';
    box.style.top = Math.max(8, Math.min(src.top - boxR.top - h - 8, boxR.height - h - 8)) + 'px';
    const off = (e) => {
      if (!box.contains(e.target)) { box.remove(); document.removeEventListener('mousedown', off); }
    };
    setTimeout(() => document.addEventListener('mousedown', off), 0);
  }

  async function pin(item) {
    try {
      const r = await call('pin', item.id);
      if (r && r.item) {
        const i = itemsCache.findIndex((x) => x.id === item.id);
        if (i >= 0) itemsCache[i] = { ...itemsCache[i], ...r.item };
        item.pinned = Boolean(r.item.pinned);
      } else item.pinned = !item.pinned;
      const card = list.querySelector('[data-mid="' + item.id + '"]');
      if (card) card.classList.toggle('pinned', Boolean(item.pinned));
      paintPins(itemsCache);
      toast(item.pinned ? 'Сообщение закреплено' : 'Сообщение откреплено');
    } catch (e) { failToast(e, 'Не получилось закрепить'); }
  }
  async function saveGif(url) {
    try { await call('saveGif', url); toast('GIF сохранён'); } catch (e) { failToast(e, 'Не получилось сохранить GIF'); }
  }
  async function delMsg(item, forAll) {
    try {
      const all = Boolean(forAll) && isAdmin();
      if (C.delete) await C.delete(item.id, all);
      else await call('delete', item.id);
      item.pinned = false;
      itemsCache = itemsCache.filter((x) => x.id !== item.id);
      const card = list.querySelector('[data-mid="' + item.id + '"]');
      if (card) card.remove();
      paintPins(itemsCache);
      if (replyTo && replyTo.id === item.id) { replyTo = null; paintReply(); }
      if (editTarget && editTarget.id === item.id) { editTarget = null; paintReply(); }
      toast(all ? 'Удалено для всех' : 'Удалено только у тебя');
    } catch (e) { failToast(e, 'Не получилось удалить'); }
  }
  async function reportMsg(item) {
    try { await call('report', item.id); toast('Жалоба ушла'); } catch (e) { failToast(e, 'Не получилось отправить жалобу'); }
  }
  async function editMsg(item) {
    editTarget = item;
    setInputText(item.text || item.caption || '');
    input.focus();
    paintReply();
    if (item.kind === 'image' || item.kind === 'gif') {
      if (item.url) {
        pendingFile = { kind: item.kind, name: item.name || 'photo.jpg', b64: '', preview: mediaMem.get(item.url) || item.url, editId: item.id };
        openAttachPreview();
      }
    }
    toast('Редактирование · Enter чтобы сохранить');
  }
  async function fwdMsg(item) {
    openFwdModal(item);
  }
  async function saveFav(item) {
    try {
      if (C.saveMessage) await C.saveMessage(item.id);
      else await call('saveMessage', item.id);
      toast('В избранном');
    } catch (e) { failToast(e, 'Не получилось'); }
  }

  function setReply(item) {
    replyTo = item;
    paintReply();
    input.focus();
  }

  function warmMedia(url) {
    if (!url || mediaMem.has(url)) return mediaMem.get(url) || url;
    const img = new Image();
    img.decoding = 'async';
    img.referrerPolicy = 'no-referrer';
    img.src = url;
    mediaMem.set(url, url);
    if (C.cacheMedia && !String(url).startsWith('data:')) {
      C.cacheMedia(url).then((r) => {
        const src = (r && (r.src || r)) || url;
        if (typeof src === 'string' && src) mediaMem.set(url, src);
      }).catch(() => {});
    }
    return url;
  }

  function mediaImg(url, cls, alt, onClick) {
    const wrap = el('div', { class: 'chat-media-wrap' });
    const cached = mediaMem.get(url) || url;
    const play = prefs.animPlay || 'viewport';
    if (isVideoUrl(url) || /\.webm(\?|$)/i.test(String(url || ''))) {
      const v = document.createElement('video');
      v.className = cls || 'chat-media';
      v.muted = true;
      v.playsInline = true;
      v.loop = play !== 'once';
      v.setAttribute('data-anim', cached);
      v.preload = 'metadata';
      if (play === 'never') v.poster = cached;
      else if (play === 'always') { v.src = cached; v.autoplay = true; }
      wrap.appendChild(v);
      watchMedia(v);
      if (onClick) v.addEventListener('click', onClick);
      return wrap;
    }
    const img = el('img', { class: cls || 'chat-media', alt: alt || '' });
    img.decoding = 'async';
    img.referrerPolicy = 'no-referrer';
    img.setAttribute('data-anim', cached);
    const still = mediaMem.get(url + ':still');
    if (still) img.setAttribute('data-still', still);
    img.src = (play === 'always' || !isAnimUrl(url)) ? cached : (still || cached);
    if (play !== 'always' && isAnimUrl(url)) watchMedia(img);
    img.addEventListener('error', () => { img.replaceWith(el('div', { class: 'chat-text', text: alt || 'файл' })); }, { once: true });
    if (C.cacheMedia && url && !String(url).startsWith('data:') && !mediaMem.has(url)) {
      C.cacheMedia(url).then((r) => {
        const src = (r && (r.src || r)) || url;
        if (typeof src === 'string' && src) {
          mediaMem.set(url, src);
          if (img.isConnected && play === 'always') img.src = src;
          img.setAttribute('data-anim', src);
        }
      }).catch(() => {});
    }
    if (onClick) img.addEventListener('click', onClick);
    wrap.appendChild(img);
    return wrap;
  }

  function stopOtherAudio(keep) {
    wrap.querySelectorAll('audio').forEach((n) => {
      if (n !== keep) {
        try { n.pause(); } catch (_) { /* */ }
      }
    });
  }

  function fmtDur(sec) {
    const n = Math.max(0, Math.floor(Number(sec) || 0));
    return String(Math.floor(n / 60)) + ':' + String(n % 60).padStart(2, '0');
  }

  function audioCard(item) {
    const box = el('div', { class: 'chat-audio-card' });
    const audio = document.createElement('audio');
    const src = mediaMem.get(item.url) || item.url;
    audio.src = src;
    audio.preload = 'auto';
    audio.playsInline = true;
    const btn = icon('play', 'Играть', () => {
      if (audio.paused) {
        stopOtherAudio(audio);
        audio.play().then(() => { btn.innerHTML = svg('pause'); }).catch((e) => failToast(e, 'Не играет'));
      } else {
        audio.pause();
        btn.innerHTML = svg('play');
      }
    });
    btn.classList.add('chat-music-play');
    audio.addEventListener('play', () => { btn.innerHTML = svg('pause'); });
    audio.addEventListener('pause', () => { btn.innerHTML = svg('play'); });
    audio.addEventListener('ended', () => { btn.innerHTML = svg('play'); });
    audio.addEventListener('error', () => { btn.innerHTML = svg('play'); toast('Аудио не загрузилось', 'bad'); });
    const meta = el('div', { class: 'chat-audio-meta' });
    meta.appendChild(el('b', { text: item.name || 'Аудио' }));
    const time = el('span', { text: '0:00' });
    meta.appendChild(time);
    const bar = el('div', { class: 'chat-audio-bar' });
    const fill = el('i');
    bar.appendChild(fill);
    bar.addEventListener('click', (e) => {
      if (!audio.duration) return;
      const r = bar.getBoundingClientRect();
      audio.currentTime = ((e.clientX - r.left) / r.width) * audio.duration;
    });
    audio.addEventListener('timeupdate', () => {
      fill.style.width = audio.duration ? Math.round((audio.currentTime / audio.duration) * 100) + '%' : '0%';
      time.textContent = fmtDur(audio.currentTime) + (audio.duration ? ' / ' + fmtDur(audio.duration) : '');
    });
    audio.addEventListener('loadedmetadata', () => { time.textContent = '0:00 / ' + fmtDur(audio.duration); });
    meta.appendChild(bar);
    box.appendChild(btn);
    box.appendChild(meta);
    box.appendChild(audio);
    return box;
  }

  function pollCard(item) {
    const p = el('div', { class: 'chat-poll' });
    p.appendChild(el('strong', { text: item.poll.question || item.text || 'Опрос' }));
    const votes = item.poll.votes || [];
    const total = votes.reduce((a, b) => a + (Number(b) || 0), 0);
    const anon = item.poll.anonymous !== false && item.poll.public !== true;
    (item.poll.options || []).forEach((opt, i) => {
      const n = votes[i] || 0;
      const pct = total ? Math.round((n / total) * 100) : 0;
      const b = el('button', {
        class: 'chat-poll-opt',
        type: 'button',
        onclick: async () => {
          try {
            const r = await call('vote', item.id, i);
            if (r && r.item) {
              Object.assign(item, r.item);
              const card = list.querySelector('[data-mid="' + item.id + '"]');
              const next = bubble(item);
              if (card && next) card.replaceWith(next);
            } else loadFresh();
          } catch (e) { failToast(e, 'Не получилось'); }
        }
      });
      const bar = el('i');
      bar.style.width = pct + '%';
      b.appendChild(bar);
      const row = el('div', { class: 'chat-poll-row' });
      row.appendChild(el('span', { text: opt }));
      row.appendChild(el('span', { class: 'pct', text: pct + '% · ' + n }));
      b.appendChild(row);
      if (!anon && item.poll.voters && item.poll.voters[i]) {
        b.appendChild(el('div', { class: 'chat-poll-voters', text: (item.poll.voters[i] || []).join(', ') }));
      }
      p.appendChild(b);
    });
    return p;
  }

  function bubble(item) {
    const mine = me && me.ok && item.nick === me.nick;
    const isSys = item.kind === 'system' || item.thread === 'system' || thread === 'system';
    const card = el('div', { class: 'chat-msg' + (mine ? ' mine' : '') + (isSys ? ' sys' : '') + (item.kind ? ' kind-' + item.kind : '') + (item.pending ? ' pending' : '') + (item.failed ? ' failed' : '') + (selectMode ? ' select-on' : '') + (selectedIds.has(item.id) ? ' picked' : '') });
    if (item.id) card.setAttribute('data-mid', item.id);
    if (item.pinned) card.classList.add('pinned');
    if (selectMode) card.appendChild(el('span', { class: 'chat-sel-dot' }));
    if (item.deleted) return null;
    if (isSys) {
      const sys = el('div', { class: 'chat-sys' });
      sys.appendChild(renderText(item.text || item.caption || ''));
      card.appendChild(sys);
      return card;
    }
    if (!mine) {
      const cachedU = userCache.get(item.nick) || {};
      const avSrc = item.avatar || cachedU.avatar || '';
      const hatSrc = item.avatarHat || hatUrl(item, 'avatarHat', shopMap) || hatUrl(cachedU, 'avatarHat', shopMap);
      const av = ava(avSrc, item.nick, Boolean(item.online || cachedU.online), { avatarHat: hatSrc, cls: 'msg' });
      av.classList.add('tiny', 'chat-msg-ava');
      av.addEventListener('click', () => openProfile(item.nick));
      card.appendChild(av);
      if (item.nick && C.user && !userCache.has(item.nick)) {
        userCache.set(item.nick, { nick: item.nick });
        C.user(item.nick).then((r) => {
          const u = (r && r.user) || r;
          if (!u) return;
          userCache.set(item.nick, u);
          item.avatar = u.avatar || item.avatar;
          item.avatarHat = hatUrl(u, 'avatarHat', shopMap) || item.avatarHat;
          const next = ava(item.avatar, item.nick, Boolean(u.online), { avatarHat: item.avatarHat, cls: 'msg' });
          next.classList.add('tiny', 'chat-msg-ava');
          next.addEventListener('click', () => openProfile(item.nick));
          if (av.isConnected) av.replaceWith(next);
        }).catch(() => {});
      }
    }
    // === СТИКЕР === показываем без пузыря: сам стикер, время и лайк по углам ===
    if (item.kind === 'sticker' && item.url) {
      const isMine = mine;
      const stWrap = el('div', { class: 'chat-sticker-card' + (isMine ? ' mine' : '') + (item.pending ? ' pending' : '') + (item.failed ? ' failed' : '') });
      stWrap.dataset.stTime = fmtTime(item.at);
      if (isMine) {
        const ticks = el('span', { class: 'chat-ticks' + (item.pending ? ' wait' : '') + (item.failed ? ' bad' : '') });
        ticks.innerHTML = item.failed ? svg('x') : svg(item.pending ? 'clock' : (item.read ? 'ticks' : 'tick'));
        stWrap.appendChild(ticks);
      }
      stWrap.appendChild(mediaImg(item.url, 'chat-sticker', item.name || 'стикер', () => lightbox(mediaMem.get(item.url) || item.url, 'image')));
      // красивый бейдж времени, виден при наведении
      stWrap.appendChild(el('span', { class: 'chat-st-time', text: fmtTime(item.at) }));
      stWrap.addEventListener('click', (e) => {
        e.stopPropagation();
        if (e.target.closest('.chat-st-like')) return;
        ctxMenu(e.clientX, e.clientY, item);
      });
      // лайк по углу: если лайк уже поставлен (мной или другими) — показываем счётчик, иначе кнопку
      const hasLike = Number((item.reactions || {})['❤'] || 0) > 0;
      if (hasLike) {
        const lc = el('span', { class: 'chat-st-count' });
        lc.appendChild(emoNode('❤'));
        lc.appendChild(el('span', { text: String((item.reactions || {})['❤']) }));
        lc.addEventListener('click', (ev) => { ev.stopPropagation(); react(item, '❤'); });
        stWrap.appendChild(lc);
      } else {
        const like = el('button', { type: 'button', class: 'chat-st-like', 'data-act': 'like', 'data-emo': '❤' });
        like.appendChild(emoNode('❤'));
        like.addEventListener('click', (ev) => { ev.stopPropagation(); react(item, '❤'); });
        stWrap.appendChild(like);
      }
      card.appendChild(stWrap);
      return card;
    }
    const bubbleEl = el('div', { class: 'chat-bubble' });
    const bStyle = item.bubbleStyle || (mine && ((me && me.bubbleStyle) || prefs.bubbleStyle)) || '';
    if (bStyle && bStyle !== 'tg') bubbleEl.classList.add('chat-bubble-style-' + bStyle);
    if (item.nameColor) bubbleEl.style.setProperty('--name-c', item.nameColor);
    if (!mine) {
      const row = el('div', { class: 'chat-msg-top' });
      const nick = nickRow(item.nick || 'гость', item.badges || (item.role === 'admin' ? ['official'] : item.role === 'bot' ? ['official'] : []), item.role === 'admin' ? 'admin' : (item.role === 'mod' ? 'mod' : (item.role === 'bot' ? 'bot' : '')));
      if (item.nameColor) nick.querySelector('b').style.color = item.nameColor;
      nick.addEventListener('click', () => openProfile(item.nick));
      row.appendChild(nick);
      if (item.streak || item.streakTier || item.streakGray) {
        row.appendChild(flameNode({
          days: item.streak || 0,
          lit: Boolean(item.streak) && !item.streakGray,
          gray: Boolean(item.streakGray),
          tier: item.streakTier || ''
        }));
      }
      bubbleEl.appendChild(row);
    }
    if (item.forwardedFrom) {
      const fwd = el('button', { type: 'button', class: 'chat-fwd', title: 'Открыть профиль' });
      const ic = el('span', { class: 'chat-fwd-ico' });
      ic.innerHTML = svg('share');
      fwd.appendChild(ic);
      fwd.appendChild(el('span', { text: 'Переслано от ' + item.forwardedFrom }));
      fwd.addEventListener('click', (e) => { e.stopPropagation(); openProfile(item.forwardedFrom); });
      bubbleEl.appendChild(fwd);
    }
    if (item.reply) {
      const r = el('div', { class: 'chat-reply' });
      r.appendChild(el('b', { text: item.reply.nick || '' }));
      r.appendChild(document.createTextNode(item.reply.text || item.reply.kind || ''));
      bubbleEl.appendChild(r);
    }
    if (item.kind === 'poll' && item.poll) bubbleEl.appendChild(pollCard(item));
    else if ((item.kind === 'image' || item.kind === 'gif') && item.url) {
      if (!item.caption) card.classList.add('bare-media');
      const media = mediaImg(item.url, 'chat-media' + (item.spoiler ? ' spoiler' : ''), item.name || item.kind, () => {
        if (item.spoiler) { media.querySelector('img')?.classList.toggle('on'); return; }
        lightbox(mediaMem.get(item.url) || item.url, item.kind);
      });
      bubbleEl.appendChild(media);
      card._mediaWrap = media;
    } else if (item.kind === 'sticker' && item.url) {
      // Стикер уже обработан отдельным блоком выше (.chat-sticker-card)
    } else if ((item.kind === 'audio' || item.kind === 'voice') && item.url) {
      bubbleEl.appendChild(audioCard(item));
    } else {
      bubbleEl.appendChild(renderText(item.text, prefs.customEmoji !== false ? emojiMap : null));
      bubbleEl.querySelectorAll('.mention').forEach((n) => {
        n.addEventListener('click', (e) => { e.stopPropagation(); openProfile(n.getAttribute('data-nick')); });
      });
      bubbleEl.querySelectorAll('.chat-tag').forEach((n) => {
        n.addEventListener('click', (e) => { e.stopPropagation(); openSearch('#' + n.getAttribute('data-tag')); });
      });
      const u = firstUrl(item.text);
      if (u) {
        const share = parseShare(u) || (/^Cryn:\/\//i.test(String(item.text || '')) ? parseShare(item.text) : null);
        if (share) {
          const txt = bubbleEl.querySelector('.chat-text');
          if (txt) txt.remove();
          bubbleEl.appendChild(shareCard(share, u));
        }
        else {
          const vid = ytId(u);
          if (vid) {
            const fr = document.createElement('iframe');
            fr.className = 'chat-yt';
            fr.src = 'https://www.youtube.com/embed/' + vid;
            fr.allow = 'accelerometer; autoplay; encrypted-media; picture-in-picture';
            bubbleEl.appendChild(fr);
          } else attachLinkPreview(bubbleEl, u);
        }
      }
    }
    if (item.caption) {
      const cap = renderText(item.caption, prefs.customEmoji !== false ? emojiMap : null);
      cap.classList.add('chat-caption');
      bubbleEl.appendChild(cap);
    }
    if (item.buttons && item.buttons.length) {
      const row = el('div', { class: 'chat-bot-btns' });
      item.buttons.forEach((b) => {
        row.appendChild(el('button', { type: 'button', text: b.text || b, onclick: () => {
          if (b.url) window.open(b.url, '_blank');
          else sendBotCmd(b.cmd || b.text || b);
        } }));
      });
      bubbleEl.appendChild(row);
    }
    const reacts = el('div', { class: 'chat-reacts' });
    paintReacts(item, reacts);
    if (reacts.childNodes.length) bubbleEl.appendChild(reacts);
    const meta = el('div', { class: 'chat-meta' });
    if (item.pinned) {
      const pinIco = el('span', { class: 'chat-pin-ico', title: 'Закреплено' });
      pinIco.innerHTML = svg('pin');
      meta.appendChild(pinIco);
    }
    meta.appendChild(el('span', { class: 'chat-time', text: fmtTime(item.at) + (item.edited ? ' · изм.' : '') }));
    if (mine) {
      const ticks = el('span', { class: 'chat-ticks' + (item.pending ? ' wait' : '') + (item.failed ? ' bad' : '') });
      ticks.innerHTML = item.failed ? svg('x') : svg(item.pending ? 'clock' : (item.read ? 'ticks' : 'tick'));
      meta.appendChild(ticks);
    }
    if (card._mediaWrap && !item.caption) card._mediaWrap.appendChild(meta);
    else bubbleEl.appendChild(meta);
    const hasAnyReact = Object.values(item.reactions || {}).some((n) => n > 0);
    if (!hasAnyReact) {
      const likeBtn = el('button', { type: 'button', class: 'chat-hover-like', title: 'Нравится' });
      likeBtn.appendChild(emoNode('❤'));
      likeBtn.addEventListener('click', (ev) => { ev.stopPropagation(); react(item, '❤'); });
      card.appendChild(likeBtn);
    }
    if (String(item.thread || thread || '').startsWith('kanal:') || thread === 'channel') {
      const cmtBtn = el('button', { type: 'button', class: 'chat-cmt-ico', title: 'Комментарии' });
      const cnt = Number(item.comments || item.commentCount || 0);
      cmtBtn.innerHTML = svg('comment') + (cnt ? '<span>' + cnt + '</span>' : '');
      cmtBtn.addEventListener('click', (ev) => { ev.stopPropagation(); openComments(item); });
      bubbleEl.appendChild(cmtBtn);
    }
    card.appendChild(bubbleEl);
    return card;
  }

  function pinnedList(items) {
    return (items || []).filter((x) => x && x.pinned && !x.deleted)
      .sort((a, b) => (Number(b.pinAt || 0) - Number(a.pinAt || 0)) || String(b.at || '').localeCompare(String(a.at || '')));
  }

  function jumpToPinned(item) {
    if (!item || !item.id) return;
    const go = (card) => {
      const listR = list.getBoundingClientRect();
      const top = card.getBoundingClientRect().top - listR.top;
      const target = list.scrollTop + top - (list.clientHeight / 2) + (card.offsetHeight / 2);
      list.scrollTo({ top: Math.max(0, target), behavior: prefs.reduceMotion ? 'auto' : 'smooth' });
      card.classList.add('picked', 'pin-flash');
      setTimeout(() => card.classList.remove('picked', 'pin-flash'), 1200);
    };
    let card = list.querySelector('[data-mid="' + item.id + '"]');
    if (card) { go(card); return; }
    const ordered = visItems();
    const idx = ordered.findIndex((x) => x && x.id === item.id);
    if (idx < 0) {
      toast('Сообщение ещё не загружено. Прокрути историю вверх.');
      return;
    }
    const sizes = virt.sizes(ordered);
    const row = sizes.rows[idx];
    if (!row) return;
    list.scrollTop = Math.max(0, row.start - 80);
    // дождаться отрисовки виртуального списка и докрутить точно к центру
    idle(() => {
      const c2 = list.querySelector('[data-mid="' + item.id + '"]');
      if (c2 && c2.isConnected) go(c2);
    });
  }

  function paintPins(items) {
    const pinned = pinnedList(items);
    pins.replaceChildren();
    if (!pinned.length) {
      pins.classList.add('hidden');
      pinCycle = 0;
      return;
    }
    pins.classList.remove('hidden');
    if (pinCycle >= pinned.length) pinCycle = 0;
    const cur = pinned[pinCycle] || pinned[0];
    pins.appendChild(el('span', { class: 'chat-pin-accent' }));
    const ico = el('span', { class: 'chat-pin-ico' });
    ico.innerHTML = svg('pin');
    pins.appendChild(ico);
    const body = el('div', { class: 'chat-pin-body' });
    body.appendChild(el('b', { class: 'chat-pin-lab', text: pinned.length > 1 ? ('Закреплено · ' + (pinCycle + 1) + '/' + pinned.length) : 'Закреплено' }));
    body.appendChild(el('span', { class: 'chat-pin-text', text: (cur.nick ? cur.nick + ': ' : '') + pinPreview(cur).slice(0, 90) }));
    pins.appendChild(body);
    if (pinned.length > 1) {
      pins.appendChild(el('span', { class: 'chat-pin-count', text: String(pinned.length) }));
    }
    const unpin = icon('x', 'Открепить', (e) => {
      e.stopPropagation();
      pin(cur);
    });
    unpin.classList.add('chat-pin-x');
    pins.appendChild(unpin);
    const thumbUrl = (cur.kind === 'image' || cur.kind === 'gif' || cur.thumb) ? (cur.thumb || cur.url) : '';
    if (thumbUrl) {
      const th = el('img', { class: 'chat-pin-thumb', alt: '' });
      th.src = mediaMem.get(thumbUrl) || thumbUrl;
      pins.insertBefore(th, body);
    }
    pins.onclick = (e) => {
      if (e.target.closest('.chat-pin-x')) return;
      const listP = pinnedList(itemsCache);
      if (!listP.length) return;
      jumpToPinned(listP[pinCycle % listP.length]);
      pinCycle = (pinCycle + 1) % listP.length;
      paintPins(itemsCache);
    };
  }

  function visItems() {
    const ordered = [...itemsCache].filter((x) => x && !x.deleted).reverse();
    return ordered;
  }

  function paintVirt(keepBottom) {
    const ordered = visItems();
    virt.compact = Boolean(prefs.compact);
    const view = list.clientHeight || 640;
    if (keepBottom) list.scrollTop = Math.max(0, (virt.sizes(ordered).total) - view);
    const v = virt.getVirtualItems(ordered, list.scrollTop, view);
    virtRange = { start: v.start, end: v.end };
    const frag = document.createDocumentFragment();
    const top = el('div', { class: 'chat-virt-pad' });
    top.style.height = v.padTop + 'px';
    frag.appendChild(top);
    let lastDay = '';
    const seen = new Set();
    for (const row of v.items) {
      const item = row.item;
      if (!item || seen.has(item.id)) continue;
      seen.add(item.id);
      const day = fmtDay(item.at);
      if (day && day !== lastDay) {
        frag.appendChild(el('div', { class: 'chat-day', text: day }));
        lastDay = day;
      }
      const node = bubble(item);
      if (node) {
        frag.appendChild(node);
      }
    }
    const bot = el('div', { class: 'chat-virt-pad' });
    bot.style.height = v.padBot + 'px';
    frag.appendChild(bot);
    const keepY = keepBottom ? Math.max(0, virt.sizes(ordered).total - view) : list.scrollTop;
    releaseMedia(list);
    list.replaceChildren(frag);
    list.scrollTop = keepY;
    idle(() => {
      if (list._measuring) return;
      let changed = false;
      list.querySelectorAll('.chat-msg[data-mid]').forEach((n) => {
        const id = n.getAttribute('data-mid');
        const h = n.getBoundingClientRect().height;
        const prev = virt.heightMap.get(id) || 0;
        rememberHeight(id, h);
        if (Math.abs(prev - h) > 6) changed = true;
      });
      if (changed) {
        list._measuring = true;
        paintVirt(keepBottom);
        list._measuring = false;
      }
    });
    prefetchAhead(ordered, v.end);
  }

  function paintList(items, reset) {
    if (reset) {
      paintVirt(atBottom);
      return;
    }
    paintVirt(false);
  }

  function appendLive(item) {
    if (!item || !item.id) return;
    if (itemsCache.some((x) => x.id === item.id)) return;
    batchIncoming(item, (pack) => {
      const near = list.scrollHeight - list.scrollTop - list.clientHeight < 80;
      const frag = document.createDocumentFragment();
      for (const it of pack) {
        if (!it || !it.id || itemsCache.some((x) => x.id === it.id)) continue;
        itemsCache.unshift(it);
        lastId = it.id;
        lastMsgMap[thread] = it;
        const node = bubble(it);
        if (node) {
          if (!prefs.reduceMotion || prefs.fancyAnim) node.classList.add('enter');
          frag.appendChild(node);
        }
      }
      if (frag.childNodes.length) list.appendChild(frag);
      if (near || (me && pack.some((p) => p.nick === me.nick))) {
        list.scrollTop = list.scrollHeight;
        atBottom = true;
        unreadMiss = 0;
        jumpBtn.classList.add('hidden');
      } else {
        unreadMiss += pack.length;
        jumpBadge.textContent = String(unreadMiss);
        jumpBadge.classList.remove('hidden');
        jumpBtn.classList.remove('hidden');
      }
    }, 120);
  }

  function prefetchAhead(ordered, from) {
    if (!C.cacheMediaMany) return;
    const urls = [];
    for (const it of ordered.slice(Math.max(0, from), from + 28)) {
      if (it && it.url) urls.push(it.url);
      if (it && it.avatar) urls.push(it.avatar);
    }
    prefetchUrls(urls, (u) => C.cacheMediaMany(u), 28);
  }

  async function loadMore(reset) {
    if (loading) return;
    if (!reset && done) return;
    loading = true;
    if (reset && !itemsCache.length) {
      offset = 0;
      done = false;
    }
    try {
      if (reset && prefs.cacheMsgs !== false) {
        try {
          const cached = await idb.msgsGet(thread);
          if (cached.length && !itemsCache.length) {
            itemsCache = cached;
            paintList(itemsCache.slice(0, 40), true);
          }
        } catch (_) { /* */ }
      }
      const lastSeq = reset ? 0 : (itemsCache[itemsCache.length - 1] && itemsCache[itemsCache.length - 1].seq) || 0;
      const data = await call('messages', { before: reset ? 0 : offset, before_seq: reset ? 0 : lastSeq, limit: 40, thread });
      if (data && data.limits) applyServerLimits(data);
      const items = (data && data.items) || [];
      if (reset) {
        const map = new Map();
        for (const it of [...itemsCache, ...items]) if (it && it.id) map.set(it.id, it);
        itemsCache = [...map.values()].sort((a, b) => String(b.at || '').localeCompare(String(a.at || '')));
        itemsCache.forEach((it) => {
          if (it.deleted) it.pinned = false;
          if (it.url) warmMedia(it.url);
          if (it.avatar) warmMedia(it.avatar);
        });
        if (!itemsCache.length) {
          list.replaceChildren(el('p', { class: 'chat-empty', text: data && data.offline ? 'Офлайн · кэш пуст' : 'Пока тихо. Напиши первым.' }));
        } else paintList(itemsCache.slice(0, Math.max(items.length, 40)), true);
        offset = items.length || itemsCache.length;
        paintPins(itemsCache);
        if (prefs.cacheMsgs !== false) idb.msgsSet(thread, itemsCache).catch(() => {});
        if (itemsCache[0]) {
          lastId = itemsCache[0].id;
          lastMsgMap[thread] = itemsCache[0];
        }
        if (C.markRead) {
      C.markRead(thread).then((r) => {
        if (me) {
          if (thread === 'global') me.unread = 0;
          else if (thread === 'system') me.unreadSystem = 0;
          else if (thread === 'channel') me.unreadChannel = 0;
          else if (thread === 'saved') me.unreadSaved = 0;
          if (r && typeof r.unread === 'number') me.unread = r.unread;
        }
        const dm = (dmsMem.items || []).find((x) => x.thread === thread);
        if (dm) dm.unread = 0;
        paintSidebar();
      }).catch(() => {});
    }
        restoreScroll();
      } else {
        const prevH = list.scrollHeight;
        const prevTop = list.scrollTop;
        itemsCache = itemsCache.concat(items);
        paintVirt(false);
        const delta = list.scrollHeight - prevH;
        if (delta) list.scrollTop = prevTop + delta;
        offset += items.length;
      }
      done = Boolean(data && data.done) || items.length < 40;
    } catch (e) {
      if (reset && !itemsCache.length) list.replaceChildren(el('p', { class: 'hint', text: friendlyErr(e, 'Чат недоступен') }));
    }
    loading = false;
  }

  async function loadFresh() {
    await loadMore(true);
  }

  function restoreScroll() {
    if (!C.scrollMap) {
      list.scrollTop = list.scrollHeight;
      return;
    }
    C.scrollMap().then((m) => {
      const s = m && m[thread];
      if (s && typeof s.top === 'number') list.scrollTop = s.top;
      else list.scrollTop = list.scrollHeight;
    }).catch(() => { list.scrollTop = list.scrollHeight; });
  }

  function attachLinkPreview(card, url) {
    if (linkCache.has(url)) {
      const meta = linkCache.get(url);
      if (meta) card.appendChild(linkCard(meta, url));
      return;
    }
    const fallback = { title: url.replace(/^https?:\/\//, '').slice(0, 48), desc: '', img: '' };
    const apply = (meta) => {
      linkCache.set(url, meta);
      if (card.isConnected) card.appendChild(linkCard(meta, url));
    };
    if (C.linkPreview) {
      C.linkPreview(url).then((r) => apply((r && r.preview) || fallback)).catch(() => apply(fallback));
      return;
    }
    apply(fallback);
  }

  function linkCard(meta, url) {
    const n = el('a', { class: 'chat-link-card', href: url, rel: 'noreferrer', target: '_blank' });
    if (meta.img) {
      const img = el('img', { alt: '' });
      img.src = meta.img;
      n.appendChild(img);
    }
    const coln = el('div');
    coln.appendChild(el('b', { text: meta.title || url }));
    if (meta.desc) coln.appendChild(el('span', { text: meta.desc }));
    n.appendChild(coln);
    return n;
  }

  list.addEventListener('scroll', () => {
    if (list.scrollTop < 48) loadMore(false);
    atBottom = list.scrollHeight - list.scrollTop - list.clientHeight < 80;
    if (atBottom) {
      unreadMiss = 0;
      jumpBtn.classList.add('hidden');
      jumpBadge.classList.add('hidden');
    } else jumpBtn.classList.remove('hidden');
    if (C.setScroll) {
      clearTimeout(list._st);
      list._st = setTimeout(() => C.setScroll(thread, { top: list.scrollTop, id: lastId }).catch(() => {}), 180);
    }
    if (list._raf) cancelAnimationFrame(list._raf);
    list._raf = requestAnimationFrame(() => {
      const ordered = visItems();
      const view = list.clientHeight || 640;
      const v = virt.getVirtualItems(ordered, list.scrollTop, view);
      if (v.start === virtRange.start && v.end === virtRange.end) return;
      paintVirt(false);
    });
  });
  list.addEventListener('click', (e) => {
    const card = e.target.closest('.chat-msg');
    if (!card) return;
    const id = card.getAttribute('data-mid');
    const item = itemsCache.find((x) => x.id === id);
    if (!item) return;
    const act = e.target.closest('[data-act]');
    if (act) {
      const a = act.getAttribute('data-act');
      if (a === 'react') react(item, act.getAttribute('data-emo') || '❤');
      else if (a === 'edit') editMsg(item);
      else if (a === 'reply') setReply(item);
      else if (a === 'select') enterSelect(item);
      else if (a === 'fwd') fwdMsg(item);
      else if (a === 'del') delMsg(item, isAdmin());
      e.stopPropagation();
      return;
    }
    if (selectMode) {
      if (selectedIds.has(item.id)) selectedIds.delete(item.id);
      else selectedIds.add(item.id);
      paintSelectBar();
      card.classList.toggle('picked', selectedIds.has(item.id));
    }
  });
  list.addEventListener('contextmenu', (e) => {
    const card = e.target.closest('.chat-msg');
    if (!card) return;
    e.preventDefault();
    const item = itemsCache.find((x) => x.id === card.getAttribute('data-mid'));
    if (item) ctxMenu(e.clientX, e.clientY, item);
  });
  list.addEventListener('dblclick', (e) => {
    const card = e.target.closest('.chat-msg');
    if (!card) return;
    const item = itemsCache.find((x) => x.id === card.getAttribute('data-mid'));
    if (item) react(item, '❤');
  });
  jumpBtn.addEventListener('click', () => {
    list.scrollTo({ top: list.scrollHeight, behavior: prefs.reduceMotion ? 'auto' : 'smooth' });
    unreadMiss = 0;
    jumpBtn.classList.add('hidden');
    jumpBadge.classList.add('hidden');
  });

  const replyBar = el('div', { class: 'chat-reply-bar hidden' });
  const attachPrev = el('div', { class: 'chat-attach-preview hidden' });
  const composeRow = el('div', { class: 'chat-compose-row' });
  const input = el('div', { class: 'field chat-input', contenteditable: 'true', role: 'textbox' });
  input.setAttribute('data-placeholder', 'Сообщение');
  composeRow.appendChild(icon('attach', 'Вложение', () => openAttach()));
  composeRow.appendChild(input);
  composeRow.appendChild(icon('smile', 'Эмодзи и стикеры', () => toggleStickers()));
  const sendBtn = icon('send', 'Отправить', sendText, 'send');
  sendBtn.addEventListener('contextmenu', (e) => {
    e.preventDefault();
    menu(sendBtn, [
      { icon: 'send', label: 'Сейчас', onclick: () => { delete composer.dataset.at; sendText(); } },
      { icon: 'bell', label: 'Без звука', onclick: () => { composer.dataset.silent = '1'; sendText(); } },
      { icon: 'clock', label: 'Когда буду в сети', onclick: () => { composer.dataset.at = 'online'; sendText(); } },
      { icon: 'pin', label: 'Через 5 мин', onclick: () => { composer.dataset.at = String(Math.floor(Date.now() / 1000) + 300); sendText(); } }
    ], { place: 'up' });
  });
  composeRow.appendChild(sendBtn);
  composer.appendChild(replyBar);
  composer.appendChild(attachPrev);
  composer.appendChild(composeRow);
  const fmtPop = el('div', { class: 'chat-fmt-pop hidden' });
  fmtPop.appendChild(icon('bold', 'Жирный', () => applyFmt('bold')));
  fmtPop.appendChild(icon('italic', 'Курсив', () => applyFmt('italic')));
  fmtPop.appendChild(icon('strike', 'Зачёркнутый', () => applyFmt('strikeThrough')));
  fmtPop.appendChild(icon('code', 'Код', () => applyFmt('code')));
  fmtPop.appendChild(icon('spoiler', 'Спойлер', () => applyFmt('spoiler')));
  fmtPop.appendChild(icon('link', 'Ссылка', () => applyFmt('link')));
  wrap.appendChild(fmtPop);
  function inputText() {
    const md = htmlToMd(input);
    if (md) return md;
    return String(input.innerText || input.textContent || '').replace(/\u00a0/g, ' ').trim();
  }
  function setInputText(v) {
    if (!v) { input.textContent = ''; return; }
    input.innerHTML = mdToHtml(v);
  }
  function applyFmt(cmd) {
    input.focus();
    if (cmd === 'code') document.execCommand('insertHTML', false, '<code>' + (window.getSelection() + '') + '</code>');
    else if (cmd === 'spoiler') document.execCommand('insertHTML', false, '<span class="spoiler">' + (window.getSelection() + '') + '</span>');
    else if (cmd === 'link') {
      const url = window.prompt('Ссылка', 'https://');
      if (url) document.execCommand('createLink', false, url);
    } else document.execCommand(cmd, false, null);
    hideFmtPop();
  }
  function hideFmtPop() { fmtPop.classList.add('hidden'); }
  function showFmtPop() {
    const sel = window.getSelection();
    if (!sel || sel.isCollapsed || !input.contains(sel.anchorNode)) { hideFmtPop(); return; }
    const r = sel.getRangeAt(0).getBoundingClientRect();
    const box = wrap.getBoundingClientRect();
    fmtPop.classList.remove('hidden');
    fmtPop.style.left = Math.max(8, r.left - box.left) + 'px';
    fmtPop.style.top = Math.max(8, r.top - box.top - 40) + 'px';
  }

  function paintReply() {
    replyBar.replaceChildren();
    if (!replyTo && !editTarget) { replyBar.classList.add('hidden'); return; }
    replyBar.classList.remove('hidden');
    const grow = el('div', { class: 'grow' });
    if (editTarget) {
      grow.appendChild(el('b', { text: 'Редактирование' }));
      grow.appendChild(document.createTextNode(' ' + String(editTarget.text || '').slice(0, 80)));
    } else {
      grow.appendChild(el('b', { text: replyTo.nick || '' }));
      grow.appendChild(document.createTextNode(' ' + String(replyTo.text || replyTo.kind || '').slice(0, 80)));
    }
    replyBar.appendChild(grow);
    replyBar.appendChild(icon('x', 'Снять', () => { replyTo = null; editTarget = null; paintReply(); }));
  }

  function paintAttach() {
    attachPrev.replaceChildren();
    if (!pendingFile) { attachPrev.classList.add('hidden'); return; }
    attachPrev.classList.remove('hidden');
    if (pendingFile.preview) {
      const img = el('img', { alt: pendingFile.name || 'file' });
      img.src = pendingFile.preview;
      attachPrev.appendChild(img);
    }
    const coln = el('div', { class: 'grow' });
    coln.appendChild(el('b', { text: pendingFile.name || 'файл' }));
    coln.appendChild(el('span', { class: 'hint', text: 'подпись снизу · до ' + Math.round(maxFileOf(pendingFile.kind) / 1024 / 1024) + ' МБ' }));
    attachPrev.appendChild(coln);
    attachPrev.appendChild(icon('x', 'Снять', () => { pendingFile = null; paintAttach(); }));
  }

  input.addEventListener('input', () => {
    pingTyping();
    showFmtPop();
    const t = inputText();
    if (t.length > LIMITS.text) {
      setInputText(t.slice(0, LIMITS.text));
      toast('Максимум ' + LIMITS.text + ' символов', 'bad');
    }
    const mentions = (t.match(/@([A-Za-z0-9_]{3,20})/g) || []).length;
    if (mentions > LIMITS.mentions) toast('Максимум ' + LIMITS.mentions + ' упоминаний', 'bad');
    if (C.setDraft) C.setDraft(thread, inputText()).catch(() => {});
    const at = inputText().slice(0, 200).match(/(^|\s)@([A-Za-z0-9_]{0,20})$/);
    if (at && C.searchUsers) {
      clearTimeout(input._at);
      input._at = setTimeout(async () => {
        try {
          const r = await C.searchUsers(at[2] || '');
          wrap.querySelectorAll('.chat-at').forEach((n) => n.remove());
          const items = (r && r.items) || [];
          if (!items.length) return;
          const box = el('div', { class: 'chat-at chat-sheet' });
          items.slice(0, 8).forEach((u) => {
            const row = el('div', { class: 'chat-user-row', onclick: () => {
              setInputText(inputText().replace(/(^|\s)@([A-Za-z0-9_]{0,20})$/, '$1@' + u.nick + ' '));
              box.remove();
              input.focus();
              pingTyping();
            } });
            row.appendChild(ava(u.avatar, u.nick, u.online));
            const t = el('p');
            t.appendChild(el('b', { text: '@' + u.nick }));
            t.appendChild(el('span', { class: 'hint', text: u.status || (u.online ? 'в сети' : '') }));
            row.appendChild(t);
            box.appendChild(row);
          });
          composer.prepend(box);
        } catch (_) { /* */ }
      }, 80);
    } else wrap.querySelectorAll('.chat-at').forEach((n) => n.remove());
  });
  input.addEventListener('mouseup', showFmtPop);
  input.addEventListener('keyup', (e) => { if (e.key === 'Shift' || e.ctrlKey || e.metaKey) showFmtPop(); });
  input.addEventListener('paste', (e) => {
    const files = e.clipboardData && e.clipboardData.files;
    if (files && files[0] && String(files[0].type || '').startsWith('image/')) {
      e.preventDefault();
      queueFile(files[0], files[0].type === 'image/gif' ? 'gif' : 'image');
    }
  });
  input.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.code === 'KeyB') { e.preventDefault(); applyFmt('bold'); return; }
    if ((e.ctrlKey || e.metaKey) && e.code === 'KeyI') { e.preventDefault(); applyFmt('italic'); return; }
    if ((e.ctrlKey || e.metaKey) && e.code === 'KeyU') { e.preventDefault(); applyFmt('underline'); return; }
    if ((e.ctrlKey || e.metaKey) && e.code === 'Enter') { e.preventDefault(); sendText(); return; }
    const box = wrap.querySelector('.chat-at');
    if (box && (e.key === 'ArrowDown' || e.key === 'ArrowUp' || e.key === 'Enter' || e.key === 'Tab')) {
      const rows = [...box.querySelectorAll('.chat-user-row')];
      if (rows.length) {
        let i = rows.findIndex((n) => n.classList.contains('on'));
        if (e.key === 'ArrowDown') i = Math.min(rows.length - 1, i + 1);
        else if (e.key === 'ArrowUp') i = Math.max(0, i - 1);
        else if (e.key === 'Enter' || e.key === 'Tab') {
          e.preventDefault();
          (rows[i] || rows[0]).click();
          return;
        }
        rows.forEach((n, k) => n.classList.toggle('on', k === i));
        if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); return; }
      }
    }
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendText();
    }
  });

  function pingTyping() {
    if (!C.typing) return;
    const now = Date.now();
    if (now - typingTimer < 1800) return;
    typingTimer = now;
    C.typing(thread).catch(() => {});
  }

  function localId() {
    return 'local-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
  }

  function optimistic(partial) {
    const item = {
      id: localId(),
      at: new Date().toISOString(),
      nick: (me && me.nick) || '',
      avatar: (me && me.avatar) || '',
      role: (me && me.role) || 'user',
      kind: 'text',
      text: '',
      pending: true,
      reactions: {},
      thread,
      ...partial
    };
    appendLive(item);
    return item;
  }

  function replacePending(local, real) {
    if (!real || !real.id) return;
    const i = itemsCache.findIndex((x) => x.id === local.id);
    if (i >= 0) itemsCache[i] = real;
    const card = list.querySelector('[data-mid="' + local.id + '"]');
    const next = bubble(real);
    if (card && next) card.replaceWith(next);
    else appendLive(real);
  }

  function failPending(local) {
    const card = list.querySelector('[data-mid="' + local.id + '"]');
    if (card) {
      card.classList.add('failed');
      card.classList.remove('pending');
    }
    const i = itemsCache.findIndex((x) => x.id === local.id);
    if (i >= 0) {
      itemsCache[i].failed = true;
      itemsCache[i].pending = false;
    }
  }

  async function retryItem(item) {
    const i = itemsCache.findIndex((x) => x.id === item.id);
    if (i >= 0) {
      itemsCache[i].failed = false;
      itemsCache[i].pending = true;
    }
    const card = list.querySelector('[data-mid="' + item.id + '"]');
    if (card) {
      card.classList.remove('failed');
      card.classList.add('pending');
    }
    try {
      const extra = { thread, kind: item.kind, url: item.url, name: item.name };
      const r = await call('send', item.text || item.name || '', extra);
      if (!r || !r.ok) throw new Error((r && r.error) || 'Не отправилось');
      if (r.item) replacePending(item, r.item);
      if (r.bot) appendLive(r.bot);
    } catch (e) {
      failPending(item);
      failToast(e, 'Не отправилось');
    }
  }

  function sendBotCmd(cmd) {
    setInputText(String(cmd || ''));
    sendText();
  }

  async function sendText() {
    const text = inputText();
    if (editTarget && (text || pendingFile)) {
      try {
        let r;
        if (pendingFile && pendingFile.b64) {
          r = await call('upload', pendingFile.kind || 'image', pendingFile.name, pendingFile.b64, { thread, caption: text, editId: editTarget.id });
        } else {
          r = await call('edit', editTarget.id, text);
        }
        if (!r || !r.ok) throw new Error((r && r.error) || 'Не изменилось');
        const id = editTarget.id;
        editTarget = null;
        pendingFile = null;
        setInputText('');
        paintReply();
        paintAttach();
        if (r.item) {
          const i = itemsCache.findIndex((x) => x.id === r.item.id);
          if (i >= 0) itemsCache[i] = r.item;
          const card = list.querySelector('[data-mid="' + r.item.id + '"]');
          const next = bubble(r.item);
          if (card && next) card.replaceWith(next);
          else paintList(itemsCache, true);
        } else {
          const it = itemsCache.find((x) => x.id === id);
          if (it) {
            it.text = text;
            it.edited = true;
            const card = list.querySelector('[data-mid="' + id + '"]');
            const next = bubble(it);
            if (card && next) card.replaceWith(next);
          }
        }
        return;
      } catch (e) { failToast(e, 'Не изменилось'); return; }
    }
    if (pendingFile) {
      await sendPending(text);
      return;
    }
    if (handleCreateBot(text) || handleAdminBot(text)) { setInputText(''); return; }
    if (!text) return;
    const hard = clientBlock(me, thread, 'text', text);
    if (hard) { toast(hard.message, 'bad'); return; }
    const block = canSend(me, thread, 'text', text);
    if (block) { toast(block, 'bad'); return; }
    if (me) me._lastSend = Date.now();
    const extra = { thread, bubbleStyle: (me && me.bubbleStyle) || prefs.bubbleStyle || 'tg' };
    if (replyTo) extra.replyTo = replyTo.id;
    if (composer.dataset.silent === '1') extra.silent = true;
    if (composer.dataset.at) extra.at = Number(composer.dataset.at) || 0;
    const local = optimistic({
      kind: extra.kind || 'text',
      text,
      url: extra.url || null,
      name: extra.name || null,
      reply: replyTo ? { id: replyTo.id, nick: replyTo.nick, text: String(replyTo.text || replyTo.kind || '').slice(0, 80) } : null
    });
    setInputText('');
    replyTo = null;
    paintReply();
    if (C.setDraft) C.setDraft(thread, '').catch(() => {});
    delete composer.dataset.at;
    delete composer.dataset.silent;
    try {
      const r = await call('send', text, extra);
      if (!r || !r.ok) throw new Error((r && r.error) || 'Не отправилось');
      if (r.scheduled) {
        toast('Отложится');
        const card = list.querySelector('[data-mid="' + local.id + '"]');
        if (card) card.remove();
        itemsCache = itemsCache.filter((x) => x.id !== local.id);
      } else if (r.item) replacePending(local, r.item);
      if (r.bot) appendLive(r.bot);
      if (r.streak) applyStreak(r.streak);
      paintSidebar();
    } catch (e) {
      failPending(local);
      failToast(e, 'Не отправилось');
    }
  }

  async function sendPending(caption) {
    if (!pendingFile) return;
    const file = pendingFile;
    const sendKind = file.kind === 'gif' ? 'gif' : (file.kind === 'voice' ? 'audio' : file.kind);
    const size = file.size || (file.b64 ? Math.ceil(String(file.b64).length * 0.75) : 0);
    const blocked = clientBlock(me, thread, sendKind, caption || '', { size });
    if (blocked) { toast(blocked.message, 'bad'); return; }
    const extra = { thread, caption: caption || '', spoiler: Boolean(file.spoiler) };
    if (file.sendWhenOnline) extra.at = 'online';
    if (replyTo) extra.replyTo = replyTo.id;
    if (file.editId || (editTarget && editTarget.id)) extra.editId = file.editId || editTarget.id;
    const editing = Boolean(extra.editId);
    const local = editing ? null : optimistic({
      kind: file.kind === 'gif' ? 'gif' : (file.kind === 'voice' ? 'audio' : file.kind),
      text: caption || file.name || '',
      caption: caption || '',
      url: file.preview || '',
      name: file.name,
      reply: replyTo ? { id: replyTo.id, nick: replyTo.nick, text: String(replyTo.text || '').slice(0, 80) } : null
    });
    pendingFile = null;
    paintAttach();
    setInputText('');
    replyTo = null;
    if (editing) editTarget = null;
    paintReply();
    try {
      let r;
      if (editing && !file.b64) {
        r = await call('edit', extra.editId, caption || '');
      } else {
        r = await call('upload', file.kind, file.name, file.b64, extra);
      }
      if (!r || !r.ok) throw new Error((r && r.error) || 'Не загрузилось');
      if (editing) {
        const id = extra.editId;
        const old = itemsCache.find((x) => x.id === id);
        if (old && r.item) Object.assign(old, r.item);
        else if (old) { old.caption = caption || old.caption; if (file.preview) old.url = file.preview; old.edited = true; }
        const card = list.querySelector('[data-mid="' + id + '"]');
        if (card && old) {
          const next = bubble(old);
          if (next) card.replaceWith(next);
        }
        toast('Изменено');
      } else if (r.item) replacePending(local, r.item);
      if (botStep === 'ava' && (file.kind === 'image' || file.kind === 'gif' || file.kind === 'avatar')) {
        handleCreateBot('да', { url: (r.item && r.item.url) || file.preview });
      }
    } catch (e) {
      if (local) failPending(local);
      failToast(e, 'Не загрузилось');
    }
  }

  function sheet(titleText, tabs) {
    closeSheets(wrap);
    const sh = el('div', { class: 'chat-sheet' });
    const hd = el('div', { class: 'chat-sheet-head' });
    const titles = el('div', { class: 'chat-modal-titles' });
    titles.appendChild(el('strong', { text: titleText }));
    hd.appendChild(titles);
    hd.appendChild(icon('x', 'Закрыть', () => sh.remove()));
    sh.appendChild(hd);
    let tabRow = null;
    if (tabs && tabs.length) {
      tabRow = el('div', { class: 'chat-sheet-tabs' });
      sh.appendChild(tabRow);
    }
    const body = el('div', { class: 'chat-sheet-body' });
    sh.appendChild(body);
    col.appendChild(sh);
    function paintTabs(active) {
      if (!tabRow) return;
      tabRow.replaceChildren();
      tabs.forEach((t, i) => {
        tabRow.appendChild(el('button', {
          type: 'button',
          class: i === active ? 'on' : '',
          text: t.label,
          onclick: () => { paintTabs(i); t.render(body); }
        }));
      });
    }
    if (tabs && tabs.length) {
      paintTabs(0);
      tabs[0].render(body);
    }
    return { sh, body };
  }

  function openAttach() {
    const anchor = composeRow.firstChild;
    menu(anchor, [
      { icon: 'shots', label: 'Фото', onclick: () => pickFile('image') },
      { icon: 'gif', label: 'GIF', onclick: () => pickFile('gif') },
      { icon: 'music', label: 'Музыка', onclick: () => pickFile('audio') },
      { icon: 'sticker', label: 'Стикер', onclick: () => pickFile('sticker') },
      { icon: 'poll', label: 'Опрос', onclick: sendPoll }
    ], { place: 'up', class: 'chat-attach-menu' });
  }

  async function sendPoll() {
    closeSheets(wrap);
    const sh = modal('Опрос');
    sh.sh.classList.add('chat-modal-compact');
    sh.body.classList.add('chat-form-gap');
    const q = el('input', { class: 'field', placeholder: 'Вопрос' });
    const optsBox = el('div', { class: 'chat-form-gap' });
    const opts = [];
    function addOpt(pre) {
      if (opts.length >= 10) return;
      const n = el('input', { class: 'field', placeholder: 'Вариант ' + (opts.length + 1) });
      if (pre) n.value = pre;
      opts.push(n);
      optsBox.appendChild(n);
    }
    addOpt(); addOpt();
    let anonymous = true;
    let multi = false;
    const anon = el('button', { class: 'btn chat-toggle on', type: 'button', text: 'Анонимный' });
    anon.onclick = () => {
      anonymous = !anonymous;
      anon.textContent = anonymous ? 'Анонимный' : 'Публичный';
      anon.classList.toggle('on', anonymous);
    };
    const multiB = el('button', { class: 'btn chat-toggle', type: 'button', text: 'Несколько ответов' });
    multiB.onclick = () => {
      multi = !multi;
      multiB.classList.toggle('on', multi);
    };
    sh.body.appendChild(q);
    sh.body.appendChild(optsBox);
    sh.body.appendChild(el('button', { class: 'btn chat-poll-add chat-compact-btn', text: 'Добавить вариант', onclick: () => addOpt() }));
    const tog = el('div', { class: 'row chat-form-gap' });
    tog.appendChild(anon);
    tog.appendChild(multiB);
    sh.body.appendChild(tog);
    sh.body.appendChild(el('button', { class: 'btn btn-sky chat-compact-btn', text: 'Создать', onclick: async () => {
      const options = opts.map((n) => n.value.trim()).filter(Boolean).slice(0, 10);
      if (!q.value.trim() || options.length < 2) { toast('Нужно минимум 2 варианта', 'bad'); return; }
      try {
        await call('poll', q.value.trim(), options, { thread, anonymous, public: !anonymous, multi });
        sh.sh.remove();
        loadFresh();
      } catch (e) { failToast(e, 'Не создалось'); }
    } }));
  }

  async function sendGif() {
    const sh = sheet('GIF по ссылке');
    const url = el('input', { class: 'field', placeholder: 'https://…gif' });
    sh.body.appendChild(url);
    sh.body.appendChild(el('button', { class: 'btn btn-sky', text: 'Отправить', onclick: async () => {
      if (!url.value.trim()) return;
      const blocked = clientBlock(me, thread, 'gif', url.value.trim());
      if (blocked) { toast(blocked.message, 'bad'); return; }
      try {
        const r = await call('send', url.value.trim(), { kind: 'gif', url: url.value.trim(), thread });
        sh.sh.remove();
        if (r && r.item) appendLive(r.item);
        else loadFresh();
      } catch (e) { failToast(e, 'Не отправилось'); }
    } }));
  }

  function insertEmoji(emo) {
    input.focus();
    const custom = prefs.customEmoji !== false && emojiMap && emojiMap[emo];
    if (custom) {
      const img = el('img', { class: 'chat-cemoji', src: emojiMap[emo], alt: emo, 'data-emo': emo });
      const sel = window.getSelection();
      if (sel && sel.rangeCount && input.contains(sel.anchorNode)) {
        const range = sel.getRangeAt(0);
        range.deleteContents();
        range.insertNode(img);
        range.setStartAfter(img);
        range.collapse(true);
        sel.removeAllRanges();
        sel.addRange(range);
      } else input.appendChild(img);
    } else {
      const sel = window.getSelection();
      if (sel && sel.rangeCount && input.contains(sel.anchorNode)) document.execCommand('insertText', false, emo);
      else input.appendChild(document.createTextNode(emo));
    }
    pingTyping();
  }

  async function toggleStickers() {
    const existing = wrap.querySelector('.chat-sheet');
    if (existing) { existing.remove(); return; }
    if (stickCache.items && stickCache.items.length) stickers = stickCache.items;
    const sh = sheet('Стикеры');
    sh.sh.classList.add('stick-style-' + (prefs.stickStyle || 'classic'), 'stick-pop', 'chat-stick-side');
    if (prefs.stickPerf) sh.sh.classList.add('perf');
    paintStickSorted(sh.body, stickers.filter((s) => s.kind !== 'gif' && (s.pack || 'official') !== 'gif'));
    try {
      const r = await call('stickers');
      stickers = (r && r.items) || stickers;
      stickCache = { items: stickers, at: Date.now() };
      stickers.forEach((s) => { if (s && s.url) warmMedia(s.url); });
      if (sh.body.isConnected) paintStickSorted(sh.body, stickers.filter((s) => s.kind !== 'gif' && (s.pack || 'official') !== 'gif'));
    } catch (_) { /* */ }
  }

  let recentStickMem = [];
  idb.kvGet('recentStick').then((v) => { if (Array.isArray(v)) recentStickMem = v; }).catch(() => {});
  function recentStickers() {
    return recentStickMem;
  }
  function pushRecentStick(s) {
    const listR = recentStickers().filter((x) => x.url !== s.url);
    listR.unshift({ url: s.url, name: s.name, pack: s.pack });
    recentStickMem = listR.slice(0, 8);
    idb.kvSet('recentStick', recentStickMem).catch(() => {});
  }
  function paintStickSorted(body, items) {
    body.replaceChildren();
    const rec = recentStickers();
    const fav = items.filter((s) => s.fav || s.starred);
    if (rec.length) {
      body.appendChild(el('p', { class: 'kicker', text: 'Недавние' }));
      paintStickGrid(body, rec.map((x) => items.find((s) => s.url === x.url) || x), true);
    }
    if (fav.length) {
      body.appendChild(el('p', { class: 'kicker', text: 'Избранные' }));
      paintStickGrid(body, fav, true);
    }
    const byPack = {};
    for (const s of items) {
      const p = s.pack || s.packId || 'Коллекция';
      (byPack[p] || (byPack[p] = [])).push(s);
    }
    for (const [name, listS] of Object.entries(byPack)) {
      body.appendChild(el('p', { class: 'kicker', text: name === 'official' ? 'Официальные' : name }));
      paintStickGrid(body, listS, true);
    }
    if (!items.length && !rec.length) body.appendChild(el('p', { class: 'hint', text: 'Стикеров пока нет. Создайте коллекцию в меню.' }));
  }

  function thumbImg(url, alt) {
    const src = warmMedia(url);
    const img = el('img', { alt: alt || '' });
    img.decoding = 'async';
    img.src = src;
    img.addEventListener('error', () => { img.style.opacity = '.35'; }, { once: true });
    return img;
  }

  function paintStickGrid(body, items, append) {
    if (!append) body.replaceChildren();
    if (!items.length) {
      if (!append) body.appendChild(el('p', { class: 'hint', text: 'Стикеров пока нет. Создайте коллекцию в меню.' }));
      return;
    }
    const style = prefs.stickStyle || 'classic';
    const play = prefs.animPlay || 'viewport';
    const grid = el('div', { class: 'chat-stickers stick-' + style + (prefs.stickPerf ? ' stick-perf' : '') });
    for (const s of items) {
      const b = el('button', { class: 'chat-sticker-btn', type: 'button', onclick: async () => {
        const blocked = clientBlock(me, thread, 'sticker', s.name || 'sticker');
        if (blocked) { toast(blocked.message, 'bad'); return; }
        closeSheets(wrap);
        pushRecentStick(s);
        const extra = { kind: 'sticker', url: s.url, name: s.name, thread };
        const local = optimistic({ kind: 'sticker', url: s.url, name: s.name, text: s.name || 'sticker' });
        try {
          const r = await call('send', s.name || 'sticker', extra);
          if (r && r.item) replacePending(local, r.item);
          else if (!r || !r.ok) throw new Error((r && r.error) || 'Не отправилось');
        } catch (e) { failPending(local); failToast(e, 'Не отправилось'); }
      } });
      const node = mediaImg(s.url, 'chat-sticker-thumb', s.name || 'стикер');
      if (play === 'never') node.querySelectorAll('img,video').forEach((n) => {
        n.removeAttribute('autoplay');
        if (n.tagName === 'VIDEO') { n.pause(); n.removeAttribute('src'); n.load(); }
      });
      b.appendChild(node);
      grid.appendChild(b);
    }
    body.appendChild(grid);
  }

  function paintGifGrid(body) {
    body.replaceChildren();
    const grid = el('div', { class: 'chat-gif-grid' });
    const listG = Array.isArray(gifs) ? gifs : [];
    if (!listG.length) {
      body.appendChild(el('p', { class: 'hint', text: 'Сохраните GIF из чата или добавьте в коллекцию.' }));
      return;
    }
    for (const url of listG) {
      const u = typeof url === 'string' ? url : url.url;
      const img = thumbImg(u, 'gif');
      img.addEventListener('click', async () => {
        const blocked = clientBlock(me, thread, 'gif', u);
        if (blocked) { toast(blocked.message, 'bad'); return; }
        closeSheets(wrap);
        const local = optimistic({ kind: 'gif', url: u, text: u });
        try {
          const r = await call('send', u, { kind: 'gif', url: u, thread });
          if (r && r.item) replacePending(local, r.item);
          else if (!r || !r.ok) throw new Error((r && r.error) || 'Не отправилось');
        } catch (e) { failPending(local); failToast(e, 'Не отправилось'); }
      });
      grid.appendChild(img);
    }
    body.appendChild(grid);
  }

  function paintEmoji(body) {
    body.replaceChildren();
    const row = el('div', { class: 'chat-emoji-grid' });
    const customKeys = prefs.customEmoji !== false ? Object.keys(emojiMap || {}) : [];
    const listE = [...new Set([...customKeys, ...EMOJI_ALL])];
    listE.forEach((emo) => {
      const b = el('button', {
        class: 'chat-sticker-btn chat-emoji-btn',
        type: 'button',
        title: emo,
        onclick: () => { insertEmoji(emo); }
      });
      b.appendChild(emoNode(emo));
      row.appendChild(b);
    });
    body.appendChild(row);
  }

  function compressImage(file, maxBytes, maxSide) {
    return new Promise((resolve, reject) => {
      if (!file || !String(file.type || '').startsWith('image/') || file.type === 'image/gif') {
        if (file && file.size > maxBytes) reject(new Error('Файл слишком большой'));
        else resolve(file);
        return;
      }
      const img = new Image();
      const url = URL.createObjectURL(file);
      img.onload = () => {
        let w = img.width;
        let h = img.height;
        const side = maxSide || 1600;
        if (w > side || h > side) {
          const s = Math.min(side / w, side / h);
          w = Math.max(1, Math.round(w * s));
          h = Math.max(1, Math.round(h * s));
        }
        const c = document.createElement('canvas');
        c.width = w;
        c.height = h;
        const ctx = c.getContext('2d');
        ctx.drawImage(img, 0, 0, w, h);
        URL.revokeObjectURL(url);
        let q = 0.86;
        const dump = (quality) => new Promise((res) => c.toBlob((b) => res(b), 'image/jpeg', quality));
        (async () => {
          let blob = await dump(q);
          while (blob && blob.size > maxBytes && q > 0.45) {
            q -= 0.12;
            blob = await dump(q);
          }
          if (!blob) { resolve(file); return; }
          resolve(new File([blob], (file.name || 'photo').replace(/\.\w+$/, '.jpg'), { type: 'image/jpeg' }));
        })().catch(reject);
      };
      img.onerror = () => { URL.revokeObjectURL(url); resolve(file); };
      img.src = url;
    });
  }

  async function queueFile(file0, kind) {
    let file = file0;
    if (kind === 'image' && (file0.type === 'image/gif' || /\.gif$/i.test(file0.name || ''))) kind = 'gif';
    try {
      if (kind === 'sticker') {
        file = await toStickerBlob(file0);
        const still = await makeStill(file0);
        if (still) mediaMem.set((file.name || 'sticker') + ':still', still);
      } else if (kind === 'image' || kind === 'avatar') file = await compressImage(file0, maxFileOf(kind), kind === 'avatar' ? 512 : 1600);
    } catch (e) { failToast(e, 'Не сжалось'); return; }
    if (file.size > maxFileOf(kind)) { toast('Файл слишком большой', 'bad'); return; }
    const blocked = clientBlock(me, thread, kind === 'voice' ? 'audio' : kind, '', { size: file.size });
    if (blocked) { toast(blocked.message, 'bad'); return; }
    const b64 = await readFile(file);
    const preview = 'data:' + (file.type || 'image/jpeg') + ';base64,' + b64;
    if (kind === 'image' || kind === 'gif') {
      pendingFile = { kind, name: file.name, b64, preview, size: file.size, spoiler: false, sendWhenOnline: false };
      openAttachPreview();
      return;
    }
    pendingFile = { kind, name: file.name, b64, preview, size: file.size };
    paintAttach();
  }

  function openAttachPreview() {
    if (!pendingFile) return;
    closeSheets(wrap);
    const sh = modal('Фото');
    const box = el('div', { class: 'chat-attach-modal' });
    const hero = el('div', { class: 'chat-attach-hero' });
    const img = el('img', { alt: pendingFile.name || 'photo' });
    img.src = pendingFile.preview;
    hero.appendChild(img);
    const tools = el('div', { class: 'chat-attach-tools' });
    tools.appendChild(icon('draw', 'Редактировать', () => openPhotoEditor(sh, img)));
    const more = icon('more', 'Ещё', () => {
      let m = box.querySelector('.chat-dots-menu');
      if (m) { m.remove(); return; }
      m = el('div', { class: 'chat-dots-menu' });
      m.appendChild(el('button', { type: 'button', text: pendingFile.spoiler ? 'Убрать спойлер' : 'Спойлер', onclick: () => {
        pendingFile.spoiler = !pendingFile.spoiler;
        img.classList.toggle('spoiler', pendingFile.spoiler);
        m.remove();
      } }));
      m.appendChild(el('button', { type: 'button', text: pendingFile.sendWhenOnline ? 'Отправить сразу' : 'Когда буду в сети', onclick: () => {
        pendingFile.sendWhenOnline = !pendingFile.sendWhenOnline;
        m.remove();
      } }));
      m.appendChild(el('button', { type: 'button', text: 'Заменить фото', onclick: async () => {
        m.remove();
        sh.sh.remove();
        pickFile(pendingFile.kind || 'image');
      } }));
      box.appendChild(m);
    });
    tools.appendChild(more);
    hero.appendChild(tools);
    box.appendChild(hero);
    const cap = el('div', { class: 'field chat-input', contenteditable: 'true', role: 'textbox' });
    cap.setAttribute('data-placeholder', 'Подпись');
    cap.addEventListener('keydown', (e) => {
      if ((e.ctrlKey || e.metaKey) && e.code === 'KeyB') { e.preventDefault(); document.execCommand('bold'); }
      if ((e.ctrlKey || e.metaKey) && e.code === 'Enter') { e.preventDefault(); go(); }
      if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); go(); }
    });
    box.appendChild(cap);
    const row = el('div', { class: 'row' });
    const capFmt = el('div', { class: 'chat-fmt-pop chat-cap-fmt' });
    capFmt.appendChild(icon('bold', 'Жирный', () => { cap.focus(); document.execCommand('bold'); }));
    capFmt.appendChild(icon('italic', 'Курсив', () => { cap.focus(); document.execCommand('italic'); }));
    capFmt.appendChild(icon('strike', 'Зачёркнутый', () => { cap.focus(); document.execCommand('strikeThrough'); }));
    capFmt.appendChild(icon('code', 'Код', () => { cap.focus(); document.execCommand('insertHTML', false, '<code>' + (window.getSelection() + '') + '</code>'); }));
    box.appendChild(capFmt);
    async function go() {
      pendingFile.caption = htmlToMd(cap) || String(cap.innerText || '').trim();
      sh.sh.remove();
      await sendPending(pendingFile.caption);
    }
    row.appendChild(el('button', { class: 'btn', text: 'Отмена', onclick: () => { pendingFile = null; sh.sh.remove(); } }));
    row.appendChild(el('button', { class: 'btn btn-sky', text: 'Отправить', onclick: go }));
    box.appendChild(row);
    sh.body.appendChild(box);
  }

  function openPhotoEditor(parentSh, previewImg) {
    const sh = modal('Редактор');
    const canvas = el('canvas', { class: 'chat-editor-canvas' });
    const img = new Image();
    img.onload = () => {
      const w = Math.min(1080, img.width);
      const h = Math.round(img.height * (w / img.width));
      canvas.width = w;
      canvas.height = h;
      const ctx = canvas.getContext('2d');
      const history = [];
      function snap() {
        history.push(ctx.getImageData(0, 0, canvas.width, canvas.height));
        if (history.length > 24) history.shift();
      }
      ctx.drawImage(img, 0, 0, w, h);
      snap();
      let mode = 'draw';
      let drawing = false;
      let color = '#ff3b30';
      let size = 5;
      let start = null;
      function pos(e) {
        const r = canvas.getBoundingClientRect();
        return { x: (e.clientX - r.left) * (canvas.width / r.width), y: (e.clientY - r.top) * (canvas.height / r.height) };
      }
      canvas.addEventListener('mousedown', (e) => {
        drawing = true;
        start = pos(e);
        if (mode === 'draw' || mode === 'blur') {
          snap();
          ctx.beginPath();
          ctx.moveTo(start.x, start.y);
        } else if (mode === 'text' || mode === 'emoji') {
          const t = mode === 'emoji' ? (canvas.dataset.emo || '😀') : window.prompt('Текст', '');
          if (t) {
            snap();
            ctx.fillStyle = color;
            ctx.font = (mode === 'emoji' ? '' : 'bold ') + Math.max(mode === 'emoji' ? 36 : 18, size * (mode === 'emoji' ? 8 : 6)) + 'px "Segoe UI Emoji", "Apple Color Emoji", "Noto Color Emoji", Inter, system-ui, sans-serif';
            ctx.fillText(t, start.x, start.y);
          }
          drawing = false;
        }
      });
      canvas.addEventListener('mousemove', (e) => {
        if (!drawing) return;
        const p = pos(e);
        if (mode === 'draw') {
          ctx.strokeStyle = color;
          ctx.lineWidth = size;
          ctx.lineCap = 'round';
          ctx.lineJoin = 'round';
          ctx.lineTo(p.x, p.y);
          ctx.stroke();
        } else if (mode === 'blur') {
          ctx.save();
          ctx.filter = 'blur(6px)';
          ctx.drawImage(canvas, p.x - 18, p.y - 18, 36, 36, p.x - 18, p.y - 18, 36, 36);
          ctx.restore();
        }
      });
      window.addEventListener('mouseup', (e) => {
        if (!drawing) return;
        drawing = false;
        if (mode === 'rect' || mode === 'arrow') {
          const p = pos(e);
          snap();
          ctx.strokeStyle = color;
          ctx.lineWidth = size;
          ctx.lineCap = 'round';
          if (mode === 'rect') ctx.strokeRect(start.x, start.y, p.x - start.x, p.y - start.y);
          else {
            ctx.beginPath();
            ctx.moveTo(start.x, start.y);
            ctx.lineTo(p.x, p.y);
            ctx.stroke();
            const ang = Math.atan2(p.y - start.y, p.x - start.x);
            ctx.beginPath();
            ctx.moveTo(p.x, p.y);
            ctx.lineTo(p.x - 14 * Math.cos(ang - 0.4), p.y - 14 * Math.sin(ang - 0.4));
            ctx.lineTo(p.x - 14 * Math.cos(ang + 0.4), p.y - 14 * Math.sin(ang + 0.4));
            ctx.closePath();
            ctx.fillStyle = color;
            ctx.fill();
          }
        }
      });
      const bar = el('div', { class: 'chat-editor-bar' });
      const emoBar = el('div', { class: 'chat-editor-emos hidden' });
      const setMode = (m, btn) => {
        mode = m;
        bar.querySelectorAll('.btn').forEach((n) => n.classList.remove('btn-sky'));
        if (btn) btn.classList.add('btn-sky');
        emoBar.classList.toggle('hidden', m !== 'emoji');
      };
      const mk = (lab, m) => {
        const b = el('button', { class: 'btn' + (m === 'draw' ? ' btn-sky' : ''), text: lab, onclick: () => setMode(m, b) });
        return b;
      };
      bar.appendChild(mk('Кисть', 'draw'));
      bar.appendChild(mk('Стрелка', 'arrow'));
      bar.appendChild(mk('Рамка', 'rect'));
      bar.appendChild(mk('Текст', 'text'));
      bar.appendChild(mk('Эмодзи', 'emoji'));
      bar.appendChild(mk('Блюр', 'blur'));
      const customKeys = prefs.customEmoji !== false ? Object.keys(emojiMap || {}) : [];
      [...new Set([...customKeys, ...EMOJI_ALL.slice(0, 48)])].forEach((emo) => {
        const b = el('button', { type: 'button', class: 'chat-editor-emo', onclick: () => {
          mode = 'emoji';
          canvas.dataset.emo = emo;
          emoBar.querySelectorAll('button').forEach((n) => n.classList.toggle('on', n === b));
        } });
        b.appendChild(emoNode(emo));
        emoBar.appendChild(b);
      });
      const col = el('input', { type: 'color', value: color, class: 'chat-editor-color' });
      col.addEventListener('input', () => { color = col.value; });
      bar.appendChild(col);
      const sz = el('input', { type: 'range', min: '2', max: '22', value: String(size), class: 'chat-editor-size' });
      sz.addEventListener('input', () => { size = Number(sz.value) || 5; });
      bar.appendChild(sz);
      bar.appendChild(el('button', { class: 'btn', text: 'Отмена штриха', onclick: () => {
        if (history.length < 2) return;
        history.pop();
        ctx.putImageData(history[history.length - 1], 0, 0);
      } }));
      let cropBox = null;
      bar.appendChild(el('button', { class: 'btn', text: 'Обрезка', onclick: () => {
        if (cropBox) { cropBox.remove(); cropBox = null; mode = 'draw'; return; }
        mode = 'crop';
        cropBox = el('div', { class: 'chat-crop-box' });
        cropBox.style.left = '12%';
        cropBox.style.top = '12%';
        cropBox.style.width = '76%';
        cropBox.style.height = '76%';
        const host = canvas.parentNode || sh.body;
        host.style.position = 'relative';
        host.appendChild(cropBox);
        let drag = null;
        cropBox.addEventListener('mousedown', (e) => {
          e.stopPropagation();
          const r = cropBox.getBoundingClientRect();
          const hr = host.getBoundingClientRect();
          drag = { x: e.clientX - r.left, y: e.clientY - r.top, hr };
        });
        window.addEventListener('mousemove', (e) => {
          if (!drag) return;
          const x = e.clientX - drag.hr.left - drag.x;
          const y = e.clientY - drag.hr.top - drag.y;
          cropBox.style.left = Math.max(0, x) + 'px';
          cropBox.style.top = Math.max(0, y) + 'px';
        });
        window.addEventListener('mouseup', () => { drag = null; });
      } }));
      bar.appendChild(el('button', { class: 'btn', text: 'Применить обрезку', onclick: () => {
        if (!cropBox) return;
        const cr = cropBox.getBoundingClientRect();
        const r = canvas.getBoundingClientRect();
        const sx = Math.max(0, (cr.left - r.left) * (canvas.width / r.width));
        const sy = Math.max(0, (cr.top - r.top) * (canvas.height / r.height));
        const sw = Math.max(8, cr.width * (canvas.width / r.width));
        const shh = Math.max(8, cr.height * (canvas.height / r.height));
        const tmp = document.createElement('canvas');
        tmp.width = Math.round(sw);
        tmp.height = Math.round(shh);
        tmp.getContext('2d').drawImage(canvas, sx, sy, sw, shh, 0, 0, tmp.width, tmp.height);
        canvas.width = tmp.width;
        canvas.height = tmp.height;
        canvas.getContext('2d').drawImage(tmp, 0, 0);
        cropBox.remove();
        cropBox = null;
        snap();
      } }));
      bar.appendChild(el('button', { class: 'btn btn-sky', text: 'Готово', onclick: () => {
        const data = canvas.toDataURL('image/jpeg', 0.92);
        pendingFile.preview = data;
        pendingFile.b64 = data.split(',')[1];
        pendingFile.name = (pendingFile.name || 'photo').replace(/\.\w+$/, '.jpg');
        if (previewImg) previewImg.src = data;
        sh.sh.remove();
      } }));
      sh.body.appendChild(canvas);
      sh.body.appendChild(emoBar);
      sh.body.appendChild(bar);
    };
    img.src = pendingFile.preview;
  }

  function showUploadBar(host, label) {
    const box = el('div', { class: 'chat-upload' });
    box.appendChild(el('span', { class: 'hint', text: label || 'Загрузка…' }));
    const bar = el('div', { class: 'chat-progress' });
    const fill = el('i');
    bar.appendChild(fill);
    box.appendChild(bar);
    (host || composer).appendChild(box);
    return {
      set(p) { fill.style.width = Math.max(0, Math.min(100, p)) + '%'; },
      done() { box.remove(); }
    };
  }

  async function pickFile(kind) {
    const accept = kind === 'audio' || kind === 'voice' ? 'audio/*'
      : (kind === 'sticker' ? 'image/png,image/jpeg,image/jpg,image/webp,image/gif,image/avif,video/webm'
      : (kind === 'gif' ? 'image/gif,image/webp' : 'image/png,image/jpeg,image/jpg,image/webp,image/gif,image/*'));
    const file0 = await pick(accept);
    if (!file0) return;
    const up = showUploadBar((kind === 'avatar' || kind === 'cover' || kind === 'banner') ? (wrap.querySelector('.chat-profile') || composer) : composer, kind === 'avatar' ? 'Аватар' : (kind === 'cover' || kind === 'banner' ? 'Баннер' : (kind === 'sticker' ? 'Стикер' : (kind === 'gif' ? 'GIF' : 'Файл'))));
    try {
      if (kind === 'avatar') {
        up.set(20);
          const file = await compressImage(file0, maxFileOf('avatar'), 512);
        up.set(45);
        const b64 = await readFile(file);
        up.set(75);
        const r = await call('upload', 'avatar', file.name, b64, {});
        up.set(100);
        up.done();
        if (!r || !r.ok) throw new Error((r && r.error) || 'Не загрузилось');
        if (r.user) me = { ...me, ...r.user };
        else if (r.url) me = { ...me, avatar: r.url };
        if (r.url) mediaMem.set(r.url, r.url);
        paintAuth();
        paintHead();
        if (meAvaBtn) meAvaBtn.replaceChildren(ava(me.avatar, me.nick, true));
        const heroAva = wrap.querySelector('.chat-profile-hero .chat-ava');
        if (heroAva && me.avatar) {
          const next = ava(me.avatar, me.nick, true, { avatarHat: hatUrl(me, 'avatarHat', shopMap) });
          heroAva.replaceWith(next);
        }
        toast('Аватар обновлён');
        return;
      }
      if (kind === 'cover' || kind === 'banner') {
        up.set(20);
        const file = await compressImage(file0, maxFileOf('image'), 1920);
        up.set(45);
        const b64 = await readFile(file);
        up.set(75);
        const r = await call('upload', 'cover', file.name, b64, {});
        up.set(100);
        up.done();
        if (!r || !r.ok) throw new Error((r && r.error) || 'Не загрузилось');
        if (r.user) me = { ...me, ...r.user };
        else if (r.url) me = { ...me, cover: r.url, banner: r.url };
        if (r.url) mediaMem.set(r.url, r.url);
        const cov = wrap.querySelector('.chat-profile-cover');
        if (cov && (me.cover || me.banner || r.url)) {
          cov.style.backgroundImage = 'url("' + String(me.cover || me.banner || r.url).replace(/["')]/g, '') + '")';
        }
        toast('Баннер обновлён');
        return;
      }
      up.set(25);
      await queueFile(file0, kind === 'voice' ? 'audio' : kind);
      up.set(55);
      if (kind === 'audio' || kind === 'sticker') {
        const extra = { thread };
        if (kind === 'sticker' && packs[0]) extra.packId = packs[0].id;
        if (!pendingFile) { up.done(); return; }
        up.set(70);
        const r = await call('upload', kind, pendingFile.name, pendingFile.b64, extra);
        up.set(100);
        pendingFile = null;
        paintAttach();
        up.done();
        if (!r || !r.ok) throw new Error((r && r.error) || 'Не загрузилось');
        if (r.url) mediaMem.set(r.url, r.url);
        if (r.item) appendLive(r.item);
        return;
      }
      // image / gif: отправляется ровно один раз из превью (fix двойной отправки GIF).
      up.done();
      return;
    } catch (e) { up.done(); failToast(e, 'Не загрузилось'); }
  }

  async function pickWallpaper() {
    const file = await pick('image/*');
    if (!file) return;
    try {
      const b64 = await readFile(file);
      const url = 'data:' + (file.type || 'image/jpeg') + ';base64,' + b64;
      const walls = { ...(prefs.walls || {}), [thread]: url };
      savePrefs({ walls, wallpaper: url });
      toast('Обои только этого чата, локально');
    } catch (e) { failToast(e, 'Не получилось'); }
  }

  async function openProfile(nick, self) {
    const sh = modal(self ? 'Мой профиль' : (nick || 'Профиль'));
    let user = self ? me : null;
    if (!self && nick && C.user) {
      try {
        const r = await C.user(nick);
        user = (r && r.user) || { nick };
      } catch (_) { user = { nick }; }
    }
    user = user || { nick };
    const box = el('div', { class: 'chat-profile' });
    const cover = el('div', { class: 'chat-profile-cover' });
    const coverSrc = user.cover || user.banner || '';
    if (coverSrc) {
      if (String(coverSrc).startsWith('linear-gradient') || String(coverSrc).startsWith('radial')) {
        cover.style.background = coverSrc;
      } else {
        const cached = mediaMem.get(coverSrc) || coverSrc;
        cover.style.backgroundImage = 'url("' + String(cached).replace(/["')]/g, '') + '")';
        if (C.cacheMedia && !String(coverSrc).startsWith('data:')) {
          C.cacheMedia(coverSrc).then((r) => {
            const s = r && (r.src || r);
            if (typeof s === 'string' && s) {
              mediaMem.set(coverSrc, s);
              if (cover.isConnected) cover.style.backgroundImage = 'url("' + s.replace(/["')]/g, '') + '")';
            }
          }).catch(() => {});
        }
      }
    }
    box.appendChild(cover);
    if (self) {
      const covHover = el('button', { class: 'chat-profile-cover-hover', type: 'button' });
      covHover.innerHTML = svg('camera') + '<span>Сменить баннер</span>';
      covHover.addEventListener('click', (e) => { e.stopPropagation(); pickFile('cover'); });
      cover.appendChild(covHover);
    }
    const hero = el('div', { class: 'chat-profile-hero' });
    const avaNode = ava(user.avatar, user.nick, user.online, { avatarHat: hatUrl(user, 'avatarHat', shopMap) });
    hero.appendChild(avaNode);
    if (self) {
      const avHover = el('button', { class: 'profile-ava-hover', type: 'button', title: 'Сменить аватар' });
      avHover.innerHTML = svg('camera');
      avHover.addEventListener('click', (e) => { e.stopPropagation(); pickFile('avatar'); });
      const wrapA = avaNode.classList && avaNode.classList.contains('chat-hat-wrap') ? avaNode : null;
      if (wrapA) wrapA.appendChild(avHover);
      else {
        const boxA = el('div', { class: 'chat-hat-wrap' });
        avaNode.replaceWith(boxA);
        boxA.appendChild(avaNode);
        boxA.appendChild(avHover);
      }
    }
    const pHat = hatUrl(user, 'profileHat', shopMap);
    if (pHat) {
      const ph = el('img', { class: 'chat-profile-hat', alt: '' });
      ph.src = pHat;
      cover.appendChild(ph);
    }
    const headMeta = el('div', { class: 'chat-profile-headmeta' });
    const nickLine = el('div', { class: 'chat-profile-nickline' });
    const badges = user.badges || (user.role === 'admin' ? ['official'] : user.verified ? ['official'] : []);
    nickLine.appendChild(nickRow(user.nick || '', badges));
    headMeta.appendChild(nickLine);
    const seen = user.online ? 'в сети' : (user.lastSeen ? fmtLastSeen(user.lastSeen) : (user.status || 'был недавно'));
    headMeta.appendChild(el('span', { class: 'hint' + (user.online ? ' on' : ''), text: seen }));
    hero.appendChild(headMeta);
    if (self) {
      const heroActions = el('div', { class: 'chat-profile-hero-actions' });
      const shopBtn = el('button', { class: 'chat-icon chat-profile-shop', type: 'button', title: 'Магазин' });
      shopBtn.innerHTML = svg('shop');
      shopBtn.addEventListener('click', (e) => { e.stopPropagation(); sh.sh.remove(); openShop(); });
      heroActions.appendChild(shopBtn);
      const editBtn = el('button', { class: 'chat-icon chat-profile-edit', type: 'button', title: 'Редактировать' });
      editBtn.innerHTML = svg('edit');
      editBtn.addEventListener('click', () => box.classList.toggle('editing'));
      heroActions.appendChild(editBtn);
      hero.appendChild(heroActions);
    }
    box.appendChild(hero);
    if (user.bio) {
      const about = el('div', { class: 'chat-profile-about' });
      about.appendChild(el('p', { class: 'kicker', text: 'О себе' }));
      about.appendChild(el('p', { class: 'chat-profile-bio', text: user.bio }));
      box.appendChild(about);
    }
    const social = el('div', { class: 'chat-social' });
    const links = [
      ['telegram', 'Telegram', user.telegram, 'https://t.me/', 'tg'],
      ['discord', 'Discord', user.discord, 'https://discord.com/users/', 'disc'],
      ['youtube', 'YouTube', user.youtube, 'https://youtube.com/@', 'youtube'],
      ['tiktok', 'TikTok', user.tiktok, 'https://tiktok.com/@', 'tiktok']
    ];
    for (const [k, lab, v, pre, ico] of links) {
      if (!v) continue;
      const href = v.startsWith('http') ? v : (pre ? pre + v.replace(/^@/, '') : '');
      const a = el('a', { class: 'chat-social-link ' + k, href: href || '#', rel: 'noreferrer', target: '_blank', title: lab });
      a.innerHTML = svg(ico, 'chat-social-ico') + '<span>' + lab + '</span>';
      a.addEventListener('click', (e) => {
        e.preventDefault();
        if (href) window.open(href, '_blank', 'noopener,noreferrer');
      });
      social.appendChild(a);
    }
    if (social.childNodes.length) box.appendChild(social);
    if (self) {
      const form = el('div', { class: 'chat-form chat-profile-editpane' });
      form.appendChild(el('p', { class: 'kicker', text: 'О себе' }));
      const bio = el('textarea', { class: 'field', placeholder: 'Расскажите о себе', rows: '3', maxlength: String(LIMITS.bio) });
      bio.value = user.bio || '';
      const status = el('input', { class: 'field', placeholder: 'Статус — коротко, что у вас сейчас', maxlength: String(LIMITS.status) });
      status.value = user.status || '';
      const bioCnt = el('span', { class: 'chat-counter', text: String((user.bio || '').length) + '/' + LIMITS.bio });
      const stCnt = el('span', { class: 'chat-counter', text: String((user.status || '').length) + '/' + LIMITS.status });
      bio.addEventListener('input', () => { bioCnt.textContent = bio.value.length + '/' + LIMITS.bio; });
      status.addEventListener('input', () => { stCnt.textContent = status.value.length + '/' + LIMITS.status; });
      form.appendChild(bio);
      form.appendChild(bioCnt);
      form.appendChild(status);
      form.appendChild(stCnt);
      form.appendChild(el('p', { class: 'kicker', text: 'Ссылки' }));
      const tg = el('input', { class: 'field', placeholder: 'Telegram' });
      tg.value = user.telegram || '';
      const dc = el('input', { class: 'field', placeholder: 'Discord' });
      dc.value = user.discord || '';
      const yt = el('input', { class: 'field', placeholder: 'YouTube' });
      yt.value = user.youtube || '';
      const tt = el('input', { class: 'field', placeholder: 'TikTok' });
      tt.value = user.tiktok || '';
      [tg, dc, yt, tt].forEach((n) => form.appendChild(n));
      form.appendChild(el('p', { class: 'kicker', text: 'Фото' }));
      const mediaRow = el('div', { class: 'row chat-form-gap' });
      const avBtn = el('button', { class: 'btn', type: 'button', onclick: () => pickFile('avatar') });
      avBtn.innerHTML = svg('camera') + '<span>Загрузить аватар</span>';
      const bnBtn = el('button', { class: 'btn', type: 'button', onclick: () => pickFile('cover') });
      bnBtn.innerHTML = svg('wallpaper') + '<span>Загрузить баннер</span>';
      mediaRow.appendChild(avBtn);
      mediaRow.appendChild(bnBtn);
      form.appendChild(mediaRow);
      form.appendChild(el('button', { class: 'btn btn-sky chat-profile-save', text: 'Сохранить изменения', onclick: async () => {
        try {
          const r = await call('saveProfile', {
            bio: String(bio.value || '').slice(0, LIMITS.bio),
            status: String(status.value || '').slice(0, LIMITS.status),
            telegram: tg.value, discord: dc.value,
            youtube: yt.value, tiktok: tt.value, avatar: (me && me.avatar) || '',
            cover: (me && (me.cover || me.banner)) || ''
          });
          if (!r || !r.ok) throw new Error((r && r.error) || 'Не сохранилось');
          me = { ...me, ...r };
          paintAuth();
          toast('Профиль сохранён');
          sh.sh.remove();
        } catch (e) { failToast(e, 'Не сохранилось'); }
      } }));
      box.appendChild(form);
      const foot = el('div', { class: 'chat-profile-acts' });
      const shareB = el('button', { class: 'btn', type: 'button', onclick: () => {
        sh.sh.remove();
        openShareModal({ kind: 'user', nick: user.nick, avatar: user.avatar, bio: user.bio });
      } });
      shareB.innerHTML = svg('share') + '<span>Поделиться</span>';
      const accB = el('button', { class: 'btn', type: 'button', onclick: () => { sh.sh.remove(); openAccounts(); } });
      accB.innerHTML = svg('nick') + '<span>Сменить аккаунт</span>';
      const setB = el('button', { class: 'btn', type: 'button', onclick: () => { sh.sh.remove(); openUiSettings(); } });
      setB.innerHTML = svg('gear') + '<span>Настройки</span>';
      foot.appendChild(shareB);
      foot.appendChild(accB);
      foot.appendChild(setB);
      box.appendChild(foot);
    } else if (me && me.ok && nick && nick !== me.nick) {
      const acts = el('div', { class: 'chat-profile-acts' });
      const writeB = el('button', { class: 'chat-profile-cta', type: 'button', onclick: () => { sh.sh.remove(); openDm(nick); } });
      writeB.innerHTML = svg('edit') + '<span>Написать</span>';
      acts.appendChild(writeB);
      const shareB = el('button', { class: 'btn', type: 'button', onclick: () => {
        sh.sh.remove();
        openShareModal({ kind: 'user', nick: user.nick, avatar: user.avatar, bio: user.bio });
      } });
      shareB.innerHTML = svg('share') + '<span>Поделиться</span>';
      acts.appendChild(shareB);
      const blockB = el('button', { class: 'btn', type: 'button', onclick: async () => {
        try { await call('block', nick); toast('Пользователь заблокирован'); } catch (e) { failToast(e, 'Не получилось'); }
      } });
      blockB.innerHTML = svg('block') + '<span>Заблокировать</span>';
      acts.appendChild(blockB);
      box.appendChild(acts);
      if (isAdmin()) {
        const admin = el('div', { class: 'chat-form' });
        admin.appendChild(el('p', { class: 'kicker', text: 'АДМИН' }));
        for (const [id, lab] of [['official', 'Офиц'], ['staff', 'Сотрудник'], ['support', 'Поддержка'], ['creator', 'Creator']]) {
          const has = Array.isArray(user.badges) && user.badges.includes(id);
          admin.appendChild(el('button', { class: 'btn', text: (has ? 'Снять: ' : 'Галочка: ') + lab, onclick: async () => {
            try {
              const on = !has;
              if (C.setBadge) await C.setBadge(nick, id, on);
              else await call('adminUser', nick, { badge: id, badgeOn: on });
              toast(on ? 'Галочка ' + lab : 'Снято: ' + lab);
              sh.sh.remove();
              openProfile(nick);
            } catch (e) { failToast(e, 'Не получилось'); }
          } }));
        }
        admin.appendChild(el('button', { class: 'btn', text: 'Кик с аккаунта', onclick: () => adminAct('kick', nick) }));
        admin.appendChild(el('button', { class: 'btn', text: 'Бан', onclick: () => adminAct('ban', nick, 24) }));
        admin.appendChild(el('button', { class: 'btn', text: 'Мут', onclick: () => adminAct('modMute', nick, 30) }));
        admin.appendChild(el('button', { class: 'btn', text: 'Варн', onclick: () => adminAct('warn', nick) }));
        admin.appendChild(el('button', { class: 'btn', text: 'Системное', onclick: async () => {
          const t = window.prompt('Сообщение', '');
          if (t) try { await call('broadcast', t, 'dm:' + nick); toast('Ушло'); } catch (e) { failToast(e, 'Не получилось'); }
        } }));
         box.appendChild(admin);
       }
     }
     sh.body.appendChild(box);
   }

  function shareCard(share, href) {
    const card = el('div', { class: 'chat-share-card' });
    const kind = share.kind || 'user';
    if (kind === 'flame' || kind === 'streak') {
      card.classList.add('chat-share-flame');
      const img = el('img', { class: 'chat-flame-big', alt: 'огонёк' });
      img.src = share.dead ? 'oqonek/oqon.webp' : 'oqonek/opon.gif';
      card.appendChild(img);
      card.appendChild(el('b', { class: 'n', text: String(share.days || 0) }));
      card.appendChild(el('span', { text: share.nick || 'Огонёк' }));
    } else if (kind === 'message' || share.text) {
      card.classList.add('chat-share-msg');
      card.appendChild(ava(share.avatar || share.ava, share.nick || share.title, false));
      const meta = el('div');
      meta.appendChild(el('b', { text: share.nick || 'Сообщение' }));
      meta.appendChild(el('span', { text: String(share.text || share.preview || '').slice(0, 140) }));
      card.appendChild(meta);
    } else {
      card.appendChild(ava(share.avatar || share.ava, share.nick || share.title, false, { avatarHat: share.avatarHat || hatUrl(share, 'avatarHat', shopMap) }));
      const meta = el('div');
      meta.appendChild(el('b', { text: share.nick || share.title || 'CrynChat' }));
      meta.appendChild(el('span', { text: share.bio || share.about || 'Профиль CrynChat' }));
      card.appendChild(meta);
    }
    const openB = el('button', { class: 'btn chat-compact-btn', type: 'button', text: 'Открыть' });
    card.appendChild(openB);
    const go = (e) => {
      if (e) e.stopPropagation();
      if (share.nick && kind !== 'message') openProfile(share.nick);
      else if (share.thread) openThread(share.thread, share.title || share.nick);
      else if (share.msgId) jumpToPinned({ id: share.msgId });
      else if (href && !/^Cryn:\/\//i.test(String(href))) window.open(String(href), '_blank', 'noopener');
    };
    openB.addEventListener('click', go);
    card.addEventListener('click', go);
    return card;
  }

  async function openPrivacy() {
    const sh = modal('Приватность');
    let doc = me && me.privacy ? me.privacy : { whoWrite: 'all', allow: [], deny: [] };
    try {
      const r = C.privacy ? await C.privacy() : await call('privacy');
      if (r && r.ok) doc = r.privacy || r;
    } catch (_) { /* */ }
    const who = el('select', { class: 'field' });
    for (const [id, lab] of [['all', 'Все'], ['contacts', 'Контакты'], ['nobody', 'Никто']]) {
      who.appendChild(el('option', { value: id, text: lab }));
    }
    who.value = doc.whoWrite || 'all';
    sh.body.classList.add('chat-form-gap');
    sh.body.appendChild(el('p', { class: 'kicker', text: 'Кто может писать мне' }));
    sh.body.appendChild(customSelect(who, [['all', 'Все'], ['contacts', 'Контакты'], ['nobody', 'Никто']], doc.whoWrite || 'all'));
    const seenSel = el('select', { class: 'field' });
    for (const [id, lab] of [['all', 'Все'], ['contacts', 'Контакты'], ['nobody', 'Никто']]) seenSel.appendChild(el('option', { value: id, text: lab }));
    seenSel.value = doc.whoOnline || doc.seenBy || 'all';
    sh.body.appendChild(el('p', { class: 'kicker', text: 'Кто видит, что я в сети' }));
    sh.body.appendChild(customSelect(seenSel, [['all', 'Все'], ['contacts', 'Контакты'], ['nobody', 'Никто']], seenSel.value));
    const avaSel = el('select', { class: 'field' });
    for (const [id, lab] of [['all', 'Все'], ['contacts', 'Контакты'], ['nobody', 'Никто']]) avaSel.appendChild(el('option', { value: id, text: lab }));
    avaSel.value = doc.whoAvatar || 'all';
    sh.body.appendChild(el('p', { class: 'kicker', text: 'Кто видит мою аватарку' }));
    sh.body.appendChild(customSelect(avaSel, [['all', 'Все'], ['contacts', 'Контакты'], ['nobody', 'Никто']], avaSel.value));
    const allow = el('input', { class: 'field', placeholder: 'Разрешить ники через запятую' });
    allow.value = (doc.allowFrom || doc.allow || []).join(', ');
    const deny = el('input', { class: 'field', placeholder: 'Запретить ники через запятую' });
    deny.value = (doc.denyFrom || doc.deny || []).join(', ');
    sh.body.appendChild(allow);
    sh.body.appendChild(deny);
    const saveP = el('button', { class: 'btn btn-sky chat-compact-btn', text: 'Сохранить', onclick: async () => {
      const patch = {
        whoWrite: who.value,
        whoOnline: seenSel.value,
        whoAvatar: avaSel.value,
        allowFrom: allow.value.split(',').map((s) => s.trim()).filter(Boolean),
        denyFrom: deny.value.split(',').map((s) => s.trim()).filter(Boolean)
      };
      try {
        const r = C.privacy ? await C.privacy(patch) : await call('privacy', patch);
        if (me) me.privacy = (r && (r.privacy || r)) || patch;
        toast('Сохранено');
        sh.sh.remove();
      } catch (e) { failToast(e, 'Не получилось'); }
    } });
    sh.body.appendChild(saveP);
    sh.body.appendChild(el('p', { class: 'kicker', text: 'Сессии' }));
    const box = el('div', { class: 'chat-session-list' });
    sh.body.appendChild(box);
    try {
      const r = C.sessions ? await C.sessions() : await call('sessions');
      const items = (r && r.items) || [];
      if (!items.length) box.appendChild(el('p', { class: 'hint', text: 'Нет других сессий' }));
      for (const s of items) {
        const row = el('div', { class: 'chat-session' });
        const ico = el('span', { class: 'chat-session-ico' });
        ico.innerHTML = svg('device');
        row.appendChild(ico);
        const meta = el('div', { class: 'chat-session-meta' });
        meta.appendChild(el('b', { text: (s.device || s.id || 'устройство') + (s.current ? ' · это устройство' : '') }));
        meta.appendChild(el('span', { class: 'hint', text: s.at ? fmtLastSeen(s.at) : (s.ip || '') }));
        row.appendChild(meta);
        if (!s.current) row.appendChild(el('button', { class: 'btn chat-compact-btn', text: 'Выйти', onclick: async () => {
          try {
            if (C.revokeSession) await C.revokeSession(s.id);
            else await call('revokeSession', s.id);
            row.remove();
          } catch (e) { failToast(e, 'Не получилось'); }
        } }));
        box.appendChild(row);
      }
    } catch (e) { box.appendChild(el('p', { class: 'hint', text: friendlyErr(e, 'Нет данных') })); }
  }

  function customSelect(native, options, value) {
    native.style.display = 'none';
    native.value = value || native.value;
    const wrapS = el('div', { class: 'chat-cselect' });
    const btn = el('button', { class: 'chat-cselect-btn field', type: 'button' });
    const cur = (options.find((o) => o[0] === native.value) || options[0] || ['', '']);
    btn.innerHTML = '<span>' + cur[1] + '</span>' + svg('chev');
    wrapS.appendChild(native);
    wrapS.appendChild(btn);
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      wrap.querySelectorAll('.chat-cselect-pop').forEach((n) => n.remove());
      const pop = el('div', { class: 'chat-cselect-pop' });
      for (const [id, lab] of options) {
        const it = el('button', { class: 'chat-cselect-item' + (native.value === id ? ' on' : ''), type: 'button' });
        it.appendChild(el('span', { text: lab }));
        if (native.value === id) {
          const mk = el('span', { class: 'chat-cselect-check' });
          mk.innerHTML = svg('check');
          it.appendChild(mk);
        }
        it.addEventListener('click', () => {
          native.value = id;
          btn.querySelector('span').textContent = lab;
          pop.remove();
        });
        pop.appendChild(it);
      }
      wrapS.appendChild(pop);
      const off = (ev) => { if (!wrapS.contains(ev.target)) { pop.remove(); document.removeEventListener('mousedown', off); } };
      setTimeout(() => document.addEventListener('mousedown', off), 0);
    });
    return wrapS;
  }

  async function openComments(item) {
    const sh = modal('Комментарии');
    sh.sh.classList.add('chat-modal-compact');
    const listC = el('div', { class: 'chat-cmt-list' });
    listC.appendChild(el('p', { class: 'hint', text: 'Загружаю…' }));
    sh.body.appendChild(listC);
    const row = el('div', { class: 'chat-compose-row chat-cmt-composer' });
    const inp = el('div', { class: 'field chat-input', contenteditable: 'true', role: 'textbox' });
    inp.setAttribute('data-placeholder', 'Комментарий');
    const sendC = el('button', { class: 'chat-icon send', type: 'button' });
    sendC.innerHTML = svg('send');
    async function go() {
      const t = String(inp.innerText || '').trim();
      if (!t) return;
      try {
        const r = C.comment ? await C.comment(item.id, t) : await call('comment', item.id, t);
        inp.textContent = '';
        if (r && r.item) paintOne(r.item);
      } catch (e) { failToast(e, 'Не отправилось'); }
    }
    sendC.addEventListener('click', go);
    inp.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); go(); } });
    row.appendChild(inp);
    row.appendChild(sendC);
    sh.body.appendChild(row);
    function paintOne(it) {
      const card = el('div', { class: 'chat-msg' + (it.nick === (me && me.nick) ? ' mine' : '') });
      card.appendChild(ava(it.avatar, it.nick, false));
      const bub = el('div', { class: 'chat-bubble' });
      bub.appendChild(el('b', { text: it.nick || '' }));
      bub.appendChild(el('p', { class: 'chat-text', text: it.text || '' }));
      card.appendChild(bub);
      listC.appendChild(card);
    }
    try {
      const r = C.comments ? await C.comments(item.id) : await call('comments', item.id);
      const items = (r && (r.items || r.comments)) || [];
      listC.replaceChildren();
      if (!items.length) listC.appendChild(el('p', { class: 'hint', text: 'Пока нет комментариев' }));
      else listC.appendChild(el('p', { class: 'chat-cmt-count', text: 'Комментарии · ' + items.length }));
      for (const it of items) paintOne(it);
      listC.scrollTop = listC.scrollHeight;
    } catch (e) {
      listC.replaceChildren(el('p', { class: 'hint', text: friendlyErr(e, 'Не загрузилось') }));
    }
  }

  function openSetPass() {
    const sh = modal('Сменить пароль');
    sh.sh.classList.add('chat-modal-compact');
    sh.body.classList.add('chat-form-gap');
    const oldP = el('input', { class: 'field', type: 'password', placeholder: 'Старый пароль' });
    const nextP = el('input', { class: 'field', type: 'password', placeholder: 'Новый пароль' });
    const again = el('input', { class: 'field', type: 'password', placeholder: 'Повторить новый пароль' });
    sh.body.appendChild(oldP);
    sh.body.appendChild(nextP);
    sh.body.appendChild(again);
    const row = el('div', { class: 'row chat-form-gap' });
    row.appendChild(el('button', { class: 'btn', text: 'Отмена', onclick: () => sh.sh.remove() }));
    row.appendChild(el('button', { class: 'btn btn-sky chat-compact-btn', text: 'Сменить пароль', onclick: async () => {
      if (nextP.value !== again.value) { toast('Пароли не совпадают', 'bad'); return; }
      try {
        const r = C.setPass ? await C.setPass(oldP.value, nextP.value) : await call('setPass', oldP.value, nextP.value);
        if (!r || !r.ok) throw new Error((r && r.error) || 'Не вышло');
        toast('Пароль изменён');
        sh.sh.remove();
      } catch (e) { failToast(e, 'Не получилось'); }
    } }));
    sh.body.appendChild(row);
  }

  function openChatProfile(id, meta) {
    const sh = modal((meta && meta.title) || id);
    const box = el('div', { class: 'chat-profile' });
    const cover = el('div', { class: 'chat-profile-cover' });
    const wall = (meta && (meta.banner || meta.cover || meta.wallpaper)) || (prefs && prefs.walls && prefs.walls[id]) || '';
    if (wall) {
      if (String(wall).startsWith('linear-gradient') || String(wall).startsWith('radial')) cover.style.background = wall;
      else cover.style.backgroundImage = 'url("' + String(wall).replace(/["')]/g, '') + '")';
    }
    box.appendChild(cover);
    const hero = el('div', { class: 'chat-profile-hero' });
    if (id === 'system') hero.appendChild(iconAva('bell', 'system'));
    else if (id === 'saved') hero.appendChild(iconAva('star', 'saved'));
    else hero.appendChild(ava(meta && meta.avatar, (meta && meta.title) || id, false));
    const metaWrap = el('div', { class: 'chat-profile-headmeta' });
    metaWrap.appendChild(nickRow((meta && meta.title) || id, id === 'channel' || id === 'system' ? ['official'] : []));
    metaWrap.appendChild(el('span', { class: 'hint', text: (meta && meta.about) || '' }));
    hero.appendChild(metaWrap);
    box.appendChild(hero);
    if (id !== 'system' && id !== 'saved') {
      const tabs = el('div', { class: 'chat-profile-chiptabs' });
      const mediaBtn = el('button', { class: 'chip on', type: 'button' });
      mediaBtn.innerHTML = svg('shots') + '<span>Медиа</span>';
      mediaBtn.addEventListener('click', () => { sh.sh.remove(); openChatMedia(id); });
      tabs.appendChild(mediaBtn);
      const pollBtn = el('button', { class: 'chip', type: 'button' });
      pollBtn.innerHTML = svg('poll') + '<span>Опросы</span>';
      pollBtn.addEventListener('click', () => { sh.sh.remove(); openChatPolls(id); });
      tabs.appendChild(pollBtn);
      const onlineBtn = el('button', { class: 'chip', type: 'button' });
      onlineBtn.innerHTML = svg('users') + '<span>В сети</span>';
      onlineBtn.addEventListener('click', () => { sh.sh.remove(); openChatOnline(id, meta); });
      tabs.appendChild(onlineBtn);
      box.appendChild(tabs);
    }
    const chatActs = el('div', { class: 'chat-profile-acts' });
    if (isAdmin()) {
      const banBtn = el('button', { class: 'btn chat-compact-btn', type: 'button' });
      banBtn.innerHTML = svg('wallpaper') + '<span>Баннер чата</span>';
      banBtn.addEventListener('click', async () => {
        const file0 = await pick('image/*');
        if (!file0) return;
        try {
          const file = await compressImage(file0, maxFileOf('image'), 1920);
          const b64 = await readFile(file);
          const r = await call('upload', 'image', file.name, b64, { thread: id, skipMsg: true });
          const url = (r && r.url) || '';
          if (!url) throw new Error((r && r.error) || 'Не загрузилось');
          await call('adminChat', id, { banner: url, cover: url });
          cover.style.backgroundImage = 'url("' + url.replace(/["')]/g, '') + '")';
          if (me && me.chats) {
            const c = me.chats.find((x) => x.id === id);
            if (c) { c.banner = url; c.cover = url; }
          }
          toast('Баннер чата сохранён');
        } catch (e) { failToast(e, 'Не получилось'); }
      });
      chatActs.appendChild(banBtn);
    }
    const wallBtn = el('button', { class: 'btn chat-compact-btn', type: 'button' });
    wallBtn.innerHTML = svg('shots') + '<span>Локальные обои</span>';
    wallBtn.addEventListener('click', async () => {
      const file = await pick('image/*');
      if (!file) return;
      try {
        const b64 = await readFile(file);
        const url = 'data:' + (file.type || 'image/jpeg') + ';base64,' + b64;
        const walls = { ...(prefs.walls || {}), [id]: url };
        prefs = { ...prefs, walls, wallpaper: url };
        if (C.setPrefs) C.setPrefs({ walls, wallpaper: url }).catch(() => {});
        applyWallpaper();
        cover.style.backgroundImage = 'url("' + url.replace(/["')]/g, '') + '")';
        toast('Обои чата установлены');
      } catch (e) { failToast(e, 'Не получилось'); }
    });
    chatActs.appendChild(wallBtn);
    const joined = me && ((me.joined || []).includes(id) || id === 'global' || id === 'saved' || id === 'system' || thread === id);
    const label = id === 'channel' ? (joined ? 'Перейти' : 'Подписаться') : (joined ? 'Перейти' : 'Вступить');
    const goBtn = el('button', { class: 'chat-profile-cta', type: 'button', onclick: () => { sh.sh.remove(); openThread(id, meta && meta.title); } });
    goBtn.innerHTML = svg('send') + '<span>' + label + '</span>';
    chatActs.appendChild(goBtn);
    box.appendChild(chatActs);
    if (id === 'global' || id === 'channel') {
      const liveBox = el('div', { class: 'chat-online-box' });
      liveBox.appendChild(el('p', { class: 'kicker', text: 'В СЕТИ' }));
      const listEl = el('div', { class: 'chat-online-list' });
      listEl.appendChild(el('p', { class: 'hint', text: 'Загружаю…' }));
      liveBox.appendChild(listEl);
      box.appendChild(liveBox);
      const paintPeople = (people, count) => {
        listEl.replaceChildren();
        const items = people || [];
        listEl.appendChild(el('p', { class: 'hint', text: (count || items.length) + ' в сети' }));
        if (!items.length) {
          listEl.appendChild(el('p', { class: 'hint', text: 'Пока никого' }));
          return;
        }
        for (const u of items) {
          const row = el('div', { class: 'chat-user-row', onclick: () => { sh.sh.remove(); openProfile(u.nick); } });
          row.appendChild(ava(u.avatar, u.nick, false));
          const t = el('p');
          t.appendChild(el('b', { text: u.nick }));
          t.appendChild(el('span', { class: 'hint on', text: u.status || 'в сети' }));
          row.appendChild(t);
          listEl.appendChild(row);
        }
      };
      (async () => {
        try {
          const r = C.presence ? await C.presence(id) : await call('presence', id);
          paintPeople(r && r.people, r && r.online);
        } catch (_) {
          try {
            const r = await call('online');
            paintPeople(r && r.people, r && (r.count || r.online));
          } catch (e) { listEl.replaceChildren(el('p', { class: 'hint', text: friendlyErr(e, 'Не получилось загрузить') })); }
        }
      })();
    }
    sh.body.appendChild(box);
  }

  // Просмотр медиа/опросов/онлайна по кнопкам в профиле чата.
  function openChatMedia(id) {
    const sh = modal('Медиа');
    const grid = el('div', { class: 'chat-med-grid' });
    sh.body.appendChild(grid);
    const items = [...(thread === id && itemsCache ? itemsCache : []), ...(chatsMem.items || [])]
      .filter((x) => x && x.thread === id && (x.kind === 'image' || x.kind === 'gif' || (x.kind === 'sticker' && x.url)));
    const seen = new Set();
    const list = [];
    for (const it of items) { if (it && it.url && !seen.has(it.url)) { seen.add(it.url); list.push(it); } }
    if (!list.length) { grid.appendChild(el('p', { class: 'hint', text: 'Пока нет медиа в этом чате.' })); return; }
    for (const it of list.slice(0, 120)) {
      const img = mediaImg(it.url, 'chat-med-item', it.name || 'медиа', () => lightbox(mediaMem.get(it.url) || it.url, it.kind === 'gif' ? 'image' : 'image'));
      grid.appendChild(img);
    }
  }
  function openChatPolls(id) {
    const sh = modal('Опросы');
    const list = [...(thread === id && itemsCache ? itemsCache : []), ...(chatsMem.items || [])]
      .filter((x) => x && x.thread === id && (x.kind === 'poll' || (x.poll)));
    if (!list.length) { sh.body.appendChild(el('p', { class: 'hint', text: 'Пока нет опросов в этом чате.' })); return; }
    for (const it of list.slice(-50)) {
      const card = el('div', { class: 'chat-poll-mini' });
      card.appendChild(el('b', { text: it.text || it.question || 'Опрос' }));
      const opts = (it.poll && it.poll.options) || [];
      for (const o of opts.slice(0, 4)) card.appendChild(el('span', { class: 'hint', text: '• ' + (String(o.label || o.text || o || '')) }));
      if (opts.length > 4) card.appendChild(el('span', { class: 'hint', text: '…' }));
      sh.body.appendChild(card);
    }
  }
  function openChatOnline(id, meta) {
    const sh = modal('В сети');
    const listEl = el('div', { class: 'chat-online-list' });
    listEl.appendChild(el('p', { class: 'hint', text: 'Загружаю…' }));
    sh.body.appendChild(listEl);
    (async () => {
      try {
        const r = C.presence ? await C.presence(id) : await call('presence', id);
        const people = (r && r.people) || ((r && r.items) || []);
        listEl.replaceChildren();
        if (!people.length) { listEl.appendChild(el('p', { class: 'hint', text: 'Пока никого' })); return; }
        for (const u of people) {
          const row = el('div', { class: 'chat-user-row', onclick: () => { sh.sh.remove(); openProfile(u.nick); } });
          row.appendChild(ava(u.avatar, u.nick, false));
          const t = el('p');
          t.appendChild(el('b', { text: u.nick }));
          t.appendChild(el('span', { class: 'hint on', text: u.status || 'в сети' }));
          row.appendChild(t);
          listEl.appendChild(row);
        }
      } catch (e) { listEl.replaceChildren(el('p', { class: 'hint', text: friendlyErr(e, 'Не получилось загрузить') })); }
    })();
  }

  function openWinSettings() {
    const sh = modal('Окно CrynChat');
    const body = sh.body;
    body.appendChild(el('p', { class: 'kicker chat-set-sec', text: 'РАЗМЕР ОКНА' }));
    body.appendChild(el('p', { class: 'hint', text: 'Пресеты и точный размер. Окно запоминается при закрытии.' }));
    const presets = el('div', { class: 'chat-theme-row' });
    for (const [id, lab] of [['compact', 'Телефон 420x747'], ['default', 'Обычное 980x720'], ['wide', 'Широкое 1280x800']]) {
      presets.appendChild(el('button', {
        class: 'btn',
        type: 'button',
        text: lab,
        onclick: async () => {
          try {
            if (api.window && api.window.setPreset) await api.window.setPreset(id);
            toast('Размер: ' + lab);
          } catch (e) { failToast(e, 'Не получилось'); }
        }
      }));
    }
    body.appendChild(presets);
    const wIn = el('input', { class: 'field', type: 'number', placeholder: 'Ширина', min: '320', max: '3840' });
    const hIn = el('input', { class: 'field', type: 'number', placeholder: 'Высота', min: '460', max: '2160' });
    (async () => {
      try {
        const st = api.window && api.window.state ? await api.window.state() : null;
        if (st && st.bounds) {
          wIn.value = String(st.bounds.width || '');
          hIn.value = String(st.bounds.height || '');
        }
      } catch (_) { /* */ }
    })();
    body.appendChild(wIn);
    body.appendChild(hIn);
    body.appendChild(el('button', {
      class: 'btn btn-sky',
      type: 'button',
      text: 'Применить размер',
      onclick: async () => {
        const w = Number(wIn.value) || 980;
        const h = Number(hIn.value) || 720;
        try {
          if (api.window && api.window.setSize) await api.window.setSize(w, h);
          toast('Окно: ' + w + 'x' + h);
        } catch (e) { failToast(e, 'Не получилось'); }
      }
    }));
    body.appendChild(el('p', { class: 'kicker chat-set-sec', text: 'МАСШТАБ ИНТЕРФЕЙСА' }));
    const zoomRow = el('div', { class: 'chat-theme-row' });
    for (const z of [0.75, 0.9, 1, 1.1, 1.25, 1.5]) {
      zoomRow.appendChild(el('button', {
        class: 'btn',
        type: 'button',
        text: Math.round(z * 100) + '%',
        onclick: async () => {
          try {
            if (api.window && api.window.setZoom) await api.window.setZoom(z);
            toast('Масштаб ' + Math.round(z * 100) + '%');
          } catch (e) { failToast(e, 'Не получилось'); }
        }
      }));
    }
    body.appendChild(zoomRow);
    body.appendChild(el('p', { class: 'kicker chat-set-sec', text: 'РЕЖИМ' }));
    body.appendChild(el('button', {
      class: 'btn',
      type: 'button',
      text: 'Развернуть / восстановить',
      onclick: async () => { if (api.window && api.window.maximize) await api.window.maximize(); }
    }));
    body.appendChild(el('button', {
      class: 'btn',
      type: 'button',
      text: 'Во весь экран (F11)',
      onclick: async () => { if (api.window && api.window.fullscreen) await api.window.fullscreen(); }
    }));
  }

  function modal(titleText, opts = {}) {
    closeSheets(wrap);
    const sh = el('div', { class: 'chat-modal' });
    const hd = el('div', { class: 'chat-modal-head' });
    hd.appendChild(icon('back', 'Назад', () => sh.remove()));
    const titles = el('div', { class: 'chat-modal-titles' });
    titles.appendChild(el('strong', { text: titleText }));
    if (opts.sub) titles.appendChild(el('span', { class: 'hint', text: opts.sub }));
    hd.appendChild(titles);
    hd.appendChild(icon('x', 'Закрыть', () => sh.remove()));
    sh.appendChild(hd);
    const body = el('div', { class: 'chat-sheet-body' });
    sh.appendChild(body);
    col.appendChild(sh);
    return { sh, body };
  }

  async function openPeople() {
    const sh = sheet('Люди');
    const q = el('input', { class: 'field chat-search', placeholder: 'Найти игрока' });
    sh.body.appendChild(q);
    const box = el('div');
    sh.body.appendChild(box);
    async function run() {
      box.replaceChildren(el('p', { class: 'hint', text: 'Ищу…' }));
      try {
        const r = await call('searchUsers', q.value.trim());
        const items = (r && r.items) || [];
        box.replaceChildren();
        if (!items.length) box.appendChild(el('p', { class: 'hint', text: 'Никого не нашли. Попробуйте другой запрос.' }));
        for (const u of items) {
          const row = el('div', { class: 'chat-user-row', onclick: () => { sh.sh.remove(); openProfile(u.nick); } });
          row.appendChild(ava(u.avatar, u.nick, u.online));
          const t = el('p');
          t.appendChild(el('b', { text: u.nick }));
          t.appendChild(el('span', { class: 'hint', text: u.status || (u.online ? 'в сети' : '') }));
          row.appendChild(t);
          box.appendChild(row);
        }
      } catch (e) { box.replaceChildren(el('p', { class: 'hint', text: friendlyErr(e, 'Не получилось найти') })); }
    }
    q.addEventListener('input', () => { clearTimeout(q._t); q._t = setTimeout(run, 220); });
    if (C.dms) {
      try {
        const d = await C.dms();
        const items = (d && d.items) || [];
        if (items.length) {
          box.appendChild(el('p', { class: 'kicker', text: 'ЛИЧКИ' }));
          for (const it of items) {
            const row = el('div', { class: 'chat-dm-row', onclick: () => { sh.sh.remove(); openThread(it.thread, it.nick); } });
            row.appendChild(ava(it.avatar, it.nick, false));
            const t = el('p');
            t.appendChild(el('b', { text: it.nick }));
            t.appendChild(el('span', { class: 'hint', text: it.text || '' }));
            row.appendChild(t);
            if (it.unread) row.appendChild(el('span', { class: 'chat-badge', text: String(it.unread) }));
            box.appendChild(row);
          }
        }
      } catch (_) { /* */ }
    }
    run();
  }

  async function openSearch(prefill) {
    const sh = sheet('Поиск по чату');
    const q = el('input', { class: 'field chat-search', placeholder: 'Текст, #тег или ник' });
    if (prefill) q.value = String(prefill);
    sh.body.appendChild(q);
    const box = el('div');
    sh.body.appendChild(box);
    async function run() {
      const query = q.value.trim();
      if (!query) { box.replaceChildren(); return; }
      box.replaceChildren(el('p', { class: 'hint', text: 'Ищу…' }));
      try {
        const r = await call('search', query);
        const items = (r && r.items) || [];
        box.replaceChildren();
        if (!items.length) box.appendChild(el('p', { class: 'hint', text: 'Ничего не нашлось по этому запросу.' }));
        for (const it of items) {
          const node = bubble(it);
          if (node) box.appendChild(node);
        }
      } catch (err) { box.replaceChildren(el('p', { class: 'hint', text: friendlyErr(err, 'Не получилось найти') })); }
    }
    q.addEventListener('keydown', (e) => { if (e.key === 'Enter') run(); });
    q.focus();
    if (prefill) run();
  }

  async function openPacks() {
    const sh = sheet('Коллекции');
    async function reload() {
      sh.body.replaceChildren();
      try {
        const r = C.packs ? await C.packs() : { items: [] };
        packs = (r && r.items) || [];
      } catch (_) { packs = []; }
      const form = el('div', { class: 'chat-form' });
      const name = el('input', { class: 'field', placeholder: 'Название коллекции' });
      const kind = el('select', { class: 'field' });
      kind.appendChild(el('option', { value: 'sticker', text: 'Стикеры' }));
      kind.appendChild(el('option', { value: 'gif', text: 'GIF' }));
      form.appendChild(name);
      form.appendChild(kind);
      form.appendChild(el('button', { class: 'btn btn-sky', text: 'Создать', onclick: async () => {
        try {
          await call('createPack', name.value.trim(), kind.value, { public: true });
          toast('Коллекция создана');
          reload();
        } catch (e) { failToast(e, 'Не создалось'); }
      } }));
      sh.body.appendChild(form);
      if (!packs.length) sh.body.appendChild(el('p', { class: 'hint', text: 'Пока пусто — создай пак стикеров или GIF.' }));
      for (const p of packs) {
        const card = el('div', { class: 'chat-pack-card' });
        const row = el('div', { class: 'row' });
        row.appendChild(el('strong', { text: p.name + ' · ' + (p.count || 0) }));
        if (p.owner) {
          row.appendChild(el('button', { class: 'btn btn-ghost', text: 'Удалить', onclick: async () => {
            try { await call('delPack', p.id); reload(); } catch (e) { failToast(e, 'Не получилось'); }
          } }));
        }
        card.appendChild(row);
        const grid = el('div', { class: 'chat-stickers' });
        for (const it of (p.items || []).slice(0, 12)) {
          const b = el('button', { class: 'chat-sticker-btn', type: 'button' });
          const img = el('img', { alt: it.name || '' });
          img.src = it.url;
          b.appendChild(img);
          b.addEventListener('click', async () => {
            try {
              await call('send', it.name || p.name, { kind: p.kind === 'gif' ? 'gif' : 'sticker', url: it.url, name: it.name, thread });
              sh.sh.remove();
              loadFresh();
            } catch (e) { failToast(e, 'Не отправилось'); }
          });
          grid.appendChild(b);
        }
        if (p.owner) {
          card.appendChild(el('button', { class: 'btn', text: 'Добавить файл', onclick: async () => {
            const file = await pick(p.kind === 'gif' ? 'image/gif,image/webp' : 'image/*');
            if (!file) return;
            if (file.size > maxFileOf(kind)) { toast('Файл слишком большой', 'bad'); return; }
            try {
              const b64 = await readFile(file);
              await call('upload', p.kind === 'gif' ? 'gif' : 'sticker', file.name, b64, { packId: p.id, thread });
              toast('Добавлено');
              reload();
            } catch (e) { failToast(e, 'Не загрузилось'); }
          } }));
        }
        card.appendChild(grid);
        sh.body.appendChild(card);
      }
    }
    await reload();
  }

  async function openDm(nick) {
    try {
      const r = await call('dmOpen', nick);
      if (!r || !r.ok) throw new Error((r && r.error) || 'Не открылось');
      await openThread(r.thread, nick, r.user);
    } catch (e) { failToast(e, 'Не открылось'); }
  }

  function paintThreadHead(nick, user) {
    const meta = chatMeta(thread) || {};
    const avSrc = (user && user.avatar) || meta.avatar || '';
    const name = (user && user.nick) || nick || meta.title || (thread === 'global' ? 'CrynChat' : thread === 'channel' ? 'Канал' : thread === 'system' ? 'Уведомления' : thread === 'saved' ? 'Избранное' : thread === 'dm:createbot' ? 'CrynBot' : thread === 'dm:adminbot' ? 'Admin' : 'Чат');
    mark.replaceChildren();
    mark.className = 'chat-mark' + (user && user.online ? ' online' : '');
    if (avSrc) {
      const img = el('img', { alt: name });
      img.src = mediaMem.get(avSrc) || avSrc;
      if (!avaSeen.has(avSrc) && !mediaMem.get(avSrc)) mark.classList.add('chat-ava-load');
      img.addEventListener('load', () => { mark.classList.remove('chat-ava-load'); avaSeen.add(avSrc); }, { once: true });
      img.addEventListener('error', () => { mark.replaceChildren(); mark.textContent = initials(name); mark.classList.remove('chat-ava-load'); }, { once: true });
      mark.appendChild(img);
      if (C.cacheMedia && !String(avSrc).startsWith('data:')) {
        C.cacheMedia(avSrc).then((r) => {
          const s = r && (r.src || r);
          if (typeof s === 'string' && s) { mediaMem.set(avSrc, s); if (img.isConnected) img.src = s; }
        }).catch(() => {});
      }
    } else mark.textContent = initials(name);
    mark.onclick = () => {
      if (String(thread).startsWith('dm:') || user) openProfile(name);
      else openChatProfile(thread, meta);
    };
    title.replaceChildren();
    title.appendChild(document.createTextNode(name));
    const dmStreak = (dmsMem.items || []).find((x) => x.thread === thread);
    const st = (user && user.streak) || streakMem || (dmStreak && dmStreak.streak);
    if (st && (st.days || st.lit || st.gray) && String(thread).startsWith('dm:')) {
      title.appendChild(flameNode(typeof st === 'object' ? st : { days: st, lit: true }));
    }
    if (thread === 'global') setSub((me && me.nick ? me.nick + ' · ' : '') + (meta.about || 'общий'), true);
    else if (thread === 'channel') setSub(meta.about || (isAdmin() ? 'канал · вы админ' : 'канал'), true);
    else if (thread === 'system') setSub('системные уведомления', true);
    else if (thread === 'saved') setSub('сохранённые сообщения', true);
    else if (thread === 'dm:createbot') setSub('бот · создать бота', true);
    else if (thread === 'dm:adminbot') setSub('бот · модерация', true);
    else setSub((user && user.status) || (user && user.online ? 'в сети' : 'личное'), true);
    titles.onclick = () => {
      if (String(thread).startsWith('dm:') || user) openProfile(name);
      else openChatProfile(thread, meta);
    };
  }

  async function openThread(th, nick, user) {
    thread = th || 'global';
    replyTo = null;
    editTarget = null;
    pendingFile = null;
    // при смене чата останавливаем музыкальный виджет, чтобы не играл фоном
    if (musicWidget) {
      const mw = musicWidget.querySelector('audio');
      if (mw) try { mw.pause(); } catch (_) { /* */ }
      musicWidget.remove();
      musicWidget = null;
    }
    itemsCache = [];
    offset = 0;
    done = false;
    lastId = '';
    unreadMiss = 0;
    pinCycle = 0;
    // мгновенно очистить DOM, чтобы не мигало старое сообщение при смене чата
    list.replaceChildren(el('div', { class: 'chat-loading-hint', text: 'Загрузка…' }));
    paintReply();
    paintAttach();
    closeSheets(wrap);
    paintThreadHead(nick, user);
    applyWallpaper();
    if (C.setLastThread) C.setLastThread(thread, nick || title.textContent).catch(() => {});
    if (liveSock && liveSock.sub) liveSock.sub(thread);
    collapseList();
    paintSidebar();
    const kanalMine = String(thread).startsWith('kanal:') && me && me.channelId && thread === 'kanal:' + me.channelId;
    const channelLock = ((thread === 'channel' && !kanalMine) || thread === 'system') && me && me.ok && me.verified !== false && !isAdmin() && !(me.needVerify) && !kanalMine;
    composer.classList.toggle('hidden', Boolean(channelLock) || !(me && me.ok) || (me.needVerify || me.verified === false));
    paintHead();
    if (C.drafts) {
      try {
        const d = await C.drafts();
        setInputText((d && d[thread]) || '');
      } catch (_) { /* */ }
    }
    await loadFresh();
    if (String(thread).includes('createbot') && !botStep && !greetedBots.has(thread) && !itemsCache.some((x) => x.role === 'bot')) {
      greetedBots.add(thread);
      handleCreateBot('/start');
    }
    if (String(thread).includes('adminbot') && !greetedBots.has(thread) && !itemsCache.some((x) => x.role === 'bot')) {
      greetedBots.add(thread);
      handleAdminBot('/start');
    }
  }

  function popupNote(item) {
    const archived = (me && me.archivedChats) || [];
    if (!shouldNotify(item, me, prefs, archived)) return;
    if (item.thread === thread && document.hasFocus()) {
      notePush(item);
      return;
    }
    notePush(item);
    savePushState();
    const body = pushBody(item);
    const title = item.nick || 'CrynChat';
    const n = (pushCounts.get(item.thread) || 1);
    const shown = n > 1 ? title + ' · ' + n : title;
    if (C.nativeNotify) C.nativeNotify({ title: shown, body, silent: !(prefs && prefs.sound) }).catch(() => {});
    if (typeof Notification !== 'undefined' && Notification.permission === 'granted') {
      try {
        const actions = [{ action: 'reply', title: 'Ответить', type: 'text', placeholder: 'Ответ…' }];
        const note = new Notification(shown, { body, silent: true, tag: 'cryn:' + (item.thread || item.id), actions });
        note.onclick = () => {
          note.close();
          if (item.thread && item.thread !== thread) openThread(item.thread, item.nick);
        };
        note.onreply = (ev) => {
          const t = (ev && (ev.response || ev.reply || '')).trim();
          if (t) call('send', t, { thread: item.thread || thread, replyTo: item.id }).catch(() => {});
        };
      } catch (_) { /* */ }
    } else if (typeof Notification !== 'undefined' && Notification.permission === 'default') {
      Notification.requestPermission().catch(() => {});
    }
  }

  async function adminAct(fn, nick, extra) {
    const reason = window.prompt('Причина', 'нарушение правил');
    if (reason == null) return;
    try {
      if (fn === 'ban') await call('ban', nick, extra || 24, reason);
      else if (fn === 'modMute') await call('modMute', nick, extra || 30, reason);
      else if (fn === 'warn') await call('warn', nick, reason);
      else if (fn === 'kick') await call('kick', nick);
      toast('Готово');
      loadFresh();
    } catch (e) { failToast(e, 'Не получилось'); }
  }

  async function openChats() {
    openList();
  }

  function lastPreview(it) {
    if (!it) return '';
    if (it.deleted) return '';
    const kind = it.kind || '';
    if (kind === 'image' || kind === 'gif') return (it.nick ? it.nick + ': ' : '') + (it.caption || (kind === 'gif' ? 'GIF' : 'Фото'));
    if (kind === 'sticker') return (it.nick ? it.nick + ': ' : '') + 'Стикер';
    if (kind === 'audio' || kind === 'voice') return (it.nick ? it.nick + ': ' : '') + 'Аудио';
    if (kind === 'poll') return (it.nick ? it.nick + ': ' : '') + 'Опрос';
    const raw = String(it.lastText || it.text || it.caption || '').replace(/\s+/g, ' ').trim();
    if (!raw) return '';
    const dm = String(it.thread || '').startsWith('dm:');
    const who = it.nick && !dm ? it.nick + ': ' : '';
    const line = who + raw;
    return line.slice(0, 72) + (raw.length > 64 ? '…' : '');
  }

  function renderSidebarRows(rows) {
    sideList.replaceChildren();
    const add = (row) => {
      const r = el('div', { class: 'chat-side-row' + (row.on ? ' on' : '') + (row.draft ? ' draft' : '') + (row.unread ? ' unread' : ''), onclick: () => {
        collapseList();
        openThread(row.id, String(row.name || '').replace(/^\* /, ''));
      } });
      r.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        const isDm = String(row.id || '').startsWith('dm:');
        const archived = (me && me.archived || []).includes(row.id);
        const items = [];
        if (isDm) {
          items.push({ icon: 'block', label: 'Заблокировать', danger: true, onclick: () => blockUser(String(row.name || '').replace(/^\* /, '')) });
          items.push({ icon: 'archive', label: archived ? 'Из архива' : 'В архив', onclick: async () => {
            try {
              const res = await call('archiveChat', row.id);
              if (me) me.archived = (res && res.archived) || [];
              paintSidebar();
            } catch (err) { failToast(err, 'Не получилось'); }
          } });
          items.push({ icon: 'trash', label: 'Удалить чат', danger: true, onclick: async () => { try { const res = await call('archiveChat', row.id); if (me) me.archived = (res && res.archived) || []; paintSidebar(); toast('Чат убран'); } catch (err) { failToast(err, 'Не получилось'); } } });
        } else {
          items.push({ icon: 'archive', label: archived ? 'Из архива' : 'В архив', onclick: async () => {
            try {
              const res = await call('archiveChat', row.id);
              if (me) me.archived = (res && res.archived) || [];
              paintSidebar();
            } catch (err) { failToast(err, 'Не получилось'); }
          } });
          items.push({ icon: 'leave', label: 'Покинуть', danger: true, onclick: async () => {
            try { const res = await call('leaveChannel', row.id); if (res && res.ok) { loadFresh(); toast('Канал покинут'); } } catch (err) { failToast(err, 'Не получилось'); }
          } });
        }
        const box = wrap.getBoundingClientRect();
        const pop = menu(r, items, { place: 'up', class: 'chat-ctx-menu' });
        pop.style.left = Math.max(8, Math.min(e.clientX - box.left, box.width - pop.offsetWidth - 8)) + 'px';
        pop.style.top = Math.max(8, Math.min(e.clientY - box.top, box.height - pop.offsetHeight - 8)) + 'px';
      });
      if (row.icon) r.appendChild(iconAva(row.icon, row.iconClass || ''));
      else r.appendChild(ava(row.avaSrc, row.name, false, { avatarHat: row.listHat || row.avatarHat, cls: 'list' }));
      if (row.listHat) {
        const deco = el('img', { class: 'chat-list-hat', alt: '' });
        deco.src = row.listHat;
        r.appendChild(deco);
      }
      if (row.listStyle) r.classList.add('list-' + row.listStyle);
      const meta = el('div', { class: 'chat-side-meta' });
      const nameRow = el('div', { class: 'chat-nick-row' });
      const nameEl = el('b', { text: row.name });
      if (row.nameColor) nameEl.style.color = row.nameColor;
      if (row.pin) {
        const pinI = el('span', { class: 'chat-side-pin' });
        pinI.innerHTML = svg('pin');
        nameRow.appendChild(pinI);
      }
      nameRow.appendChild(nameEl);
      if (row.badge) {
        const m = badgeMark(row.badge);
        if (m) nameRow.appendChild(m);
      }
      if (row.streak) nameRow.appendChild(flameNode({ days: row.streak, lit: row.streakLit, gray: row.streakGray }));
      meta.appendChild(nameRow);
      meta.appendChild(el('span', { text: row.hint || '' }));
      if (prefs.showMsgCount && row.count) meta.appendChild(el('span', { class: 'chat-side-count', text: row.count + ' сообщ.' }));
      r.appendChild(meta);
      const end = el('div', { class: 'chat-side-end' });
      const badges = el('div', { class: 'chat-side-badges' });
      if (row.mention) badges.appendChild(el('span', { class: 'chat-side-mention', text: '@' }));
      if (row.unread) badges.appendChild(el('span', { class: 'chat-badge', text: String(row.unread) }));
      if (badges.childNodes.length) end.appendChild(badges);
      if (row.time) end.appendChild(el('span', { class: 'chat-side-time', text: row.time }));
      r.appendChild(end);
      sideList.appendChild(r);
    };
    if (listMode === 'blocked') {
      if (!rows.length) sideList.appendChild(el('p', { class: 'hint', text: 'Нет заблокированных' }));
      for (const r of rows) add(r);
      return;
    }
    const live = rows.filter((r) => !r.arch);
    const hid = rows.filter((r) => r.arch);
    const seen = new Set();
    if (listMode === 'archive') {
      if (!hid.length) sideList.appendChild(el('p', { class: 'hint', text: 'Архив пуст' }));
      for (const r of hid) {
        if (seen.has(r.id)) continue;
        seen.add(r.id);
        add(r);
      }
      return;
    }
    for (const r of live) {
      if (seen.has(r.id)) continue;
      seen.add(r.id);
      add(r);
    }
    if (hid.length) {
      const head = el('button', { class: 'chat-archive-head', type: 'button' });
      head.appendChild(el('b', { text: 'Архив' }));
      head.appendChild(el('span', { class: 'hint', text: String(hid.length) }));
      head.addEventListener('click', (e) => { e.stopPropagation(); toggleListMode('archive'); });
      sideList.appendChild(head);
    }
  }

  async function paintSidebar() {
    const gen = ++sidebarPaintGen;
    const g = chatMeta('global') || { title: 'CrynChat', about: 'общий чат' };
    const c = chatMeta('channel') || { title: 'Канал', about: 'канал' };
    const q = String(sideSearch.value || '').toLowerCase();
    const match = (s) => !q || String(s || '').toLowerCase().includes(q);
    const pinned = (me && me.pinnedChats) || [];
    const archived = (me && me.archived) || [];
    const draftsMap = {};
    const rows = [];
    const hidden = new Set(prefs.hideChats || []);
    const push = (id, avaSrc, name, hint, unread, on, extra) => {
      extra = extra || {};
      if (hidden.has(id)) return;
      const draft = draftsMap[id] ? 'черновик: ' + String(draftsMap[id]).slice(0, 40) : '';
      const line = draft || hint;
      if (!match(name) && !match(line)) return;
      // Числовое время последней активности для «недавних» — как в Telegram.
      let lastAt = extra.lastAt || 0;
      if (!lastAt) {
        const lm = lastMsgMap[id];
        if (lm && lm.at) lastAt = new Date(lm.at).getTime() || 0;
      }
      if (!lastAt) {
        const cch = (chatsMem.items || []).find((c) => c.id === id) || chatMeta(id);
        if (cch && (cch.lastAt || cch.at)) lastAt = new Date(cch.lastAt || cch.at).getTime() || 0;
      }
      rows.push({
        id, avaSrc, name, hint: line, unread: prefs.showUnread === false ? 0 : (Number(unread) || 0), on, pin: pinned.includes(id), arch: archived.includes(id),
        draft: Boolean(draft), mention: Boolean(extra.mention), time: extra.time || '', badge: extra.badge || '',
        icon: extra.icon || '', iconClass: extra.iconClass || '',
        listStyle: extra.listStyle || '', streak: extra.streak || 0, streakGray: Boolean(extra.streakGray),
        streakLit: Boolean(extra.streakLit), count: extra.count || 0, nameColor: extra.nameColor || '',
        listHat: extra.listHat || '', avatarHat: extra.avatarHat || '',
        lastAt
      });
    };
    const lastOf = (id) => {
      if (lastMsgMap[id] && !lastMsgMap[id].deleted) return lastPreview(lastMsgMap[id]);
      if (thread === id && itemsCache[0] && !itemsCache[0].deleted) return lastPreview(itemsCache[0]);
      const cached = (chatsMem.items || []).find((c) => c.id === id) || chatMeta(id);
      if (cached && (cached.lastText || cached.text || cached.last)) {
        const src = cached.last && typeof cached.last === 'object' ? cached.last : cached;
        return lastPreview({
          text: src.lastText || src.text || src.caption || '',
          nick: src.lastNick || src.nick || '',
          kind: src.lastKind || src.kind || '',
          thread: id,
          deleted: src.deleted
        });
      }
      return '';
    };
    const lastTime = (id) => {
      const it = lastMsgMap[id];
      if (it && it.at) return fmtTime(it.at);
      const cached = (chatsMem.items || []).find((c) => c.id === id) || chatMeta(id);
      return fmtTime((cached && (cached.lastAt || cached.at)) || '');
    };
    push('saved', '', 'Избранное', lastOf('saved') || 'сохранённые сообщения', me && me.unreadSaved, thread === 'saved', { icon: 'star', iconClass: 'saved', time: lastTime('saved') });
    push('global', g.avatar, g.title || 'CrynChat', lastOf('global') || g.about || 'общий чат', me && me.unread, thread === 'global', { mention: Boolean(me && me.mention), icon: g.avatar ? '' : 'users', iconClass: 'global', time: lastTime('global') });
    push('system', '', 'Уведомления', lastOf('system') || 'системные события', me && me.unreadSystem, thread === 'system', { badge: 'official', icon: 'bell', iconClass: 'system', time: lastTime('system') });
    push('channel', c.avatar, c.title || 'Канал', lastOf('channel') || c.about || 'канал', me && me.unreadChannel, thread === 'channel', { badge: 'official', icon: c.avatar ? '' : 'pin', iconClass: 'channel', time: lastTime('channel') });
    push('dm:createbot', '', 'CrynBot', lastOf('dm:createbot') || 'создать бота', 0, thread === 'dm:createbot', { badge: 'official', icon: 'bot', iconClass: 'bot', time: lastTime('dm:createbot') });
    push('dm:adminbot', '', 'Admin', lastOf('dm:adminbot') || 'системные события', 0, thread === 'dm:adminbot', { badge: 'staff', icon: 'shield', iconClass: 'staff', time: lastTime('dm:adminbot') });
    for (const it of dmsMem.items || []) {
      push(it.thread, it.avatar, it.nick, lastPreview(it) || it.text || '', it.unread, thread === it.thread, {
        mention: Boolean(it.mention), time: fmtTime(it.at), badge: (it.badges && it.badges[0]) || '',
        listStyle: it.listStyle || '', streak: (it.streak && it.streak.days) || it.streak || 0,
        streakGray: Boolean(it.streakGray || (it.streak && it.streak.gray)),
        streakLit: Boolean(it.streakLit || (it.streak && it.streak.lit)),
        count: it.count || it.msgs || 0, nameColor: it.nameColor || '',
        lastAt: (it.at ? new Date(it.at).getTime() : 0)
      });
    }
    rows.sort((a, b) => (b.pin - a.pin) || (a.arch - b.arch) || ((b.lastAt || 0) - (a.lastAt || 0)));
    if (listMode !== 'blocked') renderSidebarRows(rows);
    (async () => {
      if (listMode === 'blocked') {
        try {
          const r = await call('block');
          const items = (r && (r.blocked || r.items)) || (me && me.blocked) || [];
          const blockedRows = [];
          for (const it of items) {
            const nick = typeof it === 'string' ? it : (it.nick || it.id || '');
            if (!nick || !match(nick)) continue;
            blockedRows.push({
              id: 'dm:' + nick, avaSrc: (it && it.avatar) || '', name: nick, hint: 'заблокирован', unread: 0, on: false, pin: false, arch: false
            });
          }
          if (gen !== sidebarPaintGen) return;
          renderSidebarRows(blockedRows);
        } catch (e) {
          if (gen !== sidebarPaintGen) return;
          sideList.replaceChildren(el('p', { class: 'hint', text: friendlyErr(e, 'Нет данных') }));
        }
        return;
      }
      if (C.drafts) {
        try { Object.assign(draftsMap, await C.drafts() || {}); } catch (_) { /* */ }
      }
      if (C.chats) {
        try {
          const r = await C.chats();
          if (r && r.items) {
            chatsMem = { items: r.items, at: Date.now() };
            if (me) me.chats = r.items;
            for (const c of r.items) {
              if (!c || !c.id || lastMsgMap[c.id]) continue;
              if (c.lastText || c.lastKind) {
                lastMsgMap[c.id] = { text: c.lastText || '', nick: c.lastNick || '', at: c.lastAt || '', kind: c.lastKind || '', thread: c.id };
              }
            }
          }
        } catch (_) { /* */ }
      }
      if (C.dms) {
        try {
          const d = await C.dms();
          if (d && d.items) dmsMem = { items: d.items, at: Date.now() };
        } catch (_) { /* */ }
      }
      if (gen !== sidebarPaintGen) return;
      rows.length = 0;
      push('saved', '', 'Избранное', lastOf('saved') || 'сохранённые сообщения', me && me.unreadSaved, thread === 'saved', { icon: 'star', iconClass: 'saved', time: lastTime('saved') });
      push('global', g.avatar, g.title || 'CrynChat', lastOf('global') || g.about || 'общий чат', me && me.unread, thread === 'global', { mention: Boolean(me && me.mention), icon: g.avatar ? '' : 'users', iconClass: 'global', time: lastTime('global') });
      push('system', '', 'Уведомления', lastOf('system') || 'системные события', me && me.unreadSystem, thread === 'system', { badge: 'official', icon: 'bell', iconClass: 'system', time: lastTime('system') });
      push('channel', c.avatar, c.title || 'Канал', lastOf('channel') || c.about || 'канал', me && me.unreadChannel, thread === 'channel', { badge: 'official', icon: c.avatar ? '' : 'pin', iconClass: 'channel', time: lastTime('channel') });
      push('dm:createbot', '', 'CrynBot', lastOf('dm:createbot') || 'создать бота', 0, thread === 'dm:createbot', { badge: 'official', icon: 'bot', iconClass: 'bot', time: lastTime('dm:createbot') });
      push('dm:adminbot', '', 'Admin', lastOf('dm:adminbot') || 'системные события', 0, thread === 'dm:adminbot', { badge: 'staff', icon: 'shield', iconClass: 'staff', time: lastTime('dm:adminbot') });
      for (const it of dmsMem.items || []) {
        const hatId = it.listHat || (it.cosmetics && it.cosmetics.listHat) || '';
        const hat = hatUrl(it, 'listHat', shopMap) || (shopMap.get(hatId) && shopMap.get(hatId).url) || '';
        push(it.thread, it.avatar, it.nick, lastPreview(it) || it.text || '', it.unread, thread === it.thread, {
          mention: Boolean(it.mention), time: fmtTime(it.at), badge: (it.badges && it.badges[0]) || '',
          listStyle: it.listStyle || '', streak: (it.streak && it.streak.days) || it.streak || 0,
          streakGray: Boolean(it.streakGray || (it.streak && it.streak.gray)),
          streakLit: Boolean(it.streakLit || (it.streak && it.streak.lit)),
          count: it.count || it.msgs || 0, nameColor: it.nameColor || '',
          listHat: hat, avatarHat: hatUrl(it, 'avatarHat', shopMap),
          lastAt: (it.at ? new Date(it.at).getTime() : 0)
        });
      }
      for (const c of (chatsMem.items || [])) {
        if (!c || !c.id) continue;
        if (['global', 'channel', 'system', 'saved'].includes(c.id)) continue;
        if (String(c.id).startsWith('dm:')) continue;
        push(c.id, c.avatar, c.title || c.handle || 'Канал', lastOf(c.id) || c.about || '', c.unread, thread === c.id, {
          icon: c.avatar ? '' : 'pin', iconClass: 'channel', time: lastTime(c.id), badge: 'official'
        });
      }
      rows.sort((a, b) => (b.pin - a.pin) || (a.arch - b.arch) || ((b.lastAt || 0) - (a.lastAt || 0)));
      renderSidebarRows(rows);
    })().catch(() => {});
  }

  sideSearch.addEventListener('input', () => { paintSidebar(); });

  async function loadShop() {
    try {
      const r = C.shop ? await C.shop() : await call('shop');
      shopItems = (r && r.items) || [];
      shopMap.clear();
      for (const it of shopItems) if (it && it.id) shopMap.set(it.id, it);
    } catch (_) { shopItems = shopItems || []; }
  }

  async function maybeOnboard() {
    if (!me || !me.ok || me.needVerify || me.verified === false) return;
    if (prefs.onboarded) return;
    try { if ((await idb.kvGet('onboard')) === '1') return; } catch (_) { /* */ }
    const veil = el('div', { class: 'chat-onboard-veil' });
    const card = el('div', { class: 'chat-onboard' });
    card.appendChild(el('h3', { text: 'Давайте настроим всё под вас' }));
    card.appendChild(el('p', { class: 'hint', text: 'Выберите оформление. Его всегда можно сменить в настройках интерфейса.' }));
    const grid = el('div', { class: 'chat-onboard-grid' });
    const skins = [
      ['night', 'Тёмная', 'Спокойный тёмный мессенджер'],
      ['day', 'Светлая', 'Чистый дневной интерфейс'],
      ['accent', 'Акцент', 'Фиолетовый акцент для вечера']
    ];
    function markOnboard() {
      savePrefs({ onboarded: true });
      idb.kvSet('onboard', '1').catch(() => {});
    }
    for (const [id, lab, hint] of skins) {
      const b = el('button', { class: 'chat-onboard-card', type: 'button' });
      b.appendChild(el('b', { text: lab }));
      b.appendChild(el('span', { class: 'hint', text: hint }));
      b.addEventListener('click', () => {
        savePrefs({ skin: 'classic', theme: id, onboarded: true });
        idb.kvSet('onboard', '1').catch(() => {});
        veil.remove();
      });
      grid.appendChild(b);
    }
    card.appendChild(grid);
    card.appendChild(el('button', { class: 'btn btn-ghost', type: 'button', text: 'Позже', onclick: () => {
      markOnboard();
      veil.remove();
    } }));
    veil.appendChild(card);
    wrap.appendChild(veil);
  }

  function __setOffline(v) {
    offlineEl.classList.toggle('hidden', !v);
  }
  // Мгновенная анимация «печатает / выбирает стикер» в строке композера.
  function showTyping(nick, kind) {
    if (!nick) return;
    if (typingShowTimer) { clearTimeout(typingShowTimer); typingShowTimer = 0; }
    const dots = el('span', { class: 'chat-dots chat-dots-typing' });
    dots.appendChild(el('i'));
    dots.appendChild(el('i'));
    dots.appendChild(el('i'));
    const txt = kind === 'sticker' ? nick + ' выбирает стикер…' : (kind === 'gif' ? nick + ' выбирает GIF…' : nick + ' печатает…');
    typingEl.replaceChildren(dots, el('span', { class: 'chat-typing-lab', text: txt }));
    typingEl.classList.add('on');
    typingShowTimer = setTimeout(() => {
      typingEl.classList.remove('on');
      typingEl.replaceChildren();
    }, 4200);
  }
  function bootLive() {
    if (liveSock) { try { liveSock.close(); } catch (_) { /* */ } liveSock = null; }
    if (!me || !me.ok || !me.token) return;
    const url = (me.ws && me.ws.url) || '';
    liveSock = openLive({
      token: me.token,
      uid: me.id,
      nick: me.nick,
      url,
      onStatus: (state) => {
        __setOffline(state === 'offline' || state === 'reconnecting');
      },
      onEvent: (msg) => {
        const type = msg.type || (msg.data && msg.data.type) || '';
        const data = msg.data || msg;
        if (type === 'message' || type === 'msg') {
          const item = data.item || data;
          if (item && item.thread === thread) appendLive(item);
          else paintSidebar();
        }
        if (type === 'presence') {
          if (data.uid && userCache.has(data.nick)) {
            const u = userCache.get(data.nick) || {};
            u.online = Boolean(data.online);
            userCache.set(data.nick, u);
          }
          if (data.online && data.nick) setSub(data.nick + ' в сети', true);
        }
        if (type === 'typing' && data.thread === thread && data.nick !== (me && me.nick)) {
          setSub(data.nick + ' печатает…', true);
          showTyping(data.nick, data.kind);
        }
        if (type === 'sticker' && data.thread === thread && data.nick !== (me && me.nick)) {
          setSub(data.nick + ' выбирает стикер…', true);
          showTyping(data.nick, 'sticker');
        }
      }
    });
    if (thread) liveSock.sub(thread);
  }

  function openShop() {
    const sh = modal('Магазин');
    const coins = el('p', { class: 'kicker', text: 'Пирикас: ' + String((me && me.pirikas) || 0) });
    sh.body.appendChild(coins);
    const grid = el('div', { class: 'chat-shop-grid' });
    sh.body.appendChild(grid);
    const paint = async () => {
      await loadShop();
      grid.replaceChildren();
      if (!shopItems.length) {
        grid.appendChild(el('p', { class: 'hint', text: 'Пока пусто. Админ добавит предметы.' }));
        return;
      }
      const owned = ((me && me.cosmetics && me.cosmetics.owned) || []);
      for (const it of shopItems) {
        const card = el('div', { class: 'chat-shop-card' });
        if (it.url) {
          const img = el('img', { class: 'chat-shop-preview', alt: it.name || '' });
          img.src = it.url;
          card.appendChild(img);
        }
        card.appendChild(el('b', { text: it.name || 'Предмет' }));
        card.appendChild(el('span', { class: 'hint', text: (it.kind === 'avatarHat' ? 'Шапка аватарки' : it.kind === 'listHat' ? 'Шапка списка чатов' : 'Шапка профиля') + (it.desc ? ' · ' + it.desc : '') }));
        card.appendChild(el('span', { class: 'chat-chip', text: String(it.price || 0) + ' пирикас' }));
        const has = owned.includes(it.id);
        if (has) {
          card.appendChild(el('button', { class: 'btn', text: 'Надеть', onclick: async () => {
            try {
              const r = C.shopWear ? await C.shopWear(it.id, it.kind) : await call('shopWear', it.id, it.kind);
              if (r && r.user) me = { ...me, ...r.user };
              toast('Надето');
              paintAuth();
            } catch (e) { failToast(e, 'Не получилось'); }
          } }));
        } else {
          const can = Number((me && me.pirikas) || 0) >= Number(it.price || 0);
          card.appendChild(el('button', { class: 'btn btn-sky', text: can ? 'Купить' : 'Не хватает', disabled: can ? undefined : 'disabled', onclick: async () => {
            if (!can) return;
            try {
              const r = C.shopBuy ? await C.shopBuy(it.id) : await call('shopBuy', it.id);
              if (r && r.user) me = { ...me, ...r.user };
              toast('Куплено');
              coins.textContent = 'Пирикас: ' + String((me && me.pirikas) || 0);
              paint();
            } catch (e) { failToast(e, 'Не купилось'); }
          } }));
        }
        grid.appendChild(card);
      }
    };
    paint();
  }

  function openMyKanal() {
    const sh = modal(me && me.channelId ? 'Мой канал' : 'Новый канал');
    const handle = el('input', { class: 'field', placeholder: 'Юз канала без &@' });
    const titleIn = el('input', { class: 'field', placeholder: 'Название' });
    const about = el('textarea', { class: 'field', placeholder: 'Описание', rows: '3' });
    const links = el('input', { class: 'field', placeholder: 'Ссылки через запятую https://…' });
    sh.sh.classList.add('chat-modal-compact');
    sh.body.classList.add('chat-form-gap');
    sh.body.appendChild(handle);
    sh.body.appendChild(titleIn);
    sh.body.appendChild(about);
    sh.body.appendChild(links);
    if (me && me.channelId) {
      (C.kanal ? C.kanal(me.channelId) : call('kanal', me.channelId)).then((r) => {
        const k = (r && r.kanal) || {};
        handle.value = k.handle || '';
        titleIn.value = k.title || '';
        about.value = k.about || '';
        links.value = ((k.links || []).map((x) => x.url || x).join(', '));
      }).catch(() => {});
    }
    sh.body.appendChild(el('button', { class: 'btn btn-sky chat-compact-btn', text: me && me.channelId ? 'Сохранить' : 'Создать', onclick: async () => {
      try {
        const payload = {
          handle: handle.value.trim(),
          title: titleIn.value.trim(),
          about: about.value.trim(),
          links: String(links.value || '').split(',').map((s) => s.trim()).filter(Boolean)
        };
        const r = me && me.channelId
          ? (C.saveKanal ? await C.saveKanal(payload) : await call('saveKanal', payload))
          : (C.createKanal ? await C.createKanal(payload.handle, payload) : await call('createKanal', payload.handle, payload));
        if (!r || !r.ok) throw new Error((r && r.error) || 'Не вышло');
        if (r.kanal && r.kanal.id) me.channelId = r.kanal.id;
        toast('Канал сохранён');
        sh.sh.remove();
        if (r.thread) openThread(r.thread, (r.kanal && r.kanal.title) || 'Канал');
        paintSidebar();
      } catch (e) { failToast(e, 'Не получилось'); }
    } }));
  }

  async function adminShop(body) {
    body.replaceChildren(el('p', { class: 'kicker', text: 'КОСМЕТИКА' }));
    body.appendChild(el('p', { class: 'hint', text: 'mp4, webp, gif, png. Шапка аватарки / списка чатов / профиля.' }));
    const name = el('input', { class: 'field', placeholder: 'Название' });
    const desc = el('input', { class: 'field', placeholder: 'Описание' });
    const price = el('input', { class: 'field', type: 'number', placeholder: 'Цена в пирикасе', min: '0' });
    const kind = el('select', { class: 'field' });
    for (const [v, l] of [['avatarHat', 'Шапка аватарки'], ['listHat', 'Шапка списка чатов'], ['profileHat', 'Шапка профиля']]) {
      kind.appendChild(el('option', { value: v, text: l }));
    }
    const url = el('input', { class: 'field', placeholder: 'Ссылка на файл или загрузи' });
    body.appendChild(name);
    body.appendChild(kind);
    body.appendChild(desc);
    body.appendChild(price);
    body.appendChild(url);
    body.appendChild(el('button', { class: 'btn', text: 'Загрузить файл', onclick: () => {
      const inp = el('input', { type: 'file', accept: 'image/*,video/mp4,video/webm,.gif,.webp,.png,.jpg,.mp4' });
      inp.onchange = async () => {
        const f = inp.files && inp.files[0];
        if (!f) return;
        try {
          const b64 = await readFile(f);
          const r = await call('upload', 'image', f.name, b64, { skipCache: true });
          if (r && r.url) url.value = r.url;
          toast('Файл на сервере');
        } catch (e) { failToast(e, 'Не загрузилось'); }
      };
      inp.click();
    } }));
    body.appendChild(el('button', { class: 'btn btn-sky', text: 'Добавить в магазин', onclick: async () => {
      try {
        const r = C.shopAdd ? await C.shopAdd({
          name: name.value, kind: kind.value, desc: desc.value, price: Number(price.value) || 0, url: url.value
        }) : await call('shopAdd', { name: name.value, kind: kind.value, desc: desc.value, price: Number(price.value) || 0, url: url.value });
        if (!r || !r.ok) throw new Error((r && r.error) || 'Не добавилось');
        toast('Добавлено');
        loadShop();
      } catch (e) { failToast(e, 'Не добавилось'); }
    } }));
    const giveNick = el('input', { class: 'field', placeholder: 'Выдать: ник или айди' });
    const giveItem = el('input', { class: 'field', placeholder: 'id предмета или пусто' });
    const giveCoins = el('input', { class: 'field', type: 'number', placeholder: 'Пирикас +' });
    body.appendChild(el('p', { class: 'kicker', text: 'ВЫДАТЬ' }));
    body.appendChild(giveNick);
    body.appendChild(giveItem);
    body.appendChild(giveCoins);
    body.appendChild(el('button', { class: 'btn', text: 'Выдать', onclick: async () => {
      try {
        const r = C.shopGive ? await C.shopGive(giveNick.value.trim(), { item: giveItem.value.trim(), pirikas: Number(giveCoins.value) || 0 })
          : await call('shopGive', giveNick.value.trim(), { item: giveItem.value.trim(), pirikas: Number(giveCoins.value) || 0 });
        if (!r || !r.ok) throw new Error((r && r.error) || 'Не выдалось');
        toast('Выдано');
      } catch (e) { failToast(e, 'Не выдалось'); }
    } }));
    const rightNick = el('input', { class: 'field', placeholder: '/выдать ник' });
    const rightVal = el('input', { class: 'field', placeholder: 'r1 … r12' });
    body.appendChild(el('p', { class: 'kicker', text: 'ПРАВА r1–r12' }));
    body.appendChild(rightNick);
    body.appendChild(rightVal);
    body.appendChild(el('button', { class: 'btn', text: 'Выдать право', onclick: async () => {
      try {
        const r = C.grantRight ? await C.grantRight(rightNick.value.trim(), rightVal.value.trim())
          : await call('grantRight', rightNick.value.trim(), rightVal.value.trim());
        if (!r || !r.ok) throw new Error((r && r.error) || 'Не выдалось');
        toast('Право выдано');
      } catch (e) { failToast(e, 'Не выдалось'); }
    } }));
  }

  async function openAdmin() {
    if (!isStaff()) { toast('Нет доступа', 'bad'); return; }
    const sh = modal('Админ-панель');
    const tabs = [
      { label: 'Обзор', render: (body) => adminOverview(body) },
      { label: 'Люди', render: (body) => adminPeople(body) },
      { label: 'Чаты', render: (body) => adminChats(body) },
      { label: 'Настройки', render: (body) => adminSettings(body) },
      { label: 'Лог', render: (body) => adminLog(body) },
      { label: 'Эмодзи', render: (body) => adminEmoji(body) },
      { label: 'Магазин', render: (body) => adminShop(body) }
    ];
    const tabRow = el('div', { class: 'chat-sheet-tabs chat-admin-tabs' });
    sh.body.appendChild(tabRow);
    const pane = el('div', { class: 'chat-admin-pane' });
    sh.body.appendChild(pane);
    function paintTabs(active) {
      tabRow.replaceChildren();
      tabs.forEach((t, i) => {
        tabRow.appendChild(el('button', {
          type: 'button',
          class: i === active ? 'on' : '',
          text: t.label,
          onclick: () => { paintTabs(i); t.render(pane); }
        }));
      });
    }
    paintTabs(0);
    tabs[0].render(pane);
  }

  async function adminOverview(body) {
    body.replaceChildren(el('p', { class: 'hint', text: 'Загружаю…' }));
    let stats = {};
    try { stats = await call('adminStats'); } catch (_) { stats = {}; }
    body.replaceChildren();
    const grid = el('div', { class: 'chat-admin-stats' });
    for (const [k, lab] of [['users', 'люди'], ['online', 'онлайн'], ['messages', 'сообщения'], ['bans', 'баны'], ['mutes', 'муты'], ['packs', 'паки']]) {
      const c = el('div', { class: 'chat-stat' });
      c.appendChild(el('b', { text: String(stats[k] ?? 0) }));
      c.appendChild(el('span', { text: lab }));
      grid.appendChild(c);
    }
    body.appendChild(grid);
    const text = el('textarea', { class: 'field', placeholder: 'Системное уведомление', rows: '2' });
    body.appendChild(text);
    const row = el('div', { class: 'row' });
    row.appendChild(el('button', { class: 'btn btn-sky', text: 'В общий', onclick: async () => {
      try { await call('broadcast', text.value.trim(), 'global'); toast('Отправлено'); loadFresh(); }
      catch (e) { failToast(e, 'Не получилось'); }
    } }));
    row.appendChild(el('button', { class: 'btn', text: 'В канал', onclick: async () => {
      try { await call('broadcast', text.value.trim(), 'channel'); toast('В канал'); openThread('channel', 'Канал'); }
      catch (e) { failToast(e, 'Не получилось'); }
    } }));
    body.appendChild(row);
  }

  async function adminPeople(body) {
    body.replaceChildren();
    const q = el('input', { class: 'field chat-search', placeholder: 'Ник или почта' });
    body.appendChild(q);
    const box = el('div');
    body.appendChild(box);
    async function run() {
      box.replaceChildren(el('p', { class: 'hint', text: '…' }));
      try {
        const r = await call('adminUsers', q.value.trim());
        const items = (r && r.items) || [];
        box.replaceChildren();
        if (!items.length) box.appendChild(el('p', { class: 'hint', text: 'Никого не нашли.' }));
        for (const u of items) {
          const card = el('div', { class: 'chat-pack-card' });
          const top = el('div', { class: 'row' });
          top.appendChild(ava(u.avatar, u.nick, u.online));
          const t = el('p');
          t.appendChild(el('b', { text: u.nick + (u.admin ? ' · админ' : '') }));
          t.appendChild(el('span', { class: 'hint', text: (u.email || '') + (u.banned ? ' · бан' : '') + (u.warns ? ' · варнов ' + (Array.isArray(u.warns) ? u.warns.length : u.warns) : '') }));
          top.appendChild(t);
          card.appendChild(top);
          const actions = el('div', { class: 'chat-admin-actions' });
          const act = async (fn, ...args) => {
            try { await call(fn, ...args); toast('Ок'); run(); loadFresh(); }
            catch (e) { failToast(e, 'Не получилось'); }
          };
          actions.appendChild(el('button', { class: 'btn', text: 'Варн', onclick: () => {
            const reason = window.prompt('Причина', 'спам');
            if (reason) act('warn', u.nick, reason);
          } }));
          actions.appendChild(el('button', { class: 'btn', text: 'Мут 30м', onclick: () => act('modMute', u.nick, 30, 'мут') }));
          actions.appendChild(el('button', { class: 'btn', text: 'Снять мут', onclick: () => act('modUnmute', u.nick) }));
          actions.appendChild(el('button', { class: 'btn', text: u.banned ? 'Разбан' : 'Бан 24ч', onclick: () => {
            if (u.banned) act('unban', u.nick);
            else {
              const reason = window.prompt('Причина бана', 'нарушение');
              if (reason) act('ban', u.nick, 24, reason);
            }
          } }));
          actions.appendChild(el('button', { class: 'btn', text: 'Кик', onclick: () => act('kick', u.nick) }));
          actions.appendChild(el('button', { class: 'btn', text: 'Чистка', onclick: () => act('purge', u.nick) }));
          actions.appendChild(el('button', { class: 'btn', text: 'Снять варны', onclick: () => act('clearWarns', u.nick) }));
          actions.appendChild(el('button', { class: 'btn', text: 'Править', onclick: () => adminEditUser(u, run) }));
          if (isAdmin()) actions.appendChild(el('button', { class: 'btn', text: 'Сброс пароля', onclick: async () => {
            try {
              const r = C.resetPass ? await C.resetPass(u.nick) : await call('resetPass', u.nick);
              toast((r && r.ok) ? 'Пароль сброшен, код на почте' : 'Готово');
            } catch (e) { failToast(e, 'Не получилось'); }
          } }));
          card.appendChild(actions);
          box.appendChild(card);
        }
      } catch (e) { box.replaceChildren(el('p', { class: 'hint', text: friendlyErr(e, 'Нет доступа') })); }
    }
    q.addEventListener('keydown', (e) => { if (e.key === 'Enter') run(); });
    run();
  }

  function adminEditUser(u, reload) {
    const sh = sheet('Игрок · ' + u.nick);
    const nick = el('input', { class: 'field', placeholder: 'Ник' });
    nick.value = u.nick || '';
    const bio = el('textarea', { class: 'field', placeholder: 'О себе', rows: '2' });
    bio.value = u.bio || '';
    const status = el('input', { class: 'field', placeholder: 'Статус' });
    status.value = u.status || '';
    const av = el('input', { class: 'field', placeholder: 'Аватар https://' });
    av.value = u.avatar || '';
    const tg = el('input', { class: 'field', placeholder: 'Telegram' });
    tg.value = u.telegram || '';
    [nick, bio, status, av, tg].forEach((n) => sh.body.appendChild(n));
    sh.body.appendChild(el('p', { class: 'kicker', text: 'ГАЛОЧКИ' }));
    const badges = el('div', { class: 'row chat-admin-actions' });
    for (const [id, lab] of [['official', 'Офиц'], ['staff', 'Сотрудник'], ['support', 'Поддержка'], ['creator', 'Creator']]) {
      badges.appendChild(el('button', { class: 'btn', text: lab, onclick: async () => {
        try {
          if (C.setBadge) await C.setBadge(u.nick, id, true);
          else await call('adminUser', u.nick, { badge: id, badgeOn: true });
          toast('Галочка ' + lab);
        } catch (e) { failToast(e, 'Не получилось'); }
      } }));
    }
    sh.body.appendChild(badges);
    const row = el('div', { class: 'row' });
    row.appendChild(el('button', { class: 'btn btn-sky', text: 'Сохранить', onclick: async () => {
      try {
        await call('adminUser', u.nick, {
          nickNew: nick.value.trim(), bio: bio.value, status: status.value, avatar: av.value, telegram: tg.value
        });
        toast('Сохранено');
        sh.sh.remove();
        if (reload) reload();
      } catch (e) { failToast(e, 'Не получилось'); }
    } }));
    row.appendChild(el('button', { class: 'btn', text: u.verified ? 'Снять верификацию' : 'Верифицировать', onclick: async () => {
      try { await call('adminUser', u.nick, { verified: !u.verified }); toast('Ок'); sh.sh.remove(); if (reload) reload(); }
      catch (e) { failToast(e, 'Не получилось'); }
    } }));
    sh.body.appendChild(row);
  }

  async function adminChats(body) {
    body.replaceChildren();
    for (const id of ['global', 'channel', 'system']) {
      const meta = chatMeta(id) || { id, title: id, about: '', avatar: '' };
      const card = el('div', { class: 'chat-pack-card' });
      card.appendChild(el('strong', { text: id === 'channel' ? 'Канал' : (id === 'system' ? 'Уведомления' : 'Общий чат') }));
      const titleIn = el('input', { class: 'field', placeholder: 'Название' });
      titleIn.value = meta.title || '';
      const about = el('input', { class: 'field', placeholder: 'Описание' });
      about.value = meta.about || '';
      const av = el('input', { class: 'field', placeholder: 'Аватар https://' });
      av.value = meta.avatar || '';
      const banner = el('input', { class: 'field', placeholder: 'Баннер / обои https://' });
      banner.value = meta.banner || meta.cover || '';
      card.appendChild(titleIn);
      card.appendChild(about);
      card.appendChild(av);
      card.appendChild(banner);
      const mediaRow = el('div', { class: 'row' });
      mediaRow.appendChild(el('button', { class: 'btn', text: 'Загрузить аватар', onclick: async () => {
        const file0 = await pick('image/*');
        if (!file0) return;
        try {
        const file = await compressImage(file0, maxFileOf('avatar'), 512);
          const b64 = await readFile(file);
          const r = await call('upload', 'avatar', file.name, b64, { skipMsg: true });
          if (r && r.url) av.value = r.url;
          else av.value = 'data:' + (file.type || 'image/jpeg') + ';base64,' + b64;
          toast('Аватар на сервер');
        } catch (e) { failToast(e, 'Не получилось'); }
      } }));
      mediaRow.appendChild(el('button', { class: 'btn', text: 'Загрузить баннер', onclick: async () => {
        const file0 = await pick('image/*');
        if (!file0) return;
        try {
          const file = await compressImage(file0, maxFileOf('image'), 1920);
          const b64 = await readFile(file);
          const r = await call('upload', 'cover', file.name, b64, { skipMsg: true });
          if (r && r.url) banner.value = r.url;
          else banner.value = 'data:' + (file.type || 'image/jpeg') + ';base64,' + b64;
          toast('Баннер на сервер');
        } catch (e) { failToast(e, 'Не получилось'); }
      } }));
      card.appendChild(mediaRow);
      card.appendChild(el('button', { class: 'btn btn-sky', text: 'Сохранить', onclick: async () => {
        try {
          const r = await call('adminChat', id, { title: titleIn.value, about: about.value, avatar: av.value, banner: banner.value, cover: banner.value });
          if (me && r && r.chat) {
            me.chats = (me.chats || []).filter((c) => c.id !== id).concat([r.chat]);
          }
          toast('Чат обновлён');
          if (thread === id) openThread(id, titleIn.value);
        } catch (e) { failToast(e, 'Не получилось'); }
      } }));
      body.appendChild(card);
    }
  }

  async function adminSettings(body) {
    body.replaceChildren(el('p', { class: 'hint', text: '…' }));
    let cfg = (me && me.settings) || {};
    try {
      const r = await call('adminSettings', {});
      if (r && r.settings) cfg = r.settings;
    } catch (_) { /* */ }
    body.replaceChildren();
    const flags = [
      ['requireVerify', 'Подтверждение почты'],
      ['allowGifs', 'GIF'],
      ['allowStickers', 'Стикеры'],
      ['allowUploads', 'Загрузки'],
      ['allowPolls', 'Опросы'],
      ['allowDms', 'Лички'],
      ['readonly', 'Только чтение']
    ];
    const state = { ...cfg };
    for (const [k, lab] of flags) {
      const b = el('button', {
        class: 'btn' + (state[k] ? ' btn-sky' : ''),
        type: 'button',
        text: lab + ': ' + (state[k] ? 'да' : 'нет'),
        onclick: async () => {
          state[k] = !state[k];
          try {
            const r = await call('adminSettings', { [k]: state[k] });
            if (r && r.settings && me) me.settings = r.settings;
            toast('Сохранено');
            adminSettings(body);
          } catch (e) { failToast(e, 'Не получилось'); }
        }
      });
      body.appendChild(b);
    }
    const slow = el('input', { class: 'field', type: 'number', min: '0', max: '300', placeholder: 'Slow mode, сек' });
    slow.value = String(state.slowMode || 0);
    body.appendChild(slow);
    body.appendChild(el('button', { class: 'btn btn-sky', text: 'Slow mode', onclick: async () => {
      try {
        const r = await call('adminSettings', { slowMode: Number(slow.value) || 0 });
        if (r && r.settings && me) me.settings = r.settings;
        toast('Slow mode ' + slow.value + 'с');
      } catch (e) { failToast(e, 'Не получилось'); }
    } }));
  }

  async function adminEmoji(body) {
    body.replaceChildren();
    body.appendChild(el('p', { class: 'hint', text: 'Замените символ (❤, 🔥) на webp/webm. Анимация при наведении — в настройках.' }));
    const code = el('input', { class: 'field', placeholder: 'Символ, например ❤' });
    body.appendChild(code);
    const status = el('p', { class: 'hint', text: 'Файл не выбран' });
    body.appendChild(status);
    let picked = null;
    body.appendChild(el('button', { class: 'btn', text: 'Выбрать webp / webm / gif', onclick: async () => {
      const file0 = await pick('image/webp,image/gif,video/webm,image/png');
      if (!file0) return;
      picked = file0;
      status.textContent = file0.name + ' · ' + Math.round(file0.size / 1024) + ' КБ';
    } }));
    body.appendChild(el('button', { class: 'btn btn-sky', text: 'Загрузить', onclick: async () => {
      const key = String(code.value || '').trim();
      if (!key) { toast('Укажи символ', 'bad'); return; }
      if (!picked) { toast('Выбери файл', 'bad'); return; }
      status.textContent = 'Загрузка…';
      try {
        const file = await toStickerBlob(picked);
        const b64 = await readFile(file);
        status.textContent = 'Отправка на сервер…';
        const r = await call('upload', 'sticker', file.name, b64, { emoji: key });
        const url = (r && (r.url || (r.item && r.item.url))) || '';
        if (!url) throw new Error((r && r.error) || 'Не загрузилось');
        if (C.setEmoji) await C.setEmoji(key, url);
        else await call('setEmoji', key, url);
        emojiMap[key] = url;
        idb.kvSet('emojiMap', emojiMap).catch(() => {});
        status.textContent = 'Готово: ' + key;
        toast('Эмодзи ' + key);
        adminEmoji(body);
      } catch (e) {
        status.textContent = friendlyErr(e, 'Не получилось загрузить');
        failToast(e, 'Не получилось');
      }
    } }));
    const box = el('div', { class: 'chat-stickers stick-mini' });
    body.appendChild(box);
    try {
      const r = C.emojiMap ? await C.emojiMap() : await call('emojiMap');
      const map = (r && (r.map || r.items)) || {};
      emojiMap = map;
      idb.kvSet('emojiMap', map).catch(() => {});
      for (const [k, url] of Object.entries(map)) {
        const b = el('button', { class: 'chat-sticker-btn', type: 'button', title: k });
        b.appendChild(el('img', { src: url, alt: k, class: 'chat-cemoji' }));
        b.appendChild(el('span', { text: k }));
        box.appendChild(b);
      }
      if (!Object.keys(map).length) box.appendChild(el('p', { class: 'hint', text: 'Пока пусто' }));
    } catch (e) { box.appendChild(el('p', { class: 'hint', text: friendlyErr(e, 'Нет данных') })); }
  }

  async function adminLog(body) {
    body.replaceChildren(el('p', { class: 'hint', text: '…' }));
    try {
      const r = await call('modlog');
      const items = (r && r.items) || [];
      body.replaceChildren();
      if (!items.length) body.appendChild(el('p', { class: 'hint', text: 'Лог пуст' }));
      for (const it of items) {
        body.appendChild(el('p', { class: 'chat-pin', text: fmtTime(it.at) + ' · ' + (it.admin || '') + ' · ' + it.act + ' · ' + (it.target || '') + ' ' + (it.note || '') }));
      }
    } catch (e) { body.replaceChildren(el('p', { class: 'hint', text: friendlyErr(e, 'Нет доступа') })); }
  }

  async function tick() {
    if (!me || !me.ok) return;
    if (C.presence) {
      try {
        const r = await C.presence(thread);
        const typ = (r && r.typing) || [];
        if (!typ.length) {
          typingEl.replaceChildren();
          typingEl.classList.remove('on');
        } else {
          const dots = el('span', { class: 'chat-dots' });
          dots.appendChild(el('i'));
          dots.appendChild(el('i'));
          dots.appendChild(el('i'));
          const lab = typ.length === 1 ? typ[0] + ' печатает' : (typ.length <= 3 ? typ.join(', ') + ' печатают' : typ.slice(0, 2).join(', ') + ' и ещё ' + (typ.length - 2) + ' печатают');
          typingEl.replaceChildren(dots, el('span', { class: 'chat-typing-lab', text: lab }));
          typingEl.classList.add('on');
        }
        if (thread === 'global' && r && r.online) setSub((me.nick || '') + ' · ' + r.online + ' в сети', true);
        if (r && Array.isArray(r.people) && thread === 'global') {
          const n = r.people.length || r.online || 0;
          if (n) setSub((me.nick || '') + ' · ' + n + ' в сети', true);
        }
      } catch (_) { /* */ }
    }
    try {
      const data = await call('messages', { before: 0, limit: 12, thread });
      const items = (data && data.items) || [];
      if (!items.length) return;
      const known = new Set(itemsCache.map((x) => x.id));
      const pendingMine = itemsCache.filter((x) => x.pending && me && x.nick === me.nick);
      const fresh = [];
      for (const it of items) {
        if (it && it.kind === 'poll' && it.poll && known.has(it.id)) {
          const old = itemsCache.find((x) => x.id === it.id);
          if (old && JSON.stringify(old.poll) !== JSON.stringify(it.poll)) {
            Object.assign(old, it);
            const card = list.querySelector('[data-mid="' + it.id + '"]');
            if (card) {
              const next = bubble(old);
              if (next) card.replaceWith(next);
            }
          }
        }
        if (it && it.deleted) {
          itemsCache = itemsCache.filter((x) => x.id !== it.id);
          const card = list.querySelector('[data-mid="' + it.id + '"]');
          if (card) card.remove();
          paintPins(itemsCache);
          continue;
        }
        if (!it || !it.id || known.has(it.id)) continue;
        const match = pendingMine.find((p) => p.kind === it.kind && p.text === it.text && p.nick === it.nick);
        if (match) { replacePending(match, it); continue; }
        fresh.push(it);
      }
      if (!fresh.length) {
        if (items[0]) lastId = items[0].id;
        return;
      }
      fresh.reverse().forEach((it) => {
        appendLive(it);
        if (!(me && me.nick === it.nick)) {
          popupNote(it);
          if (prefs.sound && me && !me.muted) pingSound();
        }
      });
    } catch (_) { /* */ }
  }

  async function openAccounts() {
    const sh = modal('Аккаунты');
    let doc = { items: [] };
    try { if (C.accounts) doc = await C.accounts(); } catch (_) { /* */ }
    const items = (doc.items || []).slice(0, 4);
    const accHead = el('div', { class: 'chat-acc-head' });
    accHead.appendChild(el('span', { class: 'kicker', text: 'СОХРАНЁННЫЕ' }));
    accHead.appendChild(el('span', { class: 'chat-acc-count', text: items.length + ' / 4' }));
    sh.body.appendChild(accHead);
    if (!items.length) sh.body.appendChild(el('p', { class: 'hint', text: 'Пока нет сохранённых аккаунтов. Добавьте существующий или создайте новый.' }));
    const accList = el('div', { class: 'chat-acc-grid' });
    for (const a of items) {
      const row = el('div', { class: 'chat-acc-row' + (a.email === (me && me.email) ? ' active' : ''), onclick: async () => {
        try {
          const r = await C.switchAccount(a.email);
          me = r;
          sh.sh.remove();
          paintAuth();
          paintHead();
          loadFresh();
          toast('Переключено на ' + a.nick);
        } catch (e) { failToast(e, 'Не получилось'); }
      } });
      row.appendChild(ava(a.avatar, a.nick, a.email === (me && me.email)));
      const t = el('p');
      t.appendChild(el('b', { text: a.nick || a.email }));
      t.appendChild(el('span', { class: 'hint', text: a.email }));
      row.appendChild(t);
      if (a.email === (me && me.email)) {
        const cur = el('span', { class: 'chat-acc-cur', text: 'текущий' });
        row.appendChild(cur);
      }
      accList.appendChild(row);
    }
    if (items.length) sh.body.appendChild(accList);
    sh.body.appendChild(el('p', { class: 'kicker', text: 'ДОБАВИТЬ', style: 'margin-top:16px' }));
    if (items.length < 4) {
      sh.body.appendChild(el('button', { class: 'btn btn-sky chat-acc-add', text: 'Добавить существующий аккаунт', onclick: () => addAccountForm(sh, false) }));
    } else {
      sh.body.appendChild(el('p', { class: 'hint', text: 'Максимум 4 сохранённых аккаунта' }));
    }
    if (createdCount >= 5) {
      sh.body.appendChild(el('p', { class: 'hint', text: 'На этом устройстве уже 5 созданных аккаунтов' }));
    } else if (items.length < 4) {
      sh.body.appendChild(el('button', { class: 'btn chat-acc-add', text: 'Создать новый аккаунт', onclick: () => addAccountForm(sh, true) }));
    }
    sh.body.appendChild(el('p', { class: 'kicker', text: 'ЕЩЁ' }));
    sh.body.appendChild(el('button', { class: 'btn', text: 'Оформление чата', onclick: () => { sh.sh.remove(); openUiSettings(); } }));
    sh.body.appendChild(el('button', { class: 'btn', text: 'Окно и масштаб', onclick: () => { sh.sh.remove(); openWinSettings(); } }));
    sh.body.appendChild(el('button', { class: 'btn', text: 'Экспорт данных (zip)', onclick: async () => {
      const bar = showUploadBar(sh.body, 'Собираю архив…');
      try {
        bar.set(40);
        const r = C.exportData ? await C.exportData() : await call('exportData');
        bar.set(100);
        bar.done();
        if (!r || !r.ok) throw new Error((r && r.error) || 'Не вышло');
        toast(r.path ? 'Сохранено: ' + r.path : 'Экспорт готов');
      } catch (e) { bar.done(); failToast(e, 'Не получилось'); }
    } }));
  }

  function addAccountForm(sh, isNew) {
    sh.body.replaceChildren();
    const nick = el('input', { class: 'field', placeholder: 'Ник' });
    const email = el('input', { class: 'field', placeholder: 'Почта', type: 'email' });
    const pass = el('input', { class: 'field', placeholder: 'Пароль', type: 'password' });
    if (isNew) sh.body.appendChild(nick);
    sh.body.appendChild(email);
    sh.body.appendChild(pass);
    sh.body.appendChild(el('button', { class: 'btn btn-sky', text: isNew ? 'Зарегистрировать' : 'Войти', onclick: async () => {
      try {
        if (isNew && createdCount >= 5) { toast('На этом устройстве уже 5 аккаунтов', 'bad'); return; }
        if (C.saveAccount) await C.saveAccount();
        let r;
        if (isNew) r = await call('register', nick.value, email.value, pass.value);
        else r = C.addAccount ? await C.addAccount(email.value, pass.value) : await call('login', email.value, pass.value);
        if (r && r.needDevice) { toast('Код ушёл на почту'); return; }
        if (!r || !r.ok) throw new Error((r && r.error) || 'Не вышло');
        me = { ...r, needVerify: isNew ? (r.needVerify !== false && r.verified === false) : r.needVerify };
        if (isNew) createdCount += 1;
        sh.sh.remove();
        paintAuth();
        loadFresh();
        toast(isNew ? (r.mailed ? 'Код ушёл на почту' : 'Проверьте почту') : 'Аккаунт добавлен');
      } catch (e) { failToast(e, 'Не получилось'); }
    } }));
  }

  function botMsg(text, buttons, nick) {
    appendLive({
      id: localId(), at: new Date().toISOString(), nick: nick || 'CrynBot', role: 'bot', kind: 'text',
      text, buttons: buttons || [], reactions: {}, thread, badges: ['official']
    });
  }

  let botStep = null;
  let botDraft = {};

  function handleCreateBot(text, extra) {
    const t = String(text || '').trim();
    if (thread !== 'dm:createbot' && !String(thread).includes('createbot')) return false;
    const cmd = t.split(/\s+/)[0].toLowerCase();
    const rest = t.slice(cmd.length).trim();
    if (cmd === '/cancel') {
      botStep = null;
      botDraft = {};
      botMsg('Ок, отменил. /start — начать заново.');
      return true;
    }
    if (cmd === '/revoke') {
      (async () => {
        try {
          const r = C.revokeBot ? await C.revokeBot(rest || (botDraft && botDraft.user) || '') : await call('revokeBot', rest || '');
          const tok = (r && (r.token || (r.bot && r.bot.token))) || '';
          botMsg(tok ? 'Новый токен:\n`' + tok + '`\nСтарый больше не действует.' : ((r && r.error) || 'Токен сброшен.'));
        } catch (e) { botMsg(friendlyErr(e, 'Не сбросилось')); }
      })();
      return true;
    }
    if (cmd === '/mybots' || cmd === '/bots') {
      (async () => {
        try {
          const r = C.myBots ? await C.myBots() : await call('myBots');
          const items = (r && r.items) || [];
          if (!items.length) { botMsg('Пока нет ботов. /newbot Имя — создать.'); return; }
          botMsg(items.map((b) => '• ' + (b.name || b.username || b.id) + (b.username ? ' (@' + b.username + ')' : '')).join('\n'), [
            { text: 'Создать ещё', cmd: '/newbot Мой бот' }
          ]);
        } catch (e) { botMsg(friendlyErr(e, 'Не загрузилось')); }
      })();
      return true;
    }
    if (cmd === '/delbot' || cmd === '/delete') {
      (async () => {
        try {
          const r = C.delBot ? await C.delBot(rest) : await call('delBot', rest);
          botMsg((r && r.ok) ? 'Бот удалён.' : ((r && r.error) || 'Не удалилось'));
        } catch (e) { botMsg(friendlyErr(e, 'Не удалилось')); }
      })();
      return true;
    }
    if (cmd === '/start' || t === 'Старт' || cmd === '/help') {
      botStep = botStep && botStep !== 'idle' ? botStep : 'idle';
      botMsg('Привет. Я CrynBot.\n\nКоманды:\n/newbot Имя — создать бота\n/mybots — мои боты\n/revoke [id] — новый токен\n/delbot id — удалить\n/cancel — отмена\n/help — это меню\n\nAPI бота:\nPOST https://my.cryndel.ru/acryn/index.php\nJSON: { "action", "token", ... }\n\naction=botMe — профиль\naction=botSend, thread, text — сообщение\naction=botEdit, id, text — правка\naction=botDelete, id — удалить\naction=botReply, id, text — ответ\naction=botReact, id, emoji — реакция\naction=botUpdates, offset — апдейты\naction=botSetWebhook, url — вебхук\naction=botProfile, about, avatar — профиль бота', [
        { text: 'Создать бота', cmd: '/newbot Мой бот' },
        { text: 'Мои боты', cmd: '/mybots' },
        { text: 'Документация', url: 'https://my.cryndel.ru/a/wikibot.html' }
      ]);
      return true;
    }
    if (t.startsWith('/newbot')) {
      botDraft = { name: t.replace('/newbot', '').trim() };
      if (!botDraft.name) { botMsg('Напишите название после команды. Пример: /newbot Shop'); return true; }
      botStep = 'user';
      botMsg('Юзернейм. В конце должен быть _bot, например shop_bot. Только латиница, цифры и _.');
      return true;
    }
    if (botStep === 'user') {
      let u = t.replace(/^@/, '');
      if (!u.endsWith('_bot')) u += '_bot';
      const raw = u.replace(/_bot$/, '');
      if (!/^[A-Za-z][A-Za-z0-9_]{2,27}$/.test(raw)) {
        botMsg('Юзернейм: латиница, цифры, _, 3–28 символов до _bot, начинается с буквы.');
        return true;
      }
      botDraft.user = u;
      botStep = 'ava';
      botMsg('Аватар? Отправьте фото или нажмите «Пропустить».', [{ text: 'Пропустить', cmd: 'нет' }]);
      return true;
    }
    if (botStep === 'ava') {
      const skip = !extra && /^(нет|пропустить|skip)$/i.test(t);
      if (!skip && !extra) {
        botMsg('Отправьте фото или нажмите «Пропустить».', [{ text: 'Пропустить', cmd: 'нет' }]);
        return true;
      }
      if (extra && extra.url) botDraft.avatar = extra.url;
      botStep = 'about';
      botMsg('Описание бота. Можно ссылки {Название}{https://example.com}');
      return true;
    }
    if (botStep === 'about') {
      botDraft.about = t;
      botStep = null;
      const apiName = /^[A-Za-z0-9_]{3,24}$/.test(botDraft.name) ? botDraft.name : String(botDraft.user || 'bot').replace(/_bot$/, '').slice(0, 24);
      (async () => {
        try {
          const r = await call('createBot', apiName, 'js', { about: botDraft.about, username: botDraft.user, avatar: botDraft.avatar });
          const bot = (r && (r.bot || r)) || {};
          const token = bot.token || r.token || ('cryn:' + Math.random().toString(36).slice(2) + Math.random().toString(36).slice(2));
          botMsg('Готово. @' + (bot.username || botDraft.user) + '\nТокен:\n`' + token + '`\nНикому его не показывайте.\n\nОтправить сообщение:\nPOST https://my.cryndel.ru/acryn/index.php\n{"action":"botSend","token":"' + token + '","thread":"global","text":"привет"}\n\nАпдейты: action=botUpdates\nСброс токена: /revoke', [
            { text: 'Мои боты', cmd: '/mybots' },
            { text: 'Документация', url: 'https://my.cryndel.ru/a/wikibot.html' }
          ]);
        } catch (e) {
          botMsg('Не создалось: ' + friendlyErr(e, 'ошибка') + '\nПопробуйте /newbot ещё раз.');
        }
      })();
      return true;
    }
    return false;
  }

  function handleAdminBot(text) {
    const t = String(text || '').trim();
    const isAdmThread = thread === 'dm:adminbot' || String(thread).includes('adminbot');
    if (!isAdmThread) return false;
    const parts = t.split(/\s+/);
    const cmd = (parts[0] || '').toLowerCase();
    const nick = (parts[1] || '').replace(/^@/, '');
    const rest = parts.slice(2).join(' ');
    if (!t || cmd === '/start' || t === 'Старт' || cmd === '/help') {
      if (itemsCache.some((x) => x.role === 'bot' && /системный бот/i.test(String(x.text || '')))) return true;
      const help = isAdmin()
        ? 'Я Admin — системный бот CrynChat.\n\nСюда приходят уведомления: новый чат, блокировка, мут, варн.\n\nКоманды модератора:\n/ban ник [часы] [причина]\n/mute ник [мин] [причина]\n/warn ник [причина]\n/unban ник\n/unmute ник\n/kick ник\n/profile ник\n/info'
        : 'Я Admin — системный бот CrynChat.\n\nСюда приходят служебные уведомления: вас заблокировали, новый чат создан, предупреждение, мут.\n\nПисать сюда не нужно — сообщения приходят сами.';
      botMsg(help, isAdmin() ? [{ text: 'Справка', cmd: '/help' }] : [], 'Admin');
      return true;
    }
    if (!isAdmin()) {
      botMsg('Эта команда доступна только модераторам. Служебные уведомления приходят сюда автоматически.', [], 'Admin');
      return true;
    }
    if (!['/ban', '/mute', '/kick', '/warn', '/unban', '/unmute', '/profile', '/info'].includes(cmd)) return false;
    (async () => {
      try {
        let r = null;
        if (C.adminBot) r = await C.adminBot(t, { thread });
        else r = await call('send', t, { thread });
        if (r && r.item) appendLive(r.item);
        else if (r && r.bot) appendLive(r.bot);
        else {
          botMsg(r && r.text ? r.text : (cmd + ' ' + nick + (rest ? ' · ' + rest : '') + ' — готово'), [], 'Admin');
        }
      } catch (e) { failToast(e, 'Не получилось'); }
    })();
    return true;
  }

  let resumeId = 'global';
  let resumeNick = '';
  if (C.lastThread) {
    try {
      const last = await C.lastThread();
      if (last && last.id && last.id !== 'chats') {
        resumeId = last.id;
        resumeNick = last.nick || '';
      }
    } catch (_) { /* */ }
  }
  thread = resumeId;
  paintHead();
  await loadMe();
  paintHead();
  window.addEventListener('resize', () => {
    if (!document.body.contains(wrap)) return;
    syncChrome();
  });
  await openThread(resumeId, resumeNick);
  collapseList();
  pollTimer = setInterval(tick, 1600);
  if (typeof Notification !== 'undefined' && Notification.permission === 'default') {
    Notification.requestPermission().catch(() => {});
  }
  wrap.addEventListener('remove', () => clearInterval(pollTimer), { once: true });
  const obs = new MutationObserver(() => {
    if (!document.body.contains(wrap)) {
      clearInterval(pollTimer);
      obs.disconnect();
    }
  });
  obs.observe(document.body, { childList: true, subtree: true });

  // Titlebar quick-access: global search and settings (dispatched from app.js).
  const onGlobalSearch = () => { if (document.body.contains(wrap)) openSearch(); };
  const onOpenSettings = () => { if (document.body.contains(wrap)) openUiSettings(); };
  document.addEventListener('cryn:global-search', onGlobalSearch);
  document.addEventListener('cryn:open-settings', onOpenSettings);
  const offNotify = C.onNotifyReply ? C.onNotifyReply((p) => {
    const t = String((p && p.text) || '').trim();
    if (t) call('send', t, { thread: (p && p.thread) || thread }).catch(() => {});
  }) : null;
  wrap.addEventListener('remove', () => {
    document.removeEventListener('cryn:global-search', onGlobalSearch);
    document.removeEventListener('cryn:open-settings', onOpenSettings);
    if (typeof offNotify === 'function') offNotify();
    clearInterval(pollTimer);
  }, { once: true });
}

export function openChatOverlay() {
  const old = document.getElementById('crynChatVeil');
  if (old) { old.remove(); return; }
  const veil = el('div', { class: 'chat-veil', id: 'crynChatVeil' });
  const phone = el('div', { class: 'chat-phone' });
  const chrome = el('div', { class: 'chat-phone-chrome' });
  chrome.appendChild(el('strong', { text: 'CrynChat' }));
  chrome.appendChild(icon('pause', 'Свернуть', () => {
    phone.classList.toggle('win-min');
    phone.classList.remove('win-max');
  }));
  chrome.appendChild(icon('full', 'Развернуть', () => {
    phone.classList.toggle('win-max');
    phone.classList.remove('win-min');
  }));
  chrome.appendChild(icon('x', 'Закрыть', () => veil.remove()));
  const stage = el('div', { class: 'chat-phone-stage' });
  phone.appendChild(chrome);
  phone.appendChild(stage);
  veil.appendChild(phone);
  veil.addEventListener('click', (ev) => { if (ev.target === veil) veil.remove(); });
  document.body.appendChild(veil);
  mountChat(stage, { overlay: true }).catch(() => {});
}
