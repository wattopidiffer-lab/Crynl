export const I = {
  x: '<path d="M7 7l10 10M17 7 7 17" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>',
  folder: '<path d="M4 8h6l2 2h8v9H4z" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M4 8V6h5l1.5 2" fill="none" stroke="currentColor" stroke-width="1.7"/>',
  dl: '<path d="M12 5v10M8 11l4 4 4-4M5 19h14" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>',
  gear: '<path d="M12 8.1a3.9 3.9 0 1 0 0 7.8 3.9 3.9 0 0 0 0-7.8Zm8.1 4.9a8.2 8.2 0 0 0 0-2l-2-.7a6.4 6.4 0 0 0-.7-1.6l.9-1.9a8.8 8.8 0 0 0-1.4-1.4l-1.9.9a6.4 6.4 0 0 0-1.6-.7l-.7-2a8.2 8.2 0 0 0-2 0l-.7 2a6.4 6.4 0 0 0-1.6.7l-1.9-.9a8.8 8.8 0 0 0-1.4 1.4l.9 1.9a6.4 6.4 0 0 0-.7 1.6l-2 .7a8.2 8.2 0 0 0 0 2l2 .7a6.4 6.4 0 0 0 .7 1.6l-.9 1.9a8.8 8.8 0 0 0 1.4 1.4l1.9-.9a6.4 6.4 0 0 0 1.6.7l.7 2a8.2 8.2 0 0 0 2 0l.7-2a6.4 6.4 0 0 0 1.6-.7l1.9.9a8.8 8.8 0 0 0 1.4-1.4l-.9-1.9a6.4 6.4 0 0 0 .7-1.6l2-.7Z" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/>',
  pal: '<path d="M12 4a8 8 0 1 0 0 16 3 3 0 0 0 0-6 3 3 0 0 1 0-6 8 8 0 0 0 0-4z" fill="none" stroke="currentColor" stroke-width="1.7"/><circle cx="8.5" cy="10" r="1" fill="currentColor"/><circle cx="10" cy="7.2" r="1" fill="currentColor"/><circle cx="14.5" cy="7.5" r="1" fill="currentColor"/>',
  plus: '<path d="M12 5v14M5 12h14" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>',
  play: '<path d="M8 6.5v11l9-5.5z" fill="currentColor"/>',
  copy: '<rect x="8" y="8" width="10" height="10" rx="2" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M6 16V6h10" fill="none" stroke="currentColor" stroke-width="1.7"/>',
  open: '<path d="M14 5h5v5M19 5l-8 8M10 5H6v14h14v-4" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/>',
  inst: '<rect x="4" y="5" width="7" height="7" rx="1.5" fill="none" stroke="currentColor" stroke-width="1.7"/><rect x="13" y="5" width="7" height="7" rx="1.5" fill="none" stroke="currentColor" stroke-width="1.7"/><rect x="4" y="14" width="7" height="6" rx="1.5" fill="none" stroke="currentColor" stroke-width="1.7"/>',
  servers: '<rect x="4" y="4" width="16" height="5" rx="1.4" fill="none" stroke="currentColor" stroke-width="1.7"/><rect x="4" y="10" width="16" height="5" rx="1.4" fill="none" stroke="currentColor" stroke-width="1.7"/><rect x="4" y="16" width="16" height="4" rx="1.4" fill="none" stroke="currentColor" stroke-width="1.7"/><circle cx="7.2" cy="6.5" r="0.8" fill="currentColor"/><circle cx="7.2" cy="12.5" r="0.8" fill="currentColor"/>',
  home: '<path d="M4 11.5 12 4l8 7.5V20H4z" fill="none" stroke="currentColor" stroke-width="1.8"/>',
  mods: '<path d="M4 5.5h6.2v2a1.8 1.8 0 1 0 3.6 0v-2H20v6h-2a1.8 1.8 0 1 0 0 3.6h2v3.4h-6v-2a1.8 1.8 0 1 0-3.6 0v2H4v-6h2a1.8 1.8 0 1 0 0-3.6H4z" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linejoin="round"/>',
  puzzle: '<path d="M10 4h4v2a2 2 0 1 0 4 0V4h2v6h-2a2 2 0 1 0 0 4h2v6h-6v-2a2 2 0 1 0-4 0v2H4v-6h2a2 2 0 1 0 0-4H4V4h6Z" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/>',
  sliders: '<path d="M4 7h9m4 0h3M4 17h3m4 0h9" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/><circle cx="15" cy="7" r="2" fill="var(--panel-2)" stroke="currentColor" stroke-width="1.8"/><circle cx="9" cy="17" r="2" fill="var(--panel-2)" stroke="currentColor" stroke-width="1.8"/>',
  grid: '<rect x="4" y="4" width="6" height="6" rx="1.5" fill="none" stroke="currentColor" stroke-width="1.7"/><rect x="14" y="4" width="6" height="6" rx="1.5" fill="none" stroke="currentColor" stroke-width="1.7"/><rect x="4" y="14" width="6" height="6" rx="1.5" fill="none" stroke="currentColor" stroke-width="1.7"/><rect x="14" y="14" width="6" height="6" rx="1.5" fill="none" stroke="currentColor" stroke-width="1.7"/>',
  search: '<circle cx="10.8" cy="10.8" r="6.3" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="m15.5 15.5 4.2 4.2" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>',
  scan: '<path d="M12 3.5 5 6.5V12c0 4.6 2.9 7.6 7 8.5 4.1-.9 7-3.9 7-8.5V6.5z" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M8.5 12.2l2.4 2.4 4.6-5" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/>',
  mr: '<path d="M4 19V5h4l4 5 4-5h4v14h-4v-8l-4 5-4-5v8z" fill="currentColor"/>',
  shots: '<rect x="4" y="7" width="16" height="12" rx="2" fill="none" stroke="currentColor" stroke-width="1.8"/><circle cx="9" cy="12" r="1.6" fill="currentColor"/>',
  net: '<circle cx="12" cy="12" r="8" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M4 12h16M12 4c3 3 3 13 0 16M12 4c-3 3-3 13 0 16" fill="none" stroke="currentColor" stroke-width="1.5"/>',
  cab: '<path d="M12 4 5 8v8l7 4 7-4V8z" fill="none" stroke="currentColor" stroke-width="1.8"/>',
  ver: '<path d="M6 7h12M6 12h12M6 17h8" fill="none" stroke="currentColor" stroke-width="1.8"/>',
  hp: '<path d="M4 12h4l2-4 4 8 2-4h4" fill="none" stroke="currentColor" stroke-width="1.8"/>',
  chev: '<path d="M8 10l4 4 4-4" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>',
  tab: '<rect x="4" y="6" width="16" height="12" rx="2" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M4 10h16" fill="none" stroke="currentColor" stroke-width="1.7"/>',
  google: '<circle cx="12" cy="12" r="7.5" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M12 8.5v7M9 12h7.5" fill="none" stroke="currentColor" stroke-width="1.6"/>',
  install: '<path d="M12 4v10M8 10l4 4 4-4M6 18h12" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>',
  page: '<rect x="6" y="4" width="12" height="16" rx="2" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M9 8h6M9 12h6M9 16h4" fill="none" stroke="currentColor" stroke-width="1.5"/>',
  full: '<path d="M9 5H5v4M15 5h4v4M5 15v4h4M19 15v4h-4" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/>',
  nick: '<circle cx="12" cy="9" r="3" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M6 19c1.4-3 3.4-4.5 6-4.5S16.6 16 18 19" fill="none" stroke="currentColor" stroke-width="1.7"/>',
  trash: '<path d="M4 7h16M9 7V4h6v3m-9 0 1 13h10l1-13M10 11v5m4-5v5" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>',
  plug: '<path d="M8 8V5M16 8V5M7 8h10v4.2A5 5 0 0 1 12 17a5 5 0 0 1-5-4.8zM12 17v3" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/>',
  edit: '<path d="M5 16.5V19h2.5L18 8.5 15.5 6 5 16.5z" fill="none" stroke="currentColor" stroke-width="1.7"/>',
  check: '<path d="M6 12.5l4 4 8-9" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"/>',
  pin: '<path d="M16.2 3.4a2.2 2.2 0 0 1 3.1 3.1l-1.3 1.3 3.4 3.4-1.5 1.5-1.1-.3-3.6 3.6.9 2.6-1.5 1.5-6-6 1.5-1.5 2.6.9 3.6-3.6-.3-1.1 1.3-1.3zM5.4 18.6l3.8-3.8" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"/>',
  pause: '<path d="M9 6v12M15 6v12" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/>',
  prev: '<path d="M18 6v12L9 12zM6 6v12" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round" stroke-linecap="round"/>',
  next: '<path d="M6 6v12l9-6zM18 6v12" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round" stroke-linecap="round"/>',
  music: '<path d="M9 17V6l9-2v11" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/><ellipse cx="7" cy="17.5" rx="2.2" ry="1.9" fill="none" stroke="currentColor" stroke-width="1.6"/><ellipse cx="16" cy="15.5" rx="2.2" ry="1.9" fill="none" stroke="currentColor" stroke-width="1.6"/>',
  refresh: '<path d="M5 12a7 7 0 0 1 12-4.5M19 12a7 7 0 0 1-12 4.5M17 4v4h-4M7 20v-4h4" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/>',
  file: '<path d="M7 3.6h7.2L19 8.4V20.4H7z" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linejoin="round"/><path d="M14.2 3.6v4.8H19" fill="none" stroke="currentColor" stroke-width="1.55" stroke-linejoin="round"/><path d="M10 12.2h6M10 15.4h4.4" fill="none" stroke="currentColor" stroke-width="1.45" stroke-linecap="round"/>',
  export: '<path d="M12 14V5M8 9l4-4 4 4M5 19h14" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>',
  shield: '<path d="M12 4 5 7v5c0 5 3.2 8 7 9 3.8-1 7-4 7-9V7z" fill="none" stroke="currentColor" stroke-width="1.7"/>',
  on: '<circle cx="12" cy="12" r="7" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M12 8v8" fill="none" stroke="currentColor" stroke-width="1.8"/>',
  off: '<circle cx="12" cy="12" r="7" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M9 9l6 6M15 9l-6 6" fill="none" stroke="currentColor" stroke-width="1.7"/>',
  jarmod: '<path d="M12 3.2 20.2 7.7v8.6L12 20.8 3.8 16.3V7.7Z" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linejoin="round"/><path d="M12 3.2 20.2 7.7 12 12.2 3.8 7.7Z" fill="currentColor" opacity=".22"/><path d="M12 12.2v8.6M3.8 7.7 12 12.2l8.2-4.5" fill="none" stroke="currentColor" stroke-width="1.55" stroke-linejoin="round"/>',
  zippack: '<path d="M5 8.6h14v11.2H5z" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linejoin="round"/><path d="M5 8.6 12 4.4 19 8.6" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linejoin="round"/><path d="M12 4.4v15.4" fill="none" stroke="currentColor" stroke-width="1.5"/><rect x="10.2" y="11.1" width="3.6" height="4.4" rx=".7" fill="none" stroke="currentColor" stroke-width="1.4"/><path d="M12 11.1v4.4" fill="none" stroke="currentColor" stroke-width="1.2"/>',
  shader: '<path d="M12 2.8 19.6 10.4 12 21.2 4.4 10.4Z" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linejoin="round"/><path d="M4.4 10.4h15.2" fill="none" stroke="currentColor" stroke-width="1.45"/><path d="M12 2.8 8.1 10.4h7.8Z" fill="currentColor" opacity=".28"/><path d="M8.1 10.4 12 21.2 15.9 10.4" fill="none" stroke="currentColor" stroke-width="1.35" stroke-linejoin="round"/>',
  respack: '<rect x="4.2" y="5.2" width="15.6" height="13.6" rx="2.2" fill="none" stroke="currentColor" stroke-width="1.65"/><path d="M4.2 14.8 8.4 10.8l3.2 3 2.8-2.6 5.2 4.6" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/><circle cx="9.1" cy="9.2" r="1.35" fill="currentColor"/>',
  pluginPage: '<rect x="5" y="4" width="14" height="16" rx="2.2" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M8.5 8h7M8.5 12h7M8.5 16h4.5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><circle cx="16.2" cy="16.2" r="2.4" fill="var(--panel-2)" stroke="currentColor" stroke-width="1.5"/>',
  resetApi: '<path d="M5 12a7 7 0 0 1 11.8-5.1M19 12a7 7 0 0 1-11.8 5.1" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/><path d="M16.6 3.6v4.2h-4.2M7.4 20.4v-4.2h4.2" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/>',
  send: '<path d="M3.2 10.6 20.8 3.4c.86-.36 1.64.42 1.28 1.28L15.4 21.7c-.4.96-1.74.86-2-.16l-2.4-8.2z" fill="currentColor"/>',
  smile: '<circle cx="12" cy="12" r="8" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M8.4 13.4c1.2 1.8 5.8 1.8 7.2 0" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/><circle cx="9.2" cy="10" r="1" fill="currentColor"/><circle cx="14.8" cy="10" r="1" fill="currentColor"/>',
  attach: '<path d="M16.4 11.2 10 17.6a3.2 3.2 0 0 1-4.6-4.6l7.8-7.8a2.2 2.2 0 1 1 3.1 3.1L8.6 16" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/>',
  mic: '<rect x="9" y="4" width="6" height="10" rx="3" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M7 12.2a5 5 0 0 0 10 0M12 17.2V20" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/>',
  more: '<circle cx="6" cy="12" r="1.4" fill="currentColor"/><circle cx="12" cy="12" r="1.4" fill="currentColor"/><circle cx="18" cy="12" r="1.4" fill="currentColor"/>',
  back: '<path d="M14 6 8 12l6 6" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>',
  gif: '<rect x="3.5" y="6" width="17" height="12" rx="2.2" fill="none" stroke="currentColor" stroke-width="1.65"/><path d="M7.2 14.4V9.6h3.2M7.2 12h2.2M12.2 9.6v4.8M15.4 14.4V9.6h2.8" fill="none" stroke="currentColor" stroke-width="1.45" stroke-linecap="round"/>',
  sticker: '<rect x="4.2" y="4.2" width="15.6" height="15.6" rx="4" fill="none" stroke="currentColor" stroke-width="1.65"/><path d="M14.6 4.4 19.6 9.4h-3.2A1.8 1.8 0 0 1 14.6 7.6z" fill="currentColor" opacity=".28"/><path d="M8.4 13.6c1.1 1.6 5.2 1.6 6.4 0" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><circle cx="9.2" cy="10.2" r=".9" fill="currentColor"/><circle cx="14.4" cy="10.2" r=".9" fill="currentColor"/>',
  poll: '<path d="M6 18V11M12 18V6M18 18v-4" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"/>',
  reply: '<path d="M8 11 4 7l4-4" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/><path d="M4 7h9a7 7 0 0 1 7 7v4" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/>',
  eye: '<path d="M3 12s3.6-6 9-6 9 6 9 6-3.6 6-9 6-9-6-9-6z" fill="none" stroke="currentColor" stroke-width="1.65"/><circle cx="12" cy="12" r="2.4" fill="none" stroke="currentColor" stroke-width="1.6"/>',
  bell: '<path d="M6 16h12l-1.2-2.2V10a4.8 4.8 0 1 0-9.6 0v3.8zM10 18.2a2 2 0 0 0 4 0" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linejoin="round"/>',
  ticks: '<path d="M3.6 12.2l3.1 3.2 6.6-7.4" fill="none" stroke="currentColor" stroke-width="2.05" stroke-linecap="round" stroke-linejoin="round"/><path d="M10.2 12.4l3.2 3.3 7-7.9" fill="none" stroke="currentColor" stroke-width="2.05" stroke-linecap="round" stroke-linejoin="round"/>',
  tick: '<path d="M5.2 12.4l4 4.1 9.6-10.2" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"/>',
  badge: '<circle cx="12" cy="12" r="9" fill="currentColor"/><path d="M8.2 12.2l2.5 2.5 5.2-5.4" fill="none" stroke="#fff" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"/>',
  tg: '<path d="M21 4.4 2.8 11.3c-1.2.5-1.2 1.4-.2 1.8l4.6 1.4 1.8 5.5c.2.7.4 1 1 .1.6 0 .8-.3 1.1-.6l2.6-2.5 5.4 4c1 .6 1.7.3 2-.9L22.6 5.6c.4-1.6-.6-2.3-1.6-1.2z" fill="currentColor"/>',
  disc: '<path d="M18.6 5.3A14.6 14.6 0 0 0 14.9 4l-.5 1a13.4 13.4 0 0 1 3.8 1.9 12 12 0 0 0-10 0A13.4 13.4 0 0 1 12 5L11.5 4a14.6 14.6 0 0 0-3.7 1.3A15 15 0 0 0 5.4 19.1a14.9 14.9 0 0 0 4.5 2.3l.9-1.6 1-.9a9.5 9.5 0 0 1-1.6-.8l.4-.3a11 11 0 0 0 9.6 0l.4.3a9.5 9.5 0 0 1-1.6.8l1 .9.9 1.6a14.9 14.9 0 0 0 4.5-2.3A15 15 0 0 0 18.6 5.3ZM9.5 15.8c-.9 0-1.6-.8-1.6-1.8s.7-1.8 1.6-1.8 1.6.8 1.6 1.8-.7 1.8-1.6 1.8Zm5 0c-.9 0-1.6-.8-1.6-1.8s.7-1.8 1.6-1.8 1.6.8 1.6 1.8-.7 1.8-1.6 1.8Z" fill="currentColor"/>',
  youtube: '<rect x="3.5" y="6.5" width="17" height="11" rx="3" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="m10.4 9.8 4 2.2-4 2.2z" fill="currentColor"/>',
  tiktok: '<path d="M14.5 4v9.2a3.8 3.8 0 1 1-3.8-3.8M14.5 4c.3 2.6 1.9 4.4 4.5 4.7M14.5 4V3" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/>',
  bold: '<path d="M7 5h6.4a3.4 3.4 0 0 1 0 6.8H7zM7 11.8h7.2A3.6 3.6 0 0 1 14.2 19H7z" fill="none" stroke="currentColor" stroke-width="1.7"/>',
  italic: '<path d="M10 5h8M6 19h8M14.5 5 9.5 19" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/>',
  strike: '<path d="M6 12h12M9.2 8.2C9.8 6.6 11 5.6 13 5.6c2.2 0 3.6 1.2 3.6 3 0 1.4-.6 2.2-2.4 2.8M8.4 13.4c.4 2.6 2 3.8 4.6 3.8 2.6 0 4.2-1.4 4.4-3.6" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>',
  code: '<path d="M9 8 5 12l4 4M15 8l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/>',
  spoiler: '<rect x="4" y="6" width="16" height="12" rx="3" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M8 12h8M10 9.5h4M10 14.5h4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>',
  down: '<path d="M6 10l6 6 6-6" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/>',
  link: '<path d="M10 14.5 8.2 16.3a3 3 0 0 1-4.2-4.2L7.2 9M14 9.5l1.8-1.8a3 3 0 1 1 4.2 4.2L16.8 15" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/><path d="M9.2 14.8l5.6-5.6" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>',
  video: '<rect x="3.5" y="6.5" width="12.5" height="11" rx="2" fill="none" stroke="currentColor" stroke-width="1.65"/><path d="M16 10.2 20.4 7.6v8.8L16 13.8z" fill="currentColor"/>',
  users: '<circle cx="9" cy="9" r="2.6" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M4.4 18c.8-2.6 2.4-3.8 4.6-3.8S12.8 15.4 13.6 18M16.2 10.2a2.2 2.2 0 1 0 0-4.2" fill="none" stroke="currentColor" stroke-width="1.55"/><path d="M15.4 18c.5-1.8 1.6-2.8 3.2-3.2" fill="none" stroke="currentColor" stroke-width="1.55" stroke-linecap="round"/>',
  bot: '<rect x="7" y="8" width="10" height="9" rx="3" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M12 8V5M9.4 12.2h.1M14.5 12.2h.1M9 17.2c1 .8 5 .8 6 0" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><circle cx="12" cy="4.2" r=".9" fill="currentColor"/>',
  wallpaper: '<rect x="4" y="5" width="16" height="14" rx="2.2" fill="none" stroke="currentColor" stroke-width="1.65"/><path d="M4 15.4 8.2 11l3 2.8 2.6-2.4L20 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/><circle cx="9" cy="9" r="1.2" fill="currentColor"/>',
  mute: '<path d="M4 10h3.2L12 6v12l-4.8-4H4zM16.2 9.2 20 13m0-3.8-3.8 3.8" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round"/>',
  star: '<path d="M12 3.6 14.4 9l6 .6-4.5 4 1.3 5.8L12 16.6 6.8 19.4 8.1 13.6 3.6 9.6 9.6 9z" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linejoin="round"/>',
  clock: '<circle cx="12" cy="12" r="7.2" fill="none" stroke="currentColor" stroke-width="1.65"/><path d="M12 8.2V12l2.6 2.2" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>',
  crop: '<path d="M7 3v14h14M17 21V7H3" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/>',
  draw: '<path d="M5 19h4l10-10-4-4L5 15z" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linejoin="round"/><path d="M14 6l4 4" fill="none" stroke="currentColor" stroke-width="1.65"/>',
  widget: '<rect x="4" y="6" width="16" height="12" rx="2.4" fill="none" stroke="currentColor" stroke-width="1.65"/><path d="M8 10h8M8 14h5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>',
  badgeStar: '<path d="M12 3.2 14.6 8l5.4.6-4 3.6 1.2 5.2L12 15.2 6.8 17.4 8 12.2 4 8.6 9.4 8z" fill="currentColor"/>',
  select: '<rect x="4.2" y="4.2" width="15.6" height="15.6" rx="3.2" fill="none" stroke="currentColor" stroke-width="1.65"/><path d="M8 12.2l2.6 2.6 5.4-5.6" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/>',
  menu: '<path d="M5 7h14M5 12h14M5 17h14" fill="none" stroke="currentColor" stroke-width="1.85" stroke-linecap="round"/>',
  archive: '<path d="M4 7h16l-1.2 12.2H5.2z" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linejoin="round"/><path d="M3.5 7h17v3H3.5z" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linejoin="round"/><path d="M10 13h4" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/>',
  block: '<circle cx="12" cy="12" r="8" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M7 17 17 7" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/>',
  share: '<circle cx="6.2" cy="12" r="2.2" fill="none" stroke="currentColor" stroke-width="1.6"/><circle cx="17" cy="6.5" r="2.2" fill="none" stroke="currentColor" stroke-width="1.6"/><circle cx="17" cy="17.5" r="2.2" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M8.2 11.2 15 7.4M8.2 12.8 15 16.6" fill="none" stroke="currentColor" stroke-width="1.6"/>',
  rotate: '<path d="M19 8.2A7.2 7.2 0 1 0 19.4 14" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/><path d="M19 4.4v4.4h-4.4" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/>',
  camera: '<path d="M4.5 8.2h3.1l1.4-2.2h6l1.4 2.2h3.1A1.8 1.8 0 0 1 21.3 10v8.2a1.8 1.8 0 0 1-1.8 1.8H6.3A1.8 1.8 0 0 1 4.5 18.2V10a1.8 1.8 0 0 1 1.8-1.8z" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linejoin="round"/><circle cx="12" cy="14" r="3.1" fill="none" stroke="currentColor" stroke-width="1.65"/>',
  shop: '<path d="M6.2 9.2 7.4 20h9.2l1.2-10.8z" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linejoin="round"/><path d="M8.2 9.2V7.4A3.8 3.8 0 0 1 12 3.6a3.8 3.8 0 0 1 3.8 3.8v1.8" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round"/>',
  leave: '<path d="M10 4.4H6.4A1.8 1.8 0 0 0 4.6 6.2v11.6A1.8 1.8 0 0 0 6.4 19.6H10M14.4 8.2 18.6 12l-4.2 3.8M18.6 12H9.2" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round"/>',
  comment: '<path d="M5.2 6.2h13.6A1.8 1.8 0 0 1 20.6 8v7.2a1.8 1.8 0 0 1-1.8 1.8H10.2L6 19.6v-2.6H5.2A1.8 1.8 0 0 1 3.4 15.2V8A1.8 1.8 0 0 1 5.2 6.2z" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linejoin="round"/>',
  volume: '<path d="M4.4 9.4h3.2L12 6v12l-4.4-3.4H4.4zM15.4 9.6a3.4 3.4 0 0 1 0 4.8M17.8 7.4a6.2 6.2 0 0 1 0 9.2" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round"/>',
  speaker: '<path d="M4.4 9.4h3.2L12 6v12l-4.4-3.4H4.4zM15.4 9.6a3.4 3.4 0 0 1 0 4.8M17.8 7.4a6.2 6.2 0 0 1 0 9.2" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round"/>',
  device: '<rect x="5.2" y="4.4" width="13.6" height="11.2" rx="1.6" fill="none" stroke="currentColor" stroke-width="1.65"/><path d="M8 18.4h8M12 15.6v2.8" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round"/>',
  legal: '<path d="M6 4.6h12v15.2H6z" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linejoin="round"/><path d="M9 8.2h6M9 11.4h6M9 14.6h4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>'
};

const ICON_OVERRIDES = new Set(['gear', 'trash', 'mr', 'mods', 'plug']);
let overrides = {};

const SVG_TAGS = new Set(['path', 'circle', 'rect', 'line', 'polyline', 'polygon', 'ellipse']);
const SVG_ATTRIBUTES = new Set([
  'd', 'cx', 'cy', 'r', 'rx', 'ry', 'x', 'y', 'x1', 'y1', 'x2', 'y2',
  'width', 'height', 'points', 'fill', 'stroke', 'stroke-width',
  'stroke-linecap', 'stroke-linejoin', 'fill-rule', 'opacity'
]);

function customIcon(name) {
  return ICON_OVERRIDES.has(name) && overrides[name] && typeof overrides[name] === 'object'
    ? overrides[name]
    : null;
}

export function sanitizeIconSvg(source) {
  const text = String(source || '');
  if (!text.trim() || text.length > 24 * 1024 || typeof DOMParser === 'undefined') {
    throw new Error('SVG-файл пустой, слишком большой или не поддерживается');
  }
  const parsed = new DOMParser().parseFromString(text, 'image/svg+xml');
  const root = parsed.documentElement;
  if (!root || root.localName !== 'svg' || parsed.querySelector('parsererror')) {
    throw new Error('Некорректный SVG-файл');
  }
  const viewBox = (root.getAttribute('viewBox') || '0 0 24 24').trim();
  const values = viewBox.split(/[\s,]+/).map(Number);
  if (values.length !== 4 || values.some((value) => !Number.isFinite(value))
    || values[2] <= 0 || values[3] <= 0 || values[2] > 1000 || values[3] > 1000) {
    throw new Error('SVG должен иметь корректный viewBox');
  }
  let elementCount = 0;
  const cleanNode = (node) => {
    elementCount += 1;
    if (elementCount > 256) throw new Error('SVG содержит слишком много элементов');
    if (node.nodeType !== 1 || !SVG_TAGS.has(node.localName)) {
      throw new Error('SVG может содержать только безопасные геометрические элементы');
    }
    let markup = `<${node.localName}`;
    for (const attr of [...node.attributes]) {
      const name = attr.name.toLowerCase();
      const value = attr.value.trim();
      if (!SVG_ATTRIBUTES.has(name)) throw new Error(`Недопустимый атрибут SVG: ${name}`);
      if ((name === 'fill' || name === 'stroke')
        && !/^(none|currentcolor|#(?:[\da-f]{3}|[\da-f]{4}|[\da-f]{6}|[\da-f]{8})|[a-z]+)$/i.test(value)) {
        throw new Error('В SVG разрешены только однотонные цвета');
      }
      if (['stroke-linecap', 'stroke-linejoin', 'fill-rule'].includes(name)
        && !/^(butt|round|square|miter|bevel|arcs|nonzero|evenodd)$/i.test(value)) {
        throw new Error(`Недопустимое значение SVG: ${name}`);
      }
      if (name === 'opacity' && (!/^(?:0(?:\.\d+)?|1(?:\.0+)?)$/.test(value))) {
        throw new Error('Недопустимое значение SVG: opacity');
      }
      if (name !== 'd' && name !== 'points' && name !== 'fill' && name !== 'stroke'
        && !['stroke-linecap', 'stroke-linejoin', 'fill-rule'].includes(name)
        && name !== 'opacity' && !/^[\d.,+\-\s]+$/.test(value)) {
        throw new Error(`Недопустимое значение SVG: ${name}`);
      }
      if ((name === 'd' || name === 'points') && !/^[\da-z.,+\-\s]+$/i.test(value)) {
        throw new Error(`Недопустимая геометрия SVG: ${name}`);
      }
      markup += ` ${name}="${value.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;')}"`;
    }
    if (!node.childElementCount) return `${markup}/>`;
    markup += '>';
    for (const child of node.children) markup += cleanNode(child);
    return `${markup}</${node.localName}>`;
  };
  let body = '';
  for (const child of root.children) body += cleanNode(child);
  if (!body) throw new Error('SVG не содержит рисунка');
  return { viewBox, body };
}

export function setIconOverrides(next = {}) {
  overrides = {};
  if (next && typeof next === 'object' && !Array.isArray(next)) {
    for (const name of ICON_OVERRIDES) {
      const value = next[name];
      if (typeof value === 'string' && I[value]) overrides[name] = value;
      else if (value && typeof value === 'object') {
        try {
          overrides[name] = sanitizeIconSvg(`<svg viewBox="${String(value.viewBox || '0 0 24 24')}">${String(value.body || '')}</svg>`);
        } catch (err) {
          console.warn(`Saved custom ${name} icon was rejected`, err);
        }
      }
    }
  }
  document.querySelectorAll('svg.app-icon[data-icon]').forEach((node) => {
    const name = node.getAttribute('data-icon');
    node.innerHTML = iconContent(name);
    const custom = customIcon(name);
    node.setAttribute('viewBox', custom ? custom.viewBox : '0 0 24 24');
  });
}

function iconContent(name) {
  if (ICON_OVERRIDES.has(name)) {
    const custom = overrides[name];
    if (typeof custom === 'string' && I[custom]) return I[custom];
    const safe = customIcon(name);
    if (safe) return safe.body;
  }
  return I[name] || '';
}

export function svg(name, cls = '') {
  const d = iconContent(name);
  const custom = customIcon(name);
  const viewBox = custom ? custom.viewBox : '0 0 24 24';
  return `<svg class="app-icon icon-${name}${cls ? ' ' + cls : ''}" data-icon="${name}" viewBox="${viewBox}" aria-hidden="true">${d}</svg>`;
}
