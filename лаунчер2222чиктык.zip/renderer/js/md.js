function esc(s) {
  return String(s || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

export function mdToHtml(src) {
  let text = stripTags(String(src || '')).replace(/\r\n/g, '\n');
  text = text.replace(/```[\s\S]*?```/g, (m) => `<pre class="md-pre">${esc(m.slice(3, -3).trim())}</pre>`);
  const lines = text.split('\n');
  const out = [];
  let list = false;
  for (let raw of lines) {
    if (raw.startsWith('<pre')) { if (list) { out.push('</ul>'); list = false; } out.push(raw); continue; }
    const line = raw;
    if (/^\s*[-*]\s+/.test(line)) {
      if (!list) { out.push('<ul class="md-ul">'); list = true; }
      out.push(`<li>${inline(line.replace(/^\s*[-*]\s+/, ''))}</li>`);
      continue;
    }
    if (list) { out.push('</ul>'); list = false; }
    if (/^###\s+/.test(line)) out.push(`<h4>${inline(line.slice(4))}</h4>`);
    else if (/^##\s+/.test(line)) out.push(`<h3>${inline(line.slice(3))}</h3>`);
    else if (/^#\s+/.test(line)) out.push(`<h2>${inline(line.slice(2))}</h2>`);
    else if (/^>\s+/.test(line)) out.push(`<blockquote>${inline(line.slice(2))}</blockquote>`);
    else if (!line.trim()) out.push('<p></p>');
    else out.push(`<p>${inline(line)}</p>`);
  }
  if (list) out.push('</ul>');
  return out.join('');
}

function stripTags(s) {
  return String(s || '').replace(/<[^>]+>/g, '');
}

function inline(s) {
  return esc(stripTags(s))
    .replace(/!\[([^\]]*)\]\((https?:[^)]+)\)/g, '<img alt="$1" src="$2" class="md-img">')
    .replace(/\[([^\]]+)\]\((https?:[^)]+)\)/g, '<a href="$2" rel="noreferrer">$1</a>')
    .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
    .replace(/\*([^*]+)\*/g, '<em>$1</em>')
    .replace(/`([^`]+)`/g, '<code>$1</code>');
}
