import { api } from '../api.js';
import { store, toast } from '../state.js';
import { el } from '../utils.js';
import { go } from '../router.js';

const RU = {
  'missing-class': 'Не найден класс — мод недокачан или не тот загрузчик.',
  'missing-dep': 'Не хватает зависимости. Лаунчер попробует найти её в Модринте.',
  'requires': 'Мод требует другой мод. Нажми «Исправить» — поищем в Модринте.',
  'fabric-api': 'Скорее всего нет Fabric API. Поставим его одной кнопкой.',
  'incompatible': 'Моды несовместимы. Отключим подозрительные.',
  'oom': 'Не хватило памяти. Увеличь RAM в настройках сборки.',
  'mod-load': 'Мод не загрузился. Отключим недавние или откатимся к снимку.'
};

export async function mountHealth(root, params) {
  const id = (params && params.id) || store.selectedId;
  const wrap = el('div');
  wrap.appendChild(el('p', { class: 'kicker', text: 'ПОЧИНКА' }));
  wrap.appendChild(el('h2', { class: 'h2', text: 'Починка сборки' }));
  if (!id) {
    const empty = el('div', { class: 'empty' });
    empty.appendChild(el('h3', { text: 'Нет выбранной сборки' }));
    empty.appendChild(el('p', { text: 'Выбери пак внизу или создай новый — тогда можно читать логи и чинить моды.' }));
    empty.appendChild(el('button', { class: 'btn btn-sky', text: 'К сборкам', onclick: () => go('#/instances') }));
    wrap.appendChild(empty);
    root.appendChild(wrap);
    return;
  }
  const grid = el('div', { class: 'health-grid' });
  const left = el('div', { class: 'card' });
  const right = el('div', { class: 'card' });
  grid.appendChild(left);
  grid.appendChild(right);
  wrap.appendChild(grid);
  const actions = el('div', { class: 'row', style: 'margin-top:12px' });
  wrap.appendChild(actions);
  root.appendChild(wrap);

  const [status, crash, timeline] = await Promise.all([
    api.health.getStatus(id),
    api.health.analyzeCrash(id),
    api.health.getTimeline(id)
  ]);
  left.appendChild(el('strong', { text: 'Состояние' }));
  left.appendChild(el('p', { text: 'Диск: ' + (status.diskUsage || '0') }));
  left.appendChild(el('p', { text: 'Моды: ' + (status.modCount || 0) + ' (вкл. ' + (status.enabledMods || 0) + ')' }));
  left.appendChild(el('p', { text: 'Конфликты: ' + (status.conflicts || 0) }));
  left.appendChild(el('p', { text: 'Бэкапы: ' + (status.backupStatus === 'ok' ? 'есть' : 'нет') }));
  if (status.lastLaunch) left.appendChild(el('p', { class: 'hint', text: 'Последний запуск: ' + String(status.lastLaunch).replace('T', ' ').slice(0, 16) }));

  right.appendChild(el('strong', { text: 'Что случилось' }));
  const ruSuggest = crash.ru || crash.suggestion || 'Краш не разобран. Открой лог.';
  right.appendChild(el('p', { text: ruSuggest }));
  for (const f of crash.findings || []) {
    right.appendChild(el('div', { class: 'mr-meta', text: (RU[f.hint] || f.hint) + (f.match ? ' · ' + f.match : '') }));
  }
  if (!(crash.findings || []).length) {
    right.appendChild(el('p', { class: 'hint', text: 'Логов краша нет — либо ещё не запускали, либо всё чисто.' }));
  }

  const tl = el('ul', { class: 'timeline' });
  for (const ev of timeline || []) {
    const li = el('li');
    li.appendChild(el('time', { text: (ev.at || '').replace('T', ' ').slice(0, 16) }));
    li.appendChild(document.createTextNode(' ' + (ev.text || ev.kind || '')));
    tl.appendChild(li);
  }
  wrap.appendChild(el('h3', { text: 'История', style: 'margin:16px 0 8px' }));
  if (!(timeline || []).length) wrap.appendChild(el('p', { class: 'hint', text: 'Пока тихо.' }));
  wrap.appendChild(tl);

  actions.appendChild(el('button', { class: 'btn btn-sky', text: 'Исправить', onclick: async () => {
    try {
      const r = await api.health.autoFix(id);
      toast(r.message || 'Готово', r.ok ? 'ok' : 'bad');
    } catch (e) { toast(e.message, 'bad'); }
  } }));
  actions.appendChild(el('button', { class: 'btn', text: 'Искать в Модринте', onclick: () => go('#/modrinth') }));
  actions.appendChild(el('button', { class: 'btn', text: 'Отключить подозрительные', onclick: async () => {
    const r = await api.health.fixInstance(id, 'disable-suspects');
    toast(r.ok ? 'Отключены' : (r.error || 'Не вышло'), r.ok ? 'ok' : 'bad');
  } }));
  actions.appendChild(el('button', { class: 'btn btn-ghost', text: 'Бэкап сейчас', onclick: async () => {
    await api.backup.create(id, 'manual');
    toast('Снимок создан');
  } }));
  actions.appendChild(el('button', { class: 'btn btn-ghost', text: 'Откат', onclick: async () => {
    const r = await api.health.fixInstance(id, 'rollback');
    toast(r.ok ? 'Откатили к снимку' : (r.error || 'Нет бэкапов'), r.ok ? 'ok' : 'bad');
  } }));
}
