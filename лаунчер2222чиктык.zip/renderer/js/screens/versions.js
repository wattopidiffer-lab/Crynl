import { api } from '../api.js';
import { store, toast } from '../state.js';
import { el } from '../utils.js';
import { go } from '../router.js';

export async function mountVersions(root) {
  go('#/instances');
  toast('Версии теперь внутри Сборок');
}
