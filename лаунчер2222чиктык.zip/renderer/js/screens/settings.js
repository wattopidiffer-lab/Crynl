import { api } from '../api.js';
import { store, toast } from '../state.js';
import { el } from '../utils.js';
import { chk, field, customSelect, paintSkinFace, drawSkinFront } from '../ui.js';
import { loadLocale } from '../i18n.js';

// Re-read the user's custom CSS and swap it into the live <style> node so
// changes are visible immediately, without reloading the window.
async function applyCustomCssLive() {
  const node = document.getElementById('userTheme');
  if (!node) return;
  try {
    node.textContent = (await api.theme.read()) || '';
  } catch (_) {
    node.textContent = '';
  }
}

const THEMES = [
  ['dark', 'Тёмный', '#07080c', '#7c9cff'],
  ['light', 'Светлый', '#f3f5fa', '#3b5bfd'],
  ['furry', 'Фурри', '#140918', '#ff9a4a'],
  ['girly', 'Девчачий', '#2a1020', '#ff7ab6'],
  ['professional', 'Профессиональный', '#0a0c10', '#c9a227'],
  ['glass', 'Стеклянный', '#081018', '#8ee7ff']
];

export async function mountSettings(root) {
  const s = await api.settings.getAll();
  store.settings = s;
  const ram = await api.ram.suggest().catch(() => ({ recommendedMb: 4096, totalMb: 0, freeMb: 0 }));
  const wrap = el('div');
  wrap.className = 'settings-pane';
  wrap.appendChild(el('p', { class: 'kicker', text: 'НАСТРОЙКИ' }));
  wrap.appendChild(el('h2', { class: 'h2', text: 'Лаунчер под себя' }));

  function block(title) {
    wrap.appendChild(el('h3', { text: title, style: 'margin:18px 0 8px' }));
  }

  block('Тема');
  let colorInput = null;
  const grid = el('div', { class: 'theme-grid', style: 'margin-bottom:14px' });
  for (const [id, title, bg, accent] of THEMES) {
    const b = el('button', { class: 'theme-swatch' + (((s.ui && s.ui.theme) || 'dark') === id ? ' on' : ''), onclick: async () => {
      await api.settings.set('ui.theme', id);
      // An inline --accent from the colour picker wins over [data-theme], which
      // made every theme look identical. Clear it so the theme's own palette
      // actually shows; the colour picker can still set one afterwards.
      await api.settings.set('ui.accent', '');
      document.documentElement.style.removeProperty('--accent');
      if (colorInput) colorInput.value = accent;
      document.documentElement.setAttribute('data-theme', id);
      store.settings.ui = store.settings.ui || {};
      store.settings.ui.theme = id;
      store.settings.ui.accent = '';
      grid.querySelectorAll('.theme-swatch').forEach((n) => n.classList.remove('on'));
      b.classList.add('on');
      toast('Тема: ' + title);
    } });
    const prev = el('div', { class: 'preview' });
    prev.style.background = 'linear-gradient(90deg, ' + bg + ' 55%, ' + accent + ')';
    b.appendChild(prev);
    b.appendChild(el('strong', { text: title, style: 'display:block' }));
    grid.appendChild(b);
  }
  wrap.appendChild(grid);

  const themeAccent = (THEMES.find(([id]) => id === ((s.ui && s.ui.theme) || 'dark')) || THEMES[0])[3];
  const accent = el('input', { type: 'color', value: (s.ui && s.ui.accent) || themeAccent });
  colorInput = accent;
  accent.addEventListener('change', async () => {
    await api.settings.set('ui.accent', accent.value);
    document.documentElement.style.setProperty('--accent', accent.value);
  });
  wrap.appendChild(field('Цвет интерфейса (перекрывает тему)', accent));

  const radius = el('input', { class: 'field', type: 'range', min: '4', max: '28', value: String((s.ui && s.ui.radius) || 16) });
  radius.addEventListener('input', async () => {
    document.documentElement.style.setProperty('--radius', radius.value + 'px');
    await api.settings.set('ui.radius', Number(radius.value));
  });
  wrap.appendChild(field('Скругление рамок', radius));

  const nav = customSelect([
    { value: 'left', label: 'Слева' },
    { value: 'right', label: 'Справа' },
    { value: 'top', label: 'Сверху' },
    { value: 'bottom', label: 'Снизу' }
  ], (s.ui && s.ui.navPos) || 'left', async (v) => {
    await api.settings.set('ui.navPos', v);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.navPos = v;
    if (window.__cryndelApplyUi) window.__cryndelApplyUi();
  });
  wrap.appendChild(field('Где навигация', nav));

  wrap.appendChild(field('Шрифт главной', customSelect([
    { value: 'default', label: 'Обычный' },
    { value: 'minecraft', label: 'Майнкрафтский' },
    { value: 'title', label: 'Minecraft Title' },
    { value: 'classic', label: 'Классический' }
  ], (s.ui && s.ui.homeFont) || 'default', async (v) => {
    await api.settings.set('ui.homeFont', v);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.homeFont = v;
    if (window.__cryndelApplyUi) window.__cryndelApplyUi();
  })));

  const lang = el('select', { class: 'field' });
  lang.appendChild(el('option', { value: 'ru', text: 'Русский' }));
  lang.appendChild(el('option', { value: 'en', text: 'English' }));
  lang.value = (s.ui && s.ui.language) || 'ru';
  lang.addEventListener('change', async () => {
    await api.settings.set('ui.language', lang.value);
    await api.settings.set('game.language', lang.value);
    await loadLocale(lang.value);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.language = lang.value;
    if (window.__cryndelRefresh) await window.__cryndelRefresh();
    toast(lang.value === 'en' ? 'Language saved' : 'Язык сохранён');
  });
  wrap.appendChild(field('Язык лаунчера и Minecraft', lang));

  block('Свой CSS');
  wrap.appendChild(el('p', { class: 'hint', text: 'Здесь можно переопределить любые стили лаунчера. Пиши обычный CSS — он применяется сразу и хранится между запусками.' }));
  const cssArea = el('textarea', {
    class: 'field css-editor',
    spellcheck: 'false',
    style: 'min-height:150px;font-family:var(--mono);font-size:12.5px;line-height:1.5',
    placeholder: ':root { --accent: #7c9cff; }\n.foot { backdrop-filter: blur(24px); }'
  });
  cssArea.value = await api.theme.read().catch(() => '');
  wrap.appendChild(cssArea);
  const cssRow = el('div', { class: 'row', style: 'margin-top:8px' });
  cssRow.appendChild(el('button', { class: 'btn btn-sky', text: 'Применить CSS', onclick: async () => {
    try {
      await api.theme.write(cssArea.value);
      await applyCustomCssLive();
      toast('CSS применён');
    } catch (e) { toast(e.message || 'CSS отклонён', 'bad'); }
  } }));
  cssRow.appendChild(el('button', { class: 'btn', text: 'Из файла…', onclick: async () => {
    const r = await api.theme.import();
    if (r && r.ok) {
      cssArea.value = await api.theme.read().catch(() => '');
      await applyCustomCssLive();
      toast('CSS загружен');
    } else if (r && r.error) {
      toast(r.error, 'bad');
    }
  } }));
  cssRow.appendChild(el('button', { class: 'btn btn-danger', text: 'Очистить', onclick: async () => {
    await api.theme.clear();
    cssArea.value = '';
    await applyCustomCssLive();
    toast('Свой CSS удалён');
  } }));
  wrap.appendChild(cssRow);

  block('Главная и фон');
  wrap.appendChild(chk('Видео-обои зациклить', !s.ui || s.ui.bgLoop !== false, async (v) => {
    await api.settings.set('ui.bgLoop', v);
  }));
  wrap.appendChild(chk('Всегда показывать анимацию первого открытия', Boolean(s.ui && s.ui.alwaysSplash), async (v) => {
    await api.settings.set('ui.alwaysSplash', v);
  }));
  wrap.appendChild(chk('3D-скин вместо обучения на главной', Boolean(s.ui && s.ui.showSkin3d), async (v) => {
    await api.settings.set('ui.showSkin3d', v);
  }));
  wrap.appendChild(chk('Частицы на фоне', Boolean(s.ui && s.ui.particles), async (v) => {
    await api.settings.set('ui.particles', v);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.particles = v;
    if (window.__cryndelApplyUi) window.__cryndelApplyUi();
  }));
  wrap.appendChild(chk('Фурри-виджет', s.ui && s.ui.furryWidget !== false, async (v) => {
    await api.settings.set('ui.furryWidget', v);
  }));
  wrap.appendChild(chk('Виджет скриншотов', s.ui && s.ui.shotsWidget !== false, async (v) => {
    await api.settings.set('ui.shotsWidget', v);
  }));

  const dim = el('input', { class: 'field', type: 'range', min: '20', max: '90', value: String(Math.round(((s.ui && s.ui.bgDim) || 0.55) * 100)) });
  dim.addEventListener('input', async () => {
    const v = Number(dim.value) / 100;
    document.documentElement.style.setProperty('--bg-dim', String(v));
    await api.settings.set('ui.bgDim', v);
  });
  wrap.appendChild(field('Затемнение фона', dim));

  const bgRow = el('div', { class: 'row', style: 'margin:8px 0 12px' });
  bgRow.appendChild(el('button', { class: 'btn btn-sky', text: 'Загрузить фон', onclick: async () => {
    const r = await api.theme.pickBackground();
    if (r.ok) toast('Фон выбран. Применится при следующем запуске.');
  } }));
  bgRow.appendChild(el('button', { class: 'btn btn-ghost', text: 'Сбросить фон', onclick: async () => {
    await api.settings.set('ui.backgroundFile', '');
    await api.settings.set('ui.backgroundKind', 'video');
    toast('Фон сброшен');
  } }));
  bgRow.appendChild(el('button', { class: 'btn', text: 'Видео заставки', onclick: async () => {
    const r = await api.theme.pickSplash();
    if (r && r.ok) toast('Заставка сохранена');
  } }));
  wrap.appendChild(bgRow);

  const furRow = el('div', { class: 'row', style: 'margin-bottom:12px' });
  furRow.appendChild(el('button', { class: 'btn', text: 'Картинка фурри', onclick: async () => {
    const r = await api.theme.pickFurryImage();
    if (r && r.ok) toast('Картинка сохранена');
  } }));
  furRow.appendChild(el('button', { class: 'btn', text: '3 своих звука', onclick: async () => {
    const r = await api.theme.pickFurrySounds();
    if (r && r.ok) toast('Звуки сохранены');
  } }));
  wrap.appendChild(furRow);

  block('Память и картинка');
  const mode = el('select', { class: 'field' });
  mode.appendChild(el('option', { value: 'auto', text: 'Автоматически под систему' }));
  mode.appendChild(el('option', { value: 'manual', text: 'Задать вручную' }));
  mode.value = (s.game && s.game.memoryMode) || 'auto';
  const mem = el('input', { class: 'field', type: 'range', min: '2048', max: String(Math.max(4096, ram.totalMb - 1024 || 8192)), step: '256', value: String((s.game && s.game.defaultMemoryMb) || ram.recommendedMb) });
  const memLab = el('p', { class: 'hint', text: mem.value + ' МБ  ·  в ПК ' + ram.totalMb + ' МБ' });
  mem.addEventListener('input', () => { memLab.textContent = mem.value + ' МБ'; });
  async function saveRam() {
    await api.settings.set('game.memoryMode', mode.value);
    await api.settings.set('game.defaultMemoryMb', Number(mem.value));
    if (store.selectedId) await api.instances.update(store.selectedId, { memoryMb: Number(mem.value), memoryMode: mode.value });
    toast('RAM сохранена');
  }
  mode.addEventListener('change', saveRam);
  mem.addEventListener('change', saveRam);
  wrap.appendChild(field('Оперативка для игры', mode));
  wrap.appendChild(mem);
  wrap.appendChild(memLab);

  const w = el('input', { class: 'field', type: 'number', value: String((s.game && s.game.defaultResolution && s.game.defaultResolution.width) || 1280) });
  const h = el('input', { class: 'field', type: 'number', value: String((s.game && s.game.defaultResolution && s.game.defaultResolution.height) || 720) });
  const resRow = el('div', { class: 'row' });
  resRow.appendChild(w); resRow.appendChild(h);
  wrap.appendChild(field('Разрешение окна', resRow));
  w.addEventListener('change', () => api.settings.set('game.defaultResolution', { width: Number(w.value) || 1280, height: Number(h.value) || 720 }));
  h.addEventListener('change', () => api.settings.set('game.defaultResolution', { width: Number(w.value) || 1280, height: Number(h.value) || 720 }));

  wrap.appendChild(chk('Полный экран', s.game && s.game.defaultFullscreen, (v) => api.settings.set('game.defaultFullscreen', v)));
  wrap.appendChild(chk('Спринт по нажатию, не зажимать', !s.game || s.game.toggleSprint !== false, (v) => api.settings.set('game.toggleSprint', v)));

  block('Java и рендер');
  const javaCmd = el('input', { class: 'field', placeholder: 'Полный путь java.exe', value: (s.game && s.game.javaCommand) || '' });
  javaCmd.addEventListener('change', () => api.settings.set('game.javaCommand', javaCmd.value.trim()));
  wrap.appendChild(field('Своя команда Java', javaCmd));
  const jvm = el('input', { class: 'field', placeholder: '-XX:+UseG1GC', value: (s.game && s.game.customJvmArgs) || '' });
  jvm.addEventListener('change', () => api.settings.set('game.customJvmArgs', jvm.value.trim()));
  wrap.appendChild(field('Доп. аргументы JVM', jvm));

  const gpu = el('select', { class: 'field' });
  gpu.appendChild(el('option', { value: 'auto', text: 'Авто' }));
  const gpus = await api.system.gpus().catch(() => []);
  for (const g of gpus) gpu.appendChild(el('option', { value: g.id, text: g.name }));
  gpu.value = (s.game && s.game.gpu) || 'auto';
  gpu.addEventListener('change', () => api.settings.set('game.gpu', gpu.value));
  wrap.appendChild(field('Видеокарта', gpu));

  const render = customSelect([
    { value: 'default', label: 'По умолчанию' },
    { value: 'fabulous', label: 'Fabulous' },
    { value: 'fancy', label: 'Fancy' },
    { value: 'fast', label: 'Fast' }
  ], (s.game && s.game.graphics) || 'default', (v) => api.settings.set('game.graphics', v));
  wrap.appendChild(field('Рендер игры', render));

  const javaBox = el('div', { class: 'card', style: 'margin:12px 0' });
  const javas = await api.system.detectJava().catch(() => []);
  if (!javas.length) javaBox.appendChild(el('p', { class: 'hint', text: 'Java не найдена — лаунчер скачает сам.' }));
  for (const j of javas) javaBox.appendChild(el('div', { text: j.path + ' (' + (j.version || '?') + ')', class: 'hint' }));
  javaBox.appendChild(el('button', { class: 'btn btn-sky', style: 'margin-top:10px', text: 'Скачать Java 21', onclick: async () => {
    try { toast('Качаю Java 21…'); await api.java.ensure(21); toast('Java готова'); }
    catch (e) { toast(e.message || 'Не удалось скачать Java', 'bad'); }
  } }));
  wrap.appendChild(javaBox);

  block('Лаунчер');
  wrap.appendChild(chk('Discord RPC', !s.launcher || s.launcher.discordRpc !== false, async (v) => {
    await api.settings.set('launcher.discordRpc', v);
    try { await api.discord.toggle(v); } catch (_) { /* */ }
  }));
  wrap.appendChild(chk('Сворачивать в трей при запуске игры', s.launcher && s.launcher.minimizeToTray !== false, (v) => api.settings.set('launcher.minimizeToTray', v)));
  wrap.appendChild(chk('Закрывать лаунчер при запуске игры', s.launcher && s.launcher.closeOnLaunch, (v) => api.settings.set('launcher.closeOnLaunch', v)));

  block('Скин');
  const skinBox = el('div', { class: 'card' });
  const skinRowPrev = el('div', { class: 'row', style: 'align-items:flex-start;gap:16px' });
  const skinPrev = el('img', { class: 'skin-prev', alt: 'лицо' });
  const skinFront = el('canvas', { width: '96', height: '192', class: 'skin-front' });
  skinRowPrev.appendChild(skinPrev);
  skinRowPrev.appendChild(skinFront);
  skinBox.appendChild(skinRowPrev);
  async function showSkin(p) {
    if (!p) return;
    const u = await api.skins.preview(p).catch(() => null);
    if (u) {
      paintSkinFace(skinPrev, u);
      drawSkinFront(skinFront, u);
    }
  }
  if (store.user && store.user.skin && store.user.skin.path) showSkin(store.user.skin.path);
  const skinRow = el('div', { class: 'row', style: 'margin-top:10px' });
  skinRow.appendChild(el('button', { class: 'btn btn-sky', text: 'Файл PNG', onclick: async () => {
    const r = await api.skins.importFile();
    if (r.ok) {
      await showSkin(r.path);
      if (store.selectedId) await api.skins.apply(r.path, store.selectedId);
      if (window.__cryndelRefresh) await window.__cryndelRefresh();
      toast('Скин сохранён');
    }
  } }));
  const nickSkin = el('input', { class: 'field', placeholder: 'Ник для скина' });
  skinRow.appendChild(nickSkin);
  skinRow.appendChild(el('button', { class: 'btn', text: 'По нику', onclick: async () => {
    try {
      const r = await api.skins.fromNick(nickSkin.value.trim() || (store.user && store.user.nick));
      await showSkin(r.path);
      if (store.selectedId) await api.skins.apply(r.path, store.selectedId);
      if (window.__cryndelRefresh) await window.__cryndelRefresh();
      toast('Скин скачан');
    } catch (e) { toast(e.message, 'bad'); }
  } }));
  skinBox.appendChild(skinRow);
  wrap.appendChild(skinBox);

  wrap.appendChild(el('button', { class: 'btn', style: 'margin-top:16px', text: 'О лаунчере', onclick: () => {
    location.hash = '#/about';
  } }));
  wrap.appendChild(el('button', { class: 'btn btn-danger', style: 'margin-top:8px', text: 'Сброс настроек', onclick: async () => {
    store.settings = await api.settings.reset();
    if (window.__cryndelApplyUi) window.__cryndelApplyUi();
    toast('Сброшено');
  } }));
  root.appendChild(wrap);
}
