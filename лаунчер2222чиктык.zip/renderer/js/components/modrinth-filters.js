import { el } from '../utils.js';

export function modrinthFilters(state, onChange) {
  const wrap = el('div', { class: 'filters' });
  const q = el('input', { class: 'field', placeholder: 'Поиск…', value: state.query || '' });
  q.addEventListener('change', () => onChange({ ...state, query: q.value }));
  wrap.appendChild(q);
  return wrap;
}
