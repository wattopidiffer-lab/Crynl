import { api } from './api.js';
import { store, bus, toast } from './state.js';
import { el } from './utils.js';
import { modal } from './ui.js';

const PHRASES = [
  'мяу', 'мррр', 'Крид', 'пиваа', 'мрр', 'рыыба', 'няяя', 'мяууу',
  'мрррр', 'гав? нет', 'ням', 'мур-мур', 'хррр', 'вау', 'кссс', 'уют', 'сон'
];

let host = null;
let unPin = null;
let unScale = null;

function loadPos(key, fallback) {
  try {
    const raw = localStorage.getItem('cryndel-w-' + key);
    if (raw) return JSON.parse(raw);
  } catch (_) { /* */ }
  return fallback;
}
function savePos(key, pos) {
  localStorage.setItem('cryndel-w-' + key, JSON.stringify(pos));
}

function drag(node, key) {
  let ox = 0, oy = 0, dragging = false;
  node.addEventListener('pointerdown', (e) => {
    if (e.target.closest('button') && !e.target.closest('.furry-w')) return;
    dragging = true;
    node.setPointerCapture(e.pointerId);
    const r = node.getBoundingClientRect();
    ox = e.clientX - r.left;
    oy = e.clientY - r.top;
  });
  node.addEventListener('pointermove', (e) => {
    if (!dragging) return;
    const x = Math.max(8, Math.min(innerWidth - 40, e.clientX - ox));
    const y = Math.max(8, Math.min(innerHeight - 40, e.clientY - oy));
    node.style.left = x + 'px';
    node.style.top = y + 'px';
    node.style.right = 'auto';
    node.style.bottom = 'auto';
  });
  node.addEventListener('pointerup', () => {
    if (!dragging) return;
    dragging = false;
    savePos(key, { left: node.style.left, top: node.style.top });
  });
}

function makeFurry() {
  const s = store.settings || {};
  if (s.ui && s.ui.furryWidget === false) return null;
  const w = el('div', { class: 'widget furry-w' });
  const pos = loadPos('furry', { left: '24px', top: '120px' });
  w.style.left = pos.left; w.style.top = pos.top;
  const img = el('img', { alt: 'furry' });
  const custom = s.ui && s.ui.furryImage;
  img.src = custom || 'data:image/svg+xml,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><circle cx="32" cy="36" r="18" fill="#f4b183"/><circle cx="22" cy="18" r="8" fill="#f4b183"/><circle cx="42" cy="18" r="8" fill="#f4b183"/><circle cx="26" cy="34" r="3" fill="#2a1a12"/><circle cx="38" cy="34" r="3" fill="#2a1a12"/><ellipse cx="32" cy="42" rx="4" ry="2" fill="#c97878"/></svg>');
  w.appendChild(img);
  const bubble = el('div', { class: 'furry-bubble hidden' });
  w.appendChild(bubble);
  let scale = Number((s.ui && s.ui.furryScale) || 1);
  w.style.transform = 'scale(' + scale + ')';
  img.addEventListener('click', async () => {
    w.classList.remove('bounce');
    void w.offsetWidth;
    w.classList.add('bounce');
    const phrase = PHRASES[Math.floor(Math.random() * PHRASES.length)];
    bubble.textContent = phrase;
    bubble.classList.remove('hidden');
    setTimeout(() => bubble.classList.add('hidden'), 1600);
    try {
      const r = await api.media.playFurry();
      if (r && r.url) {
        const a = new Audio(r.url);
        a.volume = 0.8;
        a.play().catch(() => {});
      }
    } catch (_) { /* */ }
  });
  drag(w, 'furry');
  return w;
}

function makeShots(pinned) {
  const s = store.settings || {};
  if (!pinned && s.ui && s.ui.shotsWidget === false) return null;
  const w = el('div', { class: 'widget shots-w' });
  const pos = loadPos('shots', { left: (innerWidth - 250) + 'px', top: '120px' });
  w.style.left = pos.left; w.style.top = pos.top;
  const img = el('img', { alt: 'shot' });
  const cap = el('div', { class: 'cap', text: 'Скриншоты' });
  w.appendChild(img);
  w.appendChild(cap);
  api.screenshots.list(6).then((items) => {
    if (!items || !items.length) { cap.textContent = 'Пока нет кадров'; return; }
    const last = items[0];
    cap.textContent = last.name || 'Кадр';
    api.screenshots.dataUrl(last.path).then((u) => { if (u) img.src = u; }).catch(() => {});
  }).catch(() => {});
  drag(w, 'shots');
  return w;
}

export function bootWidgets() {
  destroyWidgets();
  host = document.getElementById('widgetHost');
  if (!host) return;
  const fur = makeFurry();
  if (fur) host.appendChild(fur);
  const pin = localStorage.getItem('cryndel-shots-pin') === '1';
  const sh = makeShots(pin);
  if (sh) host.appendChild(sh);
  unPin = bus.on('pin-shots', () => {
    const next = localStorage.getItem('cryndel-shots-pin') !== '1';
    localStorage.setItem('cryndel-shots-pin', next ? '1' : '0');
    toast(next ? 'Скриншоты закреплены' : 'Скриншоты скрыты');
    bootWidgets();
  });
  unScale = bus.on('furry-scale', () => {
    const m = modal({ kicker: 'FURRY', title: 'Размер виджета' });
    const range = el('input', { class: 'field', type: 'range', min: '50', max: '180', value: String(Math.round(((store.settings.ui && store.settings.ui.furryScale) || 1) * 100)) });
    m.body.appendChild(range);
    range.addEventListener('input', async () => {
      const v = Number(range.value) / 100;
      await api.settings.set('ui.furryScale', v);
      store.settings.ui = store.settings.ui || {};
      store.settings.ui.furryScale = v;
      const node = host.querySelector('.furry-w');
      if (node) node.style.transform = 'scale(' + v + ')';
    });
  });
}

export function destroyWidgets() {
  if (unPin) { unPin(); unPin = null; }
  if (unScale) { unScale(); unScale = null; }
  const h = document.getElementById('widgetHost');
  if (h) h.replaceChildren();
}
