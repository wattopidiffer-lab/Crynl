const os = require('os');
const path = require('path');
const fs = require('fs-extra');

const dir = path.join(os.tmpdir(), 'cryndel-lock-test');
process.env.CRYNDEL_HOME = dir;

const LedgerKeeper = require('../../electron/managers/lockfile-manager');

describe('LedgerKeeper', () => {
  const keeper = new LedgerKeeper();

  beforeEach(async () => {
    await fs.remove(dir);
    await fs.ensureDir(path.join(dir, 'data', 'lockfiles'));
  });

  test('round-trip entry', async () => {
    await keeper.upsertEntry('i-1', {
      id: 'sodium',
      projectId: 'AANobbMI',
      filename: 'sodium.jar',
      sha512: 'abc'
    });
    const lock = await keeper.load('i-1');
    expect(lock.entries).toHaveLength(1);
    expect(lock.entries[0].id).toBe('sodium');
    await keeper.removeEntry('i-1', 'sodium');
    const after = await keeper.load('i-1');
    expect(after.entries).toHaveLength(0);
  });
});
