const { migrateUsers, migrateInstances, migrateSettings } = require('../../electron/storage/migrations');

describe('migrations', () => {
  test('users v1 to v2', () => {
    const next = migrateUsers({ version: 1, users: [{ nick: 'A' }] });
    expect(next.version).toBe(2);
    expect(next.users[0].stats).toBeTruthy();
  });

  test('instances array to doc', () => {
    const next = migrateInstances([{ id: 'i', name: 'x' }]);
    expect(next.version).toBe(2);
    expect(next.instances[0].quickPlay).toBeTruthy();
  });

  test('settings merge keeps unknown', () => {
    const next = migrateSettings({ ui: { language: 'en' } });
    expect(next.version).toBe(4);
    expect(next.ui.language).toBe('en');
    expect(next.modrinth.enabled).toBe(true);
  });

  test('legacy 80% browser zoom is reset to 100%', () => {
    const next = migrateSettings({ version: 3, browser: { zoom: 80 }, cabinet: { zoom: 80 } });
    expect(next.browser.zoom).toBe(100);
    expect(next.cabinet.zoom).toBe(100);
  });

  test('a deliberate zoom choice is preserved', () => {
    const next = migrateSettings({ version: 3, browser: { zoom: 125 } });
    expect(next.browser.zoom).toBe(125);
  });
});
