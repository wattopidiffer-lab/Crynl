const os = require('os');
const path = require('path');
const fs = require('fs-extra');

const dir = path.join(os.tmpdir(), 'cryndel-auth-test');
process.env.CRYNDEL_HOME = dir;

const ShadowPassKeeper = require('../../electron/managers/auth-manager');

describe('ShadowPassKeeper', () => {
  const auth = new ShadowPassKeeper();

  beforeEach(async () => {
    await fs.remove(dir);
    await fs.ensureDir(dir);
  });

  test('creates offline uuid', async () => {
    const u = await auth.createOffline('Steve_99');
    expect(u.nick).toBe('Steve_99');
    expect(u.offlineUuid).toMatch(/^[0-9a-f-]{36}$/);
    const cur = await auth.getCurrent();
    expect(cur.id).toBe(u.id);
  });

  test('rejects bad nick', async () => {
    await expect(auth.createOffline('ab')).rejects.toThrow();
  });

  test('accepts nick up to 20 chars', async () => {
    const u = await auth.createOffline('Twenty_Chars_Name_20');
    expect(u.nick.length).toBe(20);
  });

  test('rejects nick longer than 20', async () => {
    await expect(auth.createOffline('Twenty_Chars_Name_21x')).rejects.toThrow();
  });

  test('rejects invalid nick chars', async () => {
    await expect(auth.createOffline('bad-nick')).rejects.toThrow();
    await expect(auth.createOffline('ник')).rejects.toThrow();
  });
});
