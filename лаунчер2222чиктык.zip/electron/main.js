const { app, BrowserWindow } = require('electron');
const path = require('path');
const fs = require('fs-extra');
const logger = require('./utils/logger');
const CryndelPathVault = require('./utils/paths');
const vault = require('./storage/json-db');
const { runMigrations } = require('./storage/migrations');
const PaneSmith = require('./window-manager');
const DockNudge = require('./tray-manager');
const PulseRefresh = require('./auto-updater');
const wireAllIpc = require('./ipc/ipc-router');
const ModrinthHarbor = require('./managers/modrinth-client');
const LedgerKeeper = require('./managers/lockfile-manager');
const { StreamHauler } = require('./managers/download-manager');
const WeavePlanner = require('./managers/dependency-resolver');
const CrateShepherd = require('./managers/mod-manager');
const ShadowPassKeeper = require('./managers/auth-manager');
const ForgeCluster = require('./managers/instance-manager');
const EmberFinder = require('./managers/java-detector');
const EmberPilot = require('./managers/game-launcher');
const VaultSnapshot = require('./managers/backup-manager');
const FrameLedger = require('./managers/screenshot-manager');
const EchoAliasBridge = require('./managers/live-nick-bridge');
const PresenceBeacon = require('./managers/discord-rpc-manager');
const Hourglass = require('./managers/playtime-tracker');
const DialBoard = require('./managers/settings-manager');
const PulseClinic = require('./managers/health-manager');
const TraceRibbon = require('./managers/timeline-store');
const InboxBay = require('./managers/inbox-manager');
const SkinAtelier = require('./managers/skin-manager');
const ThemeWeaver = require('./managers/theme-manager');
const { pingHost, queryServer } = require('./managers/server-pulse');
const { suggestMemoryMb } = require('./managers/ram-advisor');

if (process.platform === 'win32') {
  app.commandLine.appendSwitch('--disable-gpu-sandbox');
}

class CryndelKernel {
  constructor() {
    this.panes = new PaneSmith();
    this.tray = new DockNudge();
    this.updater = new PulseRefresh();
    this.hub = null;
  }

  async boot() {
    await fs.ensureDir(CryndelPathVault.dataDir());
    await fs.ensureDir(CryndelPathVault.lockfilesDir());
    await fs.ensureDir(CryndelPathVault.backupsDir());
    await fs.ensureDir(CryndelPathVault.modCacheDir());
    await fs.ensureDir(path.dirname(CryndelPathVault.timelineFile('x')));
    // Any popup (target=_blank, window.open, "download in new tab") must stay
    // inside the launcher browser instead of spawning a bare Electron window.
    app.on('web-contents-created', (_e, contents) => {
      contents.setWindowOpenHandler(({ url }) => {
        if (/^https?:\/\//i.test(url) && this.hub && this.hub.window && !this.hub.window.isDestroyed()) {
          this.hub.window.webContents.send('browser:open', url);
        }
        return { action: 'deny' };
      });
    });
    await runMigrations(vault, {
      users: CryndelPathVault.usersFile(),
      instances: CryndelPathVault.instancesFile(),
      settings: CryndelPathVault.settingsFile()
    });

    const settings = new DialBoard();
    const auth = new ShadowPassKeeper();
    const modrinth = new ModrinthHarbor();
    const lockfile = new LedgerKeeper();
    const hauler = new StreamHauler();
    const mods = new CrateShepherd({ hauler, lockfile, modrinth });
    const resolver = new WeavePlanner(modrinth, mods);
    const timeline = new TraceRibbon();
    const instances = new ForgeCluster({ lockfile, modrinth, resolver, timeline });
    const java = new EmberFinder();
    const backups = new VaultSnapshot();
    const shots = new FrameLedger();
    const liveNick = new EchoAliasBridge();
    const discord = new PresenceBeacon();
    const playtime = new Hourglass();
    const health = new PulseClinic({ lockfile, mods, backups, timeline });
    const inbox = new InboxBay();
    const skins = new SkinAtelier();
    const themes = new ThemeWeaver();
    await inbox.ensure();
    await skins.ensure();
    await themes.ensure();

    const hub = {
      window: null,
      settings,
      auth,
      modrinth,
      lockfile,
      hauler,
      mods,
      resolver,
      inbox,
      skins,
      themes,
      pingHost,
      queryServer,
      suggestMemoryMb,
      timeline,
      instances,
      java,
      backups,
      shots,
      liveNick,
      discord,
      playtime,
      health,
      game: null
    };

    hub.game = new EmberPilot({
      java,
      settings,
      onEvent: (channel, payload) => {
        if (hub.window && !hub.window.isDestroyed()) {
          hub.window.webContents.send(channel, payload);
        }
        if (channel === 'game:close' || channel === 'game:crash') {
          const mins = playtime.end(payload.instanceId);
          auth.getCurrent().then((u) => {
            if (!u) return;
            const stats = u.stats || {};
            stats.playtime = (stats.playtime || 0) + mins;
            if (mins > (stats.longestSession || 0)) stats.longestSession = mins;
            return auth.patchCurrent({ stats });
          }).catch(() => {});
          timeline.append(payload.instanceId, channel === 'game:crash' ? 'crash' : 'launch',
            channel === 'game:crash' ? `Crash code ${payload.code}` : 'Launch finished').catch(() => {});
          discord.clear().catch(() => {});
          // The launcher hid itself when the game started — bring it back once the
          // session ends, otherwise the window never returns.
          if (this.panes) this.panes.show();
        }
      }
    });

    this.hub = hub;
    wireAllIpc(hub);

    const win = this.panes.create();
    hub.window = win;
    const { session } = require('electron');
    const onInboxSaved = (item) => {
      if (hub.window && !hub.window.isDestroyed()) {
        hub.window.webContents.send('inbox:saved', item);
      }
    };
    const onInboxProgress = (p) => {
      if (hub.window && !hub.window.isDestroyed()) {
        hub.window.webContents.send('inbox:progress', p);
        hub.window.webContents.send('game:progress', {
          stage: 'download',
          pct: p.pct || 0,
          loaded: p.loaded,
          total: p.total,
          message: p.filename ? `Скачиваю ${p.filename}` : 'Скачиваю файл'
        });
      }
    };
    inbox.attachSession(session.fromPartition('persist:cryndel'), onInboxSaved, onInboxProgress);
    inbox.attachSession(session.defaultSession, onInboxSaved, onInboxProgress);
    hauler.onProgress((p) => {
      if (hub.window && !hub.window.isDestroyed()) {
        hub.window.webContents.send('inbox:progress', p);
        hub.window.webContents.send('game:progress', {
          stage: 'download',
          pct: p.pct || 0,
          loaded: p.loaded,
          total: p.total,
          message: p.destPath ? require('path').basename(p.destPath) : 'Загрузка'
        });
      }
    });
    const allSettings = await settings.getAll();
    this.tray.attach(win);
    win.on('close', (e) => {
      const keep = this.hub && this.hub.game && this.hub.game.anyRunning();
      if (keep && this.hub.window) {
        e.preventDefault();
        this.hub.window.hide();
      }
    });
    if (!allSettings.launcher || allSettings.launcher.discordRpc !== false) {
      await discord.connect();
    }
    const liveCfg = (allSettings.advanced && allSettings.advanced.liveNick) || { enabled: true, wsPort: 21999 };
    if (liveCfg.enabled !== false) {
      await liveNick.start(liveCfg.wsPort || 21999);
      liveNick.on('status', (s) => {
        if (hub.window && !hub.window.isDestroyed()) {
          hub.window.webContents.send('liveNick:statusChange', s);
        }
      });
    }
    this.updater.setup();
    logger.info('Cryndel kernel ready');
  }
}

const kernel = new CryndelKernel();

app.whenReady().then(() => kernel.boot()).catch((err) => {
  logger.error('boot failed', { message: err.message, stack: err.stack });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0 && kernel.hub) {
    kernel.hub.window = kernel.panes.create();
  }
});
