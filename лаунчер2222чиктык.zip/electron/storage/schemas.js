const DEFAULT_SETTINGS = {
  version: 3,
  ui: {
    language: 'ru',
    theme: 'dark',
    animations: true,
    backgroundVideo: true,
    backgroundKind: 'video',
    backgroundFile: '',
    reducedMotion: false,
    navPos: 'left',
    accent: '',
    radius: 16,
    homeFont: 'default',
    bgLoop: true,
    bgDim: 0.55,
    bgVeil: 1,
    alwaysSplash: false,
    showSkin3d: false,
    particles: false,
    furryWidget: true,
    furryScale: 1,
    furryImage: '',
    furrySounds: [],
    splashFile: '',
    shotsWidget: true,
    hideCarousel: false,
    splash: true
  },
  game: {
    defaultMemoryMb: 4096,
    memoryMode: 'auto',
    defaultGameDir: '',
    javaPath: 'auto',
    javaCommand: '',
    jvmPreset: 'cryndel-recommended',
    customJvmArgs: '',
    envVars: '',
    defaultResolution: { width: 1280, height: 720 },
    defaultFullscreen: false,
    language: 'ru',
    toggleSprint: true,
    rawMouseInput: true,
    vsync: true,
    maxFps: 0,
    gpu: 'auto',
    graphics: 'default'
  },
  launcher: {
    closeOnLaunch: false,
    minimizeToTray: true,
    discordRpc: true,
    showConsoleOnLaunch: false,
    hideOnLaunch: false,
    confirmExit: true
  },
  versions: {
    showReleases: true,
    showSnapshots: false,
    showBetas: false,
    showOld: false
  },
  modrinth: {
    enabled: true,
    autoCheckUpdates: true,
    checkIntervalHours: 24,
    autoInstallDependencies: true,
    listLimit: 20,
    fullscreen: true,
    svgOnly: true
  },
  browser: {
    zoom: 100
  },
  cabinet: {
    zoom: 100,
    keepAlive: true
  },
  advanced: {
    apiUrl: 'https://api.cryndel.ru',
    devMode: false,
    verboseLogging: false,
    liveNick: { enabled: true, wsPort: 21999 }
  },
  extras: {
    customCss: true,
    splash: true
  }
};

const DEFAULT_USERS = {
  version: 2,
  currentUserId: null,
  users: []
};

const DEFAULT_INSTANCES = {
  version: 2,
  instances: []
};

function emptyLock(instanceId, extra) {
  return {
    version: 1,
    instanceId,
    mcVersion: extra && extra.mcVersion ? extra.mcVersion : '1.21.11',
    loader: extra && extra.loader ? extra.loader : 'fabric',
    loaderVersion: extra && extra.loaderVersion ? extra.loaderVersion : '',
    updatedAt: new Date().toISOString(),
    entries: []
  };
}

module.exports = {
  DEFAULT_SETTINGS,
  DEFAULT_USERS,
  DEFAULT_INSTANCES,
  emptyLock
};
