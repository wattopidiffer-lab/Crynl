const { spawn } = require('child_process');
const path = require('path');
const os = require('os');
const fs = require('fs-extra');
const axios = require('axios');
const crypto = require('crypto');
const AdmZip = require('adm-zip');
const CryndelPathVault = require('../utils/paths');
const logger = require('../utils/logger');
const { CryndelFault, FaultCodes } = require('../utils/errors');
const LoomBinder = require('./loader-installer');

const MANIFEST = 'https://piston-meta.mojang.com/mc/game/version_manifest_v2.json';
const UA = { 'User-Agent': 'CryndelLauncher/1.0.0 (contact@cryndel.ru)' };

class EmberPilot {
  constructor({ java, settings, onEvent }) {
    this.java = java;
    this.settings = settings;
    this.onEvent = onEvent || (() => {});
    this.running = new Map();
    this.loom = new LoomBinder();
    this.manifestCache = null;
    this.abort = null;
    this.preparing = false;
  }

  anyRunning() {
    for (const p of this.running.values()) {
      if (p && !p.killed) return true;
    }
    return this.preparing;
  }

  isCancelled() {
    return Boolean(this.abort && this.abort.aborted);
  }

  beginJob() {
    this.abort = { aborted: false };
    this.preparing = true;
    return this.abort;
  }

  cancelJob() {
    if (this.abort) this.abort.aborted = true;
    this.preparing = false;
    return { ok: true };
  }

  send(channel, payload) {
    try { this.onEvent(channel, payload); } catch (_) { /* ui */ }
  }

  isRunning(instanceId) {
    if (!instanceId) return this.anyRunning();
    const p = this.running.get(instanceId);
    return Boolean(p && !p.killed) || this.preparing;
  }

  async kill(instanceId) {
    const p = this.running.get(instanceId);
    if (p && !p.killed) {
      p.kill('SIGTERM');
      setTimeout(() => {
        try { if (!p.killed) p.kill('SIGKILL'); } catch (_) { /* */ }
      }, 4000);
    }
    this.running.delete(instanceId);
    return { ok: true };
  }

  async getManifest() {
    if (this.manifestCache) return this.manifestCache;
    const { data } = await axios.get(MANIFEST, { timeout: 20000, headers: UA });
    this.manifestCache = data;
    return data;
  }

  fmtBytes(n) {
    const x = Number(n) || 0;
    if (x >= 1073741824) return `${(x / 1073741824).toFixed(1)} ГБ`;
    if (x >= 1048576) return `${(x / 1048576).toFixed(1)} МБ`;
    if (x >= 1024) return `${Math.round(x / 1024)} КБ`;
    return `${x} Б`;
  }

  async downloadFile(url, dest, sha1, onProgress, label) {
    if (this.isCancelled()) throw new Error('Загрузка отменена');
    await fs.ensureDir(path.dirname(dest));
    const res = await axios.get(url, {
      responseType: 'stream',
      timeout: 180000,
      headers: UA,
      maxRedirects: 8
    });
    const total = Number(res.headers['content-length'] || 0);
    let loaded = 0;
    const hash = crypto.createHash('sha1');
    const chunks = [];
    await new Promise((resolve, reject) => {
      let settled = false;
      const fail = (err) => {
        if (settled) return;
        settled = true;
        try { res.data.destroy(); } catch (_) { /* */ }
        reject(err);
      };
      const ok = () => {
        if (settled) return;
        settled = true;
        resolve();
      };
      res.data.on('data', (chunk) => {
        if (this.isCancelled()) {
          fail(new Error('Загрузка отменена'));
          return;
        }
        loaded += chunk.length;
        hash.update(chunk);
        chunks.push(chunk);
        if (onProgress) {
          onProgress({
            stage: 'download',
            pct: total ? Math.min(99, Math.round((loaded / total) * 100)) : 30,
            loaded,
            total,
            message: `${label || path.basename(dest)} · ${this.fmtBytes(loaded)}${total ? ' / ' + this.fmtBytes(total) : ''}`
          });
        }
      });
      res.data.on('error', fail);
      res.data.on('end', ok);
    });
    const buf = Buffer.concat(chunks);
    if (sha1) {
      const got = hash.digest('hex');
      if (got !== sha1) throw new Error(`sha1 mismatch for ${path.basename(dest)}`);
    }
    await fs.writeFile(dest, buf);
    return buf.length;
  }

  libraryPath(lib) {
    if (lib.downloads && lib.downloads.artifact && lib.downloads.artifact.path) {
      return path.join(CryndelPathVault.librariesDir(), lib.downloads.artifact.path);
    }
    const parts = String(lib.name || '').split(':');
    if (parts.length < 3) return null;
    const [g, a, v, n] = parts;
    const file = n ? `${a}-${v}-${n}.jar` : `${a}-${v}.jar`;
    return path.join(CryndelPathVault.librariesDir(), ...g.split('.'), a, v, file);
  }

  mavenUrl(lib) {
    if (lib.downloads && lib.downloads.artifact && lib.downloads.artifact.url) return lib.downloads.artifact.url;
    const base = (lib.url) || 'https://libraries.minecraft.net/';
    const rel = this.libraryPath(lib);
    if (!rel) return null;
    const relPosix = rel.slice(CryndelPathVault.librariesDir().length).replace(/\\/g, '/').replace(/^\//, '');
    return base.replace(/\/?$/, '/') + relPosix;
  }

  osName() {
    const plat = os.platform();
    return plat === 'win32' ? 'windows' : plat === 'darwin' ? 'osx' : 'linux';
  }

  osMatches(osRule) {
    if (osRule.name && osRule.name !== this.osName()) return false;
    if (osRule.arch) {
      const a = os.arch() === 'x64' ? 'x86' : os.arch();
      if (osRule.arch !== os.arch() && osRule.arch !== a) return false;
    }
    return true;
  }

  rulesAllow(rules) {
    if (!rules || !rules.length) return true;
    let allow = rules[0].action !== 'allow';
    for (const rule of rules) {
      const osOk = !rule.os || this.osMatches(rule.os);
      if (rule.features) {
        if (rule.action === 'allow') continue;
      }
      if (rule.action === 'allow' && osOk) allow = true;
      if (rule.action === 'disallow' && osOk) allow = false;
    }
    return allow;
  }

  mergeProfiles(parent, child) {
    const out = { ...parent, ...child };
    out.libraries = [...(child.libraries || []), ...(parent.libraries || [])];
    if (parent.arguments || child.arguments) {
      out.arguments = {
        jvm: [...((parent.arguments && parent.arguments.jvm) || []), ...((child.arguments && child.arguments.jvm) || [])],
        game: [...((parent.arguments && parent.arguments.game) || []), ...((child.arguments && child.arguments.game) || [])]
      };
    }
    out.mainClass = child.mainClass || parent.mainClass;
    out.id = child.id || parent.id;
    out.inheritsFrom = undefined;
    return out;
  }

  async loadVersionJson(id) {
    const vDir = path.join(CryndelPathVault.versionsDir(), id);
    const jsonPath = path.join(vDir, `${id}.json`);
    if (await fs.pathExists(jsonPath)) return fs.readJson(jsonPath);
    const manifest = await this.getManifest();
    const info = (manifest.versions || []).find((v) => v.id === id);
    if (!info) throw new CryndelFault(FaultCodes.LAUNCH, `Unknown version ${id}`);
    const { data } = await axios.get(info.url, { timeout: 30000, headers: UA });
    await fs.ensureDir(vDir);
    await fs.writeJson(jsonPath, data);
    return data;
  }

  async resolveProfile(id) {
    let json = await this.loadVersionJson(id);
    const chain = [json];
    let guard = 0;
    while (json.inheritsFrom && guard < 6) {
      json = await this.loadVersionJson(json.inheritsFrom);
      chain.push(json);
      guard += 1;
    }
    let merged = chain[chain.length - 1];
    for (let i = chain.length - 2; i >= 0; i -= 1) merged = this.mergeProfiles(merged, chain[i]);
    return merged;
  }

  async ensureVanilla(mcVersion, onProgress) {
    const json = await this.loadVersionJson(mcVersion);
    const vDir = path.join(CryndelPathVault.versionsDir(), mcVersion);
    const jarPath = path.join(vDir, `${mcVersion}.jar`);
    if (json.downloads && json.downloads.client && !(await fs.pathExists(jarPath))) {
      if (onProgress) onProgress({ stage: 'client', pct: 12, message: 'Скачиваю клиент Minecraft…' });
      await this.downloadFile(json.downloads.client.url, jarPath, json.downloads.client.sha1, onProgress, `Клиент ${mcVersion}`);
    }
    return { json, jarPath };
  }

  async ensureLibraries(versionJson, onProgress) {
    const libs = versionJson.libraries || [];
    let i = 0;
    for (const lib of libs) {
      i += 1;
      if (!this.rulesAllow(lib.rules)) continue;
      const dest = this.libraryPath(lib);
      if (!dest) continue;
      if (!(await fs.pathExists(dest))) {
        const url = this.mavenUrl(lib);
        if (!url) continue;
        try {
          await this.downloadFile(url, dest, lib.downloads && lib.downloads.artifact && lib.downloads.artifact.sha1, onProgress, lib.name);
        } catch (err) {
          logger.warn('lib download failed', { name: lib.name, message: err.message });
        }
      }
      if (onProgress && i % 8 === 0) {
        onProgress({ stage: 'libraries', pct: 20 + Math.round((i / libs.length) * 30), message: 'Библиотеки…' });
      }
      await this.extractNatives(lib, versionJson.id);
    }
  }

  nativesDir(versionId) {
    return path.join(CryndelPathVault.versionsDir(), versionId, 'natives');
  }

  async extractNatives(lib, versionId) {
    const natives = lib.natives;
    if (!natives) return;
    const key = natives[this.osName()] || natives[os.platform()];
    if (!key) return;
    const classifier = String(key).replace('${arch}', os.arch() === 'x64' ? '64' : '32');
    const artifact = lib.downloads && lib.downloads.classifiers && lib.downloads.classifiers[classifier];
    if (!artifact || !artifact.url) return;
    const dest = path.join(CryndelPathVault.librariesDir(), artifact.path || `${lib.name}-${classifier}.jar`);
    if (!(await fs.pathExists(dest))) {
      try { await this.downloadFile(artifact.url, dest, artifact.sha1); } catch (_) { return; }
    }
    const outDir = this.nativesDir(versionId);
    await fs.ensureDir(outDir);
    try {
      const zip = new AdmZip(dest);
      zip.extractAllTo(outDir, true);
    } catch (_) { /* */ }
  }

  async ensureAssets(versionJson, onProgress) {
    if (!versionJson.assetIndex) return;
    const idxDir = path.join(CryndelPathVault.assetsDir(), 'indexes');
    await fs.ensureDir(idxDir);
    const idxFile = path.join(idxDir, `${versionJson.assetIndex.id}.json`);
    if (!(await fs.pathExists(idxFile))) {
      await this.downloadFile(versionJson.assetIndex.url, idxFile, versionJson.assetIndex.sha1, onProgress, 'Индекс ресурсов');
    }
    const index = await fs.readJson(idxFile);
    const objects = index.objects || {};
    const keys = Object.keys(objects);
    let i = 0;
    for (const key of keys) {
      const obj = objects[key];
      const hash = obj.hash;
      const dest = path.join(CryndelPathVault.assetsDir(), 'objects', hash.slice(0, 2), hash);
      i += 1;
      if (await fs.pathExists(dest)) continue;
      const url = `https://resources.download.minecraft.net/${hash.slice(0, 2)}/${hash}`;
      try { await this.downloadFile(url, dest, hash, null, key); } catch (_) { /* */ }
      if (onProgress && i % 80 === 0) {
        onProgress({ stage: 'assets', pct: 55 + Math.round((i / keys.length) * 30), message: `Ресурсы ${i}/${keys.length}` });
      }
    }
  }

  buildClasspath(versionJson, jarPath) {
    const bits = [];
    const seen = new Set();
    for (const lib of versionJson.libraries || []) {
      if (!this.rulesAllow(lib.rules)) continue;
      if (lib.natives) continue;
      const p = this.libraryPath(lib);
      if (p && !seen.has(p)) {
        seen.add(p);
        bits.push(p);
      }
    }
    bits.push(jarPath);
    return bits.join(os.platform() === 'win32' ? ';' : ':');
  }

  subst(str, map) {
    return String(str).replace(/\$\{([^}]+)\}/g, (_, k) => (map[k] !== undefined ? map[k] : `\${${k}}`));
  }

  collectArgs(list, map) {
    const out = [];
    if (!list) return out;
    for (const item of list) {
      if (typeof item === 'string') out.push(this.subst(item, map));
      else if (item && item.rules) {
        if (!this.rulesAllow(item.rules)) continue;
        const val = item.value;
        if (Array.isArray(val)) val.forEach((v) => out.push(this.subst(v, map)));
        else if (typeof val === 'string') out.push(this.subst(val, map));
      }
    }
    return out.filter((a) => {
      if (os.platform() === 'win32' && (String(a).includes('-XstartOnFirstThread') || String(a).includes('-Xdock:'))) return false;
      return true;
    });
  }

  async ensureVersion(mcVersion, onProgress) {
    return this.ensureVanilla(mcVersion, onProgress);
  }

  async prepareInstance(instance, onProgress) {
    const mc = instance.mcVersion || '1.21.11';
    const loader = (instance.modLoader || 'vanilla').toLowerCase();
    let launchId = mc;
    if (loader === 'fabric') {
      const r = await this.loom.ensureFabric(mc, instance.modLoaderVersion, onProgress);
      launchId = r.id;
      instance.modLoaderVersion = r.loaderVersion;
    } else if (loader === 'quilt') {
      const r = await this.loom.ensureQuilt(mc, instance.modLoaderVersion, onProgress);
      launchId = r.id;
      instance.modLoaderVersion = r.loaderVersion;
    } else if (loader === 'forge' || loader === 'neoforge') {
      const r = await this.loom.ensureForgeFamily(loader, mc, instance.modLoaderVersion, onProgress);
      instance.modLoaderVersion = r.loaderVersion || instance.modLoaderVersion;
      if (onProgress) {
        onProgress({
          stage: 'loader',
          pct: 18,
          message: `${loader}: клиент ${mc}${r.loaderVersion ? ', ядро ' + r.loaderVersion : ''}. Моды из папки mods.`
        });
      }
    }
    await this.ensureVanilla(mc, onProgress);
    const versionJson = await this.resolveProfile(launchId);
    const jarPath = path.join(CryndelPathVault.versionsDir(), mc, `${mc}.jar`);
    await this.ensureLibraries(versionJson, onProgress);
    await this.ensureAssets(versionJson, onProgress);
    return { versionJson, jarPath, launchId };
  }

  async resolveJava(instance, extra, onProgress) {
    const all = await this.settings.getAll().catch(() => ({}));
    const customCmd = (extra.javaCommand || (instance && instance.javaCommand) || (all.game && all.game.javaCommand) || '').trim();
    if (customCmd) return customCmd;
    const customPath = (extra.javaPath || (instance && instance.javaPath) || (all.game && all.game.javaPath) || '').trim();
    if (customPath && customPath !== 'auto' && await fs.pathExists(customPath)) return customPath;
    const needJava = this.java.majorFromInstance(instance);
    return this.java.ensure(needJava, onProgress);
  }

  async launch(instance, user, extra = {}) {
    if (this.running.get(instance.id) && !this.running.get(instance.id).killed) {
      throw new CryndelFault(FaultCodes.LAUNCH, 'Сборка уже запущена');
    }
    this.beginJob();
    const needJava = this.java.majorFromInstance(instance);
    this.send('game:progress', { instanceId: instance.id, stage: 'java', pct: 3, message: 'Проверяю Java…' });
    let javaPath;
    try {
      javaPath = await this.resolveJava(instance, extra, (p) => this.send('game:progress', { instanceId: instance.id, ...p }));
    } catch (err) {
      this.preparing = false;
      throw err;
    }

    this.send('game:progress', { instanceId: instance.id, stage: 'prepare', pct: 8, message: 'Готовлю игру…' });
    const { versionJson, jarPath, launchId } = await this.prepareInstance(instance, (p) => {
      this.send('game:progress', { instanceId: instance.id, ...p });
    });

    const gameDir = instance.gameDir;
    await fs.ensureDir(gameDir);
    await fs.ensureDir(path.join(gameDir, 'mods'));
    if (this.isCancelled()) {
      this.preparing = false;
      throw new Error('Загрузка отменена');
    }
    extra.instance = instance;
    extra.guiScale = extra.guiScale || instance.guiScale;
    extra.toggleSprint = extra.toggleSprint !== undefined ? extra.toggleSprint : instance.toggleKeys;
    extra.graphics = extra.graphics || (await this.settings.get('game.graphics').catch(() => 'default'));
    extra.gpu = extra.gpu || (await this.settings.get('game.gpu').catch(() => 'auto'));
    await this.writeGameOptions(gameDir, extra);
    await this.applySkin(gameDir, extra.skinPath || (user.skin && user.skin.path));
    const nativesDir = this.nativesDir(launchId);
    await fs.ensureDir(nativesDir);
    const cp = this.buildClasspath(versionJson, jarPath);
    const assetsRoot = CryndelPathVault.assetsDir();
    const map = {
      auth_player_name: user.nick,
      version_name: launchId,
      game_directory: gameDir,
      assets_root: assetsRoot,
      assets_index_name: versionJson.assetIndex ? versionJson.assetIndex.id : 'legacy',
      auth_uuid: user.offlineUuid,
      auth_access_token: '0',
      clientid: 'cryndel',
      auth_xuid: '0',
      user_type: 'legacy',
      version_type: versionJson.type || 'release',
      natives_directory: nativesDir,
      launcher_name: 'CryndelLauncher',
      launcher_version: '1.0.0',
      classpath: cp,
      library_directory: CryndelPathVault.librariesDir(),
      classpath_separator: os.platform() === 'win32' ? ';' : ':'
    };
    const mem = await this.resolveMemory(instance);
    const jvm = [
      `-Xmx${mem}M`,
      `-Xms${Math.min(1024, Math.max(512, Math.floor(mem / 4)))}M`,
      `-Djava.library.path=${nativesDir}`,
      '-Dminecraft.launcher.brand=CryndelLauncher',
      '-Dminecraft.launcher.version=1.0.0'
    ];
    if (Array.isArray(instance.jvmArgs)) jvm.push(...instance.jvmArgs);
    if (versionJson.arguments && versionJson.arguments.jvm) {
      jvm.push(...this.collectArgs(versionJson.arguments.jvm, map));
    } else if (versionJson.minecraftArguments) {
      /* legacy */
    }
    const seenJvm = new Set();
    const jvmUnique = jvm.filter((a) => {
      if (seenJvm.has(a)) return false;
      seenJvm.add(a);
      return true;
    });

    const gameArgs = [];
    if (versionJson.arguments && versionJson.arguments.game) {
      gameArgs.push(...this.collectArgs(versionJson.arguments.game, map));
    } else if (versionJson.minecraftArguments) {
      gameArgs.push(...this.subst(versionJson.minecraftArguments, map).split(' '));
    } else {
      gameArgs.push(
        '--username', user.nick,
        '--version', launchId,
        '--gameDir', gameDir,
        '--assetsDir', assetsRoot,
        '--assetIndex', map.assets_index_name,
        '--uuid', user.offlineUuid,
        '--accessToken', '0',
        '--userType', 'legacy',
        '--versionType', versionJson.type || 'release'
      );
    }
    if (instance.quickPlay && instance.quickPlay.enabled) {
      const host = instance.quickPlay.server || 'cryndel.ru';
      const port = String(instance.quickPlay.port || 25565);
      // 1.20+ understands the quickPlay syntax; older builds still read --server.
      gameArgs.push('--quickPlayMultiplayer', `${host}:${port}`);
      gameArgs.push('--server', host);
      gameArgs.push('--port', port);
    }
    if (instance.fullscreen) gameArgs.push('--fullscreen');
    if (instance.resolution) {
      gameArgs.push('--width', String(instance.resolution.width || 1280));
      gameArgs.push('--height', String(instance.resolution.height || 720));
    }
    if (Array.isArray(instance.extraGameArgs)) gameArgs.push(...instance.extraGameArgs);

    const extraJvm = String((await this.settings.get('game.customJvmArgs')) || '').trim();
    if (extraJvm) {
      extraJvm.split(/\s+/).filter(Boolean).forEach((a) => {
        if (!seenJvm.has(a)) { seenJvm.add(a); jvmUnique.push(a); }
      });
    }
    const gpuPick = extra.gpu && extra.gpu !== 'auto' ? extra.gpu : '';
    if (gpuPick && os.platform() === 'win32') {
      const gpuArg = `-Dsun.java2d.d3d=true`;
      if (!seenJvm.has(gpuArg)) { seenJvm.add(gpuArg); jvmUnique.push(gpuArg); }
    }
    const args = [...jvmUnique, versionJson.mainClass, ...gameArgs];
    if (this.isCancelled()) {
      this.preparing = false;
      throw new Error('Загрузка отменена');
    }
    this.preparing = false;
    this.send('game:progress', { instanceId: instance.id, stage: 'launch', pct: 100, message: 'Запускаю Minecraft…' });
    logger.info('spawning minecraft', { instanceId: instance.id, javaPath, mainClass: versionJson.mainClass });

    const env = { ...process.env, _CRYNDEL: '1' };
    if (gpuPick) env.CRYNDEL_GPU = gpuPick;
    const child = spawn(javaPath, args, {
      cwd: gameDir,
      env,
      stdio: ['ignore', 'pipe', 'pipe']
    });
    this.running.set(instance.id, child);
    child.stdout.on('data', (buf) => this.send('game:log', { instanceId: instance.id, stream: 'out', line: buf.toString() }));
    child.stderr.on('data', (buf) => this.send('game:log', { instanceId: instance.id, stream: 'err', line: buf.toString() }));
    child.on('close', (code) => {
      this.running.delete(instance.id);
      const crashed = code !== 0 && code !== null;
      this.send(crashed ? 'game:crash' : 'game:close', { instanceId: instance.id, code, at: new Date().toISOString() });
    });
    child.on('error', (err) => {
      this.running.delete(instance.id);
      this.send('game:crash', { instanceId: instance.id, error: err.message });
    });
    extra.onSpawn && extra.onSpawn(child);
    return { ok: true, pid: child.pid, launchId };
  }

  async resolveMemory(instance) {
    if (instance.memoryMb && instance.memoryMode !== 'auto') return Number(instance.memoryMb) || 4096;
    try {
      const all = await this.settings.getAll();
      if (all.game && all.game.memoryMode === 'manual' && all.game.defaultMemoryMb) {
        return Number(all.game.defaultMemoryMb);
      }
      const { suggestMemoryMb } = require('./ram-advisor');
      return suggestMemoryMb().recommendedMb;
    } catch (_) {
      return instance.memoryMb || 4096;
    }
  }

  patchOption(text, key, value) {
    const line = `${key}:${value}`;
    if (new RegExp(`^${key}:`, 'm').test(text)) return text.replace(new RegExp(`^${key}:.*$`, 'm'), line);
    return `${text}${text && !text.endsWith('\n') ? '\n' : ''}${line}\n`;
  }

  async writeGameOptions(gameDir, extra = {}) {
    const all = await this.settings.getAll().catch(() => ({}));
    const inst = extra.instance || {};
    const autoLang = extra.autoLang !== undefined ? extra.autoLang : inst.autoLang;
    const lang = extra.language || (all.ui && all.ui.language) || 'ru';
    const code = lang === 'en' ? 'en_us' : 'ru_ru';
    const file = path.join(gameDir, 'options.txt');
    let text = '';
    try {
      if (await fs.pathExists(file)) text = await fs.readFile(file, 'utf8');
    } catch (_) { text = ''; }
    if (autoLang !== false) text = this.patchOption(text, 'lang', code);
    const toggle = extra.toggleSprint !== undefined
      ? extra.toggleSprint
      : (inst.toggleKeys !== undefined ? inst.toggleKeys : (all.game && all.game.toggleSprint));
    if (toggle) {
      text = this.patchOption(text, 'key_key.sprint', 'key.keyboard.left.shift');
      text = this.patchOption(text, 'toggleSprint', 'true');
      text = this.patchOption(text, 'toggleSneak', 'true');
    }
    if (extra.guiScale) {
      text = this.patchOption(text, 'guiScale', String(extra.guiScale));
    }
    const gfx = extra.graphics || (all.game && all.game.graphics);
    if (gfx && gfx !== 'default') {
      const map = { fabulous: 'fabulous', fancy: 'fancy', fast: 'fast' };
      text = this.patchOption(text, 'graphicsMode', map[gfx] || gfx);
    }
    await fs.writeFile(file, text, 'utf8');
    try {
      if (inst && inst.addServer !== false) {
        await this.writeServersDat(gameDir, inst);
      }
    } catch (_) { /* */ }
  }

  async writeServersDat(gameDir, inst) {
    const { buildServersDat } = require('../utils/nbt');
    const qp = inst.quickPlay || {};
    const host = qp.server || 'cryndel.ru';
    const port = Number(qp.port || 25565);
    const ip = port === 25565 ? host : `${host}:${port}`;
    const file = path.join(gameDir, 'servers.dat');
    // Read any existing list (best effort) so the player's own servers survive.
    let servers = [{ name: 'Cryndel.ru', ip }];
    if (await fs.pathExists(file)) {
      try {
        const { readServersDat } = require('../utils/nbt');
        const existing = readServersDat(await fs.readFile(file));
        const merged = existing.filter((s) => s.ip !== ip);
        servers = [servers[0], ...merged];
      } catch (_) { /* ignore corrupt file */ }
    }
    await fs.writeFile(file, buildServersDat(servers));
    // Keep the human-readable list as well, some builds surface it in-game.
    await fs.writeFile(path.join(gameDir, 'cryndel-servers.txt'), ip + '\n', 'utf8');
  }

  async writeGameLang(gameDir, lang) {
    return this.writeGameOptions(gameDir, { language: lang });
  }

  async applySkin(gameDir, skinPath) {
    if (!skinPath) return;
    try {
      if (!(await fs.pathExists(skinPath))) return;
      const destDir = path.join(gameDir, 'cryndel-skins');
      await fs.ensureDir(destDir);
      await fs.copy(skinPath, path.join(destDir, 'current.png'), { overwrite: true });
      const mcSkin = path.join(gameDir, 'skin.png');
      await fs.copy(skinPath, mcSkin, { overwrite: true });
    } catch (_) { /* optional */ }
  }
}

module.exports = EmberPilot;
