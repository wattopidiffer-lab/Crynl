const fs = require('fs-extra');
const path = require('path');
const CryndelPathVault = require('../utils/paths');
const { sanitizeName } = require('./download-manager');

class ThemeWeaver {
  dir() {
    return path.join(CryndelPathVault.dataDir(), 'themes');
  }

  customFile() {
    return path.join(this.dir(), 'custom.css');
  }

  async ensure() {
    await fs.ensureDir(this.dir());
  }

  async importCss(src) {
    await this.ensure();
    const buf = await fs.readFile(src, 'utf8');
    if (buf.length > 400000) throw new Error('CSS слишком большой');
    const dest = this.customFile();
    await fs.writeFile(dest, buf, 'utf8');
    return dest;
  }

  async readCustom() {
    const dest = this.customFile();
    if (!(await fs.pathExists(dest))) return '';
    return fs.readFile(dest, 'utf8');
  }

  async writeCustom(css) {
    await this.ensure();
    const text = String(css == null ? '' : css);
    if (text.length > 400000) throw new Error('CSS слишком большой');
    await fs.writeFile(this.customFile(), text, 'utf8');
    return { ok: true, length: text.length };
  }

  async clear() {
    const dest = this.customFile();
    if (await fs.pathExists(dest)) await fs.writeFile(dest, '', 'utf8');
    return { ok: true };
  }

  async list() {
    await this.ensure();
    const names = await fs.readdir(this.dir());
    return names.filter((n) => n.endsWith('.css')).map((n) => ({
      name: sanitizeName(n),
      path: path.join(this.dir(), n)
    }));
  }
}

module.exports = ThemeWeaver;
