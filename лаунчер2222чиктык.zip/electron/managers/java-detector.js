const fs = require('fs-extra');
const path = require('path');
const os = require('os');
const { execFile } = require('child_process');
const { promisify } = require('util');
const execFileAsync = promisify(execFile);
const axios = require('axios');
const AdmZip = require('adm-zip');
const logger = require('../utils/logger');
const CryndelPathVault = require('../utils/paths');

class EmberFinder {
  majorFromInstance(instance) {
    const mc = instance && instance.mcVersion ? instance.mcVersion : '1.21.11';
    const [a, b] = mc.split('.').map((n) => parseInt(n, 10));
    if (a === 1 && b >= 21) return 21;
    if (a === 1 && b >= 18) return 17;
    return 8;
  }

  exeFromHome(home) {
    if (os.platform() === 'win32') return path.join(home, 'bin', 'java.exe');
    return path.join(home, 'bin', 'java');
  }

  async readVersion(javaPath) {
    try {
      const { stderr, stdout } = await execFileAsync(javaPath, ['-version']);
      const text = `${stderr}\n${stdout}`;
      const m = text.match(/version "([^"]+)"/);
      return m ? m[1] : null;
    } catch (err) {
      logger.debug('java version failed', { javaPath, message: err.message });
      return null;
    }
  }

  parseMajor(ver) {
    if (!ver) return 0;
    const m = String(ver).match(/^1\.(\d+)/) || String(ver).match(/^(\d+)/);
    return m ? Number(m[1]) : 0;
  }

  async walkJava(root) {
    const name = os.platform() === 'win32' ? 'java.exe' : 'java';
    const stack = [root];
    while (stack.length) {
      const dir = stack.pop();
      let kids = [];
      try { kids = await fs.readdir(dir); } catch (_) { continue; }
      for (const k of kids) {
        const full = path.join(dir, k);
        let st;
        try { st = await fs.stat(full); } catch (_) { continue; }
        if (st.isDirectory()) stack.push(full);
        else if (k === name) return full;
      }
    }
    return null;
  }

  async detect() {
    const found = [];
    const seen = new Set();
    const push = (p, source) => {
      if (!p || seen.has(p)) return;
      seen.add(p);
      found.push({ path: p, source });
    };

    const bundled = await this.walkJava(CryndelPathVault.javaDir());
    if (bundled) push(bundled, 'cryndel-runtime');

    if (process.env.JAVA_HOME) push(this.exeFromHome(process.env.JAVA_HOME), 'JAVA_HOME');
    const which = os.platform() === 'win32' ? 'where' : 'which';
    try {
      const { stdout } = await execFileAsync(which, ['java']);
      stdout.split(/\r?\n/).map((s) => s.trim()).filter(Boolean).forEach((p) => push(p, 'path'));
    } catch (_) { /* none */ }

    const extra = os.platform() === 'win32'
      ? ['C:\\Program Files\\Java', 'C:\\Program Files\\Eclipse Adoptium', 'C:\\Program Files\\Microsoft', 'C:\\Program Files\\Zulu']
      : ['/usr/lib/jvm', '/usr/lib64/jvm', '/opt/java'];
    for (const root of extra) {
      if (!(await fs.pathExists(root))) continue;
      try {
        const kids = await fs.readdir(root);
        for (const k of kids) push(this.exeFromHome(path.join(root, k)), root);
      } catch (_) { /* skip */ }
    }

    const detailed = [];
    for (const item of found) {
      if (!(await fs.pathExists(item.path))) continue;
      const ver = await this.readVersion(item.path);
      detailed.push({ ...item, version: ver, major: this.parseMajor(ver) });
    }
    return detailed;
  }

  async resolve(preferred, needMajor = 21) {
    if (preferred && preferred !== 'auto' && await fs.pathExists(preferred)) return preferred;
    const all = await this.detect();
    const ok = all.find((j) => j.major >= needMajor);
    if (!ok) throw new Error('JAVA_MISSING');
    return ok.path;
  }

  adoptiumUrl(major) {
    const osName = os.platform() === 'win32' ? 'windows' : os.platform() === 'darwin' ? 'mac' : 'linux';
    const arch = os.arch() === 'arm64' ? 'aarch64' : 'x64';
    return `https://api.adoptium.net/v3/binary/latest/${major}/ga/${osName}/${arch}/jdk/hotspot/normal/eclipse?project=jdk`;
  }

  async downloadTemurin(major, onProgress) {
    const destRoot = path.join(CryndelPathVault.javaDir(), `jdk-${major}`);
    await fs.ensureDir(destRoot);
    const existing = await this.walkJava(destRoot);
    if (existing) return existing;

    const url = this.adoptiumUrl(major);
    const ext = os.platform() === 'win32' ? 'zip' : 'tar.gz';
    const archive = path.join(CryndelPathVault.javaDir(), `temurin-${major}.${ext}`);
    if (onProgress) onProgress({ stage: 'java', pct: 5, message: `Скачиваю Java ${major}…` });

    const res = await axios.get(url, {
      responseType: 'stream',
      timeout: 180000,
      maxRedirects: 8,
      headers: { 'User-Agent': 'CryndelLauncher/1.0.0 (contact@cryndel.ru)' }
    });
    const total = Number(res.headers['content-length'] || 0);
    let loaded = 0;
    await new Promise((resolve, reject) => {
      const out = fs.createWriteStream(archive);
      res.data.on('data', (chunk) => {
        loaded += chunk.length;
        if (onProgress && total) {
          onProgress({ stage: 'java', pct: Math.min(80, Math.round((loaded / total) * 80)), message: `Java ${major}: ${Math.round(loaded / 1048576)} MB` });
        }
      });
      res.data.on('error', reject);
      out.on('error', reject);
      out.on('finish', resolve);
      res.data.pipe(out);
    });

    if (onProgress) onProgress({ stage: 'java', pct: 85, message: 'Распаковываю Java…' });
    await fs.ensureDir(destRoot);
    if (ext === 'zip') {
      const zip = new AdmZip(archive);
      zip.extractAllTo(destRoot, true);
    } else {
      await execFileAsync('tar', ['-xzf', archive, '-C', destRoot, '--strip-components=1']).catch(async () => {
        await execFileAsync('tar', ['-xzf', archive, '-C', destRoot]);
      });
    }
    const exe = await this.walkJava(destRoot);
    if (!exe) throw new Error('Java archive extracted but java binary missing');
    if (onProgress) onProgress({ stage: 'java', pct: 100, message: 'Java готова' });
    logger.info('temurin installed', { exe, major });
    return exe;
  }

  async ensure(needMajor = 21, onProgress) {
    try {
      return await this.resolve('auto', needMajor);
    } catch (_) {
      return this.downloadTemurin(needMajor, onProgress);
    }
  }
}

module.exports = EmberFinder;
