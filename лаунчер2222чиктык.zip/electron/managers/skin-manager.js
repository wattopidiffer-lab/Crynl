const fs = require('fs-extra');
const path = require('path');
const axios = require('axios');
const CryndelPathVault = require('../utils/paths');
const { sanitizeName } = require('./download-manager');

const UA = { 'User-Agent': 'CryndelLauncher/1.0.0 (contact@cryndel.ru)' };

class SkinAtelier {
  dir() {
    return path.join(CryndelPathVault.dataDir(), 'skins');
  }

  async ensure() {
    await fs.ensureDir(this.dir());
    return this.dir();
  }

  async list() {
    await this.ensure();
    const names = await fs.readdir(this.dir());
    const out = [];
    for (const name of names) {
      if (!/\.(png|jpg|jpeg)$/i.test(name)) continue;
      const full = path.join(this.dir(), name);
      const st = await fs.stat(full);
      out.push({ name, path: full, size: st.size, mtime: st.mtime.toISOString() });
    }
    out.sort((a, b) => (a.mtime < b.mtime ? 1 : -1));
    return out;
  }

  async saveBuffer(filename, buf) {
    await this.ensure();
    const safe = sanitizeName(filename.endsWith('.png') ? filename : `${filename}.png`);
    const dest = path.join(this.dir(), safe);
    await fs.writeFile(dest, buf);
    return dest;
  }

  async importFile(src) {
    const buf = await fs.readFile(src);
    return this.saveBuffer(path.basename(src), buf);
  }

  async fetchByNick(nick) {
    const name = String(nick || '').trim();
    if (!/^[A-Za-z0-9_]{3,20}$/.test(name)) throw new Error('Ник для скина: 3–20, латиница/цифры/_');
    const url = `https://minotar.net/skin/${encodeURIComponent(name)}`;
    const { data } = await axios.get(url, { responseType: 'arraybuffer', timeout: 20000, headers: UA, maxRedirects: 5 });
    return this.saveBuffer(`${name}.png`, Buffer.from(data));
  }

  async toDataUrl(filePath) {
    const buf = await fs.readFile(filePath);
    return `data:image/png;base64,${buf.toString('base64')}`;
  }

  async applyToInstance(filePath, instance) {
    if (!instance || !instance.gameDir) throw new Error('Нет сборки');
    const destDir = path.join(instance.gameDir, 'cryndel-skins');
    await fs.ensureDir(destDir);
    const dest = path.join(destDir, 'current.png');
    await fs.copy(filePath, dest, { overwrite: true });
    await fs.copy(filePath, path.join(instance.gameDir, 'skin.png'), { overwrite: true });
    return dest;
  }
}

module.exports = SkinAtelier;
