const crypto = require('crypto');
const { v4: uuidv4 } = require('uuid');
const vault = require('../storage/json-db');
const CryndelPathVault = require('../utils/paths');
const { DEFAULT_USERS } = require('../storage/schemas');
const { CryndelFault, FaultCodes } = require('../utils/errors');

function offlineUuidFromNick(nick) {
  const hex = crypto.createHash('md5').update(`OfflinePlayer:${nick}`).digest('hex');
  const bytes = Buffer.from(hex, 'hex');
  bytes[6] = (bytes[6] & 0x0f) | 0x30;
  bytes[8] = (bytes[8] & 0x3f) | 0x80;
  const h = bytes.toString('hex');
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`;
}

function nickOk(nick) {
  return typeof nick === 'string' && /^[A-Za-z0-9_]{3,20}$/.test(nick);
}

class ShadowPassKeeper {
  file() {
    return CryndelPathVault.usersFile();
  }

  async load() {
    return vault.read(this.file(), DEFAULT_USERS);
  }

  async save(doc) {
    return vault.write(this.file(), doc);
  }

  async createOffline(nick, extra = {}) {
    if (!nickOk(nick)) {
      throw new CryndelFault(FaultCodes.VALIDATION, 'Ник: 3–20 символов, латиница, цифры, _');
    }
    const doc = await this.load();
    const existing = doc.users.find((u) => u.nick.toLowerCase() === nick.toLowerCase());
    if (existing) {
      doc.currentUserId = existing.id;
      await this.save(doc);
      return existing;
    }
    const user = {
      id: `u-${uuidv4().replace(/-/g, '').slice(0, 12)}`,
      nick,
      offlineUuid: offlineUuidFromNick(nick),
      createdAt: new Date().toISOString(),
      onboardingCompleted: Boolean(extra.onboardingCompleted),
      surveyAnswer: extra.surveyAnswer || null,
      stats: {
        playtime: 0,
        launches: 0,
        lastPlayedAt: null,
        totalSessions: 0,
        longestSession: 0
      },
      skin: { type: 'default', model: 'classic' },
      cape: { id: extra.capeId || 'cryndel-classic' },
      capes: [
        { id: 'cryndel-classic', name: 'Cryndel Classic', rarity: 'common' }
      ],
      preferences: { selectedInstanceId: extra.selectedInstanceId || null }
    };
    doc.users.push(user);
    doc.currentUserId = user.id;
    await this.save(doc);
    return user;
  }

  async getCurrent() {
    const doc = await this.load();
    if (!doc.currentUserId) return null;
    return doc.users.find((u) => u.id === doc.currentUserId) || null;
  }

  async logout() {
    const doc = await this.load();
    doc.currentUserId = null;
    await this.save(doc);
    return { ok: true };
  }

  async patchCurrent(patch) {
    const doc = await this.load();
    const user = doc.users.find((u) => u.id === doc.currentUserId);
    if (!user) return null;
    if (patch.preferences) {
      user.preferences = { ...(user.preferences || {}), ...patch.preferences };
      const rest = { ...patch };
      delete rest.preferences;
      Object.assign(user, rest);
    } else {
      Object.assign(user, patch);
    }
    await this.save(doc);
    return user;
  }

  async rename(newNick) {
    if (!nickOk(newNick)) {
      throw new CryndelFault(FaultCodes.VALIDATION, 'Ник: 3–20 символов, латиница, цифры, _');
    }
    return this.patchCurrent({
      nick: newNick,
      offlineUuid: offlineUuidFromNick(newNick)
    });
  }

  async bumpLaunch() {
    const user = await this.getCurrent();
    if (!user) return null;
    user.stats = user.stats || {};
    user.stats.launches = (user.stats.launches || 0) + 1;
    user.stats.totalSessions = (user.stats.totalSessions || 0) + 1;
    user.stats.lastPlayedAt = new Date().toISOString();
    return this.patchCurrent({ stats: user.stats });
  }
}

module.exports = ShadowPassKeeper;
