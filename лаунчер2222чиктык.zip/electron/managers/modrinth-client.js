const axios = require('axios');
const logger = require('../utils/logger');
const { CryndelFault, FaultCodes } = require('../utils/errors');

const BASE = 'https://api.modrinth.com/v2';
const UA = 'CryndelLauncher/1.0.0 (contact@cryndel.ru)';

class PulseGate {
  constructor(rps = 5) {
    this.minGap = Math.ceil(1000 / rps);
    this.last = 0;
    this.chain = Promise.resolve();
  }

  schedule(fn) {
    this.chain = this.chain.then(async () => {
      const wait = this.minGap - (Date.now() - this.last);
      if (wait > 0) await new Promise((r) => setTimeout(r, wait));
      this.last = Date.now();
      return fn();
    });
    return this.chain;
  }
}

class ModrinthHarbor {
  constructor() {
    this.base = BASE;
    this.headers = { 'User-Agent': UA };
    this.gate = new PulseGate(5);
    this.http = axios.create({
      baseURL: this.base,
      headers: this.headers,
      timeout: 20000
    });
  }

  async request(method, url, opts) {
    return this.gate.schedule(async () => {
      try {
        const res = await this.http.request({ method, url, ...opts });
        return res.data;
      } catch (err) {
        const status = err.response && err.response.status;
        logger.warn('modrinth request failed', { url, status, message: err.message });
        throw new CryndelFault(
          FaultCodes.MODRINTH,
          status === 429 ? 'Modrinth rate limit' : (err.message || 'Modrinth request failed'),
          { status, url }
        );
      }
    });
  }

  async search({ query = '', type = 'mod', loader, mcVersion, limit = 20, offset = 0, index = 'relevance' } = {}) {
    const facets = [];
    if (type) facets.push([`project_type:${type}`]);
    if (loader) facets.push([`categories:${loader}`]);
    if (mcVersion) facets.push([`versions:${mcVersion}`]);
    const params = {
      query,
      limit,
      offset,
      index
    };
    if (facets.length) params.facets = JSON.stringify(facets);
    return this.request('get', '/search', { params });
  }

  async getProject(idOrSlug) {
    return this.request('get', `/project/${encodeURIComponent(idOrSlug)}`);
  }

  async getProjects(ids) {
    if (!ids || !ids.length) return [];
    return this.request('get', '/projects', { params: { ids: JSON.stringify(ids) } });
  }

  async getProjectVersions(projectId, { loader, mcVersion } = {}) {
    const params = { include_changelog: false };
    if (loader) params.loaders = JSON.stringify([loader]);
    if (mcVersion) params.game_versions = JSON.stringify([mcVersion]);
    return this.request('get', `/project/${encodeURIComponent(projectId)}/version`, { params });
  }

  async getVersion(versionId) {
    return this.request('get', `/version/${encodeURIComponent(versionId)}`);
  }

  async checkUpdateByHash(sha512, { loader, mcVersion } = {}) {
    const body = {
      hashes: [sha512],
      algorithm: 'sha512',
      loaders: loader ? [loader] : [],
      game_versions: mcVersion ? [mcVersion] : []
    };
    try {
      return await this.request('post', `/version_file/${encodeURIComponent(sha512)}/update`, { data: body });
    } catch (err) {
      if (err.details && err.details.status === 404) return null;
      throw err;
    }
  }

  async getLoaders() {
    return this.request('get', '/tag/loader');
  }

  async getGameVersions() {
    return this.request('get', '/tag/game_version');
  }

  async getCategories() {
    return this.request('get', '/tag/category');
  }
}

module.exports = ModrinthHarbor;
