const path = require('path');
const fs = require('fs-extra');
const AdmZip = require('adm-zip');
const vault = require('../storage/json-db');
const { emptyLock } = require('../storage/schemas');
const CryndelPathVault = require('../utils/paths');
const logger = require('../utils/logger');

class LedgerKeeper {
  fileFor(instanceId) {
    return CryndelPathVault.lockfile(instanceId);
  }

  async load(instanceId, extra) {
    const file = this.fileFor(instanceId);
    const data = await vault.read(file, emptyLock(instanceId, extra || {}));
    if (!data.entries) data.entries = [];
    return data;
  }

  async save(lock) {
    lock.updatedAt = new Date().toISOString();
    await vault.write(this.fileFor(lock.instanceId), lock);
    return lock;
  }

  async upsertEntry(instanceId, entry) {
    const lock = await this.load(instanceId);
    const idx = lock.entries.findIndex((e) => e.id === entry.id || e.projectId === entry.projectId);
    const next = {
      enabled: true,
      pinned: false,
      installedAt: new Date().toISOString(),
      dependencies: [],
      source: 'modrinth',
      ...entry
    };
    if (idx >= 0) lock.entries[idx] = { ...lock.entries[idx], ...next };
    else lock.entries.push(next);
    return this.save(lock);
  }

  async removeEntry(instanceId, modId) {
    const lock = await this.load(instanceId);
    lock.entries = lock.entries.filter((e) => e.id !== modId && e.projectId !== modId && e.filename !== modId);
    return this.save(lock);
  }

  async patchEntry(instanceId, modId, patch) {
    const lock = await this.load(instanceId);
    const entry = lock.entries.find((e) => e.id === modId || e.projectId === modId || e.filename === modId);
    if (!entry) return lock;
    Object.assign(entry, patch);
    return this.save(lock);
  }

  async exportToMrpack(instance, lock, outputPath) {
    const index = {
      formatVersion: 1,
      game: 'minecraft',
      versionId: lock.mcVersion,
      name: instance.name,
      summary: instance.description || '',
      files: (lock.entries || []).filter((e) => e.enabled !== false).map((e) => ({
        path: `mods/${e.filename}`,
        hashes: { sha512: e.sha512 || '' },
        downloads: e.downloadUrl ? [e.downloadUrl] : [],
        fileSize: e.size || 0
      })),
      dependencies: {
        minecraft: lock.mcVersion,
        [lock.loader]: lock.loaderVersion || ''
      }
    };
    const zip = new AdmZip();
    zip.addFile('modrinth.index.json', Buffer.from(JSON.stringify(index, null, 2)));
    await fs.ensureDir(path.dirname(outputPath));
    zip.writeZip(outputPath);
    logger.info('exported mrpack', { outputPath });
    return outputPath;
  }

  detectKind(filePath, zip) {
    const name = String(filePath || '').toLowerCase();
    const entries = zip.getEntries().map((e) => e.entryName.replace(/\\/g, '/'));
    if (entries.some((e) => e === 'modrinth.index.json' || e.endsWith('/modrinth.index.json'))) return 'mrpack';
    if (entries.some((e) => e === 'manifest.json' || e.endsWith('/manifest.json'))) return 'curseforge';
    if (entries.some((e) => /(^|\/)mods\/.+\.jar$/i.test(e))) return 'modpack-zip';
    if (entries.some((e) => e === 'pack.mcmeta' || e.endsWith('/pack.mcmeta'))) return 'resourcepack';
    if (name.endsWith('.mrpack')) return 'mrpack';
    return 'archive';
  }

  async parseMrpack(filePath) {
    const zip = new AdmZip(filePath);
    const kind = this.detectKind(filePath, zip);
    const indexEntry = zip.getEntry('modrinth.index.json')
      || zip.getEntries().find((e) => e.entryName.replace(/\\/g, '/').endsWith('modrinth.index.json'));
    if (indexEntry) {
      const index = JSON.parse(indexEntry.getData().toString('utf8'));
      return { index, zip, kind: 'mrpack' };
    }
    if (kind === 'curseforge') {
      const man = zip.getEntry('manifest.json')
        || zip.getEntries().find((e) => e.entryName.replace(/\\/g, '/').endsWith('manifest.json'));
      const raw = JSON.parse(man.getData().toString('utf8'));
      const index = {
        formatVersion: 1,
        game: 'minecraft',
        name: raw.name || path.basename(filePath, path.extname(filePath)),
        summary: raw.author ? `Автор: ${raw.author}` : '',
        versionId: (raw.minecraft && raw.minecraft.version) || '',
        files: [],
        dependencies: {
          minecraft: (raw.minecraft && raw.minecraft.version) || ''
        },
        curseforge: raw,
        needsMeta: !((raw.minecraft && raw.minecraft.version))
      };
      const loaders = ((raw.minecraft && raw.minecraft.modLoaders) || []);
      const primary = loaders.find((l) => l.primary) || loaders[0];
      if (primary && primary.id) {
        const id = String(primary.id).toLowerCase();
        if (id.startsWith('fabric')) index.dependencies.fabric = id.replace(/^fabric-/, '');
        else if (id.startsWith('neoforge')) index.dependencies.neoforge = id.replace(/^neoforge-/, '');
        else if (id.startsWith('quilt')) index.dependencies.quilt = id.replace(/^quilt-/, '');
        else if (id.startsWith('forge')) index.dependencies.forge = id.replace(/^forge-/, '');
      }
      return { index, zip, kind: 'curseforge' };
    }
    if (kind === 'modpack-zip' || kind === 'archive') {
      const guessed = path.basename(filePath, path.extname(filePath));
      const index = {
        formatVersion: 1,
        game: 'minecraft',
        name: guessed,
        summary: 'Импорт ZIP',
        versionId: '',
        files: [],
        dependencies: { minecraft: '', fabric: '' },
        localOnly: true,
        needsMeta: true
      };
      return { index, zip, kind: kind === 'modpack-zip' ? 'modpack-zip' : 'archive' };
    }
    throw new Error('Это не модпак: нет modrinth.index.json и папки mods');
  }

  async extractOverrides(zip, gameDir) {
    await fs.ensureDir(gameDir);
    const entries = zip.getEntries();
    const skip = new Set(['modrinth.index.json', 'manifest.json']);
    for (const e of entries) {
      if (e.isDirectory) continue;
      let name = e.entryName.replace(/\\/g, '/');
      if (skip.has(name) || name.endsWith('/modrinth.index.json')) continue;
      if (name.startsWith('overrides/')) name = name.slice('overrides/'.length);
      if (name.startsWith('client-overrides/')) name = name.slice('client-overrides/'.length);
      if (!name || name.endsWith('/')) continue;
      const dest = path.join(gameDir, name);
      await fs.ensureDir(path.dirname(dest));
      await fs.writeFile(dest, e.getData());
    }
  }
}

module.exports = LedgerKeeper;
