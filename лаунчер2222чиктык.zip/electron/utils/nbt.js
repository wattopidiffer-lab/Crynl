const zlib = require('zlib');

// Minimal NBT writer. Minecraft's servers.dat is a gzipped, unnamed compound
// containing a "servers" list, so a full NBT library would be overkill here.

const TAG = { Byte: 1, Short: 2, Int: 3, String: 8, List: 9, Compound: 10 };

function short(value) {
  const b = Buffer.alloc(2);
  b.writeInt16BE(value | 0, 0);
  return b;
}

function int(value) {
  const b = Buffer.alloc(4);
  b.writeInt32BE(value | 0, 0);
  return b;
}

function str(value) {
  const data = Buffer.from(String(value), 'utf8');
  return Buffer.concat([short(data.length), data]);
}

function byte(value) {
  return Buffer.from([value & 0xff]);
}

// payload: array of Buffers already including each element's type byte + name.
function named(type, name, payload) {
  return Buffer.concat([byte(type), str(name), payload]);
}

// In NBT, list elements carry no type byte and no name — the element type is
// declared once in the list header, so each compound is just its body.
function listOfCompounds(name, compoundBodies) {
  return named(TAG.List, name, Buffer.concat([
    byte(TAG.Compound),
    int(compoundBodies.length),
    ...compoundBodies
  ]));
}

function compoundBody(children) {
  return Buffer.concat([...children, byte(0)]);
}

function rootCompound(children) {
  return Buffer.concat([byte(TAG.Compound), short(0), compoundBody(children)]);
}

// Builds the exact bytes Minecraft writes into <gameDir>/servers.dat.
function buildServersDat(servers) {
  const bodies = (servers || []).map((s) => compoundBody([
    named(TAG.String, 'name', str(s.name || s.ip)),
    named(TAG.String, 'ip', str(s.ip)),
    named(TAG.Byte, 'acceptTextures', byte(s.acceptTextures === false ? 0 : 1)),
    named(TAG.Byte, 'hidden', byte(s.hidden ? 1 : 0))
  ]));
  const doc = rootCompound([listOfCompounds('servers', bodies)]);
  return zlib.gzipSync(doc);
}

// Reads back the servers from a servers.dat buffer. Tolerant: a corrupt or
// foreign file yields [] so callers keep their defaults.
function readServersDat(buf) {
  let raw;
  try {
    raw = zlib.gunzipSync(buf);
  } catch (_) {
    return [];
  }
  let pos = 0;
  const u1 = () => raw[pos++];
  const u2 = () => { const v = raw.readUInt16BE(pos); pos += 2; return v; };
  const i4 = () => { const v = raw.readInt32BE(pos); pos += 4; return v; };
  const s = () => { const n = u2(); const v = raw.subarray(pos, pos + n).toString('utf8'); pos += n; return v; };

  const payload = (type) => {
    switch (type) {
      case TAG.Byte: return u1();
      case TAG.Short: return u2();
      case TAG.Int: return i4();
      case TAG.String: return s();
      case TAG.List: {
        const et = u1();
        const n = i4();
        const out = [];
        for (let i = 0; i < n; i++) out.push(payload(et));
        return out;
      }
      case TAG.Compound: {
        const obj = {};
        let t = u1();
        while (t !== 0) {
          obj[s()] = payload(t);
          t = u1();
        }
        return obj;
      }
      default: throw new Error('unsupported tag ' + type);
    }
  };

  const root = {};
  if (u1() !== TAG.Compound) return [];
  s();
  while (pos < raw.length) {
    const t = u1();
    if (t === 0) break;
    root[s()] = payload(t);
  }
  const list = root.servers;
  if (!Array.isArray(list)) return [];
  return list.map((e) => ({ name: e.name, ip: e.ip, acceptTextures: e.acceptTextures !== 0 }))
    .filter((e) => e.ip);
}

// Convenience: just the server names.
function readServerNames(buf) {
  return readServersDat(buf).map((s) => s.name);
}

module.exports = { buildServersDat, readServersDat, readServerNames, TAG };
