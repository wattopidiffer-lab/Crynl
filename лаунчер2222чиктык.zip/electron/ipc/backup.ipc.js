const { ipcMain } = require('electron');

function bindBackupIpc(hub) {
  ipcMain.handle('backup:create', async (_e, instanceId, label) => {
    const inst = await hub.instances.get(instanceId);
    const meta = await hub.backups.create(inst, label);
    await hub.timeline.append(instanceId, 'backup', `Snapshot ${meta.id}`);
    return meta;
  });
  ipcMain.handle('backup:list', async (_e, instanceId) => hub.backups.list(instanceId));
  ipcMain.handle('backup:restore', async (_e, instanceId, backupId) => {
    const inst = await hub.instances.get(instanceId);
    const r = await hub.backups.restore(inst, backupId);
    await hub.timeline.append(instanceId, 'backup', `Restored ${backupId}`);
    return r;
  });
  ipcMain.handle('backup:delete', async (_e, instanceId, backupId) => hub.backups.delete(instanceId, backupId));
}

module.exports = bindBackupIpc;
