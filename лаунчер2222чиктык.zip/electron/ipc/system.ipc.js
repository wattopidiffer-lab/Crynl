const { ipcMain, shell, dialog, clipboard } = require('electron');
const fs = require('fs-extra');

const ALLOW = [
  'modrinth.com',
  'cdn.modrinth.com',
  'cryndel.ru',
  'my.cryndel.ru',
  'play.cryndel.ru',
  'www.cryndel.ru',
  'github.com',
  'adoptium.net',
  'minecraft.net',
  'mojang.com'
];

function hostAllowed(url) {
  try {
    const u = new URL(url);
    if (u.protocol !== 'https:' && u.protocol !== 'http:') return false;
    return ALLOW.some((d) => u.hostname === d || u.hostname.endsWith(`.${d}`));
  } catch (_) {
    return false;
  }
}

function bindSystemIpc(hub) {
  ipcMain.handle('system:openExternal', async (_e, url) => {
    if (!hostAllowed(url)) return { ok: false, error: 'URL not allowed' };
    await shell.openExternal(url);
    return { ok: true };
  });
  ipcMain.handle('system:selectDirectory', async () => {
    const r = await dialog.showOpenDialog(hub.window, { properties: ['openDirectory'] });
    return r.canceled ? null : r.filePaths[0];
  });
  ipcMain.handle('system:detectJava', async () => hub.java.detect());
  ipcMain.handle('system:copyToClipboard', async (_e, text) => {
    clipboard.writeText(String(text || ''));
    return { ok: true };
  });
  ipcMain.handle('system:getStorageInfo', async () => {
    const instances = await hub.instances.list();
    return hub.health.storageInfo(instances);
  });
  ipcMain.handle('system:clearCache', async (_e, type) => hub.health.clearCache(type));
  ipcMain.handle('health:getStatus', async (_e, instanceId) => {
    const inst = instanceId ? await hub.instances.get(instanceId) : null;
    return hub.health.getStatus(inst);
  });
  ipcMain.handle('health:analyzeCrash', async (_e, instanceId) => {
    const inst = instanceId ? await hub.instances.get(instanceId) : null;
    return hub.health.analyzeCrash(inst);
  });
  ipcMain.handle('health:fixInstance', async (_e, instanceId, action) => {
    const inst = instanceId ? await hub.instances.get(instanceId) : null;
    return hub.health.fixInstance(inst, action);
  });
  ipcMain.handle('health:autoFix', async (_e, instanceId) => {
    const inst = await hub.instances.get(instanceId);
    if (!inst) throw new Error('Сборка не найдена');
    return hub.health.autoFix(inst, hub);
  });
  ipcMain.handle('health:getTimeline', async (_e, instanceId) => hub.health.getTimeline(instanceId));
  ipcMain.handle('system:gpus', async () => {
    const os = require('os');
    const { execFile } = require('child_process');
    const { promisify } = require('util');
    const execFileAsync = promisify(execFile);
    const out = [{ id: 'auto', name: 'Авто' }];
    try {
      if (os.platform() === 'win32') {
        const { stdout } = await execFileAsync('wmic', ['path', 'win32_VideoController', 'get', 'Name'], { windowsHide: true });
        stdout.split(/\r?\n/).map((s) => s.trim()).filter((s) => s && s !== 'Name').forEach((name, i) => {
          out.push({ id: 'gpu-' + i, name });
        });
      } else {
        const { stdout } = await execFileAsync('sh', ['-c', 'lspci 2>/dev/null | grep -i -E "vga|3d|display" || true']);
        stdout.split(/\n/).map((s) => s.trim()).filter(Boolean).forEach((line, i) => {
          out.push({ id: 'gpu-' + i, name: line.replace(/^.*controller:\s*/i, '') });
        });
      }
    } catch (_) { /* */ }
    return out;
  });
  ipcMain.handle('discord:toggle', async (_e, on) => {
    if (on) await hub.discord.connect();
    else await hub.discord.disconnect();
    return { ok: true };
  });
  ipcMain.handle('lockfile:load', async (_e, instanceId) => hub.lockfile.load(instanceId));
  ipcMain.handle('lockfile:export', async (_e, instanceId) => hub.instances.exportMrpack(instanceId, hub.window));
  ipcMain.handle('app:getVersion', async () => {
    const pkg = await fs.readJson(require('path').join(__dirname, '..', '..', 'package.json'));
    return pkg.version;
  });
  ipcMain.handle('window:minimize', async () => hub.window && hub.window.minimize());
  ipcMain.handle('window:maximize', async () => {
    if (!hub.window) return;
    if (hub.window.isMaximized()) hub.window.unmaximize();
    else hub.window.maximize();
  });
  ipcMain.handle('window:close', async () => hub.window && hub.window.close());
}

module.exports = { bindSystemIpc, hostAllowed };
