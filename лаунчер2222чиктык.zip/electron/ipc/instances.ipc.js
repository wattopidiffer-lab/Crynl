const { ipcMain } = require('electron');

function bindInstancesIpc(hub) {
  ipcMain.handle('instances:list', async () => hub.instances.list());
  ipcMain.handle('instances:get', async (_e, id) => hub.instances.get(id));
  ipcMain.handle('instances:create', async (_e, dto) => {
    const inst = await hub.instances.create(dto || {});
    const user = await hub.auth.getCurrent();
    if (user) await hub.auth.patchCurrent({ preferences: { selectedInstanceId: inst.id } });
    return inst;
  });
  ipcMain.handle('instances:createFromBuild', async (_e, buildId, name) => {
    const inst = await hub.instances.createFromBuild(buildId, name);
    await hub.auth.patchCurrent({ preferences: { selectedInstanceId: inst.id } });
    return inst;
  });
  ipcMain.handle('instances:delete', async (_e, id) => hub.instances.delete(id));
  ipcMain.handle('instances:update', async (_e, id, patch) => hub.instances.update(id, patch));
  ipcMain.handle('instances:openFolder', async (_e, id) => hub.instances.openFolder(id));
  ipcMain.handle('instances:exportMrpack', async (_e, id) => hub.instances.exportMrpack(id, hub.window));
  ipcMain.handle('instances:importMrpack', async (_e, meta) => {
    return hub.instances.importMrpack(hub.window, (p) => {
      if (hub.window && !hub.window.isDestroyed()) hub.window.webContents.send('game:progress', p);
    }, meta || {});
  });
  ipcMain.handle('instances:catalog', async () => hub.instances.loadBuilds());
  ipcMain.handle('instances:select', async (_e, id) => {
    await hub.auth.patchCurrent({ preferences: { selectedInstanceId: id } });
    return { ok: true };
  });
  ipcMain.handle('instances:patchSodium', async (_e, id) => {
    const fs = require('fs-extra');
    const path = require('path');
    const inst = await hub.instances.get(id);
    if (!inst) throw new Error('Сборка не найдена');
    const cfgDir = path.join(inst.gameDir, 'config');
    await fs.ensureDir(cfgDir);
    const file = path.join(cfgDir, 'sodium-options.json');
    const cfg = {
      quality: { weather_quality: 'DEFAULT', leaves_quality: 'DEFAULT', enable_vignette: false },
      performance: { chunk_update_threads: 0, always_defer_chunk_updates: true },
      notifications: { hide_donation_button: true }
    };
    await fs.writeJson(file, cfg, { spaces: 2 });
    if (inst.addServer !== false) {
      const servers = path.join(inst.gameDir, 'servers.dat');
      /* servers.dat is NBT; options.txt + extra note is enough for later launch patch */
    }
    return { ok: true };
  });
}

module.exports = bindInstancesIpc;
