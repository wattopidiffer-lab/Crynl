const { ipcMain, shell } = require('electron');

function sendProgress(hub, p) {
  if (hub.window && !hub.window.isDestroyed()) hub.window.webContents.send('game:progress', p);
}

function bindInboxIpc(hub) {
  ipcMain.handle('inbox:list', async () => hub.inbox.list());
  ipcMain.handle('inbox:dir', async () => hub.inbox.ensure());
  ipcMain.handle('inbox:openDir', async () => {
    const dir = await hub.inbox.ensure();
    return shell.openPath(dir);
  });
  ipcMain.handle('inbox:downloadUrl', async (_e, url, filename) => {
    const dest = await hub.inbox.downloadUrl(url, filename, (p) => {
      if (hub.window && !hub.window.isDestroyed()) hub.window.webContents.send('inbox:progress', p);
      sendProgress(hub, { stage: 'download', pct: p.pct || 0, loaded: p.loaded, total: p.total, message: `Скачиваю ${p.filename || filename || ''} ${p.pct || 0}%` });
    });
    return { ok: true, path: dest };
  });
  ipcMain.handle('inbox:importToInstance', async (_e, filePath, instanceId) => {
    const inst = await hub.instances.get(instanceId);
    if (!inst) throw new Error('Сборка не выбрана');
    return hub.inbox.importIntoInstance(filePath, inst, hub.mods);
  });
  ipcMain.handle('inbox:importMrpackPath', async (_e, filePath, meta) => {
    const res = await hub.instances.importPackFile(filePath, (p) => sendProgress(hub, p), meta || {});
    if (res.instance) {
      await hub.auth.patchCurrent({ preferences: { selectedInstanceId: res.instance.id } });
    }
    return res;
  });
  ipcMain.handle('inbox:importAsResourcepack', async (_e, filePath, instanceId) => {
    return hub.instances.importAsResourcepack(filePath, instanceId);
  });
}

module.exports = bindInboxIpc;
