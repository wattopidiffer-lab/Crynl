const { ipcMain } = require('electron');

function bindModrinthIpc(hub) {
  ipcMain.handle('modrinth:search', async (_e, params) => hub.modrinth.search(params || {}));
  ipcMain.handle('modrinth:getProject', async (_e, id) => hub.modrinth.getProject(id));
  ipcMain.handle('modrinth:getVersions', async (_e, projectId, filters) => hub.modrinth.getProjectVersions(projectId, filters || {}));
  ipcMain.handle('modrinth:getVersion', async (_e, versionId) => hub.modrinth.getVersion(versionId));
  ipcMain.handle('modrinth:tags', async () => {
    const [loaders, versions, categories] = await Promise.all([
      hub.modrinth.getLoaders().catch(() => []),
      hub.modrinth.getGameVersions().catch(() => []),
      hub.modrinth.getCategories().catch(() => [])
    ]);
    return { loaders, versions, categories };
  });
  ipcMain.handle('modrinth:install', async (_e, instanceId, projectId) => {
    const inst = await hub.instances.get(instanceId);
    if (!inst) throw new Error('Instance not found');
    const versions = await hub.modrinth.getProjectVersions(projectId, {
      loader: inst.modLoader,
      mcVersion: inst.mcVersion
    });
    if (!versions || !versions.length) throw new Error('Нет совместимой версии для этой сборки');
    const preview = versions[0];
    const result = await hub.resolver.resolveAndInstall(instanceId, preview.id, new Set(), {
      loader: inst.modLoader,
      mcVersion: inst.mcVersion
    });
    await hub.timeline.append(instanceId, 'mod', `Installed ${preview.name || projectId}`);
    return { ok: true, installed: hub.resolver.flatten(result), optional: result.optional || [], incompatible: result.incompatible || [] };
  });
  ipcMain.handle('modrinth:installVersion', async (_e, instanceId, versionId) => {
    const inst = await hub.instances.get(instanceId);
    const result = await hub.resolver.resolveAndInstall(instanceId, versionId, new Set(), {
      loader: inst && inst.modLoader,
      mcVersion: inst && inst.mcVersion
    });
    await hub.timeline.append(instanceId, 'mod', `Installed version ${versionId}`);
    return { ok: true, installed: hub.resolver.flatten(result) };
  });
}

module.exports = bindModrinthIpc;
