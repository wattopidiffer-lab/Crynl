const bindAuthIpc = require('./auth.ipc');
const bindInstancesIpc = require('./instances.ipc');
const bindVersionsIpc = require('./versions.ipc');
const bindModrinthIpc = require('./modrinth.ipc');
const bindModsIpc = require('./mods.ipc');
const bindGameIpc = require('./game.ipc');
const bindSettingsIpc = require('./settings.ipc');
const bindScreenshotsIpc = require('./screenshots.ipc');
const bindLiveNickIpc = require('./live-nick.ipc');
const bindBackupIpc = require('./backup.ipc');
const { bindSystemIpc } = require('./system.ipc');
const bindInboxIpc = require('./inbox.ipc');
const bindOnboardIpc = require('./onboard.ipc');
const bindExtrasIpc = require('./extras.ipc');

function wireAllIpc(hub) {
  bindAuthIpc(hub);
  bindInstancesIpc(hub);
  bindVersionsIpc(hub);
  bindModrinthIpc(hub);
  bindModsIpc(hub);
  bindGameIpc(hub);
  bindSettingsIpc(hub);
  bindScreenshotsIpc(hub);
  bindLiveNickIpc(hub);
  bindBackupIpc(hub);
  bindSystemIpc(hub);
  bindInboxIpc(hub);
  bindOnboardIpc(hub);
  bindExtrasIpc(hub);
}

module.exports = wireAllIpc;
